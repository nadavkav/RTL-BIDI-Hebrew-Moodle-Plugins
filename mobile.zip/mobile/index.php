<?php
	
	/*
	 **************************************************************************
	 * Visit us at http://www.mpage.hk *
	 * The Friendly Open mPage for iPhone/iPod Touch *
	 * Visit us at http://www.mbooks.hk *
	 * The Friendly Open mBooks for iPad *
	 **************************************************************************
	 **************************************************************************
	 * NOTICE OF COPYRIGHT *
	 * *
	 * Copyright (C) 2010 MassMedia.hk *
	 * *
	 * This plugin is free; you can redistribute it and/or modify *
	 * it under the terms of the GNU General Public License as *
	 * published by the Free Software Foundation; either version*
	 * 2 of the License, or (at your option) any later version. *
	 * *
	 * This program is distributed in the hope that it will be useful, *
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of *
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the *
	 * GNU General Public License for more details: *
	 * *
	 * http://www.gnu.org/copyleft/gpl.html *
	 * *
	 * *
	 * *
	 **************************************************************************
	 */
	
	require_once('main.php');
	
?>