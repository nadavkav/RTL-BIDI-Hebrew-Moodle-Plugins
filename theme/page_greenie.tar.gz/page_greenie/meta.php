<!--[if IE 7]>
    <link rel="stylesheet" type="text/css" href="<?php echo $CFG->httpsthemewww ?>/greenie/styles_ie7.css" />
<![endif]-->
<!--[if IE 6]>
    <link rel="stylesheet" type="text/css" href="<?php echo $CFG->httpsthemewww ?>/greenie/styles_ie6.css" />
<![endif]-->
