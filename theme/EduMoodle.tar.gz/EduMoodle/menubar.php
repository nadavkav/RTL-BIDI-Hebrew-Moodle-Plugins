<div><table cellpadding=0 cellspacing=0 style="width:100%;"><tr><td><div style="font-size:1px;width:6px;height:20px;"></div></td><td style="width:100%;">
<ul id="qm0" class="qmmc">

<?php $text ='<li><a href="'.$CFG->wwwroot.'/">Home</a>';
echo $text;
?>
</li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">News</a>></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">Parents</a></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">The Curriculum</a></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">Downloads</a></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">Contact Us</a></li>
		
	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a href="http://moodle.jonahosting.com/moodle/course/view.php?id=4">User Guide</a></li>
		
<li class="qmclear">&nbsp;</li></ul></td></tr></table>


</div>
<!-- Create Menu Settings: (Menu ID, Is Vertical, Show Timer, Hide Timer, On Click ('all', 'main' or 'lev2'), Right to Left, Horizontal Subs, Flush Left, Flush Top) -->
<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>
