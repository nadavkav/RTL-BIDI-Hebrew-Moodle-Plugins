<div><table cellpadding=0 cellspacing=0 style="width:954px;"><tr><td>
<ul id="nav" class="dropdown dropdown-horizontal">
	<?php
 $text ='<li id="n-left"><a href="'.$CFG->wwwroot.'/">Home</a>';
 echo $text;
?>
		<ul>
					<li class="first"><a href="http://vle.newbury-college.ac.uk/mod/forum/view.php?id=1048">Student News</a></li>
					<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1203">Terms of Use</a></li>
					<li><a href="http://vle.newbury-college.ac.uk">Back to Homepage</a></li>
				</ul>
			</li>
	<li id="n-left"><a href="./" class="dir">Courses</a>
		<ul>
			<li class="first"><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=119">Course Finder</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/my">My Courses</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/category.php?id=21">Key Skills</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=9">Tutorial</a></li>
		
			
		</ul>
	</li>
	<li id="n-left"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2" class="dir">Learner Services</a>
		<ul>
			<li class="first"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2">Learner Services Home</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1519">Attendance</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/file.php/1/Shuttle_Bus_Service.pdf">Bus Timetable</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=3334">Refectory Menus</a></li>
			<li><span class="dir">Rooming</span>
				<ul>
					<li class="first"><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/mondaysrooming.xls">Monday</a></li>
					<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/tuesdaysrooming.xls">Tuesday</a></li>
					<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/wednesdaysrooming.xls">Wednesday</a></li>
					<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/thursdaysrooming.xls">Thursday</a></li>
					<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/fridaysrooming.xls">Friday</a></li>
				</ul>
			</li>
			<li><span class="dir">Skill Builder</span>
				<ul>
					<li class="first"><a href="http://sb.newbury-college.ac.uk/bksb_IA">Initial Assessment</a></li>
					<li><a href="http://sb.newbury-college.ac.uk/bksb%20lit%20diagnostic/">Literacy Diagnostic</a></li>
					<li><a href="http://sb.newbury-college.ac.uk/bksb%20num%20diagnostics/">Numeracy Diagnostic</a></li>
				</ul>
			</li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1526">The Zone</a></li>
        	<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2#Future">Virtual Careers Library</a></li>
		</ul>
		</li>
	<li id="n-left"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200" class="dir">Student Council</a>
		<ul>
			<li class="first"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200">Student Council Home</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200#woot">Student Voice</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=2897">Student ID Card</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/forum/index.php?id=200">Woot! Message Boards</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/slideshow/index.php?id=200">Photo Galleries</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/blocks/inwicast/index.php?id=200">Videos</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=4210">Online Games</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=4330">SPECIAL: Comic Relief</a></li>
		</ul>
	</li>
	<li id="n-left"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=3" class="dir">LRC / Resources</a>
	
		<ul>
			<li class="first"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=3">Learning Resource Centre Home</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2#Future">Virtual Careers Library</a></li>
		</ul>
	</li>
	<li id="n-right"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=4" class="dir">IT Services</a>
		<ul>
			<li class="first"><a href="http://vle.newbury-college.ac.uk/course/view.php?id=4">IT Services Home</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=4#wifi">WiFi Wireless Internet</a></li>
			<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=801">Report a Fault</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/questionnaire/view.php?id=1287">Site Unblock Request</a></li>
		</ul>
			</li>
			

<li id="n-right"><span class="dir">Themes</span>
		<ul>
			<li class="first"><a href="javascript:chooseStyle('theme-default', 60)">Default</a></li>
			<li><a href="javascript:chooseStyle('theme-spring', 60)">Spring is in the Eire!</a></li>
			<li><a href="javascript:chooseStyle('theme-cropcircle', 60)">They came from outta town!</a></li>
			<li><a href="javascript:chooseStyle('theme-white', 60)">It's all white!</a></li>
			<li><a href="javascript:chooseStyle('theme-60', 60)">60 Years of College!</a></li>
		<!--</li>-->
</ul>
</td><td> <a href="<?php echo $CFG->wwwroot.'/mod/forum/index.php?id=200' ?>"><img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/pix/mod/forum/icon.gif" alt="Woot! Message Boards" title="Woot! Message Boards" width="16" height="16" align="middle" /></a>
		  <img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/images/menubar_app_separator.gif" alt="" title="" width="2" height="21" hspace="1" align="middle" />
		  <a href="<?php echo $CFG->wwwroot.'/mod/slideshow/index.php?id=200' ?>"><img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/pix/mod/slideshow/icon.gif" alt="Photo Galleries" title="Photo Galleries" width="16" height="16" align="middle" /></a>
		  <img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/images/menubar_app_separator.gif" alt="" title="" width="2" height="21" hspace="1" align="middle" />
		  <a href="<?php echo $CFG->wwwroot.'/blocks/inwicast/index.php?id=200' ?>"><img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/pix/mod/flashvideo/icon.gif" alt="Videos" title="Videos" width="16" height="16" align="middle" /></a>
		  <img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/images/menubar_app_separator.gif" alt="" title="" width="2" height="21" hspace="1" align="middle" />
		  <a href="<?php echo $CFG->wwwroot.'/mod/resource/view.php?id=4210' ?>"><img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/pix/sport_8ball.gif" alt="Games" title="Games" width="16" height="16" align="middle" /></a>
		  <img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/images/menubar_app_separator.gif" alt="" title="" width="2" height="21" hspace="1" align="middle" />
		  <a href="http://email.newbury-college.ac.uk"><img src="<?php echo $CFG->wwwroot.'/theme/'.current_theme() ?>/pix/icon_outlook.gif" alt="Web Outlook" title="Web Outlook" width="16" height="16" align="middle" /></a>
		 </td></tr></table></div></div>