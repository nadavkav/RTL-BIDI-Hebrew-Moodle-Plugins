This is a course menu modification to allow users to select their courses via a fluid "accordion-style" menu. The script assumes that you have a set of categories for the headers and subcategories for the "accordion" list. Courses within these subcategories will be linked under this list.  Any additional subcategories will also be displayed within this list.


Requirements
------------

This has been tested with Moodle 1.9 but should work with most other versions.  There are no guarantees so please make sure you backup first, but I anticipate you won't run into any problems.  


Installation Instructions
-------------------------

1) Extract all files from this zip file

2) Copy the "accordion_course_menu" folder and its contents to your theme's folder

3) Edit your root index.php file and look for the following lines:

        $frontpagelayout = $CFG->frontpage;
    }

    foreach (explode(',',$frontpagelayout) as $v) {
        switch ($v) {     /// Display the main part of the front page.


   Insert the following code snippet between the "}" and "foreach" lines:

   //Display Accordion Course Menu
   include('./theme/'. current_theme() .'/accordion_course_menu/accordion_course_menu.php');

4) Edit your theme's header.html file and insert the following code within the <head> tags:

    	<script src="<?php echo $CFG->themewww .'/'. current_theme() ?>/accordion_course_menu/jquery-1.2.6.min.js"></script>
	<script>
	$(document).ready(function(){
		$("dd").hide();
		$("dt a").click(function(){	
		if ($(this).parent().next().is(':visible')) {
		$(this).parent().next().slideUp("slow");
		}
		else {
			$("dd:visible").slideUp("slow");
			$(this).parent().next().slideDown("slow");
		}
			return false;
		});
	});
	</script>

5) That's it!

Adjust the styles within the accordion_course_menu/accordion_course_menu.php file to suit your theme.


Comments/Suggestions/Feedback
----------------------------

Mark Schumann
mschumann@gmail.com






