<!--[if IE 7]>
    <link rel="stylesheet" type="text/css" href="<?php echo $CFG->httpsthemewww ?>/flex_bowl/styles_ie7.css" />
<![endif]-->
<!--[if IE 6]>
    <link rel="stylesheet" type="text/css" href="<?php echo $CFG->httpsthemewww ?>/flex_bowl/styles_ie6.css" />
<![endif]-->