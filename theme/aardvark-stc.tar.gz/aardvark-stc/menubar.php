<div><table cellpadding=0 cellspacing=0 style="width:954px;"><tr><td><div style="font-size:1px;width:6px;height:29px;"></div></td><td style="width:100%;">
<ul id="qm0" class="qmmc">

	<?php
 $text ='<li><a href="'.$CFG->wwwroot.'/">HOME</a>';
 echo $text;
?>


		<ul>
		<li><a href="http://vle.newbury-college.ac.uk/mod/forum/view.php?id=1048">Student News</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1203">Terms of Use</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://vle.newbury-college.ac.uk">Back to Homepage</a></li>
		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://vle.newbury-college.ac.uk/my">COURSES</a>

		<ul>
		<li><a href="http://vle.newbury-college.ac.uk/my">My Courses</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/category.php?id=21">Key Skills</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=9">Tutorial</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=119">Course Finder</a></li>
		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://vle.newbury-college.ac.uk/course/view.php?id=2">LEARNER SERVICES</a>

		<ul>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2">Learner Services Home</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1519">Attendance</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1526">Health Zone</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200#woot">Student Voice</a></li>
<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200">Student Council</a></li>
<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2#Future">Virtual Careers Library</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1417">Bus Timetable (Main Service)</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=1403">Bus Timetable (Greenham)</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/mondaysrooming.xls">Monday Rooming</a></li>
		<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/tuesdaysrooming.xls">Tuesday Rooming</a></li>
		<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/wednesdaysrooming.xls">Wednesday Rooming</a></li>
		<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/thursdaysrooming.xls">Thursday Rooming</a></li>
		<li><a href="http://www.newbury-college.ac.uk/intranet/staff/rooming/fridaysrooming.xls">Friday Rooming</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a class="qmparent" href="javascript:void(0);">Skill Builder</a>

			<ul>
			<li><a href="http://netg.newbury-college.ac.uk/bksb_IA_Web/IA.asp">Initial Assessment</a></li>
			<li><a href="http://netg.newbury-college.ac.uk/bksblitdiag">Literacy Diagnostic</a></li>
			<li><a href="http://netg.newbury-college.ac.uk/bksbnumdiag">Numeracy Diagnostic</a></li>
			</ul></li>

		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://vle.newbury-college.ac.uk/course/view.php?id=200">STUDENT COUNCIL</a>

		<ul>
<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200">Student Council Home</a></li><li><span class="qmdivider qmdividerx" ></span></li>
<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=200#woot">Student Voice</a></li>
<li><a href="http://vle.newbury-college.ac.uk/mod/forum/index.php?id=200">Woot! Message Boards</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/slideshow/index.php?id=200">Photo Galleries</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/flashvideo/index.php?id=200">Videos</a></li>
		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://vle.newbury-college.ac.uk/course/view.php?id=3">LRC / ONLINE RESOURCES</a>

		<ul>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=3">Learning Resource Centre</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=2#Future">Virtual Careers Library</a></li>
		</ul></li>

	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent" href="http://vle.newbury-college.ac.uk/course/view.php?id=4">IT SERVICES</a>

		<ul>
		<li><a href="http://vle.newbury-college.ac.uk/course/view.php?id=4">IT Services Home</a></li>
		<li><span class="qmdivider qmdividerx" ></span></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/resource/view.php?id=801">Report a Fault</a></li>
		<li><a href="http://vle.newbury-college.ac.uk/mod/questionnaire/view.php?id=1287">Site Unblock Request</a></li>
		</ul></li>
		
	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a href="http://email.newbury-college.ac.uk/">WEB OUTLOOK</a></li>
	
	<li><span class="qmdivider qmdividery" ></span></li>
	<li><a class="qmparent"
href="http://vle.newbury-college.ac.uk">THEME</a>
	<ul>
	
<?php
 $text ='<li><a href="'.$CFG->wwwroot.'/?&theme=college_red">Default</a></li>';
 $text .='<li><a href="'.$CFG->wwwroot.'/?&theme=emo_pink3">Emo Pink</a></li>';
 $text .='<li><a href="'.$CFG->wwwroot.'/?&theme=camo3">Camouflage</a></li>';  
 echo $text;
?>
	</ul></li>
	
	
<li class="qmclear">&nbsp;</li></ul></td></tr></table>


</div>
<!-- Create Menu Settings: (Menu ID, Is Vertical, Show Timer, Hide Timer, On Click ('all', 'main' or 'lev2'), Right to Left, Horizontal Subs, Flush Left, Flush Top) -->
<script type="text/javascript">qm_create(0,false,0,500,false,false,false,false,false);</script>
</DIV></div>