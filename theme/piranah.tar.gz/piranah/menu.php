<ul>
<li><a href="/moodle/" title="Home" class="current"><span>Home</span></a></li>
<li><a href="" title="AboutUs" <span>AboutUs</span></a></li>
<li><a href="" title="Services"><span>Services</span></a></li>
<li><a href="" title="Our Work"><span>Our Work</span></a></li>
<li><a href="" title="Contact Us"><span>Contact Us</span></a></li>
</ul>