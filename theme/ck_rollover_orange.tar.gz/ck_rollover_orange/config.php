<?PHP // $Id: config.php,v 1.6 2006/09/28 10:32:26 jamiesensei Exp $

// == CK080321
$THEME->sheets = array('styles_color','a','blocks_rollover_buttons','block_menu');

$THEME->standardsheets = array('styles_layout','styles_fonts','styles_color');  
/// This variable can be set to an array containing
/// filenames from the *STANDARD* theme.
$THEME->modsheets = true;  
/// When this is enabled, then this theme will search for 
/// files named "styles.php" inside all Activity modules and 
/// include them. 
$THEME->blocksheets = true;  
/// When this is enabled, then this theme will search for 
/// files named "styles.php" inside all Block modules and 
/// include them.
$THEME->langsheets = false;  
/// By setting this to true, then this theme will search for 
/// a file named "styles.php" inside the current language
/// directory.
$THEME->navmenuwidth = 50;
/// You can use this to control the cutoff point for strings 
/// in the navmenus (list of activities in popup menu etc)
/// Default is 50 characters wide.
$THEME->makenavmenulist = false;  
/// By setting this to true, then you will have access to a
/// new variable in your header.html and footer.html called
/// $navmenulist.

$THEME->resource_mp3player_colors = 
 'bgColour=000000&btnColour=ffffff&btnBorderColour=cccccc&iconColour=000000&'.
 'iconOverColour=00cc00&trackColour=cccccc&handleColour=ffffff&loaderColour=ffffff&'.
 'font=Arial&fontColour=3333FF&buffer=10&waitForPlay=no&autoPlay=yes';
/// With this you can control the colours of the "big" MP3 player 
/// that is used for MP3 resources.

$THEME->filter_mediaplugin_colors = 
 'bgColour=000000&btnColour=ffffff&btnBorderColour=cccccc&iconColour=000000&'.
 'iconOverColour=00cc00&trackColour=cccccc&handleColour=ffffff&loaderColour=ffffff&'.
 'waitForPlay=yes';

/// ...And this controls the small embedded player


$THEME->custompix = false;

?>
