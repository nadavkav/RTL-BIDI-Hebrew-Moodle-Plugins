<?php
/**
 * @package    filter
 * @subpackage timelinewidget
 * @copyright  (c) 2010 Nicholas Freear
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v2 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version = 2011052200;
