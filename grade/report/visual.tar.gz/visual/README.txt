 __  __                                   ___
/\ \/\ \   __                            /\_ \
\ \ \ \ \ /\_\     ____   __  __     __  \//\ \
 \ \ \ \ \\/\ \   /',__\ /\ \/\ \  /'__`\  \ \ \
  \ \ \_/ \\ \ \ /\__, `\\ \ \_\ \/\ \L\.\_ \_\ \_
   \ `\___/ \ \_\\/\____/ \ \____/\ \__/.\_\/\____\
    `\/__/   \/_/ \/___/   \/___/  \/__/\/_/\/____/
 ____                                      __
/\  _`\                                   /\ \__
\ \ \L\ \      __   _____     ___    _ __ \ \ ,_\
 \ \ ,  /    /'__`\/\ '__`\  / __`\ /\`'__\\ \ \/
  \ \ \\ \  /\  __/\ \ \L\ \/\ \L\ \\ \ \/  \ \ \_
   \ \_\ \_\\ \____\\ \ ,__/\ \____/ \ \_\   \ \__\
    \/_/\/ / \/____/ \ \ \/  \/___/   \/_/    \/__/
                      \ \_\
                       \/_/       ,+7$$Z$ZO= 
                    :+$$Z$$ZOZZZOOOOOOOOD,:,,,
                 +Z$ZOOO8OO8OOOOOOOOO8+====~~:,
               7$ZOOOOZOZOOOOOOOOOO8+++++=~:,
            77$88OZ8MMDZZZOOOOOOOZ+?++==~:,
         77Z$$Z8MM8OZOZZZZOOOO8ONDN+=~:,
       I7$Z$NMOOOOOO$$$ZZOOOOOD8D8D8:,
    II7$7MDZOOZZZZOZ$$ZZ$OOZNDNDDDD8DO         ,IIII777I~ 
 7?$$ZOMOOZZZ777MMMMMMMMMMMDNDN8DDDD$$7,   =+++++???IIII7777$? 
   ,,,:Z==++===7NMMMND8DDDMMD8DDDDD777777:?=~~~~==+++???II777$$$, 
    ,:DM~~~~::,O8ND8OO8Z$$$$DDDDDD7IIIIII+~~~=?I77$$$$77IIII77$$Z+, 
      ,8,,,,   ONND$ZZ$$777DDDDNDO$77II??+++I7$ZZOOOOZZ$77IIII7$ZZZ:,
       M,::,   O$D888ZO$II77DDD88OZ$7IIIIIII7$ZOO8OOOOOZ$77III77$ZO=:
      =M,,,    ?+~~+I$$$ZI778D$I?+=$77IIIII7$ZOO++===~~~$$7IIII7$ZOO~: 
      OM,,,    I?==?I7$O8D777?+=:,,:77I?III7ZOO++=~:,,,,:77I?II7$ZOO=~,
      8MI::,   I?=+II7$O8??+=~:,    77I?II7$ZOO+=~,      ?7I??II$ZOO+~: 
      ~M=~~,   I?++II7ZOO+=~,       II?+?I7$ZOO=~,       ,II+?II7ZOO+~: 
       M::~:   I?++II7ZOO+=:,       II++?I7$ZOO=~,        II++II7ZOO+~: 
       M,:~:   I?++II7ZOO+=:        II++?II$ZOO=~,        I?++II7ZOO+=: 
       M=::,   I?++II7ZOO+=:        II++?II$ZOO=~,        I?++II7ZOO+=:
       MI:::   I?++?I7ZOO+=:        II++?II$ZOO=~,        I?=+II7ZOO+=: 
      ,M?:~:   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+=:
      =M=:~:   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+=:
       M,:~:   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+~: 
       M,:~:   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+~: 
       M,::,   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+~: 
         ,:,   I?++?I7$OO+=:        II+=?II$ZOO=~,        I?=+II7ZOO+~: 
          ,    IIII77$ZOO+=:        IIIII77$OOO=~,        IIII77$ZOO+~:
               77$$ZZZOOO+=:        77$$ZZZOOOO=~,        77$ZZZOOOO+~:
               $ZOOOOOOOO+=:        $$ZOOOOOOOO=~,        $ZOOOOOOOO+=:


=== About Visual Report ===
The visual report gradebook plug-in was developed as part of a Google
Summer of Code 2008 project The goal of the plug-in is to provide a
framework for providing flash based visualizations for gradebook data
using flex and the flare action script libraries. Several visualizations
such as Average Grades vs Items, Normalized Grades vs Students, and
several different types of Grade Distributions are included and new
visualizations can be easily dropped in by developers.


=== About Author ===
This plug-in was originally created by a computer science student named Daniel Servos as part of
a Google Summer of Code 2008 project.

==== Contact Information ====
Name: Daniel Servos
E-mail: dservos@lakeheadu.ca
Blog: HackerDan.com


=== Copyright ===
Moodle - Modular Object-Oriented Dynamic Learning Environment
http://moodle.org

Copyright (C) 1999 onwards  Martin Dougiamas  http://moodle.com

This program is free software; you can redistribute it and/or modify it under the terms of the GNU
General Public License as published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details:

http://www.gnu.org/copyleft/gpl.html


=== Version / Release ===
This plug-in was developed for Moodle 2.0 dev.

This is the first real release of this plug-in and should be considered an beta version in that it
has not yet had a chance to be extensively tested by users in real life situations and may have
unknown bugs or issues.

Version: 1.0.0b


=== Development Information ===
==== Front End ====
The flash front end for this visualization was made in adobe flex builder 3 for linux and uses an
alpha version of the flare actionscript libbary. The source code for the fron end can be found in
the ./flare_visualization/ dir with the flare libs that where used. Flare is open source and can
be found at http://flare.prefuse.org/. The newest version of flare changed several things so the
included copy of the flare lib is needed to complie the front end and the fron end code still 
needs to be ported to the newest flare realse. 

==== Adding new Visualizations ====
To add a new visualization to the plug-in, extend the abstract class visualization (grade/report/stats/visualizations/visualization.php) and place you class in a file name
visual_yournamehere.php in grade/report/stats/visualizations and it should be automatically loaded
in to plug-in.

==== Specification ====
http://docs.moodle.org/en/Student_projects/Animated_grade_statistics_report

==== TO DO ====
* Add more visualizations.
* Back port to Moodle 1.9.x
* Export functionality to other programs and document types like excel.
* Port to flare 2008.07.29 (new major flare release that had some big changes to the API witch
would require some recoding of the plug-in?s front end).
* Account for outcomes.
* "Find me in data" - a feature i wanted to add to show a user where they are in the data being
visualized.
* Better looking graphically and more natural UI.
* Add visualizations that go beyond just grades in a course. Compare different courses, years,
drop out trends, age of students, submission times, etc.
