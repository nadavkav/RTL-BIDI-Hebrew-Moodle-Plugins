<?php
/* 
 * updates laegrader report to current syntax )lower-case_
 * in case its previously been installed using old syntax (LAE)
 */


function xmldb_gradereport_laegrader_upgrade($oldversion=0) {
    return true;
}
?>
