<?PHP // $Id$ 

$string['modulename'] = 'LAE Grader Report';
$string['laegrader:view'] = 'View the lae grader report';
$string['preferences'] = 'laegrader report preferences';
$string['gradeeditalways'] = 'Editing ALWAYS on for laegrader';
$string['configgradeeditalways'] = 'Configure Always-on Editing for laegrader';
$string['laegraderreportheight'] = 'Height (in pixels) of scrollable portion of LAE grader report';
$string['accuratetotals'] = 'Accurate POINT TOTALS';
$string['configaccuratetotals'] = 'Categories and course POINT TOTALS computed accurately';
$string['zerofill'] = 'Fill empty grades in this column with zeroes (changes not automatically saved)';
?>
