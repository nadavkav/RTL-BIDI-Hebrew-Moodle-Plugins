<?PHP // $Id$ 

$string['modulename'] = 'דוח ציונים - תצוגה נגללת';
$string['laegrader:view'] = 'צפייה ב: דוח ציונים - תצוגה נגללת';
$string['preferences'] = 'הגדרות - דוח ציונים - תצוגה נגללת';
$string['gradeeditalways'] = 'מצב עריכת ציונים קבוע';
$string['configgradeeditalways'] = 'הגדרות מצב עריכת ציונים קבוע';
$string['laegraderreportheight'] = 'גובה (בפיקסלים) של סרגל שמות פעילויות';
$string['accuratetotals'] = 'רמת דיוק של סיכום כולל';
$string['configaccuratetotals'] = 'רמת הדיוק של חישוב סיווגים וסיכום ציונים כולל של הקורס';
$string['zerofill'] = 'הזנת אפסים לערכים חסרים בעמודה זו (לא נשמר באופן אוטומטי)';
?>
