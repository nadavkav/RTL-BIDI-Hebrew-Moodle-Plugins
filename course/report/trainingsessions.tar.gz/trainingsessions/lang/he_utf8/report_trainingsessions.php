<?php // $Id: report_trainingsessions.php,v 1.1.2.1 2010/08/20 10:55:21 diml Exp $

$string['advancement'] = 'Progression';
$string['ashtml'] = 'תצורת HTML';
$string['asxls'] = 'Get Excel export';
$string['allgroups'] = 'כל הקבוצות';
$string['connections'] = 'Connections';
$string['course'] = 'דוח משתמשים כולל';
$string['coursename'] = 'שם קבוצה';
$string['chooseagroup'] = 'בחרו קבוצה';
$string['chooseaninstitution'] = 'בחרו מוסד';
$string['done'] = 'מעקב התקדמות: ';
$string['elapsed'] = 'Total time';
$string['enddate'] = 'End date';
$string['equlearningtime'] = 'זמן פעילות מצטבר: ';
$string['executing'] = 'Training';
$string['evaluating'] = 'משימה';
$string['firstname'] = 'שם פרטי';
$string['generateXLS'] = 'יצוא לגליון אלקטרוני';
$string['generatereports'] = 'יצירת דוחות';
$string['hits'] = 'צפיות';
$string['institution'] = 'מוסד';
$string['institutions'] = 'מוסדות';
$string['item'] = 'פריט';
$string['lastname'] = 'שם משפחה';
$string['trainingreports'] = 'Trainign reports';
$string['trainingsessions'] = 'Training sessions';
$string['trainingsessions_report_advancement'] = 'Progress report';
$string['trainingsessions_report_connections'] = 'Connections report';
$string['trainingsessions_report_institutions'] = 'Institution report';
$string['trainingsessionsreport'] = 'Training session reports';
$string['over'] = 'over';
$string['parts'] = 'Parts';
$string['nostructure'] = 'No measurable structure found';
$string['role'] = 'תפקיד';
$string['reports'] = 'דוחות';
$string['sectionname'] = 'שם יחידת ההוראה';
$string['selectforreport'] = 'הצגה בדוח';
$string['startdate'] = 'תאריך תחילה';
$string['seedetails'] = 'מידע נוסף';
$string['timeperpart'] = 'זמן כולל עבור יחידת הוראה';
$string['totalduration'] = 'Total sequence time';
$string['updatefromcoursestart'] = 'מתחילת הקורס';
$string['user'] = 'דוח משתמש';
$string['visited'] = 'צפיות';
$string['headsection'] = 'מבוא';

?>
