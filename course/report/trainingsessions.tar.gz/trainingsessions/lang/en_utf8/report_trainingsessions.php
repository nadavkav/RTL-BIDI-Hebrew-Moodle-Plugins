<?php // $Id: report_trainingsessions.php,v 1.1.2.1 2010/08/20 10:55:21 diml Exp $

$string['advancement'] = 'Progression';
$string['ashtml'] = 'HTML Format';
$string['asxls'] = 'Get Excel export';
$string['allgroups'] = 'All groups';
$string['connections'] = 'Connections';
$string['course'] = 'Training';
$string['coursename'] = 'Group name';
$string['chooseagroup'] = 'Choose a group';
$string['chooseaninstitution'] = 'Choose an intitution';
$string['done'] = 'Done: ';
$string['elapsed'] = 'Total time';
$string['enddate'] = 'End date';
$string['equlearningtime'] = 'Training equivalent time: ';
$string['executing'] = 'Training';
$string['evaluating'] = 'Assessment';
$string['firstname'] = 'Firstname';
$string['generateXLS'] = 'Generate XLS';
$string['generatereports'] = 'Generate reports';
$string['hits'] = 'Hits';
$string['institution'] = 'Institution';
$string['institutions'] = 'institutions';
$string['item'] = 'Item';
$string['lastname'] = 'Lastname';
$string['trainingreports'] = 'Trainign reports';
$string['trainingsessions'] = 'Training sessions';
$string['trainingsessions_report_advancement'] = 'Progress report';
$string['trainingsessions_report_connections'] = 'Connections report';
$string['trainingsessions_report_institutions'] = 'Institution report';
$string['trainingsessionsreport'] = 'Training session reports';
$string['over'] = 'over';
$string['parts'] = 'Parts';
$string['nostructure'] = 'No measurable structure found';
$string['role'] = 'Role';
$string['reports'] = 'Reports';
$string['sectionname'] = 'Section/Sequence name';
$string['selectforreport'] = 'Inclure in reports';
$string['startdate'] = 'Start date';
$string['seedetails'] = 'See details';
$string['timeperpart'] = 'Time elapsed per part';
$string['totalduration'] = 'Total sequence time';
$string['updatefromcoursestart'] = 'From course start';
$string['user'] = 'Per participant';
$string['visited'] = 'Visited';
$string['headsection'] = 'Heading section';

?>
