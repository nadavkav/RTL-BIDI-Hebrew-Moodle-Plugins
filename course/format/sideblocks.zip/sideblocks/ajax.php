<?php
/**
 * This file is required if the course format is to support AJAX.
 */


$CFG->ajaxcapable = true;
$CFG->ajaxtestedbrowsers = array('MSIE' => 6.0, 'Gecko' => 20061111);

?>
