<?php
/**
 * Created by Nadav Kavalerchik.
 * User: nadavkav
 * Date: 5/28/11
 * Time: 10:40 PM
 * sideblocks course format
 */

$string['formatsideblocks'] = 'נושאים - עמודות משבצות בצד שמאל';
$string['namesideblocks'] = 'יחידת הוראה';

?>