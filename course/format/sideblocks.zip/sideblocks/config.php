<?php
//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the 
// format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = 'activity_modules,admin_begin_teacher,'.
								'communication_and_sharing,messages,table_of_contents,'.
								'course_list:news_items,calendar_upcoming,';
//
?>