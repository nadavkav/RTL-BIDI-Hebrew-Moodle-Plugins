<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 1/22/12
 * Description:
 *    Change me...
 */

$string['formatsummaryblk'] = 'Single Topic + Topics Overview Menu';
$string['namesummaryblk'] = 'Topic';
$string['navmenu'] = 'Topics Menu';