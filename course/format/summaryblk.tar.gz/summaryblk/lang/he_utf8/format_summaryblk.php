<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 1/22/12
 * Description:
 *    Change me...
 */

$string['formatsummaryblk'] = 'תצוגת יחידת הוראה בודדת + תפריט מבואות צדדי';
$string['namesummaryblk'] = 'יחידת הוראה';
$string['navmenu'] = 'תפריט יחידות הוראה';
$string['overview'] = 'מבוא';
$string['prev'] = 'הקודמת';
$string['next'] = 'הבאה';
$string['nexttopic'] = 'היחידה הבאה...';