<?php
/**
 * Collapsed Topics Information
 *
 * @package    course/format
 * @subpackage topcollhid
 * @copyright  2009-2011 @ G J Barnard in respect to modifications of standard topics format.
 * @link       http://docs.moodle.org/en/Collapsed_Topics_course_format
 * @license    http://creativecommons.org/licenses/by-sa/3.0/ Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
 */

//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the
// format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = 'participants,activity_modules,search_forums,'.
                               'admin,course_list:news_items,calendar_upcoming,'.
                               'recent_activity';
//
?>