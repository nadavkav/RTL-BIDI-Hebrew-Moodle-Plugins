<?php
/**
 * Created by Nadav Kavalerchik.
 * User: nadavkav
 * Date: 5/28/11
 * Time: 10:40 PM
 * Hiddenmod course format
 */

$string['formatsideblocks'] = 'Topics - Blocks on left side';
$string['namesideblocks'] = 'Topic';

?>