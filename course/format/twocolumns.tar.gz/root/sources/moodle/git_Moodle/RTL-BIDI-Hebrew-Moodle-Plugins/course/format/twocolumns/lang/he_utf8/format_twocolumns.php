<?php 

$string['formattwocolumns'] = 'יחידות הוראה - שתי עמודות';
$string['nametwocolumns'] = 'יחידת הוראה ';

?>