<?php 

$string['formattwocolumns'] = 'יחידות הוראה - בשתי עמודות';
$string['nametwocolumns'] = 'יחידת הוראה ';

?>