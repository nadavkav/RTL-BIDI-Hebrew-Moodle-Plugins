<?php 

$string['formattwocolumns'] = 'Topics - Two Columns';

?>