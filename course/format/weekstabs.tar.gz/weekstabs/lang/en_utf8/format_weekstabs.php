<?PHP // $Id: format_weekstabs.php,v 1.1 2008/11/08 22:26:26 arborrow Exp $ 
      // months.php - created with Moodle 1.9 
      
$string['formatweekstabs'] = 'Weekly tab format';
$string['monthhide'] = 'Hide months';
$string['monthlyoutline'] = 'Monthly outline';
$string['monthshow'] = 'Show months';
$string['showallmonths'] = 'Show all months';
$string['showonlymonth'] = 'Show only month';

?>
