<?php
$string['formattopicstree']='תצורת מבנה עץ-נושאים'; // Name to display for format
$string['topicstree']='יחידות הוראה'; // Name of a section within your format
$string['nametopicstree'] = 'יחידות הוראה ';
?>

