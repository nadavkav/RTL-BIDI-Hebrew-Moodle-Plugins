<?php
$string['formattopicstree']='פעילויות מוזחות מוצגות במבנה עץ-נושאים'; // Name to display for format
$string['topicstree']='יחידות הוראה'; // Name of a section within your format
$string['nametopicstree'] = 'יחידות הוראה ';
?>

