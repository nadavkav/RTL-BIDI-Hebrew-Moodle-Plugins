<?php
$string['formattopicstree']='Formato de temas en arbol'; // Name to display for format
$string['topicstree']='sección'; // Name of a section within your format
?>

