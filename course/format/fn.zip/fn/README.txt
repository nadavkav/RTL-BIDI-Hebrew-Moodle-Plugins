
Course Format: FN Tabs



############################################################################################################

How it works:

Documentation for this block is located at www.moodlefn.knet.ca



############################################################################################################

Installation:

The FN Tabs course format was created for Moodle 1.9.x

This block follows standard Moodle install instructions 

-copy the folder in the into your /course/format/ folder
-copy the files in lang folder into your moodle lang folder.
-visit the Admin page in Moodle to activate it



#############################################################################################################

Notes:

This course format is part of the MoodleFN plug-in series (www.moodlefn.knet.ca)

Sponsor: K-Net (www.knet.ca)
Designer: Fernando Oliveira (fernandooliveira@knet.ca)
Coder: Mike Churchward (www.oktech.ca)