<?php
// This file defines the current version of the
// First Nations (FN) format/theme/block add-on.
// This can be compared against the values stored in the 
// database (firstnations_version) to determine whether upgrades should
// be performed (see db/*.php)

  $plugin->version  = 2007060102; // Plugin version (update when tables change)
  $plugin->requires = 2007021510; // Required Moodle version

?>