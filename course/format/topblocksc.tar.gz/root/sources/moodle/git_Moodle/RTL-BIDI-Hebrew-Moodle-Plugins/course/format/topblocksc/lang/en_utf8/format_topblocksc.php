<?php
$string['nametopblocksc'] = 'Unit name';
$string['formattopblocksc'] = '3 Blocks above a fixed-width centered page';
?>