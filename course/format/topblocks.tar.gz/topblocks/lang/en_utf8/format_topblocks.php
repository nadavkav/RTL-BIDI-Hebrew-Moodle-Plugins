<?php
$string['nametopblocks'] = 'Unit name';
$string['formattopblocks'] = '4 Blocks above a scratched page layout';
?>