<?php
$string['nametopblocks'] = 'יחידות הוראה';
$string['formattopblocks'] = 'משבצות ניהול בראש המרחב';
?>