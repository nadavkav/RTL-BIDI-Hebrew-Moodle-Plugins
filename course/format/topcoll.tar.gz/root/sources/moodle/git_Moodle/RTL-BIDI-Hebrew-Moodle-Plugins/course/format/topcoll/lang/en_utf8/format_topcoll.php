<?php

$string['nametopcoll']='Collapsed Topics';
$string['formattopcoll']='Collapsed Topics';
$string['toggle']='(click to show OR hide)';

?>
