<?php

$string['nametopcoll']='יחידות הוראה נחבות';
$string['formattopcoll']='תצורת יחידות הוראה נחבות';
$string['toggle']='(הקליקו כאן להצגה או הסתרה)';


?>
