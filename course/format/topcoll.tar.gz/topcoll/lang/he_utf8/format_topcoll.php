<?php

$string['nametopcoll']='יחידות הוראה נחבות';
$string['formattopcoll']='יחידות הוראה נסתרות/נגלות';
$string['toggle']='(הקליקו כאן להצגה או הסתרה)';


?>
