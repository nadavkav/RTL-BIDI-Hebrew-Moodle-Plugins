<?php

$string['formattopsidesum'] = 'יחידות הוראה בעלות מבוא צדדי';
$string['nametopsidesum'] = 'יחידת הוראה';

?>