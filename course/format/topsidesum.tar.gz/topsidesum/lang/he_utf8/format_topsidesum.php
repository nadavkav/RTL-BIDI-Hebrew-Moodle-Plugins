<?php

$string['formattopsidesum'] = 'פסקת מבוא לצד פעילויות ומשאבים';
$string['nametopsidesum'] = 'יחידת הוראה';

?>