<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 12/6/11
 * Description:
 *    Change me...
 */

?>

/*
.topsidesum td#left-column {width: 150px !important;}
.topsidesum td#right-column {width: 320px !important;}
*/

.topsidesum .sideblock .header {
-webkit-border-top-left-radius: 3px;
-webkit-border-top-right-radius: 3px;
-moz-border-radius-topleft: 3px;
-moz-border-radius-topright: 3px;
border-top-left-radius: 3px;
border-top-right-radius: 3px; }

.topsidesum .sideblock .content, .topsidesum .sideblock .footer {
-webkit-border-bottom-left-radius: 3px;
-webkit-border-bottom-right-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-moz-border-radius-bottomright: 3px;
border-bottom-left-radius: 3px;
border-bottom-right-radius: 3px; }