<?php
/**
 * Created by JetBrains PhpStorm.
 * User: root
 * Date: 10/9/11
 * Time: 11:34 PM
 * To change this template use File | Settings | File Templates.
 */
?>
// CSS code...

#calendarview {float:right; width:75%;}
#calendarfilters {float:left; width:25%;}