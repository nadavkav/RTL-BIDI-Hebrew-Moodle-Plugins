<?php
/**
 * Created by JetBrains PhpStorm.
 * User: root
 * Date: 10/10/11
 * Time: 12:35 AM
 * To change this template use File | Settings | File Templates.
 */

$string['formatcalendar'] = 'לוח שנה ויומן ארועים'; // Name to display for format
$string['namecalendar'] = 'יחידות הוראה'; // Name of a section within your format