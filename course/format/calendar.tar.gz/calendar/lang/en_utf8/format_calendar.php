<?php
/**
 * Created by JetBrains PhpStorm.
 * User: root
 * Date: 10/10/11
 * Time: 12:35 AM
 * To change this template use File | Settings | File Templates.
 */

$string['formatcalendar'] = 'Calendar'; // Name to display for format
$string['namecalendar'] = 'Topics'; // Name of a section within your format