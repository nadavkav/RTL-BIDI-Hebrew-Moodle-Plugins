<?php
$string['nameletsplay'] = 'יחידות הוראה';
$string['formatletsplay'] = 'יחידות הוראה במשחק';
?>