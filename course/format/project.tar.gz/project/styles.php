.container {
  background-color: #efefef;
  border: solid 1px #999999;
  padding: 1px;
  margin: 2px;
}

.resource_upload {
  margin-right: 20px;
  float: left;
  white-space: nowrap;
}

.coursefile_upload {
  float:left;
  white-space: nowrap;
}

.project_backup {
  whitespace: nowrap;
  float: right;
}

.project_clearer {
  clear: both;
}