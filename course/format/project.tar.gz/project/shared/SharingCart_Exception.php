<?php
/**
 *  SharingCart_Exception
 */

class SharingCart_Exception extends Exception
{
}

?>