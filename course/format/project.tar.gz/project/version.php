<?php
  $plugin->version  = 2008123101; // Plugin version (update when tables change)
  $plugin->requires = 2007101508; // Required Moodle version
?>