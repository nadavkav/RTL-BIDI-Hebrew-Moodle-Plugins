<?php  //$Id: upgrade.php,v 1.2 2007/01/21 23:49:23 stronk7 Exp $


function xmldb_format_project_upgrade($oldversion=0) {
    global $CFG, $THEME, $db;

    $result = true;
    return $result;
}

?>
