<?php

$string['formattopheader'] = 'מבוא רוחבי מעל התוכן';
$string['nametopheader'] = 'יחידת הוראה';

?>