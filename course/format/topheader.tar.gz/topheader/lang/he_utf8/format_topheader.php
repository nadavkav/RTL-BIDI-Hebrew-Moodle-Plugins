<?php

$string['formattopheader'] = 'מבוא ברוחב מלא, מעל יחידות ההוראה';
$string['nametopheader'] = 'יחידת הוראה';

?>