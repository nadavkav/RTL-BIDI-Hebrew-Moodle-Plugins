<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 12/6/11
 * Description:
 *    Change me...
 */

?>

/*
.topheader td#left-column {width: 150px !important;}
.topheader td#right-column {width: 320px !important;}
*/

.topheader .sideblock .header {
-webkit-border-top-left-radius: 3px;
-webkit-border-top-right-radius: 3px;
-moz-border-radius-topleft: 3px;
-moz-border-radius-topright: 3px;
border-top-left-radius: 3px;
border-top-right-radius: 3px; }

.topheader .sideblock .content, .topheader .sideblock .footer {
-webkit-border-bottom-left-radius: 3px;
-webkit-border-bottom-right-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-moz-border-radius-bottomright: 3px;
border-bottom-left-radius: 3px;
border-bottom-right-radius: 3px; }