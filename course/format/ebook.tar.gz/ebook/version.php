<?php
// This file defines the current version of the
// eBook course/format/ebook add-on.
// This can be compared against the values stored in the
// database (firstnations_version) to determine whether upgrades should
// be performed (see db/*.php)

  $plugin->version  = 2011052902; // Plugin version (update when tables change)
  $plugin->requires = 2007021510; // Required Moodle version

?>