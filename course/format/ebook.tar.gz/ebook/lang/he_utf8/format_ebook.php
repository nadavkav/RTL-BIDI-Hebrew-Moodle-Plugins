<?php

$string['nameebook'] = 'עמוד';
$string['formatebook'] = 'ספר דיגיטלי';
$string['chapter'] = 'פרק';
$string['page'] = 'עמוד';

?>