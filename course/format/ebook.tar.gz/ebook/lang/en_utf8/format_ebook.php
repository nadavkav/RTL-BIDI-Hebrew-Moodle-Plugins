<?php

$string['nameebook'] = 'Page';
$string['formatebook'] = 'eBook';
$string['chapter'] = 'Chapter';
$string['page'] = 'Page';

?>