<?php
$string['nametopoverblk'] = 'Unit name';
$string['formattopoverblk'] = 'Overview section with sideblock column';
?>