<?php

$string['formattopoverblk'] = 'פסקת מבוא מעל יחידות הוראה ועמודת המשבצות השמאלית';
$string['nametopoverblk'] = 'יחידת הוראה';
