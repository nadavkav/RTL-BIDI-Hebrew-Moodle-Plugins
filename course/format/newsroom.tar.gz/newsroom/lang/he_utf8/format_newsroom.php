<?php

$string['formatnewsroom'] = 'עיתון דיגיטלי';
$string['namenewsroom'] = 'מדור';
$string['more'] = 'כתבות נוספות...';

?>