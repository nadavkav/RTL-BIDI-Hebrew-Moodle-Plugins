<?php
$string['nameletsplay'] = 'Unit name';
$string['formatletsplay'] = 'Lets play';
?>