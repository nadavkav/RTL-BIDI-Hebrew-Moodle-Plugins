<?php
$string['nameletsplay'] = 'יחידות הוראה';
$string['formatletsplay'] = 'פעילויות מתוך יחידות הוראה כמשחק';
?>