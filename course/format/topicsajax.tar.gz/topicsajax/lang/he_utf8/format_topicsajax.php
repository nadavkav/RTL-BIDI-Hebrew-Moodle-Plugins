<?php
$string['nametopicsajax'] = 'יחידת הוראה';
$string['formattopicsajax'] = 'יחידת הוראה בודדת + ניווט מהיר בעזרת לשוניות';
?>