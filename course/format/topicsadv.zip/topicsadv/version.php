<?php
  $plugin->version  = 2012200401; // Plugin version (update when tables change)
  $plugin->requires = 2007101508; // Required Moodle version
?>