<?php
$string['formatsections'] = 'תצורת מדורים (ללא מספור)';
$string['namesections'] = 'יחידת לימוד';
?>