<?php
$string['formatsections'] = 'Topics (no numbers)';
$string['namesections'] = 'Topics';
?>