<?php
/**
 * Created by Nadav Kavalerchik.
 * User: nadavkav
 * Date: 5/28/11
 * Time: 10:40 PM
 * Hiddenmod course format
 */

$string['formathiddenmod'] = 'Topics - Indented Modules are Hidden';

?>