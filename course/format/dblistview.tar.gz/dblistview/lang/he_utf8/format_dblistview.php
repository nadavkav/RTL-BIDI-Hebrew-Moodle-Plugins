<?php

$string['formatdblistview'] = 'תצוגת תבניות רשימה מתוך בסיס נתונים';
$string['namedblistview'] = 'יחידת הוראה';
$string['more'] = 'מידע נוסף...';

?>