<?php
$string['nametopics'] = 'Unit name';
?>