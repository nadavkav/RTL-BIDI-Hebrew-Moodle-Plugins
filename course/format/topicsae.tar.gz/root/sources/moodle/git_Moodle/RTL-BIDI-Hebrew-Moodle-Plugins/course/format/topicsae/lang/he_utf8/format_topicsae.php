<?php
$string['nametopicsae'] = 'יחידת לימוד - עריכה מתקדמת';
$string['formattopicsae'] = 'תצורת יחידת לימוד - עריכה מתקדמת';
?>