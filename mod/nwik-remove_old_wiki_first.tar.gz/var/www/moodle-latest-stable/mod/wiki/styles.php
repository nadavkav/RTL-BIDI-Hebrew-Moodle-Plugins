.dir-rtl td.nwikileftnow {
text-align:right;
}