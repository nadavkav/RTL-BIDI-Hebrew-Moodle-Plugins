<?php
$string['resourcetypekalturaswfdoc'] = 'סרט + מצגת (מתואמים)';
$string['uploaddocument'] = 'העלו מסמך מצגת';
$string['selectvideo'] = 'בחרו סרט וידאו';
$string['syncdescription'] = 'Once a video and document have been selected and ready, you can save your selection and proceed to sync keypoints';
?>