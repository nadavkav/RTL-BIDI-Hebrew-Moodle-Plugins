<?php
$string['resourcetypekalturaswfdoc'] = 'Video Presentation';
$string['uploaddocument'] = 'Upload Document';
$string['selectvideo'] = 'Select Video';
$string['syncdescription'] = 'Once a video and document have been selected and ready, you can save your selection and proceed to sync keypoints';
?>