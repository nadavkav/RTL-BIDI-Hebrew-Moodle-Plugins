<?php
$string['resourcetypekalturavideo'] = 'סרט';
$string['addvideo'] = 'הוספת סרט';
$string['video'] = 'סרט';
$string['editablevideo'] = 'סרט הניתן לעריכה';
$string['replacevideo'] = 'החלפת סרט';
$string['previewvideo'] = 'תצוגה מקדימה';
$string['previeweditvideo'] = 'תצוגה מקדימה ועריכה';
$string['videoconversion'] = 'הסרט נמצא בתהליך המרה, אנא המתינו.';
$string['clickhere'] = 'הקיליקו כאן';
$string['convcheckdone'] = 'לבדיקה אם ההמרה הסתיימה';
$string['videotext'] = 'This will allow you to select and display a single video.';
$string['videoremixtext'] = 'If you add several files, they will play as a sequence that you can then add to and edit.';
?>