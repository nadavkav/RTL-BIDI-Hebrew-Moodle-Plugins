<?php
$string['resourcetypekalturavideo'] = 'Video';
$string['addvideo'] = 'Add Video';
$string['video'] = 'Video';
$string['editablevideo'] = 'Add Editable Video';
$string['replacevideo'] = 'Replace Video';
$string['previewvideo'] = 'Preview';
$string['previeweditvideo'] = 'Preview & Edit';
$string['videoconversion'] = 'The video is now being converted';
$string['clickhere'] = 'Click here';
$string['convcheckdone'] = 'to check if conversion is done';
$string['videotext'] = 'This will allow you to select and display a single video.';
$string['videoremixtext'] = 'If you add several files, they will play as a sequence that you can then add to and edit.';
?>