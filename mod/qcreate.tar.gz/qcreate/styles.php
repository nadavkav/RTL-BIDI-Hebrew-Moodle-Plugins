ul#requiredqlist li { font-weight:bold }

ul#requiredqlist ul li { font-weight:normal }
