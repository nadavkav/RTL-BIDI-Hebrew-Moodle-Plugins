<?PHP // $Id: version.php,v 1.1 2003/09/30 02:45:19 moodler Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of bookings
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2005071700;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
