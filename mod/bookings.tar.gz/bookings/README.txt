This is version 0.4 of the bookings module.
So far there are three different types of bookings
weekly,yearly and appointment.
This mod is not yet finished ...
I'm releasing this early version so as to get some feedback
on changes/improvements.

LACKING FEATURES:
backup and restore
proper lists over user reservations
a year calender view for booking
    behaves much as yearly booking, but you book
    a day instead of a whole week


The code needs to be refined and moodleized a bit more.    
