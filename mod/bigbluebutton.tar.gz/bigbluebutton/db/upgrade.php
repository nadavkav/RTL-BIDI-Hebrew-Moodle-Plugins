<?php  

function xmldb_bigbluebutton_upgrade($oldversion=0) {

    global $CFG, $THEME, $db;

    $result = true;
    return $result;
}

?>
