///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                                                                       //
// Copyright (C) 2010 Dual Code Inc. (www.dualcode.com)                  //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//          http://www.gnu.org/copyleft/gpl.html                         //
//                                                                       //
///////////////////////////////////////////////////////////////////////////


BigBlueButton module for Moodle:
------------------------------------

Dual Code Inc. (www.dualcode.com) is an eLearning company that combines open-source and 
commercial products to deliver world-class, hosted learning environments to their customers.
Dual Code offers a hosted Corporate University, online courses & other eLearning 2.0 tools.
 

BigBlueButton (www.bigbluebutton.org) is an open-source web meeting product. With BigBlueButton, 
you can show presentations, applications and your desktop to any other person over the Internet. 
You can chat, show your webcam and talk with others in the meeting. 

