<?php  // $Id$

function xmldb_quizcopy_upgrade($oldversion=0) {
    return true;
}

?>
