<?php
$string['quizcopy'] = 'שכפול בוחן';
$string['quizcopyname'] = 'שם הבוחן החדש';
$string['error'] = 'שכפול הבוחן בוטל, כתוצאה מתקלת מערכת. אנא פנו לצוות הניהול של המערכת';
$string['modulename'] = 'שכפול בוחן';
$string['modulenameplural'] = 'שיכפול בוחן';
$string['originalquiz'] = 'הבוחן המקורי';
?>
