<?php
$string['quizcopy'] = 'Quiz Copy';
$string['quizcopyname'] = 'Name for new quiz';
$string['error'] = 'Error creating quiz copy';
$string['modulename'] = 'Quiz Copy';
$string['modulenameplural'] = 'Quiz Copy';
$string['originalquiz'] = 'Old Quiz';
?>
