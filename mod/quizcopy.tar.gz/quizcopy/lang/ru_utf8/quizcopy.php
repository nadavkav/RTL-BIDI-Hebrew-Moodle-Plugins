<?php
$string['quizcopy'] = 'Копия теста';
$string['quizcopyname'] = 'Имя для нового теста';
$string['error'] = 'Ошибка создания копии теста';
$string['modulename'] = 'Копия теста';
$string['modulenameplural'] = 'Копия теста';
$string['originalquiz'] = 'Старый тест';
?>
