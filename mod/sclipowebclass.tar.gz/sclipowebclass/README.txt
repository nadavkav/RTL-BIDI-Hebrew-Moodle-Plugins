To install this module you need to:

1) Unzip this folder in the directory /mod (so all files are located in /mod/sclipowebclass)
2) As admin, goto Notifications - everything will be set up correctly
3) Enjoy Sclipo!