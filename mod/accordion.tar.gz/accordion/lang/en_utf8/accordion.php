<?PHP // $Id: accord.php,v 1.2 2008/10/25 09:44:05  $ 
      // accord.php - 

$string['accordtitle'] = 'Accordian Title';
$string['accordcontent'] = 'Accordian Summary';
$string['modulename'] = 'Accordion';
$string['modulenameplural'] = 'Accordians';
$string['resourcetypeaccordion'] = 'Insert an Accordian';
$string['resourcetypeaccord'] = 'Accordian';

?>
