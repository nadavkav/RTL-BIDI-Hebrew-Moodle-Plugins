﻿<?PHP // $Id: flashupload.php, 2008/10/27 hgeppl

$string['flashupload'] = 'העלאת מספר קבצים';
$string['uploadtime'] = 'משך';
$string['timeremain'] = 'יתרת';
$string['estimating'] = 'מעריך...';
$string['of'] = 'של';
$string['at'] = 'ב';
$string['pending'] = 'ממתין...';
$string['cancel_upload'] = 'ביטול העלאה';
$string['file_too_big'] = 'קובץ גדול מידי';
$string['zero_byte'] = 'אין אפשרות להעלות קובץ ריק';

?>