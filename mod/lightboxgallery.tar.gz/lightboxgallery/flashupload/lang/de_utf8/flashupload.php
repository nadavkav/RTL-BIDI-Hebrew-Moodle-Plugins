﻿<?PHP // $Id: flashupload.php, 2008/10/27 hgeppl

$string['flashupload'] = 'Mehrere Dateien hochladen';
$string['uploadtime'] = 'Dauer';
$string['timeremain'] = 'verbleibend';
$string['estimating'] = 'Schätze...';
$string['of'] = 'von';
$string['at'] = 'bei';
$string['pending'] = 'Warte...';
$string['cancel_upload'] = 'Upload abbrechen';
$string['file_too_big'] = 'Datei ist zu groß';
$string['zero_byte'] = 'Datei hat keinen Inhalt';

?>