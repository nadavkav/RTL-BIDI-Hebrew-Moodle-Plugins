﻿<?PHP // $Id: flashupload.php, 2008/10/27 hgeppl

$string['flashupload'] = 'Upload Multiple Files';
$string['uploadtime'] = 'Duration';
$string['timeremain'] = 'remaining';
$string['estimating'] = 'Estimating';
$string['of'] = 'of';
$string['at'] = 'at';
$string['pending'] = 'Pending...';
$string['cancel_upload'] = 'Cancel Upload';
$string['file_too_big'] = 'File is too big';
$string['zero_byte'] = 'Cannot upload Zero Byte files.';

?>
