<?php // $Id: mysql.php,v 1.2 2006/03/22 14:58:44 janne Exp $

function learningdiary_upgrade($oldversion) {
/// This function does anything necessary to upgrade
/// older versions to match current functionality

    global $CFG;

    if ( $oldversion < 2006032201 ) {
        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_comments ";
        $sql .= "ADD COLUMN format TINYINT(1) unsigned NOT NULL DEFAULT '0'";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_guided_structure ";
        $sql .= "ADD COLUMN format TINYINT(1) unsigned NOT NULL DEFAULT '0'";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_pages ";
        $sql .= "ADD COLUMN format TINYINT(1) unsigned NOT NULL DEFAULT '0'";
        execute_sql($sql);
    }

    return true;
}

?>
