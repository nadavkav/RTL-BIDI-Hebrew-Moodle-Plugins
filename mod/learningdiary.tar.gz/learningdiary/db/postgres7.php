<?php // $Id: postgres7.php,v 1.1 2006/03/22 14:58:44 janne Exp $

function learningdiary_upgrade($oldversion) {
/// This function does anything necessary to upgrade
/// older versions to match current functionality

    global $CFG;

    if ( $oldversion < 2006032201 ) {

        // Alter learningdiary_comments.
        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_comments ";
        $sql .= "ADD COLUMN format CHAR(1)";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_comments ";
        $sql .= "ALTER COLUMN format SET DEFAULT '0'";
        execute_sql($sql);

        $sql  = "UPDATE TABLE {$CFG->prefix}learningdiary_comments ";
        $sql .= "SET format = '0' WHERE format IS NULL";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_comments ";
        $sql .= "ALTER COLUMN format SET NOT NULL";
        execute_sql($sql);

        // Alter learningdiary_guided_structure
        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_guided_structure ";
        $sql .= "ADD COLUMN format CHAR(1)";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_guided_structure ";
        $sql .= "ALTER COLUMN format SET DEFAULT '0'";
        execute_sql($sql);

        $sql  = "UPDATE TABLE {$CFG->prefix}learningdiary_guided_structure ";
        $sql .= "SET format = '0' WHERE format IS NULL";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_guided_structure ";
        $sql .= "ALTER COLUMN format SET NOT NULL";
        execute_sql($sql);

        // Alter learningdiary_pages
        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_pages ";
        $sql .= "ADD COLUMN format CHAR(1)";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_pages ";
        $sql .= "ALTER COLUMN format SET DEFAULT '0'";
        execute_sql($sql);

        $sql  = "UPDATE TABLE {$CFG->prefix}learningdiary_pages ";
        $sql .= "SET format = '0' WHERE format IS NULL";
        execute_sql($sql);

        $sql  = "ALTER TABLE {$CFG->prefix}learningdiary_pages ";
        $sql .= "ALTER COLUMN format SET NOT NULL";
        execute_sql($sql);

    }

    return true;
}

?>