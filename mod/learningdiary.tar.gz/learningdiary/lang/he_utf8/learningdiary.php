<?PHP // $Id$ 
      // learningdiary.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addcomment'] = 'הוספת תגובה';
$string['addeditcommentfor'] = 'הערות עבור: <strong>$a</strong>';
$string['addsubchapter'] = 'הוספת תת-פרק';
$string['addsuccess'] = 'רשומה חדשה נוספה!';
$string['and'] = 'וגם';
$string['available'] = 'זמין מתאריך';
$string['back'] = 'חזרה';
$string['bothdiaries'] = 'שניי מצבי יומן';
$string['chapter'] = 'פרק';
$string['chapterhistory'] = 'היסטוריית הפרק';
$string['chapters'] = 'פרקים';
$string['chaptertitle'] = 'כותרת הפרק';
$string['choose'] = 'בחרו $a';
$string['chooseastudent'] = 'בחרו תלמיד';
$string['comment'] = 'הערה';
$string['commentaddfailed'] = 'לא ניתן להוסיף הערה עבור: $a';
$string['commentaddsuccess'] = 'נוספה הערה ל: $a';
$string['commentdeleted'] = 'הערה נמחקה בהצלחה!';
$string['comments'] = 'הערות';
$string['commentupdatefailed'] = 'לא ניתן לעדכן את ההערה: <strong>$a</strong>!!!';
$string['commentupdatesuccess'] = 'ההערה <em>$a</em> עודכנה בהצלחה!';
$string['confirmdelete'] = 'אישור מחיקה';
$string['confirmdeletechapter'] = 'אתם עומדים למחוק פרק <strong>$a</strong>. האם אתם מעוניינים בכך?';
$string['confirmuserentrydelete'] = 'אתם עומדים למחוק ידיעה של התלמיד: <strong>$a</strong> entry!.<br />האם אתם מעוניינים בכל?';
$string['content'] = 'תוכן';
$string['created'] = 'נוצר';
$string['deletechapter'] = 'מחיקת פרק $a';
$string['deleteentry'] = 'מחיקת פרק';
$string['deletesuccess'] = 'הפרק נמחק בהצלחה!';
$string['deleteuserentry'] = 'מחיקת דיווח תלמיד';
$string['diarymode'] = 'אופי היומן';
$string['diffbetweenversions'] = 'הבדל בין גרסאות';
$string['difference'] = 'הבדל';
$string['edit'] = 'עריכת $a';
$string['edityourentry'] = 'עריכת הדיווח שלך';
$string['errornocontent'] = 'תוכן חסר!';
$string['errornotitle'] = 'כותרת חסרה!';
$string['guidance'] = 'הכוונה';
$string['guideddiary'] = 'יומן מודרך';
$string['intro'] = 'תאור';
$string['level'] = 'רמה';
$string['mainlevel'] = 'ראשי';
$string['management'] = 'ניהול';
$string['modulename'] = 'יומן תלמיד אישי';
$string['modulenameplural'] = 'יומני תלמידים אישיים';
$string['newchapter'] = 'הוספת פרק חדש';
$string['noguidedentryfound'] = '<p>אנא הזינו את הדיווח שלכם!</p>';
$string['nohistory'] = '<p>לא קיימת היסטוריית דיווחים!</p>';
$string['nonumbering'] = 'אל תשתמשו במיספור';
$string['normalnumbering'] = 'השתמשו במיספור';
$string['numbering'] = 'מיספור';
$string['onlyguideddiary'] = 'מורה מנחה את נושאי הדיווח ביומן';
$string['onlyuserdiary'] = 'תלמידים בוחרים בעצמם את נושאי הדיווח';
$string['question'] = 'שאלת הכוונה';
$string['structures'] = 'הנחייה מובנת';
$string['title'] = 'כותרת';
$string['updatesuccess'] = '<strong>$a</strong> עודכן בהצלחה!';
$string['userdiary'] = 'יומן תלמיד אישי';
$string['version'] = 'גירסה';

?>
