Learning diary - readme
===================================================

Module by Mediamaisteri Group (2005, 2006)
Janne Mikkonen <janne.mikkonen@mediamaisteri.com>
