<?php // $Id: managementform.php,v 1.5 2007/09/24 13:34:30 janne Exp $

      // This is a management form for guided learningdiary.

      if ( !defined('MOODLE_INTERNAL') ) {
          die("This page cannot be viewed by it self!!!");
      }

      // Cache some strings
      $strnewchapter = get_string('newchapter','learningdiary');

      if ( !empty($structure) && is_array($structure) ) {
          $initeditor = false;
          ?>
    <form method="post" action="management.php">
    <input type="hidden" name="id" value="<?php p($diary->cm->id) ?>" />
    <input type="hidden" name="sesskey" value="<?php p($USER->sesskey) ?>" />
    <ul style="list-style-type: none;">
    <li><a href="management.php?id=<?php p($diary->cm->id) ?>&amp;sesskey=<?php
    p($USER->sesskey) ?>&amp;action=add&amp;parentid=0"><?php echo $strnewchapter ?></a></li>
    </ul>
    <div style="width: 95%">
          <?php
    learningdiary_print_structure(0, $structure);
          ?>
    </div>
    <ul style="list-style-type: none;">
    <li><a href="management.php?id=<?php p($diary->cm->id) ?>&amp;sesskey=<?php
    p($USER->sesskey) ?>&amp;action=add&amp;parentid=0"><?php echo $strnewchapter ?></a></li>
    </ul>
    <center>
    <p><input type="submit" name="removeselected" value="<?php print_string('deleteselected'); ?>" /></p>
    </center>
    </form>
          <?php

      } else if ( !empty($structure) && is_object($structure) ) {
          $initeditor = true;
          ?>
    <form method="post" action="management.php">
    <input type="hidden" name="id" value="<?php p($diary->cm->id); ?>" />
    <input type="hidden" name="pageid" value="<?php p($pageid) ?>" />
    <input type="hidden" name="sesskey" value="<?php p($USER->sesskey) ?>" />
    <input type="hidden" name="parentid" value="<?php p($structure->parentid) ?>" />
    <ul style="list-style-type: none;">
        <li>
        <table border="0" cellpadding="4" cellspacing="2">
        <tr valign="top">
            <td align="right"><?php print_string('chapter','learningdiary') ?>:</td>
            <td><input type="text" name="title" value="<?php print(stripslashes($structure->title)) ?>" size="40" /></td>
        </tr>
        <tr valign="top">
            <td align="right"><?php print_string('guidance','learningdiary') ?>:
            <br /><br />
            <?php
            helpbutton('writing', get_string('helpwriting'), 'moodle', true, true);
            echo '<br />';
            helpbutton('questions', get_string('helpquestions'), 'moodle', true, true);
            echo '<br />';
            if ($usehtmleditor) {
                helpbutton('richtext', get_string('helprichtext'), 'moodle', true, true);
            } else {
                emoticonhelpbutton('form', 'intro');
            }
            echo '<br />';
            ?>
            </td>
            <td><?php
            print_textarea($usehtmleditor, "8", "40", "", "", "information", $structure->information, $diary->course->id);
            ?><br />
        <?php
        if ($usehtmleditor) {   /// Trying this out for a while
            print_string('formathtml');
            echo '<input type="hidden" name="format" value="'.FORMAT_HTML.'" />';
        } else {
            choose_from_menu(format_text_menu(), "format", $structure->format, "");
        }
        helpbutton("textformat", get_string("helpformatting"));
            ?></td>
        </tr>
        <tr valign="top">
            <td align="right"><?php print_string('available','learningdiary') ?>:</td>
            <td><?php
            print_date_selector("pday","pmonth","pyear", $structure->available);
            print_time_selector("phour","pmin", $structure->available, 1);
            helpbutton('available', get_string('available', 'learningdiary'), 'learningdiary'); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td><input type="submit" value="<?php print_string('savechanges'); ?>" />
            <input type="submit" name="cancel" value="<?php print_string('cancel'); ?>" /></td>
        </tr>
        </table>
        </li>
    </ul>
    </form>
          <?php
      } else {
          ?>
    <ul style="list-style-type: none;">
    <li><a href="management.php?id=<?php p($diary->cm->id) ?>&amp;sesskey=<?php
    p($USER->sesskey) ?>&amp;action=add&amp;parentid=0"><?php echo $strnewchapter ?></a></li>
    </ul>
          <?php
      }
?>