<?php header("Content-Type: text/css"); ?>

a.mod_ld_dimmed:link {
    color: #c0c0c0;
}
a.mod_ld_dimmed:active {
    color: #c0c0c0;
}
a.mod_ld_dimmed:visited {
    color: #c0c0c0;
}
div.mod_ld_noentry {
    margin-top: 20px;
    margin-left: 30px;
    font-size: large;
    font-weight: bold;
}
div.mod_ld_devider {
    height: 1px;
    border-top: 1px solid #ddd;
}
div.mod_ld_information {
}
.mod_ld_submit {
    font-size: 8pt;
}
table.mod_ld_comment_head {
    background-color: #f5f5f5;
    font-size: small;
    border-bottom: 1px solid #000;
}
.mod_ld_hidden {
    display: none;
}
.mod_ld_navi_list {
    list-style-type: none;
    list-style-position: outside;
}
li.mod_ld_navi_item {
    margin-left: -1.5em;
}
.mod_ld_toolbar {
    text-align: right;
}
.mod_ld_comment_links {
    text-align: right;
}
.mod_ld_confirm_warning {
    text-align: center;
}