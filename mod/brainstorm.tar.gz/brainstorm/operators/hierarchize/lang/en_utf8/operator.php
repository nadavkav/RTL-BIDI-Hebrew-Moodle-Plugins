<?php

$string['clearalldata'] = 'Clear all hierarchy data';
$string['hierarchize'] = 'Hierarchize';
$string['hierarchizesettings'] = 'Parameter settings for hierarchization';
$string['maxarity'] = 'Maximum numbr of childs per note (max. arity)';
$string['maxlevels'] = 'Maximum tree height';
$string['mytree'] = 'My hierarchy';
$string['notreeset'] = 'No tree has been set';
$string['printindeepness'] = 'Display in deepness';
$string['printbyline'] = 'Display by lines';
$string['tree'] = 'Hierachize ideas';
?>