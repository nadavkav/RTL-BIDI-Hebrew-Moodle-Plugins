<?php

$string['absolute'] = 'Absolute order';
$string['absoluteconstraint'] = 'Scaling must end in an absolute ordering. You can not use that value again.';
$string['allevaluated'] = 'All ideas have been valuated';
$string['barwidth'] = 'Bar width';
$string['clearall'] = 'Clear all scaling data';
$string['givingweightstoideas'] = 'Giving weights to ideas';
$string['moodlescale'] = 'Moodle scale';
$string['myscaling'] = 'My scaling';
$string['nootherscalings'] = 'No more scaling available from other participants';
$string['noscalings'] = 'No scaling data available';
$string['otherscales'] = 'Scaling of other participants';
$string['parallelquantify'] = 'Parallel valuation';
$string['quantifiertype'] = 'Quantifier type';
$string['randomquantify'] = 'Random valuation';
$string['savescaling'] = 'Save scaling';
$string['scale'] = 'Valuation';
$string['scalesettings'] = 'Parameter settings for scaling';
$string['unscaled'] = 'Non valuated ideas';
?>