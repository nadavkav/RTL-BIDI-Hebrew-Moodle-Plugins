<?php

$string['absolute'] = 'Ordre absolu ';
$string['absoluteconstraint'] = 'La valuation doit instaurer une relation d\'ordre absolue. Vous ne pouvez pas mettre ici une valeur déjà donnée par ailleurs.';
$string['allevaluated'] = 'Toutes les idées ont été valuées';
$string['barwidth'] = 'Largeur du bargraphe';
$string['clearall'] = 'Effacer toutes mes données';
$string['givingweightstoideas'] = 'Donner des pondérations à des idées';
$string['moodlescale'] = 'Barême Moodle ';
$string['myscaling'] = 'Ma valuation';
$string['nootherscalings'] = 'Aucune données de valuation des autres participants';
$string['noscalings'] = 'Aucune données de valuation';
$string['otherscales'] = 'Les valuations des autres';
$string['parallelquantify'] = 'Présentation globale ';
$string['quantifiertype'] = 'Type de quantifieur ';
$string['randomquantify'] = 'Présentation aléatoire ';
$string['savescaling'] = 'Enregistrer les pondérations';
$string['scale'] = 'Valuation ';
$string['scalesettings'] = 'Réglage des paramètres pour la valuation';
$string['unscaled'] = 'Idées non valuées';
?>