<?php

$string['addthreemore'] = 'Ajouter trois champs';
$string['allowcheckcycles'] = 'Autoriser la vérification des cycles ';
$string['clearconnections'] = 'Effacer toutes les relations';
$string['checkcycles'] = 'Examiner les cycles';
$string['displaynormal'] = 'Afficher en mode normal';
$string['editmultiplemapentry'] = 'Entrée d\'un quantificateur multiple de relation';
$string['fieldname'] = 'Nom ';
$string['fieldvalue'] = 'Valeur ';
$string['gridediting'] = 'Edition par grille ';
$string['gridediting'] = 'Edition par grille ';
$string['inputdata'] = 'Entrer des données ';
$string['onetoonerandom'] = 'Qualification de paires aléatoires ';
$string['picktwoandqualify'] = 'Choix d\'une paire et qualification  ';
$string['map'] = 'Mise en relation';
$string['mapofresponses'] = 'Carte des relations';
$string['mapsettings'] = 'Réglage des paramètres de la mise en relation';
$string['orderminusone'] = 'Ordre inférieur : $a';
$string['orderplusone'] = 'Ordre supérieur : $a';
$string['organizingmap'] = 'Mettre en relation des idées';
$string['quantified'] = 'Quantifier la relation ';
$string['saveconnections'] = 'Enregistrer les relations';
$string['savemultiple'] = 'Enregistrer les données';
$string['showmatrixproduct'] = 'Montrer les chemins';
$string['toomuchdata'] = 'Trop de données d\'entrée pour cette implémentation de l\'opérateur (max=$a)';
?>