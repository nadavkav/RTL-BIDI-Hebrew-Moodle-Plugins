<?php

$string['addthreemore'] = 'הוספת שלושה שדות חדשים';
$string['allowcheckcycles'] = 'אפשרו בדיקה מחזורית';
$string['clearconnections'] = 'מחיקת כל נתוניי המיפוי';
$string['checkcycles'] = 'הצגת מחזורים';
$string['displaynormal'] = 'הצגה במצב רגיל';
$string['editmultiplemapentry'] = 'עדכון ערך הצלבת־הרעיונות';
$string['fieldname'] = 'שם';
$string['fieldvalue'] = 'ערך';
$string['gridediting'] = 'עריכה בתבנית רשת';
$string['inputdata'] = 'נתוני קלט';
$string['onetoonerandom'] = 'השוואת זוגות אקראים';
$string['picktwoandqualify'] = 'בחרו זוג והעריכו';
$string['map'] = 'מפה';
$string['mapofresponses'] = 'רעיונות מיפוי';
$string['mapsettings'] = 'הגדרות מאפיינים עבור \"מפה\"';
$string['orderminusone'] = 'סדר נמוך: $a';
$string['orderplusone'] = 'סדר גבוה: $a';
$string['organizingmap'] = 'מיפוי רעיונות יחדיו';
$string['quantifiedmap'] = 'העריכו את החיבור בין הרעיונות';
$string['saveconnections'] = 'שמירת חיבורים';
$string['savemultiple'] = 'שמירת ערכיי הצלבת־הרעיונות';
$string['showmatrixproduct'] = 'הצגת נתיבים';
$string['toomuchdata'] = 'יותר מידי מידע עבור סמל־יחוס זה (מירבי=$a)';
?>