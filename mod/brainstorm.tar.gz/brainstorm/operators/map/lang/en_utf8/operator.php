<?php

$string['addthreemore'] = 'Add three more fields';
$string['allowcheckcycles'] = 'Allow cycle checking';
$string['clearconnections'] = 'Clear all mapping data';
$string['checkcycles'] = 'Show cycles';
$string['displaynormal'] = 'Display in normal mode';
$string['editmultiplemapentry'] = 'Edit a composite qualifier';
$string['fieldname'] = 'Name';
$string['fieldvalue'] = 'Value';
$string['gridediting'] = 'Grid editing';
$string['inputdata'] = 'Input data';
$string['onetoonerandom'] = 'Random pair comparison';
$string['picktwoandqualify'] = 'Pick pair and qualify';
$string['map'] = 'Map';
$string['mapofresponses'] = 'Mapping ideas';
$string['mapsettings'] = 'Parameter settings for the mapping';
$string['orderminusone'] = 'Lower order: $a';
$string['orderplusone'] = 'Higher order: $a';
$string['organizingmap'] = 'Mapping ideas together';
$string['quantified'] = 'Quantify the connection';
$string['saveconnections'] = 'Save the connections';
$string['savemultiple'] = 'Save the composite qualifier';
$string['showmatrixproduct'] = 'Show pathes';
$string['toomuchdata'] = 'Too much data for this implementation of the operator (max=$a)';
?>