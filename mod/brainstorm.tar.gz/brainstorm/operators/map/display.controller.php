<?php

/**
* Module Brainstorm V2
* Operator : map
* @author Valery Fremaux
* @package Brainstorm 
* @date 20/12/2007
*/

// TODO : should implement action code here if needed

?>