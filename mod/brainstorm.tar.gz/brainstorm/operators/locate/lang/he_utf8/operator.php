<?php

$string['datarangeis'] = 'יש להזין ערכים על פי התחום';
$string['displaysize'] = 'הצגת מימדים';
$string['height'] = 'גובה';
$string['locate'] = 'שטח';
$string['locatesettings'] = 'הגדרות מאפיינים עבור \"שטח\"';
$string['notconfigured'] = 'רכיב זה טרם הוגדר.';
$string['organizinglocate'] = 'מיקום דו־מימדי (שטח) של הרעיונות';
$string['savelocations'] = 'שמירת מיקומים';
$string['showlabels'] = 'הצגת ביאור';
$string['width'] = 'רוחב';
$string['xmaxrange'] = 'ערך מירבי (X)';
$string['xminrange'] = 'ערך נמוך (X)';
$string['xquantifier'] = 'ציר רוחב X';
$string['ymaxrange'] = 'ערך מירבי (Y)';
$string['yminrange'] = 'ערך נמוך (Y)';
$string['yquantifier'] = 'ציר גובה Y';
$string['criteriax'] = 'ציר  X';
$string['criteriay'] = 'ציר  Y';

?>