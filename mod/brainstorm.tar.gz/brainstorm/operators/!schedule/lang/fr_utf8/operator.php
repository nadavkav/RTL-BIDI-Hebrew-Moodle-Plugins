<?php

$string['schedule'] = 'Graphage';
$string['schedulesettings'] = 'Réglage des paramètres pour le graphage';
$string['quantifyedges'] = 'Quantifier les arêtes ';
?>