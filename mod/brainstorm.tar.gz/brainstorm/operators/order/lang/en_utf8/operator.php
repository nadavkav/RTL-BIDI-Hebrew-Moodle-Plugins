<?php

$string['absolute'] = 'Absolute order';
$string['agreewithyou'] = '$a inputs agree with you';
$string['agreewithyousingle'] = '$a input agrees with you';
$string['checkpreference'] = 'Check your preference (higher grade) ';
$string['comparisons'] = ' matching to qualify ';
$string['confirmpaircompare'] = 'Warning, this ordering process removes all all ordering data. Continue anymay ?';
$string['finished'] = 'You weighted all the pairs. The final order you obtained is :';
$string['myordering'] = 'My ordering';
$string['noorderset'] = 'No ordering defined yet';
$string['noresponses'] = 'No responses to order';
$string['order'] = 'Ordering';
$string['ordersettings'] = 'Parameter settings for ordering';
$string['original'] = 'Original (time ordered)';
$string['paircompare'] = 'Ordering process using pair ordering process';
$string['pickandswapordering'] = 'Pick and swap';
$string['puttingideasinorder'] = 'Putting ideas in order';
$string['rank'] = 'Score';
$string['remains'] = 'Remains ';
$string['reordering...'] = 'Reordering for final recording... done.';
$string['response'] = 'Response';
$string['resume'] = 'Stop process now ';
$string['saveorder'] = 'Save the ordering';
$string['startpaircompare'] = 'Start ordering by comparing pairs';

?>