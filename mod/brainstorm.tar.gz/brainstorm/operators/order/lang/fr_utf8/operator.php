<?php

$string['absolute'] = 'Ordre absolu ';
$string['agreewithyou'] = '$a réponses exprimées sont d\'accord avec vous';
$string['agreewithyousingle'] = '$a réponse exprimée est d\'accord avec vous';
$string['checkpreference'] = 'Cochez votre préférence ';
$string['comparisons'] = ' comparaisons a effectuer ';
$string['confirmpaircompare'] = 'Attention, cette procédure efface les données de rangement. Voulez-vous continuer ?';
$string['finished'] = 'Vous avez qualifié toutes les combinaisons. L\'ordre que vous avez obtenu est le suivant :';
$string['myordering'] = 'Mon rangement';
$string['noorderset'] = 'Aucun ordre défini pour l\'instant';
$string['noresponses'] = 'Pas d\'idées à ordonner';
$string['order'] = 'Ordonnancement';
$string['ordersettings'] = 'Réglage des paramètres pour l\'ordonnancement';
$string['original'] = 'Ordre original';
$string['paircompare'] = 'Processus d\'ordonnancement par préférence deux à deux';
$string['pickandswapordering'] = 'Choisir et intervertir';
$string['puttingideasinorder'] = 'Mettre de l\'ordre dans les idées';
$string['rank'] = 'Score';
$string['remains'] = 'Il reste ';
$string['reordering...'] = 'Renumérotation pour ordre final... Terminé.';
$string['response'] = 'Réponses';
$string['resume'] = 'Arrêter ici ';
$string['saveorder'] = 'Enregistrer l\'ordonnancement';
$string['startpaircompare'] = 'Démarrer la procédure de comparaison par paire';
?>