<?php

$string['addcategory'] = 'הוספת סיווג';
$string['agreewithyou'] = '$a מסכים אתך';
$string['agreewithyousingle'] = '$a מסכים אתך';
$string['allowmultiple'] = 'אפשרו מַפְתֵּחַ־נוֹשְׂאִים של מספר סיווגים ';
$string['blindness'] = 'בודדו את המשתמש בזמן המיון ';
$string['categorize'] = 'סיווג';
$string['categories'] = 'סיווגים';
$string['categorizesettings'] = 'הגדרות פעולת \"סיווג\"';
$string['categoriseresponses'] = 'סיווג רעיונות';
$string['disagreewithyou'] = '$a אינו מסכים אתך';
$string['disagreewithyousingle'] = '$a אינו מסכים אתך';
$string['maxitemspercategory'] = 'מספר פריטים מירבי עבור סיווג ';
$string['mycategories'] = 'הסיווגים שלי';
$string['nocategories'] = 'אין סיווגים';
$string['notcategorised'] = 'לא סווג';
$string['nothinghere'] = 'אין מידע עבור סיווג זה';
$string['organizingcategorize'] = 'סיווג רעיונות';
$string['othercategories'] = 'סיווגים ממשתמשים אחרים';
$string['publishcategoriesoncollect'] = 'פרסום סיווגים בטופס מיוחד';
$string['savecategories'] = 'שמירת סיווגים';
$string['savecategorization'] = 'שמירת סיווג';
$string['uncategorized'] = 'ללא סיווג';
$string['alluncategorized'] = 'לא קיימים סיווגים של משתמשים אחרים';

?>