<?php

$string['allowreducesourcemerge'] = 'אפשרו צמצום רעיונות מקוריים';
$string['choicedata'] = 'קבוצת רעיונות';
$string['custommerge'] = 'איחוד';
$string['filterlimitundefined'] = 'מספר הרעיונות המירבי שיש לשמור לא הוגדר.<br/> ההגדרות של סמל־יחס זה - איחוד, טרם נשמרו.';
$string['maxideasleftmerge'] = 'מספר רעיונות מירבי לאחר האיחוד';
$string['merge'] = 'איחוד';
$string['mergedata'] = 'איחוד נתונים';
$string['mergeddata'] = 'נתונים מאוחדים';
$string['mergesettings'] = 'הגדות מאפיינים ל\"איחוד\"';
$string['mymerges'] = 'האיחוד שלי';
$string['nomergeinprogress'] = 'לא קיים תהליך איחוד, כעת.';
$string['noothermerges'] = 'לא קיימים תהליכי איחוד אחרים (של משתמשים אחרים)';
$string['organizingmerge'] = 'אחדו מספר רעיונות לאחד כדי לצמצם את מספר הרעיונות';
$string['othermerges'] = 'רעיונות איחוד של משתמשים אחרים';
$string['responsestokeep'] = 'רעיונות לשימור';
$string['saveandreduce'] = 'שמירה וצימצום הרעיונות המקוריים';
$string['savemerges'] = 'שמירה ואיחוד הרעיונות';
$string['sourcedata'] = 'רעיונות מקוריים';
?>