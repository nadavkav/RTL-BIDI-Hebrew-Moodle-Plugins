<?php

$string['allowreducesource'] = 'Autoriser la réduction de la source ';
$string['choicedata'] = 'Groupes d\'idées';
$string['custommerge'] = 'Synthèse';
$string['filterlimitundefined'] = 'Le nombre d\'idées à garder n\'est pas défini.<br/> La configuration du filtre n\'a probablement pas été encore enregistrée';
$string['maxideasleft'] = 'Nombre final maximum de réponses';
$string['merge'] = 'Réduction par fusion';
$string['mergedata'] = 'Données de fusion';
$string['mergeddata'] = 'Synthèse';
$string['mergesettings'] = 'Réglage des paramètres pour la réduction par fusion';
$string['mymerges'] = 'Ma fusion';
$string['nomergeinprogress'] = 'Pas de fusion en cours';
$string['noothermerges'] = 'Pas d\'autres fusions en cours';
$string['organizingmerge'] = 'Faire la synthèse des idées pour en réduire le nombre'; 
$string['othermerges'] = 'Les fusions des autres';
$string['responsestokeep'] = 'réponses à conserver';
$string['saveandreduce'] = 'Sauver et réduire la source';
$string['savemerges'] = 'Sauvegarder les synthèses';
$string['sourcedata'] = 'Idées sources';
?>