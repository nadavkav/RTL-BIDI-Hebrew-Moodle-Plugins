<?php

$string['allowreducesource'] = 'Allow reducing the source';
$string['choicedata'] = 'Ideas sets';
$string['custommerge'] = 'Merge';
$string['filterlimitundefined'] = 'The max amount of ideas to keep is not defined.<br/> The configuration for this operator might not have been saved.';
$string['maxideasleft'] = 'Max number of ideas after merging';
$string['merge'] = 'Reduction by merging';
$string['mergedata'] = 'Merge data';
$string['mergeddata'] = 'Merged data';
$string['mergesettings'] = 'Parameter settings for merging ideas';
$string['mymerges'] = 'My merge';
$string['nomergeinprogress'] = 'No merge in progress';
$string['noothermerges'] = 'No more other merges in progress (other paricipants)';
$string['organizingmerge'] = 'Merge ideas into one to reduce ideas number'; 
$string['othermerges'] = 'Other participant\'s mergings';
$string['responsestokeep'] = 'idea(s) to keep';
$string['saveandreduce'] = 'Save and reduce the source';
$string['savemerges'] = 'Save the merges';
$string['sourcedata'] = 'Source data';
?>