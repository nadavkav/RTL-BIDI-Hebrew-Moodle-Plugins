<?php

$string['absolute'] = 'Ordre absolu ';
$string['allowreducesource'] = 'Autoriser la réduction de la source ';
$string['candeletemore'] = 'Eliminer plus de réponses que la contrainte';
$string['filter'] = 'Réduction par élimination';
$string['filtereddata'] = 'Données filtrées';
$string['filtersettings'] = 'Réglage des paramètres pour le filtrage par élimination';
$string['maxideasleft'] = 'Nombre final maximum de réponses';
$string['myfilter'] = 'Mon filtrage';
$string['nofilteringinprogress'] = 'Pas de filtrage en cours';
$string['nootherstatuses'] = 'Pas de données d\'autres participants';
$string['organizingfilter'] = 'Réduction des entrées par élimination';
$string['otherfilters'] = 'Filtrage des autres participants';
$string['responsestoeliminate'] = 'réponse(s) à éliminer';
$string['saveordering'] = 'Sauvegarder ce filtrage';
$string['saveorderingandreduce'] = 'Sauvegarder et réduire les entrées';
$string['keepit'] = 'Garder';
$string['recording filter...'] = 'Enregistrement du filtre...effectué.';
?>