<?php

$string['absolute'] = 'Absolute order';
$string['allowreducesource'] = 'Allow source reduction';
$string['candeletemore'] = 'Can delete more than required remainder';
$string['filter'] = 'Filtering by eliminating';
$string['filtereddata'] = 'Filtered inputs';
$string['filtersettings'] = 'Parameter settings for filtering';
$string['maxideasleft'] = 'Maximum number of ideas after filtering';
$string['myfilter'] = 'My filtering';
$string['nofilteringinprogress'] = 'No filtering in progress';
$string['nootherstatuses'] = 'No filtering in progress by other participants';
$string['organizingfilter'] = 'Reducing ideas number by eliminating';
$string['otherfilters'] = 'Filtering of other participants';
$string['responsestoeliminate'] = 'idea(s) to eliminate';
$string['saveordering'] = 'Save this filtering';
$string['saveorderingandreduce'] = 'Save and reduce the source (delete filtered)';
$string['keepit'] = 'Keep them';
$string['recording filter...'] = 'Recording filter data...done.';
?>