<?PHP // $Id: version.php,v 1.21 2007/07/04 16:36:18 mellermann Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2008020400;
$module->requires = 2006050510;  // Requires this Moodle version
$module->cron     = 0;

?>
