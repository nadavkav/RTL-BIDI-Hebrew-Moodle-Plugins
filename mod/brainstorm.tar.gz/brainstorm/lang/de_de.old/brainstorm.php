<?PHP // $Id$ 
      // brainstorm.php - created with Moodle 1.4.3 (2004083130)


$string['addmoreresponses'] = 'Weitere Antworten/Ideen/Beiträge ergänzen';
$string['brainstormname'] = 'Link (Kursseite)';
$string['brainstormtext'] = 'Zusammenfassung';
$string['categories'] = 'Sortierkriterien/Kategorien';
$string['categoriseresponses'] = '$a Antworten einordnen';
$string['heightresponse'] = 'Höhe des Antwortfeldes';
$string['helptext'] = 'Hilfetext';
$string['modulename'] = 'Brainstorming';
$string['modulenameplural'] = 'Brainstorming';
$string['mustentercategory'] = 'Sie müssen zumindest ein Sortierkriterium/eine Kategorie anlegen, bevor Sie speichern können.';
$string['mustentersomething'] = 'Sie müssen zuerst eine Antwort eingeben, bevor Sie speichern können. Bisher wurde noch nichts gespeichert.';
$string['notcategorised'] = 'Nicht zugeordnet';
$string['notresponded'] = 'Kein Antworten bisher eingetragen';
$string['numcolumns'] = 'Zahl der Spalten';
$string['numresponses'] = 'Zahl der Antworten';
$string['responded'] = 'eingegebene Antworten';
$string['responses'] = 'Antworten';
$string['savecategories'] = 'Sortierkriterien/Kategorien speichern';
$string['savecategorisation'] = 'Zuordnungen abspeichern';
$string['savemyresponse'] = 'Meine Antworten speichern';
$string['select'] = 'Auswählen';
$string['widthresponse'] = 'Breite des Antwortfeldes';

?>
