.dir-rtl .bd {
text-align:right;
}
