<?php //$Id: block_search_forums.php,v 1.1 2006/02/06 09:28:54 moodler Exp $

$string['blocktitle'] = 'Search LOs-metadata';
$string['advancedsearch'] = 'Advanced search';

?>