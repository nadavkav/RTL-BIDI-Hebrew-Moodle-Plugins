<?php // $Id: version.php,v 1.34 2009/10/01 15:35:12 fabiangebert Exp $

/**
 * Code fragment to define the version of studynotes
 * This fragment is called by moodle_needs_upgrading() and /admin/index.php
 *
 * @author 
 * @version $Id: version.php,v 1.34 2009/10/01 15:35:12 fabiangebert Exp $
 * @package studynotes
 **/

$module->version  = 2009100100;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
