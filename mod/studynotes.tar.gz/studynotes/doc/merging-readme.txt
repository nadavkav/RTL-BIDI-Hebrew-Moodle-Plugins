open print version
copy whole <div id="content"... stuff into setup-*.html
remove <span class="toctoggle">[^\]]*]</span>
remove <span class="editsection">[^\]]*]</span>
remove /en/Image:
remove /de/Bild:
replace /en/images[^"]*/([^"]+).png" with \1.png"
replace /de/images[^"]*/([^"]+).png" with \1.png"
remove toctoggle-script
nicely format code with aptana
