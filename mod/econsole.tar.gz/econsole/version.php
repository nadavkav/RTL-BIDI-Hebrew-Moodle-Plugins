<?php
/**
 * Code fragment to define the version of econsole
 * This fragment is called by moodle_needs_upgrading() and /admin/index.php
 *
 * @author 
 * @version $Id: version.php,v 1.5 2007/04/01 22:57:16 stronk7 Exp $
 * @package econsole
 **/
//The current module version (Date: YYYYMMDDXX)
$module->version = 2009021701;
//Period for cron to check this module (secs)
$module->cron = 0;
?>
