<html>
<head>
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
body {
	background-color: #eef4f8;
	margin-left: 20px;
	margin-right: 20px;
}
.style7 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-weight: bold;
	color: #006600;
	font-size: 18px;
	text-indent: 60px;
}
.style8 {font-size: 24px}
.style9 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	text-indent: 60px;
}
.style10 {color: #FF6600}
.style12 {color: #FF6600; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /></head>

<body>
<p>&nbsp;</p>
<h1 class="style7 style8">Ajuda para o uso do Econsole</h1>
<p align="justify" class="style9">Na estrutura do curso voc&ecirc; reconhecer&aacute; o Console pelo &iacute;cone <img src="imagens/icon.gif" width="21" height="22" alt="ss">, que, uma vez clicado, abrir&aacute; uma nova janela semelhante a mostrada abaixo. </p>
<center>
  <p><img src="imagens/tela_numerada.gif" alt="" width="740" height="508" border="0" usemap="#Map">
<map name="Map"><area shape="circle" coords="11,6,1" href="#"><area shape="circle" coords="26,22,18" href="#cabecalho"><area shape="circle" coords="28,112,20" href="#barra">
  <area shape="circle" coords="26,363,22" href="#icones">
<area shape="circle" coords="30,458,20" href="#recurso"><area shape="circle" coords="722,415,19" href="#navegacao"><area shape="circle" coords="720,186,18" href="#conteudo"></map></p>
  <p>&nbsp;</p>
</center>
<ol>
  <li>
    <div align="justify"><strong class="style9"><a name="cabecalho"></a>CABE&Ccedil;ALHO:</strong> </strong>
        <span class="style9">O primeiro item mostra o n&uacute;mero da aula atual e o segundo item a li&ccedil;&atilde;o e o total de li&ccedil;&otilde;es desta aula.</span></div>
  </li><br>
  <li>
    <div align="justify"><strong class="style9"><a name="barra"></a>BARRA TEMA:</strong> <span class="style9">Atribui  uma identidade visual ao curso.</span></div>
  </li><br>
  <li>
    <div align="justify"><strong class="style9"><a name="icones"></a>&Iacute;CONES:</strong> <span class="style9">Utilizados para salientar recursos e apontar caminhos alternativos no conte&uacute;do (destacar bibliotecas, pastas, v&iacute;deos, &aacute;udios, ferramentas ou softwares, revis&otilde;es, videoconfer&ecirc;ncia, etc.). Nem sempre estes &iacute;cones s&atilde;o links. Os que s&atilde;o configurados para apontar um caminho  trar&atilde;o uma informa&ccedil;&atilde;o escrita ao lado, salientando esta a&ccedil;&atilde;o.</span></div>
  </li><br>
  <li>
    <div align="justify"><strong class="style9"><a name="recurso"></a>BOT&Otilde;ES DE RECURSO:</strong> <span class="style9">Estes bot&otilde;es  conduzem para as atividades habilitadas no curso e a cada avan&ccedil;o do console podem variar de intensidade conforme o status (ativo/inativo), al&eacute;m de mostrarem a sua fun&ccedil;&atilde;o quando sobrepostos pelo mouse.</span><br>
      <span class="style9">Os bot&otilde;es se tornam INATIVOS quando a atividade que representa ainda n&atilde;o est&aacute; liberada pelos tutores do curso ou ainda n&atilde;o est&aacute; no momento de realizar a atividade.<br>
    Os bot&otilde;es ATIVOS mostram as atividades dispon&iacute;veis para aquele momento e, normalmente, ser&atilde;o abertas na &aacute;rea de conte&uacute;do do Console.<span class="style10"> SEMPRE AP&Oacute;S CONCLUIR QUALQUER UMA DAS ATIVIDADES ACIONADAS POR ESTES BOT&Otilde;ES, CLIQUE NO &Iacute;CONE CENTRAL  PARA RETORNAR A &Uacute;LTIMA TELA DO CONSOLE.</span></span></div>
  </li><br>
  <li>
  <div align="justify"><strong class="style9"><a name="navegacao"></a>BOT&Otilde;ES DE NAVEGA&Ccedil;&Atilde;O:</strong> <span class="style9"> Os bot&otilde;es AVAN&Ccedil;AR e VOLTAR quando acionados determinam o avan&ccedil;o e o recuo para a pr&oacute;xima tela do console,  al&eacute;m de mostrar o nome da li&ccedil;&atilde;o seguinte ou anterior quando sobrepostos pelo mouse. <span class="style10">O BOT&Atilde;O CENTRAL RECARREGA A TELA DA LI&Ccedil;&Atilde;O ATUAL E SERVE SEMPRE DE RETORNO, AP&Oacute;S REALIZADA ALGUMA ATIVIDADE ACIONADA PELOS BOT&Otilde;ES DE RECURSO.</span></span></div>
  </li><br>
  <li>
    <div align="justify"><strong class="style9"><a name="conteudo"></a>&Aacute;REA DE CONTE&Uacute;DO:</strong>        <span class="style9">Disp&otilde;e o conte&uacute;do da li&ccedil;&atilde;o, mostrando, sempre que necess&aacute;rio, a barra de rolagem &agrave; direita.</span></div>
  </li>
</ol>
<center><p>&nbsp;</p>
</center>

</body>
</html>
