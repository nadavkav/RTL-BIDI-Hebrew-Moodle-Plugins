<?PHP // $Id: allmetadata.php,v 1.2.2.3 2006/07/31 05:56:48 vg Exp $ 
      // search_allmetadata.php - created with Moodle 1.5 (2005020101)


$string['allmetadata'] = 'כל מאפייני-המידע הנוספים';
$string['allmods'] = 'כל רכיבי ההוראה';
$string['allcourses'] = 'כל מרחביי הלימוד';
$string['mycourses'] = 'המרחבים שלי';
$string['modulenameplural'] = 'חיפוש במאפייני-המידע של הרכיבים';

$string['nometadata'] = 'לא נמצאו מאפייני -מידע מסוג Dublin Core Metadata או IEEE-LOM Metadata';
$string['nocourses'] = 'לא נמצאו מרחבים העונים לחיפוש';
$string['nomodules'] = 'לא נמצאו רכיבים - פעילויות או משאבים העונים לחיפוש';

$string['advancedsearch'] = 'חיפוש מתקדם';
$string['nometacontaining'] = 'לא נמצאו רכיבי פעילויות או משאבים המכילים את המילים \'$a\' ';
$string['search'] = 'חיפוש';
$string['searchdatefrom'] = 'משאבים/פעילויות אשר נוצרו אחרי התאריך';
$string['searchdateto'] = 'משאבים/פעילויות אשר נוצרו עד התאריך';
$string['searchallmetadataintro'] = 'אנא הזינו מילות חיפוש לאחד או מספר שדות בטופס הבא:';
$string['searchallmetadatas'] = 'התחילו חיפוש';
$string['searchfullwords'] = 'מילים אילו צריכות להופיע ביחד (כמשפט)';
$string['searchnotwords'] = 'סינון תוצאות אשר מילים אילו מופיעות בהן';
$string['searchphrase'] = 'תחביר מדיוק לחיפוש במאפייני-המידע של הפעילות/משאב';
$string['searchsubject'] = 'מילים אשר מופיעות בתאור הפעילות/משאב';
$string['searchuser'] = 'שם המחבר/יוצר של הפעילות/משאב';

$string['searchuserid'] = 'The Moodle ID of the author/creator';
$string['searchwords'] = 'חיפוש כללי של מילים המופיעות בכל מקום';
$string['searchresults'] = 'תוצאות החיפוש';
$string['searchwhichmetadatas'] = 'בחרו את מאפיין-מידע של הרכיב, בו יתבצע החיפוש';
$string['searchwhichcourse'] = 'בחרו מרחב לימוד מסויים למיקוד החיפוש';
$string['searchwhichmods'] = 'בחירת סוג הפעילות/משאב למיקוד החיפוש';
$string['seealllos'] = 'הצגת כל הפעילויות/משאבים אשר נוצרו על ידי המורה:';
?>
