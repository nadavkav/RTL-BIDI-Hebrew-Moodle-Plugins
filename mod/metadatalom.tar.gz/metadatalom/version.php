<?PHP // $Id: version.php,v 1.2 2006/04/29 22:19:41 skodak Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of metadatalom
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2006090100;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
