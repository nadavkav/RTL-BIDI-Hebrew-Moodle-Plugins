<?php

$module->version  = 2010102201;
$module->requires = 2007101550;
$module->cron     = 60;

$module->displayversion = 'Stable R2.23';
?>
