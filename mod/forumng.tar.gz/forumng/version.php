<?php

$module->version  = 2010051300;
$module->requires = 2007101540;
$module->cron     = 60;

// Stable version number; increment major number for new branch release,
// increment minor number for bugfix changes
$module->displayversion = 'Stable R1.1';
?>
