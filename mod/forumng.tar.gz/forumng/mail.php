<?php
require_once('../../config.php');
require_once('forum_mail_list.php');

print_header();

print_footer();
?>