<?php 

$plugin->version = 2010041400;
$plugin->requires = 2007101513;

?>