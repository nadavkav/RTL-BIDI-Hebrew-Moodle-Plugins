<?php

$string['typeteam'] = 'משימה בצוות';
$string['existingteams'] = 'צוותים קיימים';
$string['jointeam'] = 'הצטרפו לצוות';
$string['createteam'] = 'יצירת צוות';
$string['teammember'] = 'חברי הצוות';
$string['viewmember'] = 'תצוגת חברי הצוות';
$string['createteamlabel'] = 'הוסיפו אותי לצוות חדש';
$string['teamname'] = 'שם הצוות';
$string['editteam'] = 'עריכת מאפייני הצוות';
$string['deleteteam'] = 'מחיקת צוות';
$string['openclosemembership'] ='פתיחה/סגירה';
$string['removeteammember'] = 'הסרת חבר מהצוות';
$string['teamsubmission'] = 'הגשות הצוות';
$string['teamnameerror'] = 'יש להזין שם לצוות';
$string['teamnameexist'] = 'צוות בשם זה,קיים.';
$string['createteamerror'] = 'שגיאה בעת יצירת הצוות';
$string['jointeamerror'] = 'שגיאה בעת הוספת חבר חדש לצוות';
$string['lastmembererror'] = 'לא ניתן להסיר את חבר הצוות האחרון';
$string['teamclosedwarning'] = 'לא ניתן להצטרף לצוות בשלב זה';
$string['teamopen'] = 'ניתן להצטרף לצוות';
$string['teamclosed'] = 'הרשמה והצטרפות לצוות, הסתיימה.';

?>