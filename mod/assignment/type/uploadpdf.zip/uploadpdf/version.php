<?php

$plugin->version = 2011101000;
$plugin->requires = 2007020200;

$submodule->version  = $plugin->version;
$submodule->requires = $plugin->requires;


?>