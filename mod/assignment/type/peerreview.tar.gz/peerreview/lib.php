<?php

$DOWNLOAD_FILE_TO_REVIEW = 'type/peerreview/downloadFileToReview.php';
$FILE_PREFIX = 'toReview';

?>