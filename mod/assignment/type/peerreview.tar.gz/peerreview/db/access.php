<?php 
 
$mod_peerreview_capabilities = array();


?>
