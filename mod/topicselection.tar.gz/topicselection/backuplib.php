<?php //$Id: backuplib.php,v 1.0 2007/06/17 03:45:29 SerafimPanov Exp $
    //This php script contains all the stuff to backup/restore
    //topicselection mods

    //
    // Meaning: pk->primary key field of the table
    //          fk->foreign key to link with parent
    //          nt->nested field (recursive data)
    //          CL->course level info
    //          UL->user level info
    //          files->table may have files)
    //
    //-----------------------------------------------------------

    function topicselection_check_backup_mods($course,$user_data=false,$backup_unique_code,$instances=null) {

        if (!empty($instances) && is_array($instances) && count($instances)) {
            $info = array();
            foreach ($instances as $id => $instance) {
                $info += topicselection_check_backup_mods_instances($instance,$backup_unique_code);
            }
            return $info;
        }
        return $info;
    }
    
    function topicselection_check_backup_mods_instances($instance,$backup_unique_code) {
        //First the course data
        $info[$instance->id.'0'][0] = '<b>'.$instance->name.'</b>';
        $info[$instance->id.'0'][1] = '';

        //Now, if requested, the user_data
        if (!empty($instance->userdata)) {
            $info[$instance->id.'1'][0] = get_string("messages","topicselection");
            if ($ids = chat_message_ids_by_instance ($instance->id)) { 
                $info[$instance->id.'1'][1] = count($ids);
            } else {
                $info[$instance->id.'1'][1] = 0;
            }
        }
        return $info;
    }

    function topicselection_backup_mods($bf,$preferences) {

        global $CFG;

        $status = true;

        //Iterate over topicselection table
        $topicselections = get_records ("topicselection","course",$preferences->backup_course,"id");
        if ($topicselections) {
            foreach ($topicselections as $topicselection) {
                if (backup_mod_selected($preferences,'topicselection',$topicselection->id)) {
                    $status = topicselection_backup_one_mod($bf,$preferences,$topicselection);
                }
            }
        }
 
        return $status;  
    }
    
    function topicselection_backup_one_mod($bf,$preferences,$topicselection) {

        global $CFG;
    
        if (is_numeric($topicselection)) {
            $topicselection = get_record('topicselection','id',$topicselection);
        }
    
        $status = true;

        //Start mod
        fwrite ($bf,start_tag("MOD",3,true));
        //Print topicselection data
        fwrite ($bf,full_tag("ID",4,false,$topicselection->id));
        fwrite ($bf,full_tag("MODTYPE",4,false,"topicselection"));
        fwrite ($bf,full_tag("COURSE",4,false,$topicselection->course));
        fwrite ($bf,full_tag("TEACHER",4,false,$topicselection->teacher));
        fwrite ($bf,full_tag("NAME",4,false,$topicselection->name));
        fwrite ($bf,full_tag("INTRO",4,false,$topicselection->intro));
        fwrite ($bf,full_tag("SLOTS",4,false,$topicselection->slots));
        fwrite ($bf,full_tag("SESSIONS",4,false,$topicselection->sessions));
        fwrite ($bf,full_tag("NUMBERTIMESLOTS",4,false,$topicselection->numbertimeslots));
        fwrite ($bf,full_tag("SAMETOPIC",4,false,$topicselection->sametopic));
        fwrite ($bf,full_tag("OWNTOPIC",4,false,$topicselection->owntopic));
        fwrite ($bf,full_tag("DIFFERENTTOPIC",4,false,$topicselection->differenttopic));
        fwrite ($bf,full_tag("TIME",4,false,$topicselection->time));
        fwrite ($bf,full_tag("TOPICSELECTIONTIME",4,false,time()));
        //if we've selected to backup users info, then execute backup_topicselection_messages
        topicselection_backup_topicselection_topics ($bf,$preferences,$topicselection);
        topicselection_backup_topicselection_sessions ($bf,$preferences,$topicselection);
        topicselection_backup_topicselection_topicuser ($bf,$preferences,$topicselection);
        //End mod
        $status =fwrite ($bf,end_tag("MOD",3,true));

        return $status;
    }
    
    
    function topicselection_backup_topicselection_topics ($bf,$preferences,$topicselection) {

        global $CFG;

        $status = true;

        $datas = get_records("topicselection_topics", 'instance', $topicselection->id);
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("TOPICSELECTION_TOPICS",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("INSTANCE",6,false,$cha_mes->instance));       
                fwrite ($bf,full_tag("NAME",6,false,$cha_mes->name));       
                fwrite ($bf,full_tag("DESCRIPTION",6,false,$cha_mes->description));       
                fwrite ($bf,full_tag("TIME",6,false,$cha_mes->time));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("TOPICSELECTION_TOPICS",4,true));
        }
        return $status;
    }
    
    
    function topicselection_backup_topicselection_sessions ($bf,$preferences,$topicselection) {

        global $CFG;

        $status = true;

        $datas = get_records("topicselection_sessions", 'instance', $topicselection->id);
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("TOPICSELECTION_SESSIONS",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("INSTANCE",6,false,$cha_mes->instance));       
                fwrite ($bf,full_tag("NAME",6,false,$cha_mes->name));       
                fwrite ($bf,full_tag("DESCRIPTION",6,false,$cha_mes->description));       
                fwrite ($bf,full_tag("TIME",6,false,$cha_mes->time));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("TOPICSELECTION_SESSIONS",4,true));
        }
        return $status;
    }
    
    
    function topicselection_backup_topicselection_topicuser ($bf,$preferences,$topicselection) {

        global $CFG;

        $status = true;

        $datas = get_records("topicselection_topicuser", 'instance', $topicselection->id);
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("TOPICSELECTION_TOPICUSER",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("INSTANCE",6,false,$cha_mes->instance));       
                fwrite ($bf,full_tag("TOPIC",6,false,$cha_mes->topic));       
                fwrite ($bf,full_tag("USERID",6,false,$cha_mes->userid));       
                fwrite ($bf,full_tag("TIME",6,false,$cha_mes->time));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("TOPICSELECTION_TOPICUSER",4,true));
        }
        return $status;
    }
    
    
?>