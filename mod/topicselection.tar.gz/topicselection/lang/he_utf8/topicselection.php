<?php 

$string['modulename'] = 'תלמיד בוחר משימה';
$string['modulenameplural'] = 'בחירת משימות';

$string['topic'] = 'נושא ';
$string['topicselection_topicselectionfieldset'] = 'הזינו את הנושאי המשימה';
$string['topicselection_topicselectionname'] = 'כותרת';
$string['topicselection_topicselectionintro'] = 'תאור';
$string['topicselection_timeslots'] = 'מאפייני משך זמן המפגש (לא חובה)';

$string['topicselection_numberoftimeslots'] = 'מספר מפגשים';
$string['topicselection_amountoftimeneeded'] = 'כמה זמן דרוש למפגש';
$string['topicselection_numberofsessions'] = 'מספר ימים או מפגשים הדרושים להשלמת המשימה';
$string['topicselection_startandendtime'] = 'תחילת וסיום זמן המפגש';
$string['topicselection_blank5'] = 'הוספת נושאי משימה נוספים';

$string['topicselection_otheroptions'] = 'אפשרויות נוספות';
$string['topicselection_sametopic'] = 'כמה נושאים יכולים תלמידים לבחור?';
$string['topicselection_differenttopic'] = 'כמה פעמים ניתן לבחור נושא מסויים?';

$string['topicselection_owntopic'] = 'האם התלמידים יכולים לבחור בעצמם נושאים?';
$string['topicselection_staddtopic'] = 'או... בחרו נושא חדש :';

$string['topicselection_options'] = 'אפשרויות';

$string['topicselection_youcanchoose'] = '<b>ניתן לבחור</b>';
$string['topicselection_topiccanbechoose'] = '<b>נושא לבחירה</b>';

$string['topicselection_choosetimeslot'] = 'בחרו זמן למפגש:';
$string['topicselection_numbertimeslots'] = 'כמה מפגשים ? ';

$string['topicselection_alltimeslotbusy'] = 'כל זמני המפגשים תפוסים';
$string['wasnotchosenyet'] = 'לא בשימוש';
$string['waschosenby'] = 'נבחר על ידי';
$string['donotusetimeslots'] = 'אין צורך במפגשים';
$string['sessionorday'] = 'מפגש או יום';
$string['topic'] = 'נושא ';
$string['topics'] = 'נושאים ';
$string['slot'] = 'מפגש ';
$string['slots'] = 'מפגשים ';
$string['del'] = 'ביטול ';


?>