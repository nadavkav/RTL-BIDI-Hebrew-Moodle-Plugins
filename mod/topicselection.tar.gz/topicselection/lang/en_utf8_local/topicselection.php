<?php 

$string['modulename'] = 'Topic Selection';
$string['modulenameplural'] = 'topicselection';

$string['topicselection_topicselectionfieldset'] = 'Enter topics below';
$string['topicselection_topicselectionname'] = 'Title';
$string['topicselection_topicselectionintro'] = 'Description';
$string['topicselection_timeslots'] = 'Time slot information (optional)';

$string['topicselection_numberoftimeslots'] = 'Number of time slots needed';
$string['topicselection_amountoftimeneeded'] = 'Amount of time needed for each slot';
$string['topicselection_numberofsessions'] = 'Number of sessions or days to complete all topics';
$string['topicselection_startandendtime'] = 'Start and end time for each time slot';
$string['topicselection_blank5'] = 'Add more topics';

$string['topicselection_otheroptions'] = 'Other options';
$string['topicselection_sametopic'] = 'How many topics can students choose?';
$string['topicselection_differenttopic'] = 'How many times can a topic be choosen?';

$string['topicselection_owntopic'] = 'Can students choose their own topic?';
$string['topicselection_staddtopic'] = 'Or choose your own topic:';

$string['topicselection_options'] = 'Options';

$string['topicselection_youcanchoose'] = '<b>You can choose</b>';
$string['topicselection_topiccanbechoose'] = '<b>Topic can be choosen</b>';

$string['topicselection_choosetimeslot'] = 'Choose a time slot:';
$string['topicselection_numbertimeslots'] = 'How many time slots can students choose?';

$string['topicselection_alltimeslotbusy'] = 'All time slots busy';
$string['wasnotchosenyet'] = 'was not chosen yet.';


?>