# $Id: mysql.php,v 1.0 2007/07/27 16:10:00 Serafim Panov

CREATE TABLE `prefix_topicselection` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL default '',
  `course` varchar(255) NOT NULL default '',
  `teacher` varchar(255) NOT NULL default '',
  `slots` varchar(255) NOT NULL default '',
  `sessions` int(10) unsigned NOT NULL default '1',
  `numbertimeslots` int(10) unsigned NOT NULL default '1',
  `sametopic` int(10) unsigned NOT NULL default '0',
  `owntopic` varchar(255) NOT NULL default 'no',
  `differenttopic` varchar(255) NOT NULL default 'no',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='topicselection';

CREATE TABLE `prefix_topicselection_topics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `instance` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL default '',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='topicselection topics';

CREATE TABLE `prefix_topicselection_sessions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `instance` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL default '',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='topicselection sessions';

CREATE TABLE `prefix_topicselection_topicuser` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `instance` int(10) unsigned NOT NULL default '0',
  `topic` varchar(255) NOT NULL default '',
  `userid` int(10) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='topicselection users - topic';




# --------------------------------------------------------
