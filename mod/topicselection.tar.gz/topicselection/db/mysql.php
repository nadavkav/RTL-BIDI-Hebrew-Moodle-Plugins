<?php // $Id: mysql.php,v 1.0 2007/07/27 16:10:00 Serafim Panov

function topicselection_upgrade($oldversion) {
    global $CFG;

    if ($oldversion < 2007031000) {

       # Do something ...

    }

    return true;
}

?>
