<?php  // $Id: mysql.php,v 1.0 2007/07/27 16:10:00 Serafim Panov

    require_once("../../config.php");
    require_once("lib.php");
    require_once($CFG->libdir . "/formslib.php");
    
    $id = optional_param('id', 0, PARAM_INT); // Course Module ID, or
    $a  = optional_param('a', 0, PARAM_INT);  // topicselection ID
    $t  = optional_param('t', 0, PARAM_INT);  // topicselection ID
    $ttime  = optional_param('ttime', 0, PARAM_INT);  // topicselection ID
    
    $topic = optional_param('topic', 0, PARAM_INT);
    $timeslot = optional_param('timeslot');
    $ttname = optional_param('ttname');

    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }
    
        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }
    
        if (! $topicselection = get_record("topicselection", "id", $cm->instance)) {
            error("Course module is incorrect");
        }

    } else {
        if (! $topicselection = get_record("topicselection", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $topicselection->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("topicselection", $topicselection->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }

    require_login($course->id);

    add_to_log($course->id, "topicselection", "view", "view.php?id=$id", "$cm->instance");

/// Print the page header

    if ($course->category) {
        $navigation = "<a href=\"../../course/view.php?id=$course->id\">$course->shortname</a> ->";
    } else {
        $navigation = '';
    }
    
    $topicselection->name = get_string('modulename','topicselection');
    $strtopicselection = '['.get_string('modulename','topicselection').']';

    print_header("$course->shortname: $topicselection->name", "$course->fullname",
                 "$navigation <a href=index.php?id=$course->id>$strtopicselections</a> -> $topicselection->name", 
                  "", "", true, update_module_button($id, $course->id, $strtopicselection), 
                  navmenu($course));
                  
    if ($a == "del") {
        if ($ttime != 0) {
            $topicdata = get_record ("topicselection_sessions", "instance", $cm->instance, "name", $ttime);
            $topicdata->description = "";
            update_record ("topicselection_sessions", $topicdata);
            
            if ($topicselection->slots != 0) {
                delete_records ("topicselection_topicuser", "topic", $t, "userid", $USER->id, "time", $ttime);
            }
            else
            {
                delete_records ("topicselection_topicuser", "topic", $t, "userid", $USER->id);
            }
        }
        else
        {
            delete_records ("topicselection_topics", "id", $t, "description", $USER->id);
        } 
    }
                  
    if ($topic && empty($ttname)) {
        if (empty($timeslot) && $topicselection->slots > 0) {
            notice("Please choose time slot", 'view.php?id=' . $id);
        }
        else if (count($timeslot) > $topicselection->numbertimeslots) {
            notice("You can choose only " . $topicselection->numbertimeslots . " time slots", 'view.php?id=' . $id);
        }
        else
        {
            foreach ($timeslot as $timeslotkey => $timeslotvalue) {
                $checktopictimeslot = get_record ("topicselection_sessions", "instance", $cm->instance, "name", $timeslotkey);
            
                if (empty($checktopictimeslot->description)) {
                    $checknumberoftopic = count_records ("topicselection_topicuser", "topic", $topic);
                
                    if ($checknumberoftopic < $topicselection->differenttopic) {
                        $addtopic = new object;
                        $addtopic->instance = $cm->instance;
                        $addtopic->topic = $topic;
                        $addtopic->userid = $USER->id;
                        if ($topicselection->slots != 0) {
                            $addtopic->time = $timeslotkey;
                        }
                    
                        $idtopicuser = insert_record("topicselection_topicuser", $addtopic);
                        
                        $topicdata = get_record ("topicselection_sessions", "instance", $cm->instance, "name", $timeslotkey);
                        $topicdata->description = $idtopicuser;
                        
                        update_record ("topicselection_sessions", $topicdata);
                        
                    }
                    else
                    {
                        notice("This topic can be seleced only $topicselection->differenttopic time. Please choose other topic", 'view.php?id=' . $id);
                    }
                    
                }
                else
                {
                    if ($topicselection->slots != 0) {
                        notice("Please choose other time slot", 'view.php?id=' . $id);
                    }
                    else
                    {
                        notice("Please choose other topic", 'view.php?id=' . $id);
                    }
                }
                
            }
        }
    
    } 
    else if ($topic && $ttname)
    {
    
        if (empty($timeslot) && $topicselection->slots > 0) {
            notice("Please choose time slot", 'view.php?id=' . $id);
        }
        else if (count($timeslot) > $topicselection->numbertimeslots) {
            notice("You can choose only " . $topicselection->numbertimeslots . " time slots", 'view.php?id=' . $id);
        }
        else
        {
            foreach ($timeslot as $timeslotkey => $timeslotvalue) {
                
                $addtopic = new object;
                $addtopic->instance = $cm->instance;
                $addtopic->name = $ttname;
                $idnewt = insert_record("topicselection_topics", $addtopic);
                
                $addtopic = new object;
                $addtopic->instance = $cm->instance;
                $addtopic->topic = $idnewt;
                $addtopic->userid = $USER->id;
                if ($topicselection->slots != 0) {
                    $addtopic->time = $timeslotkey;
                }
        
                $idtopicuser = insert_record("topicselection_topicuser", $addtopic);
               
                $topicdata = get_record ("topicselection_sessions", "instance", $cm->instance, "name", $timeslotkey);
                $topicdata->description = $idtopicuser;
                     
                update_record ("topicselection_sessions", $topicdata);
                
            }
        }
        
    }
   
    //print_simple_box_start('left', '100%', '#ffffff', 10);
    //                
    
    echo "<br /><br />";
   
    $topics = get_records ("topicselection_topics", "instance", $cm->instance, "id");
    $sessions = get_records ("topicselection_sessions", "instance", $cm->instance, "id");
    
    $noneed = 0;
    $noneedtimeslots = Array ();
   
    $table->head = array (get_string('topic','topicselection'), get_string('waschosenby','topicselection'));
    $table->align = array ("left", "left");
    $table->width = "100%";

    foreach ($topics as $topic) {
        $topicuser = get_records ("topicselection_topicuser", "topic", $topic->id, "id");
        if (!$topicuser) {
            $choosed = get_string('wasnotchosenyet','topicselection');
            $notchoosed[$topic->id] = $topic->name;
        }
        else
        {
            $userscount = 0;
            foreach ($topicuser as $topicuser_) {
                $userscount ++;
                $userdata = get_record ("user", "id", $topicuser_->userid);
                //USER CAN CHOOSE ONLY 1 TIME
                if ($topicuser_->userid == $USER->id) 
                {
                    $noneed ++;
                }
                $choosed   .= $userdata->firstname . " " . $userdata->lastname . ' '; 
                
                if ($topicselection->slots != 0) {
                    $topicdate = date('d M Y  H:i', $topicuser_->time) . " ";
                    $choosed   .= "(".$topicdate.")";
                }
                
                if ($topicuser_->userid == $USER->id) 
                {
                    if ($topicuser_->time == 0) {
                        $topicuser_->time = 1;
                    }
                    $choosed .= ' {<a href="view.php?id='.$id.'&a=del&t='.$topic->id.'&ttime='.$topicuser_->time.'">'.get_string("del","topicselection").'</a>} ';
                }
                $choosed .= '<br />';
                
                $noneedtimeslots[] = $topicuser_->time;
            }
            
            if (count($topicuser) < $topicselection->differenttopic) {
                $notchoosed[$topic->id] = $topic->name;
            }
        }
        
        if ($topic->description == $USER->id) {
            $topic->name = $topic->name . ' {<a href="view.php?id='.$id.'&a=del&t='.$topic->id.'">del</a>} ';
        }
        
        $table->data[] = array ($topic->name, $choosed);
        $choosed   = "";
        $topicdate = "";
    }

    if (!empty($table)) {
        print_table($table);
    }
    



    class mod_topicselection_details_form extends moodleform {
    
        function definition() {
            global $notchoosed, $sessions, $topicselection, $noneedtimeslots;
        
            $mform    =& $this->_form;

            $mform->addElement('header', 'topicselection_otheroptions', get_string('topicselection_options', 'topicselection')); 
            
            if ($topicselection->sametopic != 0 && $topicselection->sametopic == 1) {
                $choosesametopictext = "1 topic";
                $mform->addElement('static', null, get_string('topicselection_youcanchoose', 'topicselection'), $choosesametopictext); 
            }
            else if ($topicselection->sametopic != 0)
            {
                $choosesametopictext = $topicselection->sametopic . ' topics';
                $mform->addElement('static', null, get_string('topicselection_youcanchoose', 'topicselection'), $choosesametopictext); 
            }
            
            if ($topicselection->sametopic < $topicselection->numbertimeslots) {
                $topicselection->numbertimeslots = $topicselection->sametopic;
            }
            
            if ($topicselection->numbertimeslots == 1) {
                $choosesametopictext = "1 time slot";
                $mform->addElement('static', null, get_string('topicselection_youcanchoose', 'topicselection'), $choosesametopictext); 
            }
            else
            {
                $choosesametopictext = $topicselection->numbertimeslots . ' times slots';
                $mform->addElement('static', null, get_string('topicselection_youcanchoose', 'topicselection'), $choosesametopictext); 
            }
            

            if (count($notchoosed) > 0) {
                $mform->addElement('select', 'topic', 'Choose a topic:', $notchoosed);
            }
            
            if ($topicselection->owntopic == "yes") {
                $mform->addElement('text', 'ttname', get_string('topicselection_staddtopic', 'topicselection'), array('size'=>'64')); 
            }

            $i = 0;
            foreach ($sessions as $session) {
                if (!in_array ($session->name, $noneedtimeslots)) {
                    $i ++;
                    if ($i == 1) {
                        $sessiontimeslottext = get_string('topicselection_choosetimeslot', 'topicselection');
                    }
                    else
                    {
                        $sessiontimeslottext = "";
                    }
                
                    $mform->addElement('checkbox', 'timeslot['.$session->name.']', $sessiontimeslottext, date('d M Y  H:i', $session->name));
                    $mform->setDefault('timeslot['.$session->name.']', 0);
                }
            }
            
            if ($i == 0) {
                $mform->addElement('static', null, get_string('topicselection_choosetimeslot', 'topicselection'), get_string('topicselection_alltimeslotbusy', 'topicselection')); 
            }
            
            // buttons
            $this->add_action_buttons(false);
        }
    }
    
    
    if ($noneed < $topicselection->sametopic) {
        $mform = new mod_topicselection_details_form('view.php?id=' . $id);
        $mform->display();
    }
    
    //print_simple_box_end();
                  
    

    print_footer($course);

?>