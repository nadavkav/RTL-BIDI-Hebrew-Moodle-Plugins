<?php //$Id

/**
 * This file defines de main topicselection configuration form
 * It uses the standard core Moodle (>1.8) formslib. For
 * more info about them, please visit:
 * 
 * http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * The form must provide support for, at least these fields:
 *   - name: text element of 64cc max
 *
 * Also, it's usual to use these fields:
 *   - intro: one htmlarea element to describe the activity
 *            (will be showed in the list of activities of
 *             topicselection type (index.php) and in the header 
 *             of the topicselection main page (view.php).
 *   - introformat: The format used to write the contents
 *             of the intro field. It automatically defaults 
 *             to HTML when the htmleditor is used and can be
 *             manually selected if the htmleditor is not used
 *             (standard formats are: MOODLE, HTML, PLAIN, MARKDOWN)
 *             See lib/weblib.php Constants and the format_text()
 *             function for more info
 */

require_once ('moodleform_mod.php');

$update      = optional_param('update'); 

if ($update) {
    if (! $cm = get_record("course_modules", "id", $update)) {
        error("Course Module ID was incorrect");
    }

    $topicsdata = get_records ('topicselection_topics', 'instance', $cm->instance, 'id');
    
    foreach ($topicsdata as $topicsdata_) {
        $topicsdatat[] = $topicsdata_->name;
    }
    
    $sessionsdata = get_records ('topicselection_sessions', 'instance', $cm->instance, 'id');
    
    foreach ($sessionsdata as $sessionsdata_) {
        $sessionsdatat[] = $sessionsdata_->name;
    }
}

class mod_topicselection_mod_form extends moodleform_mod {

    function definition() {

        global $COURSE, $CFG, $topicsdatat, $sessionsdatat;
        
        $addtopics   = optional_param('addtopics'); 
        $topics      = optional_param('topics'); 
        $update      = optional_param('update'); 
        $return      = optional_param('return'); 
        $slots       = optional_param('slots'); 
        
        if (empty($addtopics)) {
            $addtopics = 10;
            if ($update && $addtopics < count($topicsdatat)) {
                $addtopics = count ($topicsdatat);
            }
        }
        else if ($_SESSION['SESSION']->topicselection_slots == $slots)
        {
        echo "";
            $addtopics = count($topics) + 5;
        }
        else
        {
            $addtopics = count($topics);
        }
        
        $mform    =& $this->_form;
        
        if ($update && !isset($slots)) {
            $slots = count($sessionsdatat);
        }
        
        if (!empty($slots)) {
            $_SESSION['SESSION']->topicselection_slots = $slots;
        }
        else
        {
            $slots = 0;
            $_SESSION['SESSION']->topicselection_slots = $slots;
        }

//-------------------------------------------------------------------------------
        $mform->addElement('header', 'general', get_string('general', 'form'));

        $mform->addElement('text', 'name', get_string('topicselection_topicselectionname', 'topicselection'), array('size'=>'64'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        $mform->addElement('htmleditor', 'intro', get_string('topicselection_topicselectionintro', 'topicselection'));
        //$mform->setType('intro', PARAM_RAW);
        //$mform->addRule('intro', get_string('required'), 'required', null, 'client');
//-------------------------------------------------------------------------------

        $mform->addElement('header', 'topicselection_topicselectionfieldset', get_string('topicselection_topicselectionfieldset', 'topicselection'));
        
        for ($i=1; $i <= $addtopics; $i++) {
            $mform->addElement('text', 'topics['.$i.']', get_string('topic','topicselection') . $i . ' ', array('size'=>'64'));
            $mform->setType('name', PARAM_TEXT);
            if ($update && !empty($topicsdatat[$i - 1])) {
                $mform->setDefault('topics['.$i.']', $topicsdatat[$i - 1]);
            }
        }
        
        
        $this->repeat_elements($repeated, $repeatsatstart, $repeatedoptions, 'noanswers', 'addtopics', '5', get_string('topicselection_blank5', 'topicselection'));
        
        //---------------------------------------
        
        $mform->addElement('header', 'topicselection_timeslots', get_string('topicselection_timeslots', 'topicselection'));
        
        $slots1[0] = get_string('donotusetimeslots','topicselection');
        
        for ($i=1; $i <= 100;$i++) {
            if ($i == 1) {
                $slots1[$i] = $i .' '. get_string('slot','topicselection');
            }
            else
            {
                $slots1[$i] = $i .' '. get_string('slots','topicselection');
            }
        }
        
        
        for ($i=1; $i <= 100;$i++) {
            $sessions1[$i] = $i .' '. get_string('sessionorday','topicselection');
        }
        
        for ($i=1; $i <= 10;$i++) {
            $timeofsloth1[$i] = $i .' '. get_string('hours');
        }
        
        for ($i=1; $i <= 60;$i++) {
            $timeofslotm1[$i] = $i .' '. get_string('minute');
        }
        
        for ($i=1; $i <= 20;$i++) {
            if ($i == 1) {
                $sametopic1[$i] = $i .' '. get_string('topic','topicselection');
            }
            else
            {
                $sametopic1[$i] = $i .' '. get_string('topics','topicselection');
            }
        }
        
        for ($i=0; $i <= 100;$i++) {
            $howtimestopicchoosen[$i] = $i;
        }
        
        for ($i=1; $i <= 20;$i++) {
            $numbertimeslots1[$i] = $i;
        }
        
        $mform->addElement('select', 'slots', get_string('topicselection_numberoftimeslots', 'topicselection'), $slots1, array('onChange'=>'skipClientValidation = true; document.getElementById(\'id_addtopics\').click();'));
        //$mform->setDefault('slots', 10); 
        //array('onChange'=>'skipClientValidation = true; document.getElementById(\'mform1\').submit(); return true;')
        
        //$mform->addElement('select', 'timelimith', get_string('topicselection_amountoftimeneeded', 'topicselection'), $timeofsloth1);
        //$mform->addElement('select', 'timelimitm', '', $timeofslotm1);
        
        //$mform->addElement('select', 'sessions', get_string('topicselection_numberofsessions', 'topicselection'), $sessions1);
        
        //$mform->addElement('static', 'label2', '<br /><br />', '');
        
        //$mform->addElement('static', 'label2', get_string('topicselection_startandendtime', 'topicselection'), '');
        
        if ($slots > 0) {
            for ($i=1; $i <= $slots; $i++) {
                if ($i == 1) {
                    $nameoffield = get_string('topicselection_startandendtime', 'topicselection');
                }
                else
                {
                    $nameoffield = "";
                }
                $mform->addElement('date_time_selector', 'timeslot['.$i.']', $nameoffield, array('step'=>1));
                if ($update && !empty($sessionsdatat[$i - 1])) {
                    $mform->setDefault('timeslot['.$i.']', $sessionsdatat[$i - 1]);
                } 
                else
                {
                    $mform->setDefault('timeslot['.$i.']', time());
                }
            }
        }
        
        //-----------------------------------------------------------------------
        $mform->addElement('header', 'topicselection_otheroptions', get_string('topicselection_otheroptions', 'topicselection'));
        $mform->addElement('select', 'numbertimeslots', get_string('topicselection_numbertimeslots', 'topicselection'), $numbertimeslots1);
        $mform->addElement('select', 'sametopic', get_string('topicselection_sametopic', 'topicselection'), $sametopic1);
        $mform->addElement('select', 'differenttopic', get_string('topicselection_differenttopic', 'topicselection'), $howtimestopicchoosen);
        $mform->addElement('select', 'owntopic', get_string('topicselection_owntopic', 'topicselection'), Array( 'yes' => get_string('yes') , 'no' => get_string('no') ));
        

//-------------------------------------------------------------------------------
        $this->standard_coursemodule_elements();
//-------------------------------------------------------------------------------
        $this->add_action_buttons();

    }
}

?>
