<?php  // $Id: mysql.php,v 1.0 2007/07/27 16:10:00 Serafim Panov

function topicselection_add_instance($topicselection) {

global $CFG, $USER;
    
    $id = $topicselection->courseid;
    $topicselection->time = time();
    $topicselection->teacher  = $USER->id;
    $topicselection->topics = $_POST['topics'];
    
    $instance = insert_record("topicselection", $topicselection);
    
    foreach ($topicselection->topics as $topicdata) {
        if (!empty($topicdata)) {
            $topics = new object;
            $topics->instance = $instance;
            $topics->name     = $topicdata;
            $topics->time     = time();
            insert_record("topicselection_topics", $topics);
        }
    }
    
    foreach ($topicselection as $key_ => $value_) {
        if (strstr($key_, 'timeslot[')) {
            $sessions = new object;
            $sessions->instance = $instance;
            $sessions->name     = $value_;
            $sessions->time     = time();
            insert_record("topicselection_sessions", $sessions);
        }
    }
    
    
    return $instance;
}




function topicselection_update_instance($topicselection, $id) {
    global $CFG;
    
    $topicselection->topics = $_POST['topics'];
    
    $topicselection->id = $topicselection->instance;
    $topicselection->time = time();
    $topicselection->teacher  = $USER->id;
    
    delete_records ("topicselection_topics", "instance", $topicselection->instance);
    delete_records ("topicselection_sessions", "instance", $topicselection->instance);
    
    foreach ($topicselection->topics as $topicdata) {
        if (!empty($topicdata)) {
            $topics = new object;
            $topics->instance = $topicselection->instance;
            $topics->name     = $topicdata;
            $topics->time     = time();
            insert_record("topicselection_topics", $topics);
        }
    }
    
    foreach ($topicselection as $key_ => $value_) {
        if (strstr($key_, 'timeslot[')) {
            $sessions = new object;
            $sessions->instance = $topicselection->instance;
            $sessions->name     = $value_;
            $sessions->time     = time();
            insert_record("topicselection_sessions", $sessions);
        }
    }
    
    # May have to add extra stuff in here #

    return update_record("topicselection", $topicselection);
    
}



function topicselection_submit_instance($topicselection, $id) {

    global $CFG;

}



function topicselection_delete_instance($id) {

    global $CFG;

    if (! $topicselection = get_record("topicselection", "id", "$id")) {
        return false;
    }

    $result = true;

    # Delete any dependent records here #

    if (! delete_records("topicselection", "id", "$topicselection->id")) {
        $result = false;
    }

    return $result;
}




function topicselection_user_outline($course, $user, $mod, $topicselection) {
    return $return;
}




function topicselection_user_complete($course, $user, $mod, $topicselection) {
    return true;
}




function topicselection_print_recent_activity($course, $isteacher, $timestart) {
    global $CFG;

    return false;  //  True if anything was printed, otherwise false 
}




function topicselection_cron () {
    global $CFG;

    return true;
}




function topicselection_grades($topicselectionid) {
   return NULL;
}




function topicselection_get_participants($topicselectionid) {
    global $CFG;
    return get_records_sql("SELECT * FROM ".$CFG->prefix."user");
}




function topicselection_scale_used ($topicselectionid,$scaleid) {
    $return = false;
   
    return $return;
}



?>
