<?php //$Id: backuplib.php,v 1.0 2007/06/17 03:45:29 SerafimPanov Exp $
    //This php script contains all the stuff to backup/restore
    //topicselection mods

    //
    // Meaning: pk->primary key field of the table
    //          fk->foreign key to link with parent
    //          nt->nested field (recursive data)
    //          CL->course level info
    //          UL->user level info
    //          files->table may have files)
    //
    //-----------------------------------------------------------
    //This function executes all the restore procedure about this mod
    function topicselection_restore_mods($mod,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get record from backup_ids
        $data = backup_getid($restore->backup_unique_code,$mod->modtype,$mod->id);

        if ($data) {

            //Now get completed xmlized object   
            $info = $data->info;

            //traverse_xmlize($info);                                                                     //Debug
            //print_object ($GLOBALS['traverse_array']);                                                  //Debug
            //$GLOBALS['traverse_array']="";                                                              //Debug
            // if necessary, write to restorelog and adjust date/time fields
            if ($restore->course_startdateoffset) {
                restore_log_date_changes('topicselection', $restore, $info['MOD']['#'], array('TOPICSELECTIONTIME'));
            }
            //Now, build the topicselection record structure
            $topicselection->course = $restore->course_id;
            $topicselection->teacher = backup_todb($info['MOD']['#']['TEACHER']['0']['#']);
            $topicselection->name = backup_todb($info['MOD']['#']['NAME']['0']['#']);
            $topicselection->intro = backup_todb($info['MOD']['#']['INTRO']['0']['#']);
            $topicselection->slots = backup_todb($info['MOD']['#']['SLOTS']['0']['#']);
            $topicselection->sessions = backup_todb($info['MOD']['#']['SESSIONS']['0']['#']);
            $topicselection->numbertimeslots = backup_todb($info['MOD']['#']['NUMBERTIMESLOTS']['0']['#']);
            $topicselection->sametopic = backup_todb($info['MOD']['#']['SAMETOPIC']['0']['#']);
            $topicselection->owntopic = backup_todb($info['MOD']['#']['OWNTOPIC']['0']['#']);
            $topicselection->differenttopic = backup_todb($info['MOD']['#']['DIFFERENTTOPIC']['0']['#']);
            $topicselection->time = backup_todb($info['MOD']['#']['TIME']['0']['#']);
            
            $user = backup_getid($restore->backup_unique_code,"user",$topicselection->teacher);
            if ($user) {
                $topicselection->teacher = $user->new_id;
            }

            //The structure is equal to the db, so insert the topicselection
            $newid = insert_record ("topicselection",$topicselection);

            //Do some output     
            //if (!defined('RESTORE_SILENTLY')) {
            //    echo "<li>".get_string("modulename","topicselection")." \"".format_string(stripslashes($topicselection->name),true)."\"</li>";
            //}
            //backup_flush(300);

            if ($newid) {
                //We have the newid, update backup_ids
                backup_putid($restore->backup_unique_code,$mod->modtype, $mod->id, $newid);
                //Now check if want to restore user data and do it.
                if (restore_userdata_selected($restore,'topicselection',$mod->id)) {
                    //Restore topicselection_messages
                    topicselection_restore_topicselection_topics ($mod->id, $newid, $info, $restore);
                    topicselection_restore_topicselection_topicuser ($mod->id, $newid, $info, $restore);
                    topicselection_restore_topicselection_sessions ($mod->id, $newid, $info, $restore);
                }
            } else {
                $status = false;
            }
        } else {
            $status = false;
        }

        return $status;
    }


    
    function topicselection_restore_topicselection_topics ($old_topicselection_id, $new_topicselection_id,$info,$restore) {

        global $CFG, $oldidarray;

        $status = true;
        
        //Get the messages array 
        $messages = $info['MOD']['#']['TOPICSELECTION_TOPICS']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the topicselection_MESSAGES record structure
            
            $message->instance = $new_topicselection_id;
            $message->name = backup_todb($mes_info['#']['NAME']['0']['#']);
            $message->description = backup_todb($mes_info['#']['DESCRIPTION']['0']['#']);
            $message->time = backup_todb($mes_info['#']['TIME']['0']['#']);
            
            if (!empty($message->description)) {
                $user = backup_getid($restore->backup_unique_code,"user",$message->description);
                if ($user) {
                    $message->description = $user->new_id;
                }
            }

            $newidm = insert_record ("topicselection_topics",$message);
            $oldidarray[$old_topicselection_id]['topicselection_topics'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    
    
    
    function topicselection_restore_topicselection_topicuser ($old_topicselection_id, $new_topicselection_id,$info,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get the messages array 
        $messages = $info['MOD']['#']['TOPICSELECTION_TOPICUSER']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the topicselection_MESSAGES record structure
            
            $message->instance = $new_topicselection_id;
            $message->topic = $oldidarray[$old_topicselection_id]['topicselection_topics'][backup_todb($mes_info['#']['TOPIC']['0']['#'])];
            $message->userid = backup_todb($mes_info['#']['USERID']['0']['#']);
            $message->time = backup_todb($mes_info['#']['TIME']['0']['#']);
            
            $user = backup_getid($restore->backup_unique_code,"user",$message->userid);
            if ($user) {
                $message->userid = $user->new_id;
            }

            $newidm = insert_record ("topicselection_topicuser",$message);
            $oldidarray[$old_topicselection_id]['topicselection_topicuser'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    
    
    function topicselection_restore_topicselection_sessions ($old_topicselection_id, $new_topicselection_id,$info,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get the messages array 
        $messages = $info['MOD']['#']['TOPICSELECTION_SESSIONS']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the topicselection_MESSAGES record structure
            
            $message->instance = $new_topicselection_id;
            $message->name = backup_todb($mes_info['#']['NAME']['0']['#']);
            $descr  = backup_todb($mes_info['#']['DESCRIPTION']['0']['#']);
            
            if (!empty($descr)) {
                $message->description = $oldidarray[$old_topicselection_id]['topicselection_topicuser'][backup_todb($mes_info['#']['DESCRIPTION']['0']['#'])];
            }
            else
            {
                $message->description = "";
            }
            
            $message->time = backup_todb($mes_info['#']['TIME']['0']['#']);

            $newidm = insert_record ("topicselection_sessions",$message);
            $oldidarray[$old_topicselection_id]['topicselection_sessions'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    

    function topicselection_restore_logs($restore,$log) {

        $status = true;

        return $status;
    }
    
?>
