<?php // $Id: mysql.php,v 1.0 2007/07/27 16:10:00 Serafim Panov

$module->version  = 2007031000;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
