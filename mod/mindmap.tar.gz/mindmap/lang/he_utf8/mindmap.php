<?php

$string['mindmap'] = 'מפת חשיבה';

$string['modulename'] = 'מפת חשיבה';
$string['modulenameplural'] = 'מפות חשיבה';

$string['mindmapfieldset'] = 'דוגמת שדה ריקה';
$string['mindmapintro'] = 'מבוא למפת חשיבה';
$string['mindmapname'] = 'שם מפת החשיבה';
$string['editable'] = 'עריכה';

?>
