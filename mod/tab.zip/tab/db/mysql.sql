# $Id: mysql.sql,v 1.2 2006/08/28 16:41:20 mark-nielsen Exp $
# This file contains a complete database schema for all the 
# tables used by this module, written in SQL

# It may also contain INSERT statements for particular data 
# that may be used, especially new entries in the table log_display

