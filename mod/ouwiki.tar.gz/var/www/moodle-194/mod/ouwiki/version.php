<?php

$module->version  = 2010042201;
$module->requires = 2007101509;
$module->cron     = 0;

$module->displayversion = 'Unstable development version (use at own risk)';
?>
