<?php



 /*

 * @copyright &copy; 2007 University of London Computer Centre

 * @author http://www.ulcc.ac.uk, http://moodle.ulcc.ac.uk

 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License

 * @package ILP

 * @version 1.0

 */



$module->version  = 2008072607;  // The current module version (Date: YYYYMMDDXX)

$module->cron     = 0;           // Period for cron to check this module (secs)



?>