<?php // $Id: version.php,v 1.7 2009/03/25 22:36:36 deeknow Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2009022401;
$module->requires = 2007101509;  // Requires this Moodle version
$module->cron     = 60;

?>
