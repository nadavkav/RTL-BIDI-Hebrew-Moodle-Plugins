Dialogue Module
---------------

Originally released By Ray Kingdon
Subsequent contributions by others

Download latest version via CVS:
   http://cvs.moodle.org/contrib/plugins/mod/dialogue/

Ongoing discussion for the module carried out here:
   http://moodle.org/mod/forum/view.php?id=854
   http://tracker.moodle.org/browse/CONTRIB-412