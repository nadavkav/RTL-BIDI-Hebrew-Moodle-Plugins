<?php

$string['allowanonymouspost'] = 'Allow post question as anonymous';
$string['anonymous'] = 'Anonymous';
$string['authorinfo'] = 'Posted by $a->user at $a->time';
$string['displayasanonymous'] = 'Display as anonymous';
$string['heat'] = 'Heat';
$string['hotquestion'] = 'hotquestion';
$string['hotquestionintro'] = 'Topic';
$string['hotquestionname'] = 'Activity Name';
$string['inputquestion'] = 'Submit your question here:';
$string['invalidquestion'] = 'Empty questions are ignored.';
$string['modulename'] = 'Hot Question';
$string['modulenameplural'] = 'Hot Questions';
$string['newround'] = 'Open a new round';
$string['newroundconfirm'] = 'Are you sure? (Existing questions and votes will be archived)';
$string['noquestions'] = 'No question now.';
$string['question'] = 'Questions';
$string['questionsubmitted'] = 'Your question has been submitted successfully.';
$string['round'] = 'Round $a';
$string['vote'] = 'Vote';

?>
