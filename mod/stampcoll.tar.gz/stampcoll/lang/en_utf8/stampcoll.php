<?PHP // $Id: stampcoll.php,v 1.7 2008/04/11 22:17:22 mudrd8mz Exp $ 

$string['addstampbutton'] = 'Add';
$string['confirmdel'] = 'Do you really want to delete this stamp?';
$string['deletestamp'] = 'Delete stamp';
$string['displayzero'] = 'Display users with no stamps';
$string['editstamps'] = 'Edit stamps';
$string['givenby'] = 'From: $a';
$string['givento'] = 'To: $a';
$string['modulenameplural'] = 'Stamp collections';
$string['modulename'] = 'Stamp collection';
$string['nostampscollected'] = 'No stamps collected';
$string['nostampsincollection'] = 'No stamps in this collection';
$string['notallowedtoviewstamps'] = 'You are not allowed to view stamps in this collection';
$string['nousers'] = 'No users';
$string['numberofcollectedstamps'] = 'Number of collected stamps: $a';
$string['numberofstamps'] = 'Stamps';
$string['numberofyourstamps'] = 'Number of your stamps: $a';
$string['ownstamps'] = 'Own stamps';
$string['showupdateforms'] = 'Show forms to update stamps';
$string['stampcoll:collectstamps'] = 'Collect stamps';
$string['stampcoll:givestamps'] = 'Give stamps';
$string['stampcoll:managestamps'] = 'Manage stamps';
$string['stampcoll:viewotherstamps'] = 'View others\' stamps';
$string['stampcoll:viewownstamps'] = 'View own stamps';
$string['stampimageinfo'] = 'Recommended size is 35x35 pixels';
$string['stampimage'] = 'Stamp image';
$string['studentsperpage'] = 'Students per page';
$string['timemodified'] = 'Last change';
$string['updatestampbutton'] = 'Update';
$string['viewstamps'] = 'View stamps';
?>
