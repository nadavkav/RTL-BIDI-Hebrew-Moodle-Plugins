<?PHP // $Id: stampcoll.php,v 1.1 2008/04/27 17:38:36 mudrd8mz Exp $ 

$string['addstampbutton'] = 'A�adir';
$string['confirmdel'] = '�Realmente quieres borrar este sello';
$string['deletestamp'] = 'Borrar sello';
$string['displayzero'] = 'Mostrar usuarios sin sellos';
$string['editstamps'] = 'Editar sellos';
$string['givenby'] = 'Desde: $a';
$string['givento'] = 'Para: $a';
$string['modulenameplural'] = 'Colecci�n de sellos';
$string['modulename'] = 'Colecci�n de sellos';
$string['nostampscollected'] = 'No hay sellos';
$string['nostampsincollection'] = 'No hay sellos en esta colecci�n';
$string['notallowedtoviewstamps'] = 'No est�s autorizado para ver sellos en esta colecci�n';
$string['nousers'] = 'No hay usuarios';
$string['numberofcollectedstamps'] = 'Sellos coleccionados: $a';
$string['numberofstamps'] = 'Sellos';
$string['numberofyourstamps'] = 'N�mero de sellos: $a';
$string['ownstamps'] = 'Sellos propios';
$string['showupdateforms'] = 'Show forms to update stamps';
$string['stampcoll:collectstamps'] = 'Collect stamps';
$string['stampcoll:givestamps'] = 'Give stamps';
$string['stampcoll:managestamps'] = 'Gestionar sellos';
$string['stampcoll:viewotherstamps'] = 'Ver otros\' stamps';
$string['stampcoll:viewownstamps'] = 'Ver sellos propios';
$string['stampimageinfo'] = 'Tama�o recomendado 35x35 pixels';
$string['stampimage'] = 'Imagen del sello';
$string['studentsperpage'] = 'Alumnos por p�gina';
$string['timemodified'] = '�ltimo cambio';
$string['updatestampbutton'] = 'Actualizar';
$string['viewstamps'] = 'Ver sellos';
?>
