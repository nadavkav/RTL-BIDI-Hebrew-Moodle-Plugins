NWiki/DFWiki is a project conceived and leaded by Ludo (Marc Alier,
malier@lsi.upc.edu) to build a new wiki wiki module for Moodle. 
It started on Feb 2005 and still goes on now at late 2007.

This alternative Wiki module (called also new wiki or NWiki) is the evolution of
DFWiki to fit in Moodle 1.6/1.7/1.8./1.9/2.0 replacing the standard wiki module.
The Moodle roadmap places NWiki as the official Wiki module for Moodle 2.0.
   
All the NWiki/DFWiki development has been done within the frame of degree
projects in the Computer Science Engineering studies in the FIB school
(http://www.fib.upc.edu) of the UPC University (http://www.upc.edu) in
Barcelona, Spain.

The main developers that have worked in this project are:
* Ferran Recio
* David Castro
* Jordi Piguillem Poch
* Bernardino Todoli

And a growing number of students that contributes to this project.

NWiki has two parallel projects:

1. The Nwiki Course, which allows to place a wiki in the main course page (even
in the Moodle main course).

2. The WikiBook Module that allows to create a ordered and due noted sequence of
pages out of a chaotic wiki. It also allows to place metadata, and export to
formats like docBook, pdf, scorm and so on.

NWiki/DFWiki has the same license as Moodle, that is, the GNU GPL v2 license.

Find NWiki news in www.moodle.org in "using moodle" > wiki forum and in the 
NWiki home page at http://morfeo.upc.es/crom/course/view.php?id=4

Thank you for using DF/NWiki!

Ludo (Marc Alier) 

malier@lsi.upc.edu
http://www.lsi.upc.edu/~malier
