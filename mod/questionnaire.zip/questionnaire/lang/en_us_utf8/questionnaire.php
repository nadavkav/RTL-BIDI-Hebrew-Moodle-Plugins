<?PHP // $Id: questionnaire.php,v 1.2 2007/09/04 20:34:05 joseph_rezeau Exp $ 

$string['dateformatting'] = 'Use the month/day/year format, e.g. for March 14th, 1945:&nbsp; <strong>3/14/1945</strong>';
$string['strfdate'] = '%%m/%%d/%%Y';
$string['strfdateformatcsv'] = 'm/d/Y H:i:s';
?>