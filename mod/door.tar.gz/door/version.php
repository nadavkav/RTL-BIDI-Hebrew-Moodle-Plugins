<?php // $Id: version.php,v 1.27 2005/04/14 21:10:39 danmarsden Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007102900;
$module->requires = 2007021500;;  // Requires this Moodle version
$module->cron     = 0;

?>