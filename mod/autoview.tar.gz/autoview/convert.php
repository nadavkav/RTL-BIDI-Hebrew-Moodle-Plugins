<?php
/**
* This code is copyright to EuroMotor AutoTrain LLP and is licenced under the GNU GPL Licence
**/

 require_once("../../config.php");
 require_once("lib.php");

 $l=required_param('id',PARAM_INT);
 $url=required_param('url',PARAM_PATH);
 $swf=optional_param('swf', 'false', PARAM_TEXT);
 $pdf=optional_param('pdf', 'false', PARAM_TEXT);
 $jpg=optional_param('jpg', 'false', PARAM_TEXT);

 if (! $autoview = get_record("autoview", "id", $l))
  error("Course module is incorrect");

 if (! $course = get_record("course", "id", $autoview->course))
  error("Course is misconfigured");

 if (! $cm = get_coursemodule_from_instance("autoview", $autoview->id, $course->id))
  error("Course Module ID was incorrect");

 require_login($course->id);

 if (testPeclHttp()==false)
 {
  die(get_string("pecl_http_warn", "autoview"));
 }

 $vresource=$CFG->wwwroot.'/mod/autoview/vresource/';

 $context = get_context_instance(CONTEXT_MODULE, $cm->id);

 if (has_capability('moodle/legacy:editingteacher', $context))
 {
  $types="";
  if ($swf=="true")
   $types=$types."swf,";
  if ($pdf=="true")
   $types=$types."pdf,";
  if ($jpg=="true")
   $types=$types."jpg";

  $data=array(
   'types' => $types,
   'key' => $CFG->autoview_conversionkey
  );

  $mimetype="application/vnd.ms-powerpoint";

  $files = array(
  array(
    'name' => 'file',
    'type' => $mimetype,
    'file' => $CFG->dataroot.'/'.$course->id.'/'.$url
   )
  );

  $http_response=http_post_fields($CFG->autoview_conversionurl, $data, $files);
  $convertdata=http_parse_message($http_response);

  if ($convertdata->headers["Content-Type"]=="text/plain")
  {
   $params= array(
    'vresource' => $CFG->wwwroot.'/mod/autoview/vresource/',
    'message' => get_string("conversionfailed", "autoview").'. '.$convertdata->body,
    'fname' => '',
    'slidecount' => '0',
    'swf' => '',
    'pdf' => '',
    'jpg' => '');
   echo process_xsl($CFG->dirroot."/mod/autoview/avedit/convert.xml", $CFG->dirroot."/mod/autoview/avedit/convert.xsl", $params);
  }
  else
  {
   $index=stripos($url, '.');

   if ($index<1)
    $index=strlen($url);
   $fname=substr($url,0,$index);
   $newfile=$CFG->dataroot.'/'.$course->id.'/'.$fname.'.zip';

   $fh = fopen($newfile, 'w') or die(get_string("convertsavefailed", "autoview"));
   fwrite($fh,$convertdata->body);
   fclose($fh);

   unzip_file($newfile, '', false);
   unlink($newfile);

   $params= array(
    'vresource' => $CFG->wwwroot.'/mod/autoview/vresource/',
    'message' => get_string("conversiondone", "autoview"),
    'fname' => $fname,
    'swf' => $swf,
    'pdf' => $pdf,
    'jpg' => $jpg);

   $xmlFile=$CFG->dataroot.'/'.$course->id.'/'.$fname.'.xml';
   if (!file_exists($xmlFile))
    echo process_xsl($CFG->dirroot."/mod/autoview/avedit/convert.xml", $CFG->dirroot."/mod/autoview/avedit/convert.xsl", $params);
   else
   {
    echo process_xsl($xmlFile, $CFG->dirroot."/mod/autoview/avedit/convert.xsl", $params);
    unlink($xmlFile);
   }
  }
 }
 ?>

