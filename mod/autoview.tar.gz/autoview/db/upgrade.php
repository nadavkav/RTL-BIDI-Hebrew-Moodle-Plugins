<?php

function xmldb_autoview_upgrade($oldversion=0) {

 if ($oldversion < 2008030310) {
     $table = new XMLDBTable('autoview');
     $field = new XMLDBField('noframe');
     $field->setAttributes(XMLDB_TYPE_INTEGER, '1', true, true, false, false, null, "0", 'configfile');
     return add_field($table, $field);
 }

    return true;
}

?>
