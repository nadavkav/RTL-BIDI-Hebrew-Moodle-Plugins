<?PHP

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of start
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2008030601;  // The current module version (Date: YYYYMMDDXX)
$module->requires = 2006101007;  // Requires this Moodle version
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
