<?PHP // $Id: label.php,v 1.2 2003/11/18 07:28:46 moodler Exp $ 
      // start.php - created with Moodle 1.2 development (2003111400)

$string['autoviewtext'] = 'שם מצגת וידאו';
$string['chooseconfig'] = 'בחירת קובץ הגדרות';
$string['configfile'] = 'קובץ הגדרות';
$string['convertsavefailed'] = 'Could not save converted file';
$string['editbutton'] = 'מצב עריכה';
$string['editoff'] = 'מצב תצוגה';
$string['modulename'] = 'מצגות וידאו';
$string['modulenameplural'] = 'מצגות וידאו';
$string['xmlsavefailed'] = 'Configuration file save failed';
$string['configconversionurl'] = 'Document conversion service URL';
$string['configconversionkey'] = 'Document conversion service access key';
$string['conversiondone'] = 'The document has been converted.';
$string['conversionfailed'] = 'Conversion failed';
$string['xmlhelp']= 'In most cases you will want to use the default configuration file. This will be created for you automatically in the course home directory '.
 'using the resource name as a file name. However, if you have copied an AutoView presentation from another'.
 ' location, uncheck the box and select the .avx configuration file for that presentation here. You may also uncheck the box and enter'.
 ' an unused file name here with the .avx file extension if you want to specify the name and location of the AutoView configuration file manually.';
$string['xmlnote'] = 'Note : If you choose a configuration file name here that does not already exist then a blank configuration will be created automatically.';
$string['noxsl'] = 'Warning : No suitable XSL parser has been found. Please update your PHP with XSL support enabled. Please see the ReadMe file in the autoview module'.
 ' directory for more information on how to do this';
$string['pecl_http_warn'] = 'Warning : The pecl_http PHP extension is not installed on your server. You will need this to use the '.
 'document conversion service. The module can be downloaded from http://pecl.php.net/package/pecl_http/ . If you do not intend to use '.
 'a document conversion service this warning can be ignored.';
$string['createnew'] = 'Use default AutoView configuration file (reccomended)';
$string['configlivecapture']= 'Live capture java applet URL';
$string['configflashserver']= 'Flash/Red5 communication server URL';
$string['confignote'] = 'These parameters are used to configure';
$string['confignote2'] = 'add-on services';
$string['confignote3'] = 'for AutoView. Leave them blank if you are not using any add-on services, they are not needed for normal usage.';
$string['confignote4'] = 'See the AutoView website for more details.';
$string['hidenav'] = 'Hide Moodle Navigation Bar';
?>
