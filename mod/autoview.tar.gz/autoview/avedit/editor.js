/*************************************************************************

   Copyright: EuroMotor-AutoTrain LLP 2007

   License: GPL + Commercial

   Authors: Tim Williams (tmw@autotrain.org)

*************************************************************************/

var loaded=false;
var tid;

var DISPLAY_COMPONENTS=0;
var DISPLAY_SUBTITLES=1;
var DISPLAY_TIMESTITLES=2;
var DISPLAY_OPTIONS=3;

var currentDisplay;

/*****Startup mechanism*****/ 
function startEditor()
{
 if (!loaded)
 {
  if (parent.videoframe.browser!=parent.videoframe.MOZILLA && parent.videoframe.browser!=parent.videoframe.MSIE)
   showMessage(getString("e_editmodesupport"));

  setElementHTML("editor",
     " <div id=\"topbar\"></div>\n"+
     " <div id=\"main\"></div>\n"+
     " <div id=\"bottombar\"></div>\n"+
     " <iframe height=\"0\" width=\"0\" frameborder=\"0\" name=\"usefulIframe\" marginwidth=\"0\""+
     "  marginheight=\"0\"></iframe>");

  topBar();
  componentsDisplay();
  bottomBar();
  loaded=true;

  //if (parent.videoframe.slideSet==false && parent.videoframe.videoSet==false && parent.videoframe.subtitleSet==false)
  // if (confirm(getString("e_use_quick_start")))
  //  quickStart();
 }
}

/*****Language handling*****/
/*****Language strings for the editor are merged into the autoview core, so pick them up from there*****/

function getString(id)
{
 return parent.videoframe.getString(id);
}

/*****Error handling*****/

function showMessage(mes)
{
 parent.videoframe.showMessage(mes);
}

/*****Interface Methods*****/

function topBar()
{
 var data="<table width=\"100%\"><tr>\n"+
  " <td width=\"50%\"><a href=\"javascript:componentsDisplay();\" class=\"linkbutton\" style=\"display:block;text-align:center;\"\n"+
  "  title=\""+getString("e_sources_title")+"\" id=\"sourcebutton\">"+getString("e_sources")+"</a></td>\n"+
  " <td width=\"50%\"><a href=\"javascript:timesTitlesDisplay();\" class=\"linkbutton\" style=\"display:block;text-align:center;\"\n"+
  "  title=\""+getString("e_timestitles_title")+"\" id=\"timetitlebutton\">"+getString("e_timestitles")+"</a></td>\n"+
  "</tr><tr>\n"+
  " <td width=\"50%\"><a href=\"javascript:subtitlesDisplay();\" class=\"linkbuttongrey\" style=\"display:block;text-align:center;\"\n"+
  "  title=\""+getString("e_subtitlesbutton_title")+"\" id=\"subtitlebutton\">"+getString("e_subtitlesbutton")+"</a></td>\n"+
  " <td width=\"50%\"><a href=\"javascript:optionsDisplay()\" class=\"linkbutton\" style=\"display:block;text-align:center;\"\n"+
  "  title=\""+getString("e_options_title")+"\" id=\"optionbutton\">"+getString("e_options")+"</a></td>\n"+
  "</tr></table><hr />\n";
  setElementHTML("topbar", data);
}

function setButtonStyles(source, tt, sub, opt)
{
 if (source)
  document.getElementById("sourcebutton").className='linkbuttonselected';
 else
  document.getElementById("sourcebutton").className='linkbutton';

 if (tt)
  document.getElementById("timetitlebutton").className='linkbuttonselected';
 else
  document.getElementById("timetitlebutton").className='linkbutton';

 if (sub)
  document.getElementById("subtitlebutton").className='linkbuttonselected';
 else
  document.getElementById("subtitlebutton").className='linkbutton';

 if (opt)
  document.getElementById("optionbutton").className='linkbuttonselected';
 else
  document.getElementById("optionbutton").className='linkbutton';
}

function bottomBar()
{
 var data="<hr />\n"+
  "<table width=\"100%\"><tr><td>\n"+
  " <a href=\"javascript:saveAll()\" class=\"linkbutton\" style=\"display:block;text-align:center;\"\n"+
  "  title=\""+getString("e_save_title")+"\">"+getString("e_save")+"</a>"+
  "</td></tr></table>\n";
 setElementHTML("bottombar", data);
}

function optionsDisplay()
{
 currentDisplay=DISPLAY_OPTIONS;
 setButtonStyles(false, false, false, true);
 var data="<h1 align=\"center\">Presentation options</h1><br />\n"+
  "<table>\n";

 data=data+getOptionItem("showthumbs", parent.videoframe.thumbnailsActiveDefault);
 data=data+getOptionItem("showsubtitles", parent.videoframe.subtitlesActiveDefault);
 data=data+getOptionItem("autostart", parent.videoframe.autoStartDefault);
 data=data+getOptionItem("videoright", parent.videoframe.videoPosition);
 data=data+getOptionItem("pauseafterslide", parent.videoframe.pauseAfterSlide);

 data=data+"</table>\n"+
  "<hr />\n"+
  "<h1 align=\"center\">Control options</h1><br />\n"+
  "<table>\n";

 data=data+getOptionItem("videos", parent.videoframe.showVideoControls);
 data=data+getOptionItem("slides", parent.videoframe.showSlideControls);
 data=data+getOptionItem("subtitles", parent.videoframe.showSubtitleControls);
 data=data+getOptionItem("language", parent.videoframe.showLanguageControls);
 data=data+getOptionItem("position", parent.videoframe.showPositionControls);
 data=data+getOptionItem("slideMenu", parent.videoframe.showSlideMenu);
 data=data+getOptionItem("thumbnail", parent.videoframe.showThumbnailControls);
 data=data+getOptionItem("other", parent.videoframe.showOtherControls);

 setElementHTML("main", data);
}

function getOptionItem(name, select)
{
 var c="";
 if (select)
  c=" checked";

 return " <tr>\n"+
  "  <td valign=\"top\">\n"+
  "   <form action=\"\" name=\"option_"+name+"\" style=\"margin:0px;padding:0px;\">\n"+
  "    <input type=\"checkbox\" name=\"box\""+c+" onClick=\"updateOption(document.option_"+name+".box, '"+name+"');\" />\n"+
  "   </form>\n"+
  "  </td>\n"+
  "  <td valign=\"top\">"+getString("e_"+name)+"</td>\n"+
  " </tr>\n";
}

function subtitlesDisplay()
{
 currentDisplay=DISPLAY_SUBTITLES;
 setButtonStyles(false, false, true, false);
 var type=getString("e_subtitle");
 var data="<h1 align=\"center\">"+getString("e_subtitle")+" "+getString("e_sources")+"</h1><br />\n";
  data=data+"<table>\n";

 var langsFound=new Array();
 for (var lang in parent.videoframe.subtitleSrc)
 {
   data=data+"<tr>\n"+
   "<td valign=\"top\">\n"+
   " <a href=\"javascript:deleteSubtitleSrc('"+lang+"');\""+
   "  class=\"linkbutton\" title=\""+getString("e_delete")+" "+type+" "+getString("e_source")+"\">X</a>&nbsp;"+
   "<a href=\"javascript:editSubtitleSrc('"+lang+"');\" class=\"linkbutton\" title=\""+getString("e_edit")+" "+type+" "+getString("e_sources")+"\">E</a>"+
   "</td><td>\n"+
   " "+parent.videoframe.getLangString(lang,"langname")+" ("+lang+")\n"+
   "</td>\n"+
   "</tr>\n";
  langsFound.push(lang);
 }

 data=data+"</table><br />\n";

 var hasSources=false;
 var dataB=" <h1>"+getString("e_new_sub_source")+"</h1>\n"+
  "<form action=\"javascript:editSubtitleSrc(document.forms.newsubs.lang.value);\" name=\"newsubs\">\n"+
  " <select name=\"lang\">\n";

 for (var l in parent.videoframe.lang)
  if (parent.videoframe.arrayContains(langsFound, l)==false)
  {
   hasSources=true;
   dataB=dataB+"  <option value=\""+l+"\">"+parent.videoframe.getLangString(l,"langname")+" ("+l+")</option>\n";
  }
 dataB=dataB+" </select>\n"+
  " <input type=\"submit\" value=\""+getString("e_add")+"\" />\n"+
  "</form>";

 if (hasSources)
  data=data+dataB;

 data=data+"<hr />\n"+
  "<h1 align=\"center\">"+getString("e_subediting")+"</h1><br />\n"+
  "<table width=\"100%\"><tr>\n"+
  " <td><a href=\"javascript:addSubtitleBefore();\" class=\"linkbutton\" title=\""+getString("e_addsubbeforetitle")+"\" "+
  "style=\"display:block;text-align:center;\">"+getString("e_addsubbefore")+"</a></td>\n"+
  " <td><a href=\"javascript:addSubtitleAfter();\" class=\"linkbutton\" title=\""+getString("e_addsubaftertitle")+"\" "+
  "style=\"display:block;text-align:center;\">"+getString("e_addsubafter")+"</a></td>\n"+
  "</tr><tr>\n"+
  " <td colspan=\"2\"><a href=\"javascript:editSubtitle();\" class=\"linkbutton\" title=\""+getString("e_editsubtitle")+"\" "+
  "style=\"display:block;text-align:center;\">"+getString("e_editsub")+"</a></td>\n"+
  "</tr><tr>\n"+
  " <td colspan=\"2\"><a href=\"javascript:deleteSubtitle();\" class=\"linkbutton\" title=\""+getString("e_deletesubtitle")+"\""+
  "style=\"display:block;text-align:center;\">"+getString("e_deletesub")+"</a></td>\n"+
  "</tr></table><br />\n"+
  "<div id=\"subtitlesummary\"></div><br />\n";

 setElementHTML("main", data);
 fillSubtitleSummary();
}

function fillSubtitleSummary()
{
 if (parent.videoframe.subtitleSet==false || parent.videoframe.subtitlesActive==false)
 {
  setElementHTML("subtitlesummary", "");
  return;
 }

 var data="<h1>"+getString("e_subtitlesummary")+"</h1><br />\n"+
  "<form action=\"\" name=\"subtitlesummary\">\n"+
  "<select name=\"item\" "+
  "onchange=\"parent.videoframe.setSubtitle(parseInt(this.options[this.selectedIndex].value))\">\n";

 for (var loop=1; loop<parent.videoframe.subtitles.length; loop++)
 {
  var select="";
  if (loop==parent.videoframe.currentSubtitle)
   select=" selected";

  data=data+"<option value=\""+loop+"\""+select+" title=\""+htmlEscape(parent.videoframe.subtitles[loop])+"\">"+loop+" : "+
   parent.videoframe.subtitles[loop].substring(0,23)+"</option>\n";
 }
 data=data+"</select>\n"+
  "</form>\n";

 setElementHTML("subtitlesummary", data);
}

function componentsDisplay()
{
 currentDisplay=DISPLAY_COMPONENTS;
 setButtonStyles(true, false, false, false);
 var data=componentEditor("Video", parent.videoframe.avSrc);
 data=data+"<hr />\n";
 data=data+componentEditor("Slide", parent.videoframe.allSlideSrc);
 setElementHTML("main", data);
}

function componentEditor(type, sources)
{
 var data="<h1 align=\"center\">"+getString("e_"+type)+" "+getString("e_sources")+"</h1><br />\n";

 var langs=parent.videoframe.findValidLangs(sources);
 for (var loop=0; loop<langs.length; loop++)
 {
  data=data+" <h2>"+parent.videoframe.getLangString(langs[loop],"langname")+" ("+langs[loop]+")</h2>\n"+
   "<table>\n";

  for (var vLoop=0; vLoop<sources[langs[loop]].length; vLoop++)
   data=data+"<tr>\n"+
    "<td valign=\"top\">\n"+
    " <a href=\"javascript:delete"+type+"Src('"+langs[loop]+"',"+vLoop+");\""+
    "  class=\"linkbutton\" title=\""+getString("e_delete")+" "+getString("e_"+type)+" "+getString("e_source")+"\">X</a>&nbsp;"+
    "<a href=\"javascript:edit"+type+"Src('"+langs[loop]+"',"+vLoop+");\" class=\"linkbutton\" "+
    "  title=\""+getString("e_edit")+" "+getString("e_"+type)+" "+getString("e_sources")+"\">E</a>"+
    "</td><td>\n"+
    sources[langs[loop]][vLoop].label()+""+
    "</td>\n"+
    "</tr>\n";

  data=data+"</table>\n";

  if (type=="Slide")
  {
   data=data+"<form action=\"javascript:setNumSlidesValue('"+langs[loop]+"', document.numslideform_"+langs[loop]+".size.value);\"\n"+
    "  name=\"numslideform_"+langs[loop]+"\"><table><tr>\n"+
    " <td><h3>"+getString("e_numslides")+"</h3></td>\n"+
    " <td><input type=\"text\" size=\"2\" value=\""+parent.videoframe.titles[langs[loop]].length+"\" name=\"size\" class=\"small\" /></td>\n"+
    " <td><input type=\"submit\" value=\""+getString("e_set")+"\" /></td>\n"+
    "</tr></table></form>\n";
  }

 }

 var l="en";
 if (typeof(parent.videoframe.selectedLang)!="undefined")
  l=parent.videoframe.selectedLang;

 data=data+"<p style=\"margin-bottom:4px;\">"+
  "<a href=\"javascript:edit"+type+"Src('"+l+"', -1);\" title=\"Add a new pre-processed "+type+" Source\" class=\"linkbutton\"\n"+
  " style=\"display:block;text-align:center;margin:3px;\">"+getString("e_add")+" "+type+" "+getString("e_source")+"</a>\n";
 if (type==getString("e_Slide"))
 {
  var cl="linkbuttongrey";
  if (conversionURL.length>0)
   cl="linkbutton";
  data=data+"<a href=\"javascript:convertSlides();\"\n"+
   " title=\""+getString("e_convert_title")+"\" class=\""+cl+"\"\n"+
   " style=\"display:block;text-align:center;margin:3px;\">"+getString("e_convert_button")+"</a>\n";
 }
 else
 if (type==getString("e_Video"))
 {
  var cl="linkbuttongrey";
  if (liveCaptureInstalled)
   cl="linkbutton";
  data=data+"<a href=\"javascript:useLiveCapture();\"\n"+
   " title=\""+getString("e_livecapture_title")+"\" class=\""+cl+"\"\n"+
   " style=\"display:block;text-align:center;margin:3px;\">"+getString("e_livecapture_button")+"</a>\n";
 }
 data=data+"</p>\n";

 return data;
}

function timesTitlesDisplay()
{
 currentDisplay=DISPLAY_TIMESTITLES;
 clearInterval(tid);
 setButtonStyles(false, true, false, false);
 var currentTitle=parent.videoframe.titles[parent.videoframe.slideLang][parent.videoframe.currentSlide-1];
 var data="<h1 align=\"center\">"+getString("e_set_title")+"<h1><br />\n"+
  " <form action=\"javascript:setTitle()\" name=\"titleform\" style=\"margin:2px;padding:0px;\">\n"+
  "  <table><tr>\n"+
  "   <td><input type=\"text\" size=\"20\" name=\"title\" value=\""+currentTitle+"\"/></td>\n"+
  "   <td align=\"right\"><input type=\"submit\" value=\""+getString("e_set")+"\" /></td>\n"+
  " </tr></table>\n"+
  " </form>\n"+
  "<hr />\n"+
  "<h1 align=\"center\">"+getString("e_set_times")+"</h1><br />\n"+
  "<table><tr>\n"+
  " <td>Video Position :</td><td><div id=\"videotime\">0:0.0</div></td>\n"+
  "</tr></table>\n";

 var slideList="<table width=\"100%\"><tr>\n"+
  " <td><h1 align=\"center\">"+getString("e_slide_plural")+"</h1></td>\n"+
  "</tr><tr>\n"+
  " <td><a href=\"javascript:updateSlideTime()\" class=\"linkbutton\" style=\"display:block;text-align:center;\""+
  "  title=\""+getString("e_set_slidetime_title")+"\">"+getString("e_set_time_button")+"</a></td>\n"+
  "</tr><tr>\n"+
  " <td><a href=\"javascript:updateSlideTimeAndMove()\" class=\"linkbutton\" style=\"display:block;text-align:center;\""+
  "  title=\""+getString("e_slidemoveset_title")+"\">"+
  getString("e_moveset_button")+"</a></td>\n"+
  "</tr></table>\n"+
  "<div style=\"width:100px;height:200px;overflow:auto;\" id=\"slidetimesdiv\"></div>\n";

 if (parent.videoframe.subtitleSet==true && parent.videoframe.subtitlesActive==true)
 {
  var subtitlesList="<table width=\"100%\"><tr>\n"+
   " <td><h1 align=\"center\">"+getString("e_sub_plural")+"</h1></td>\n"+
   "</tr><tr>\n"+
   " <td><a href=\"javascript:updateSubtitleTime()\" class=\"linkbutton\" style=\"display:block;text-align:center;\""+
   "  title=\""+getString("e_set_subtime_title")+"\">"+getString("e_set_time_button")+"</a></td>\n"+
   "</tr><tr>\n"+
   " <td><a href=\"javascript:updateSubtitleTimeAndMove()\" class=\"linkbutton\" style=\"display:block;text-align:center;\""+
   "  title=\""+getString("e_submoveset_title")+"\">"+
   getString("e_moveset_button")+"</a></td>\n"+
   "</tr></table>\n"+
   "<div style=\"width:100px;height:200px;overflow:auto;\" id=\"subtimesdiv\"></div>\n";

  data=data+"<table cellspacing=\"0\" cellpadding=\"0\" align=\"center\" width=\"100%\"><tr>\n"+
   " <td align=\"center\" style=\"border-right:1px solid #000000;\">"+subtitlesList+"</td>\n"+
   " <td align=\"center\">"+slideList+"</td>\n"+
   "</tr></table>\n";
 }
 else
  data=data+"<div align=\"center\">"+slideList+"</div>";

 setElementHTML("main", data);
 fillSubtitleTimesList();
 fillSlideTimesList();
 tid=setInterval('updateTimeDisplay()', 500);
}

function fillSubtitleTimesList()
{
 var data="<table cellpadding=\"1\" cellspacing=\"0\">\n"+
  " <tr>\n"+
  "  <td style=\"font-size:small;\">1:</td><td style=\"font-size:small;\">"+getTimeString(0)+"</td>\n"+
  " </tr>\n"+
  getTimeList(parent.videoframe.subTimes[parent.videoframe.avLang], parent.videoframe.subtitles.length-1, "Subtitle")+
  "</table>\n";

 setElementHTML("subtimesdiv", data);
}

function fillSlideTimesList()
{
 var data="<table cellpadding=\"1\" cellspacing=\"0\">\n"+
  " <tr>\n"+
  "  <td style=\"font-size:small;\">1:</td><td style=\"font-size:small;\">"+getTimeString(0)+"</td>\n"+
  " </tr>\n";

 var times=parent.videoframe.times[parent.videoframe.avLang];
 var titles=parent.videoframe.titles[parent.videoframe.avLang];
 data=data+getTimeList(times, titles.length, "Slide");

 data=data+"</table>\n"+
  "</td></tr></table>\n";
 setElementHTML("slidetimesdiv", data);
}

function getTimeList(times, number, type)
{
 var data="";
 for (var loop=1; loop<number; loop++)
 {
  var t="";
  if (typeof(times[loop])!="undefined")
   t=getTimeString(times[loop]/100);

  data=data+" <tr>\n"+
   "  <td valign=\"middle\" style=\"font-size:small;\">"+(loop+1)+"</td>\n"+
   "  <td valign=\"middle\">\n"+
   "   <form style=\"margin:0px;padding:0px;\""+
   "    action=\"javascript:set"+type+"Time("+loop+", document.forms.timeindex"+loop+".time.value);\" name=\"timeindex"+loop+"\">\n"+
   "    <input type=\"text\" size=\"6\" value=\""+t+"\" name=\"time\" style=\"font-size:x-small;\" "+
   "     onChange=\"javascript:set"+type+"Time("+loop+", document.forms.timeindex"+loop+".time.value);\" />\n"+
   "    <!-- <input type=\"submit\" value=\"&gt;\" style=\"font-size:x-small;\" /> -->\n"+
   "   </form>\n"+
   "  </td>\n"+
   " </tr>\n";
 }
 return data;
}

function updateTimeDisplay()
{
 if (parent.videoframe.videoSet==true)
  setElementHTML("videotime", getTimeString(parent.videoframe.selectedAVSource.getPosition()/100));
}

function setElementHTML(name, html)
{
 var element=document.getElementById(name);
 if (element!=null)
  element.innerHTML=html;
}

/*****Slide/Subtitle time methods*****/

function setSlideTime(index, pos)
{
 var pos=processTimeString(pos);
 var r=parent.videoframe.setSlideTime(index, pos*100);
 if (r==1)
 {
  fillSlideTimesList();
  showMessage(getString("e_slide_time_warn"));
 }
}

function updateSlideTimeAndMove()
{
 parent.videoframe.setSlideSync(false);
 parent.videoframe.nextSlide();
 updateSlideTime();
}

function updateSlideTime()
{
 var r=parent.videoframe.setSlideTimeToCurrent();
 if (r==1)
  showMessage(getString("e_slide_time_warn"));
 fillSlideTimesList();
}

function setSubtitleTime(index, pos)
{
 var pos=processTimeString(pos);
 var r=parent.videoframe.setSubtitleTime(index, pos*100);
 if (r==1)
  showMessage(getString("e_sub_time_warn"));
 fillSubtitleTimesList();
}

function updateSubtitleTimeAndMove()
{
 parent.videoframe.setSlideSync(false);
 parent.videoframe.nextSubtitle();
 updateSubtitleTime();
}

function updateSubtitleTime()
{
 var r=parent.videoframe.setSubtitleTimeToCurrent();
 if (r==1)
  showMessage(getString("e_sub_time_warn"));
 fillSubtitleTimesList();
}

function getTimeString(lTotalTenths)
{
 var m=parseInt(lTotalTenths/600);
 var remainder=parseInt(lTotalTenths-(m*600));
 var s=parseInt(remainder/10);
 var t=parseInt(remainder-(s*10));
 if (s.length==1)
  $s="0".$s;
 return m+":"+s+"."+t;
}

function processTimeString(data)
{
 var colon=data.indexOf(":");
 var dot=data.indexOf(".");
 var m=parseInt(data.substring(0,colon));
 if (dot<colon)
  dot=data.length;
 var s=parseInt(data.substring(colon+1, dot));

 var t=0;
 if (dot<data.length)
  t=parseInt(data.substring(dot+1, data.length));

 return (m*600)+(s*10)+t;
}

/*****Titles methods*****/

function setTitle()
{
 parent.videoframe.setCurrentSlideTitle(document.titleform.title.value);
 saveXMLConfig();
}

/*****Source edit methods methods*****/

function setNumSlidesValue(lang, num)
{
 parent.videoframe.setNumSlides(lang, num);
 eval("document.numslideform_"+lang+".size.value=num");
 saveXMLConfig();
}

function deleteVideoSrc(lang, num)
{
 var ok=confirm(getString("e_delete_source"));
 if (ok)
 {
  parent.videoframe.deleteAVSrc(lang, num);
  componentsDisplay();
  saveXMLConfig();
 }
}

function editVideoSrc(lang, num)
{
 var source;
 if (typeof(parent.videoframe.avSrc[lang])!="undefined" && typeof(parent.videoframe.avSrc[lang][num])!="undefined")
  source=parent.videoframe.avSrc[lang][num];
 else
  source=new parent.videoframe.QuicktimeVideo("", parent.videoframe.SPEED_NONE, true);

 var data="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"+
  "<html>\n"+
  "<head>\n"+
  " <title>"+getString("e_edit")+" "+getString("e_Video")+" "+getString("e_source")+"</title>\n"+
  " <link type=\"text/css\" rel=\"stylesheet\" href=\""+parent.videoframe.vresourcePath+"style.css\" />\n"+
  " <script language=\"javascript\" type=\"text/javascript\">\n"+
  "  var lang=\""+lang+"\";\n"+
  "  var num="+num+";\n"+
  " </script>\n"+
  "</head>\n"+
  "<body>\n"+
  "<form action=\"javascript:submitSource();\" name=\"form\">\n";

 data=data+"<h1 align=\"center\">"+getString("e_edit")+" "+getString("e_Video")+" "+getString("e_source")+"</h1><br />\n"+
  " <table align=\"center\">\n"+
  "  <tr>\n"+
  "   <td>Language</td>\n"+
  "   <td>\n"+
  getLangOptions()+
  "   </td>\n"+
  "  </tr><tr>\n"+
  "   <td>Video Type</td>\n"+
  "   <td>\n"+
  "    <select name=\"type\" onChange=\"updateDisplay();\">\n";

 data=data+formOption(source.type, parent.videoframe.VIDEO_FLASH, getString("flashvideo"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_JAVAAUDIO, getString("javaaudio"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_FLASHLIVE, getString("livecaptureflash"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_JAVALIVE, getString("livecapture"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_NONE, getString("novideoplayer"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_QUICKTIME, getString("quicktime"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_REALPLAYER, getString("realplayer"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_WINDOWSMEDIA, getString("windowsmedia"));
 data=data+formOption(source.type, parent.videoframe.VIDEO_VLC, getString("vlcvideo"));

 data=data+"    </select>\n"+
  "    <a href=\"javascript:detectType()\" title=\""+getString("e_detect_video_type_title")+"\" class=\"linkbutton\">"+getString("e_detect_video_type")+"</a>\n"+
  "   </td>\n"+
  "  </tr>\n"+
  "  <tr>\n"+
  "   <td><div id=\"urllabel\">"+getString("e_video_url")+"</div></td>\n"+
  "   <td><div id=\"urlbox\"><input type=\"textfield\" size=\"50\" name=\"url\" value=\""+source.url+"\" />"+
  "&nbsp;<input type=\"button\" value=\"Select\" onClick=\"window.open('"+fileBrowser+"', '_blank', 'width=750,height=480,status=no,toolbar=no,menubar=no,scrollbars=yes,resizable=1')\" /></div></td>\n"+
  "  </tr><tr>\n"+
  "   <td><div id=\"bandlabel\">"+getString("e_bandwidth")+"</div></td>\n"+
  "   <td>\n"+
  "    <div id=\"bandbox\"><select name=\"speed\">\n";

 data=data+formOption(source.speed, parent.videoframe.SPEED_NONE, getString("e_none"));
 data=data+formOption(source.speed, parent.videoframe.SPEED_MODEM, getString("speed"+parent.videoframe.SPEED_MODEM));
 data=data+formOption(source.speed, parent.videoframe.SPEED_BROAD, getString("speed"+parent.videoframe.SPEED_BROAD));
 data=data+formOption(source.speed, parent.videoframe.SPEED_STREAM, getString("speed"+parent.videoframe.SPEED_STREAM));

 data=data+"    </select></div>\n"+
  "   </td>\n"+
  " </tr><tr>\n"+
  "  <td><div id=\"eventlabel\">"+getString("e_event_triggers")+"</div></td>\n"+
  "  <td><div id=\"eventcheck\"><input type=\"checkbox\" name=\"triggers\"";

 if (!source.useTimeMonitor())
  data=data+" checked";

 data=data+" /></div></td>\n"+
  " </tr><tr>\n"+
  "  <td colspan=\"2\"><div id=\"eventnote\"><font size=\"-1\">("+getString("e_eventnote")+")</font></div></td>\n"+
  " </tr>\n"+
  "</table>\n"+
  "<p align=\"center\"><input type=\"submit\" value=\""+getString("e_update")+"\" /></p>\n"+
  "</form>\n"+
  "<!-- The defer attribute below is needed to stop IE crashing and using 100% of the processor time. Don't ask me why this works, but it does -->\n"+
  "<script language=\"javascript\" type=\"text/javascript\" src=\"avedit/videosrc.js\" defer></script>\n"+
  "</body>\n"+
  "</html>\n";

 popupWindow(data);
}

function formOption(toTest, type, name)
{
 if (toTest==type)
  return "    <option value=\""+type+"\" selected>"+name+"</option>\n";
 else
  return "    <option value=\""+type+"\">"+name+"</option>\n";
}

function getLangOptions(selectedLang)
{
 data="    <select name=\"lang\">\n";

 var langList=parent.videoframe.findValidLangs(parent.videoframe.lang);
 for (var loop=0; loop<langList.length; loop++)
  data=data+formOption(selectedLang, langList[loop], parent.videoframe.getLangString(langList[loop], "langname")+" ("+langList[loop]+")");

 data=data+"    </select>\n";

 return data;
}

function addUpdateVideoSrc(lang, num, newlang, type, url, speed, monitor)
{
 parent.videoframe.addUpdateAVSrc(lang, num, newlang, type, url, speed, monitor);
 componentsDisplay();
 saveXMLConfig();
 //*****Real player dosn't pick up a changed URL without a page reload*****/
 if (type==parent.videoframe.VIDEO_REALPLAYER && num>-1)
  setTimeout("parent.videoframe.location.reload()", 1500);
}

function deleteSlideSrc(lang, num)
{
 var ok=confirm(getString("e_delete_source"));
 if (ok)
 {
  var oldSlideSet=parent.videoframe.slideSet;
  parent.videoframe.deleteSlideSrc(lang, num);
  componentsDisplay();
  saveXMLConfig();
  if (oldSlideSet!=parent.videoframe.slideSet)
   setTimeout("parent.videoframe.location.reload()", 1500);
 }
}

function editSlideSrc(lang, num)
{
 if (typeof(parent.videoframe.allSlideSrc[lang])!="undefined" && typeof(parent.videoframe.allSlideSrc[lang][num])!="undefined")
  editSlideSrcWindow(lang, num, parent.videoframe.allSlideSrc[lang][num]);
 else
  editSlideSrcWindow(lang, -1, new parent.videoframe.OOFlashSlide(""));
}

function editSlideSrcWindow(lang, num, source)
{
 var data="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"+
  "<html>\n"+
  "<head>\n"+
  " <title>"+getString("e_edit")+" "+getString("e_Slide")+" "+getString("e_source")+"</title>\n"+
  " <link type=\"text/css\" rel=\"stylesheet\" href=\""+parent.videoframe.vresourcePath+"style.css\" />\n"+
  "</head>\n"+
  "<body>\n"+
  "<form action=\"javascript:opener.addUpdateSlideSrc('"+lang+"', "+num+", document.form.lang.value, document.form.type.value, document.form.url.value, document.form.slideType.value);window.close();\""+
  " name=\"form\" onSubmit=\"checkURL();\">\n"+
  "<h1 align=\"center\">"+getString("e_edit")+" "+getString("e_Slide")+" "+getString("e_source")+"</h1><br />\n"+
  " <table align=\"center\">\n"+
  "  <tr>\n"+
  "   <td>Language</td>\n"+
  "   <td>\n"+
  getLangOptions(lang)+
  "   </td>\n"+
  "  </tr><tr>\n"+
  "   <td>Slide Type</td>\n"+
  "   <td>\n"+
  "    <select name=\"type\" onChange=\"updateDisplay();\">\n";

 data=data+formOption(source.type, parent.videoframe.SLIDE_OOFLASH, getString("flashslides"));
 data=data+formOption(source.type, parent.videoframe.SLIDE_IMAGE_PRELOAD, getString("preloadimage"));
 data=data+formOption(source.type, parent.videoframe.SLIDE_IMAGE, getString("imageslides"));
 data=data+formOption(source.type, parent.videoframe.SLIDE_PDF, getString("pdfslides")+" ("+getString("e_print_only")+")");
 data=data+formOption(source.type, parent.videoframe.SLIDE_NONE, getString("noslides"));

 data=data+"    </select>\n"+
  "    <a href=\"javascript:opener.convertSlides();window.close();\" title=\""+getString("e_convert_slides")+" (.ppt, .odp, .sxi) \""+
  "     class=\"linkbutton\">"+getString("e_convert_button")+"</a>\n"+
  "   </td>\n"+
  "  </tr>\n"+
  "  <tr>\n"+
  "   <td><div id=\"urllabel\">"+getString("e_slide_url")+"</div></td>\n"+
  "   <td><div id=\"urlbox\"><input type=\"textfield\" size=\"50\" name=\"url\" value=\""+source.url+"\" onChange=\"checkURL();\" />"+
  "&nbsp;<input type=\"button\" value=\"Select\" onClick=\"window.open('"+fileBrowser+"', '_blank', 'width=750,height=480,status=no,toolbar=no,menubar=no,scrollbars=yes,resizable=1')\" /></div></td>\n"+
  "  </tr>\n"+
  "  <tr>\n"+
  "   <td><div id=\"typelabel\">"+getString("e_image_type")+"</div></td>\n"+
  "   <td>\n"+
  "    <div id=\"typebox\"><select name=\"slideType\">\n";

 data=data+formOption(source.slideType, "", "None");
 data=data+formOption(source.slideType, ".jpg", "JPEG");
 data=data+formOption(source.slideType, ".png", "PNG");
 data=data+formOption(source.slideType, ".gif", "GIF");

 data=data+"     </select> ("+getString("e_image_only")+")</div>\n"+
  "</td>\n"+
  "  </tr>\n"+
  "</table>\n"+
  " <p align=\"center\"><input type=\"submit\" value=\""+getString("e_update")+"\" /></p>\n"+
  "</form>\n"+
  "<!-- The defer attribute below is needed to stop IE crashing and using 100% of the processor time. Don't ask me why this works, but it does -->\n"+
  "<script language=\"javascript\" type=\"text/javascript\" src=\"avedit/slidesrc.js\" defer></script>\n"+
  "</body>\n"+
  "</html>\n";

 popupWindow(data);
}

function addUpdateSlideSrc(lang, num, newlang, type, url, slideType, noUpdate)
{
 if (typeof(noUpdate)=="undefined")
  noUpdate=false;

 var oldSlideSet=parent.videoframe.slideSet;
 parent.videoframe.addUpdateSlideSrc(lang, num, newlang, type, url, slideType);
 componentsDisplay();

 if (oldSlideSet!=parent.videoframe.slideSet && noUpdate==false)
 {
  saveXMLConfig();
  setTimeout("parent.videoframe.location.reload()", 1500);
 }
}


function deleteSubtitleSrc(lang)
{
 var ok=confirm(getString("e_delete_source"));
 if (ok)
 {
  parent.videoframe.deleteSubtitleSrc(lang);
  subtitlesDisplay();
  saveXMLConfig();
 }
}

function editSubtitleSrc(lang)
{
 if (typeof(lang)=="undefined")
 {
  alert("No language specified.");
  return;
 }

 var url="";
 if (typeof(parent.videoframe.subtitleSrc[lang])!="undefined")
  url=parent.videoframe.subtitleSrc[lang];

 var data="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"+
  "<html>\n"+
  "<head>\n"+
  " <title>"+getString("e_edit")+" "+getString("e_subtitle")+" "+getString("e_source")+"</title>\n"+
  " <link type=\"text/css\" rel=\"stylesheet\" href=\""+parent.videoframe.vresourcePath+"style.css\" />\n"+
  "</head>\n"+
  "<body>\n"+
  "<form action=\"javascript:submitForm();\" name=\"form\">\n"+
  "<input type=\"hidden\" name=\"lang\" value=\""+lang+"\" />\n"+
  "<h1 align=\"center\">"+getString("e_edit")+" "+getString("e_subtitle")+" "+getString("e_source")+"</h1><br />\n"+
  " <table align=\"center\">\n"+
  "  <tr>\n"+
  "   <td>"+getString("e_subtitle_source_type")+"</td>\n"+
  "   <td>\n"+
  "    <select name=\"type\" onchange=\"updateDisplay();\">\n"+
  "     <option value=\"jsavs\">"+getString("e_subtype_jsavsfile")+"</option>\n"+
  "     <option value=\"blank\">"+getString("e_subtype_blank")+"</option>\n"+
  "     <!--<option value=\"textfile\">"+getString("e_subtype_textfile")+"</option>-->\n"+
  "     <option value=\"textbox\">"+getString("e_subtype_textbox")+"</option>\n"+
  "    </select>\n"+
  "   </td>\n"+
  "  </tr>\n"+
  "  <tr>\n"+
  "   <td><div id=\"urllabel\">"+getString("e_subtitle_url")+"</div></td>\n"+
  "   <td><div id=\"urlbox\"><input type=\"textfield\" size=\"50\" name=\"url\" value=\""+url+"\" />&nbsp;"+
  "<input type=\"button\" value=\"Select\" onClick=\"window.open('"+fileBrowser+"', '_blank', "+
  "'width=750,height=480,status=no,toolbar=no,menubar=no,scrollbars=yes,resizable=1')\" /></div></td>\n"+
  "  </tr><tr>\n"+
  "   <td valign=\"top\"><div id=\"boxlabel\">"+getString("e_subtitle_boxname")+"</div></td>\n"+
  "   <td><div id=\"subbox\"><textarea name=\"subtitles\" cols=\"50\" rows=\"30\"></textarea></div></td>\n"+
  "  </tr>\n"+
  "</table>\n"+
  " <p align=\"center\"><input type=\"submit\" value=\""+getString("e_update")+"\" /></p>\n"+
  "</form><br />\n"+
  "<!-- The defer attribute below is needed to stop IE crashing and using 100% of the processor time. Don't ask me why this works, but it does -->\n"+
  "<script language=\"javascript\" type=\"text/javascript\" src=\"avedit/subtitlesrc.js\" defer></script>\n"+
  "</body>\n"+
  "</html>";

 popupWindow(data);
}

function addUpdateSubtitleSrc(lang, type, data)
{
 if (type=="jsavs")
  parent.videoframe.addUpdateSubtitleSrc(lang, data);
 else
 if (type=="blank")
 {
  parent.videoframe.subtitleLang=lang;
  var subtitles=new Array();
  subtitles[1]="";
  var file=getNewSubtitleFileName(lang);
  saveSubtitles(subtitles, lang, file);
  parent.videoframe.addUpdateSubtitleSrc(lang, file);
 }
 else
 if (type=="textfile")
 {
  alert("Not implemented");
 }
 else
 if (type=="textbox")
 {
  var subtitles=processSubtitles(data);
  var file=getNewSubtitleFileName(lang);
  saveSubtitles(subtitles, lang, getNewSubtitleFileName(lang));
  parent.videoframe.addUpdateSubtitleSrc(lang, file);
 }

 subtitlesDisplay();
 saveXMLConfig();
}

function getNewSubtitleFileName(lang)
{
 var dot=xmlFile.lastIndexOf(".");
 var strippedName=xmlFile.substring(0,dot);
 return strippedName+"-"+lang+".avs";
}

/*****These methods processs a subtitle transcript into useable subtitles*****/

function processSubtitles(subdata)
{
 var split=subdata.split("\n");
 var splitData=false, splitQuestion=false;
 var subtitles=new Array();
 subtitles[0]="";

 for (var loop=0; loop<split.length; loop++)
 {
  //split[loop]=split[loop].trim();

  if (splitQuestion==false && split[loop].length>210)
  {
   splitQuestion=true;
   splitData=confirm(getString("e_sub_split"));
  }

  if (split[loop].length>210 && splitData==true)
   splitSubtitle(split[loop], subtitles);
  else
   if (split[loop].length>0)
    subtitles.push(split[loop]);
 }

 /**
 var data="";
 for (var loop=0; loop<subtitles.length; loop++)
  data=data+"<p>"+loop+": "+subtitles[loop]+"</p>\n";

 popupWindow(data);
 **/

 return subtitles;
}

function splitSubtitle(toSplit, subtitles)
{
 var testChars=new Array(".", "?", "!", ";", ":", ",");
 var right;

 for (var charNum=0; charNum<testChars.length; charNum++)
 {
  var pos=toSplit.indexOf(testChars[charNum]);

  if (pos<211 && pos>-1)
  {
   var newPos=toSplit.indexOf(testChars[charNum], pos+1);
   if (pos<60 || toSplit.length-pos<60 || newPos-pos<60)
   {
    if (newPos<211 && newPos>-1)
     pos=newPos;
   }

   if (pos>29)
   {
    var left=toSplit.substring(0, pos+1);
    subtitles.push(left);
    right=toSplit.substring(pos+1);
    break;
   }
  }
 }

 if (typeof(right)=="undefined")
 {
  var length=211;
  if (toSplit.length<420)
   length=toSplit.length/2;
 
  var fullStop=data.indexOf(".");
  if (fullStop<420)
   length=fullStop/2;

  var space=toSplit.substring(0,length).lastIndexOf(" ");
  if (space<211 && space>-1)
  {
   var left=toSplit.substring(0, space+1);
   subtitles.push(left);
   right=toSplit.substring(space+1);
  }
  else
  {
   subtitles.push(toSplit);
   return;
  }
 }

 if (right.length>210)
  return splitSubtitle(right, subtitles);
 else
  if (right.length>0)
   subtitles.push(right);
}

/*****Subtitle editing methods*****/

function addSubtitleBefore()
{
 if (typeof(parent.videoframe.subtitles)!="undefined")
 {
  parent.videoframe.addSubtitleBefore();
  fillSubtitleSummary();
  saveCurrentSubtitles();
 }
}

function addSubtitleAfter()
{
 if (typeof(parent.videoframe.subtitles)!="undefined")
 {
  parent.videoframe.addSubtitleAfter();
  fillSubtitleSummary();
  saveCurrentSubtitles();
 }
}

function editSubtitle()
{
 if (typeof(parent.videoframe.subtitles)!="undefined")
  parent.videoframe.editSubtitle();
}

function deleteSubtitle()
{
 if (typeof(parent.videoframe.subtitles)!="undefined")
 {
  parent.videoframe.deleteSubtitle();
  fillSubtitleSummary()
  saveCurrentSubtitles();
 }
}

/*****For popup windows*****/

function popupWindow(data)
{
 var exwin=window.open("","_blank",
  "width=750,height=300,toolbar=no,menubar=no,scrollbars=yes,resizable=yes");
 exwin.document.open("text/html");
 exwin.document.writeln(data);
 exwin.document.close();
 return exwin;
}

/*****Handle options/controls*****/

function updateOption(check, option)
{
 if (option=="videos")
 {
  parent.videoframe.showVideoControls=check.checked;
  parent.videoframe.setVideoControls();
 }
 else
 if (option=="slides")
 {
  parent.videoframe.showSlideControls=check.checked;
  parent.videoframe.setSlideControls();
 }
 else
 if (option=="subtitles")
 {
  parent.videoframe.showSubtitleControls=check.checked;
  parent.videoframe.setSubtitleControls();
 }
 else
 if(option=="language")
 {
  parent.videoframe.showLanguageControls=check.checked;
  parent.videoframe.setLanguageHTML();
 }
 if (option=="position")
 {
  parent.videoframe.showPositionControls=check.checked;
  parent.videoframe.setPositionControl();
 }
 else
 if (option=="slideMenu")
 {
  parent.videoframe.showSlideMenu=check.checked;
  parent.videoframe.setSlideMenu();
 }
 else
 if (option=="thumbnail")
 {
  parent.videoframe.showThumbnailControls=check.checked;
  parent.videoframe.setThumbnailControl();
 }
 else
 if (option=="other")
 {
  parent.videoframe.showOtherControls=check.checked;
  parent.videoframe.setExtraButtonsHTML();
 }
 else
 if (option=="showthumbs")
 {
  parent.videoframe.setThumbnailsActive(check.checked);
  parent.videoframe.setThumbnails(check.checked);
 }
 else
 if (option=="showsubtitles")
 {
  parent.videoframe.setSubtitlesActive(check.checked);
  parent.videoframe.setSubtitles(check.checked);
 }
 else
 if (option=="autostart")
 {
  parent.videoframe.setAutoStart(check.checked);
 }
 else
 if (option=="videoright")
 {
  if (check.checked)
   parent.videoframe.setVideoPosition(parent.videoframe.VIDEORIGHT);
  else
   parent.videoframe.setVideoPosition(parent.videoframe.VIDEOLEFT);

  setTimeout("parent.videoframe.location.reload()", 1500);
 }
 else
 if (option=="pauseafterslide")
 {
  parent.videoframe.setPauseAfterSlide(check.checked);
 }

 saveXMLConfig();
}

/****Save presentation****/

function saveAll()
{
 saveXMLConfig();
 if (parent.videoframe.subtitleSet)
  saveCurrentSubtitles()
}

function saveXMLConfig()
{
 var data="";
 if (typeof(btoa)=="undefined")
  data=encodeBase64(parent.videoframe.exportXMLConfig(""));
 else
  data=btoa(parent.videoframe.exportXMLConfig(""));

 window.usefulIframe.document.open("text/html");
 window.usefulIframe.document.writeln("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"+
  "<html><head><title>XML Config</title></head>\n"+
  "<body>\n"+
  "<form action=\""+xmlSendURL+"\" method=\"post\" type=\"multipart/form-data\" name=\"formdata\">\n"+
  " <input type=\"hidden\" name=\"xmldata\" value=\""+data+"\" />"+
  " <input type=\"hidden\" name=\"xmlid\" value=\""+xmlID+"\" />\n"+
  " <input type=\"submit\" value=\"Submit XML Configuration\" /><br />\n"+
  "</form>\n"+
  "</body>\n"+
  "</html>\n");
 window.usefulIframe.document.forms.formdata.submit();
}

function saveCurrentSubtitles()
{
 saveSubtitles(parent.videoframe.subtitles, parent.videoframe.subtitleLang, parent.videoframe.subtitleSrc[parent.videoframe.subtitleLang]);
}

function saveSubtitles(subtitles, subtitleLang, file)
{
 var fileChange=false;
 if (file.indexOf(".js")>0)
 {
  if (confirm(getString("e_subtitlefileformat")))
  {
   file=getNewSubtitleFileName(subtitleLang);
   fileChange=true;
  }
  else
   return;
 }

 var data="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+
  "<avsubtitles>\n"+
  " <version>"+parent.videoframe.VERSION+"</version>\n"+
  " <lang>"+subtitleLang+"</lang>\n"+
  " <subdata>\n";

 for (var loop=1; loop<subtitles.length; loop++)
  data=data+"  <subtitle pos=\""+loop+"\">"+parent.videoframe.jsEscape(subtitles[loop])+"</subtitle>\n";

 data=data+" </subdata>\n"+
  "</avsubtitles>\n";

 if (typeof(btoa)=="undefined")
  data=encodeBase64(data);
 else
  data=btoa(data);

 window.usefulIframe.document.open("text/html");
 window.usefulIframe.document.writeln("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"+
  "<html><head><title>XML Config</title></head>\n"+
  "<body>\n"+
  "<form action=\""+xmlSendURL+"\" method=\"post\" type=\"multipart/form-data\" name=\"formdata\">\n"+
  " <input type=\"hidden\" name=\"xmldata\" value=\""+data+"\" />"+
  " <input type=\"hidden\" name=\"xmlid\" value=\""+xmlID+"\" />\n"+
  " <input type=\"hidden\" name=\"subtitlefile\" value=\""+file+"\" />\n"+
  " <input type=\"submit\" value=\"Submit XML Configuration\" /><br />\n"+
  "</form>\n"+
  "</body>\n"+
  "</html>\n");

 window.usefulIframe.document.forms.formdata.submit();

 if (fileChange)
  parent.videoframe.addUpdateSubtitleSrc(subtitleLang, file);
}


/*****PPT Converter code*****/

function convertSlides()
{
 var data="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\""+
  "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n"+
  "<html>\n"+
  "<head>\n"+
  " <title>"+getString("e_convert_heading")+"</title>\n"+
  " <link type=\"text/css\" rel=\"stylesheet\" href=\""+parent.videoframe.vresourcePath+"style.css\" />\n"+
  "</head>\n"+
  "<body>\n"+
  "<form action=\""+conversionURL+"\" name=\"form\">\n"+
  " <input type=\"hidden\" name=\"id\" value=\""+xmlID+"\" />\n"+
  "<h1 align=\"center\">"+getString("e_convert_heading")+"</h1><br />\n";

 if (conversionURL.length>0)
  data=data+" <table align=\"center\">\n"+
   "  <tr>\n"+
   "   <td>"+getString("e_slide_file")+"<br />(.ppt/.odp/.sxi)</td>\n"+
   "   <td><input type=\"textfield\" size=\"50\" name=\"url\" />&nbsp;<input type=\"button\" value=\""+getString("e_select")+"\""+
   "     onClick=\"window.open('"+fileBrowser+"', '_blank', 'width=750,height=480,status=no,toolbar=no,menubar=no,scrollbars=yes,resizable=1')\" /></td>\n"+
   "  </tr>\n"+
   "  <tr>\n"+
   "   <td valign=\"top\">"+getString("e_convert_to")+"</td>\n"+
   "   <td>\n"+
   "    <input type=\"checkbox\" name=\"swf\" value=\"true\" checked />"+getString("e_flash")+"<br />\n"+
   "    <input type=\"checkbox\" name=\"pdf\" value=\"true\" checked />"+getString("e_pdf")+"<br />\n"+
   "    <input type=\"checkbox\" name=\"jpg\" value=\"true\" checked />"+getString("e_images")+"<br />\n"+
   "   </td>\n"+
   "  </tr>\n"+
   "</table>\n"+
   " <p align=\"center\"><input type=\"submit\" value=\""+getString("e_convert")+"\" /></p>\n"+
   "</form>\n";
 else
  data=data+"<p>"+getString("e_convertmessage")+"</p>";

 data=data+"</body>\n"+
 "</html>\n";

 popupWindow(data);
}

/*****Quick access to Live Capture*****/

function useLiveCapture()
{
 if (parent.videoframe.hasLiveCapture(true))
  return;

 var ln="en";
 if (typeof(parent.videoframe.selectedLang)!="undefined")
  ln=parent.videoframe.selectedLang;

 if (parent.videoframe.flashServer.length>0 && parent.videoframe.liveCaptureURL.length>0)
 {
  //We have both types of capture available
  if (confirm(getString("e_livecapturechoice")))
   parent.videoframe.addUpdateAVSrc(null, -1, ln, parent.videoframe.VIDEO_JAVALIVE, null, null, null);
  else
   parent.videoframe.addUpdateAVSrc(null, -1, ln, parent.videoframe.VIDEO_FLASHLIVE, null, null, null);
 }
 else
 if (parent.videoframe.flashServer.length>0)
  parent.videoframe.addUpdateAVSrc(null, -1, ln, parent.videoframe.VIDEO_FLASHLIVE, null, null, null);
 else
 if (parent.videoframe.liveCaptureURL.length>0)
  parent.videoframe.addUpdateAVSrc(null, -1, ln, parent.videoframe.VIDEO_JAVALIVE, null, null, null);

 componentsDisplay();
 saveXMLConfig();
}

/*****New presentation wizard*****/

function quickStart()
{
 alert("Quickstart");
 window.open(parent.videoframe.avEditDir+"quickstart.html");
}

/*****Pause Method*****/

function pause(millis) 
{
 var date = new Date();
 var curDate = null;
 
 do { curDate = new Date(); } 
 while(curDate-date < millis);
}

/*****Escape text for HTML*****/

function htmlEscape(prep)
{
 if (typeof(prep)=="undefined")
  return "";

 for (var pos=0; pos<prep.length; pos++)
 {
  var c=prep.charCodeAt(pos);
  if (c>127 || c==34 || c==61 || c==62 || c==38 || c==39 || c==60 || c==62 || c==45)
  {
   var first=prep.substring(0,pos)+"&#"+c+";";
   prep=first+prep.substring(pos+1);
   pos=first.length-1;
  }
 }
 return prep;
}
