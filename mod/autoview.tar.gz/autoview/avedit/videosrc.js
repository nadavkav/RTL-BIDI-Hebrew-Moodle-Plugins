updateDisplay();

function updateDisplay()
{
 var selection=document.form.type.value;

 if (selection==opener.parent.videoframe.VIDEO_JAVALIVE ||
     selection==opener.parent.videoframe.VIDEO_FLASHLIVE ||
     selection==opener.parent.videoframe.VIDEO_NONE || 
     selection==opener.parent.videoframe.VIDEO_VLC ||
     selection==opener.parent.videoframe.VIDEO_JAVAAUDIO ||
     selection==opener.parent.videoframe.VIDEO_FLASH)
  setEventDisplay("none");
 else
  setEventDisplay("inline");

 if (selection==opener.parent.videoframe.VIDEO_JAVALIVE ||
     selection==opener.parent.videoframe.VIDEO_FLASHLIVE ||
     selection==opener.parent.videoframe.VIDEO_NONE)
 {
  setURLDisplay("none");
  setBandwidthDisplay("none");
 }
 else
 {
  setURLDisplay("inline");
  setBandwidthDisplay("inline");
 }
} 

function setEventDisplay(val)
{
 document.getElementById("eventlabel").style.display=val;
 document.getElementById("eventcheck").style.display=val;
 document.getElementById("eventnote").style.display=val;
}

function setURLDisplay(val)
{
 document.getElementById("urllabel").style.display=val;
 document.getElementById("urlbox").style.display=val;
}

function setBandwidthDisplay(val)
{
 document.getElementById("bandlabel").style.display=val;
 document.getElementById("bandbox").style.display=val;
}

function submitSource()
{
 if (checkType())
 {
  opener.addUpdateVideoSrc(lang, num, document.form.lang.value, document.form.type.value, document.form.url.value,     
   document.form.speed.value, !document.form.triggers.checked);
  window.close();
 }
}

function checkType()
{
 var detectedType=getTypeFromExtension();

 //If types match it's OK
 if (detectedType==document.form.type.value)
  return true;

 if (document.form.type.value==opener.parent.videoframe.VIDEO_JAVALIVE  || document.form.type.value==opener.parent.videoframe.VIDEO_FLASHLIVE)
  return true;

 //VLC won't be detected, but can play most things except Real
 if (detectedType!=opener.parent.videoframe.VIDEO_REALPLAYER && document.form.type.value==opener.parent.videoframe.VIDEO_VLC)
  return true;

 return confirm(opener.getString("e_video_type_warn"));
}

function detectType()
{
 var type=getTypeFromExtension();
 if (type==opener.parent.videoframe.VIDEO_NONE)
  alert(opener.getString("e_unrecognised_video_type"));
 else
  document.form.type.value=type;
}

function getTypeFromExtension()
{
 if (document.form.url.value.indexOf(".mov")>-1 || document.form.url.value.indexOf(".mp4")>-1 ||
     document.form.url.value.indexOf(".mp3")>-1)
  return opener.parent.videoframe.VIDEO_QUICKTIME;
 else
 if (document.form.url.value.indexOf(".rm")>-1 || document.form.url.value.indexOf(".ram")>-1 ||
     document.form.url.value.indexOf(".ra")>-1 || document.form.url.value.indexOf(".rv")>-1)
  return opener.parent.videoframe.VIDEO_REALPLAYER;
 else
 if (document.form.url.value.indexOf(".wmv")>-1 || document.form.url.value.indexOf(".asf")>-1 ||
     document.form.url.value.indexOf(".avi")>-1 || document.form.url.value.indexOf(".wma")>-1)
  return opener.parent.videoframe.VIDEO_WINDOWSMEDIA;
 else
 if (document.form.url.value.indexOf(".ogg")>-1)
  return opener.parent.videoframe.VIDEO_JAVAAUDIO;
 else
 if (document.form.url.value.indexOf(".flv")>-1)
  return opener.parent.videoframe.VIDEO_FLASH;

 return opener.parent.videoframe.VIDEO_NONE;
}