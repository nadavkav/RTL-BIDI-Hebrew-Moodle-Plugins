<?php
/**
* This code is copyright to EuroMotor AutoTrain LLP and is licenced under the GNU GPL Licence
**/

    require_once("../../config.php");
    require_once("lib.php");

    $l = optional_param('l',0,PARAM_INT);
    $slidenum = optional_param('slidenum', 1, PARAM_INT);
    if (! $autoview = get_record("autoview", "id", $l))
     error("Course module is incorrect");

    if (! $course = get_record("course", "id", $autoview->course))
     error("Course is misconfigured");

    if (! $cm = get_coursemodule_from_instance('autoview', $autoview->id, $course->id))
     error('Course Module ID was incorrect');

    require_login($course->id);
    $context = get_context_instance(CONTEXT_MODULE, $cm->id);
    if (has_capability('moodle/legacy:editingteacher', $context))
    {
     /*****If there is no conversion service, send a blank URL*****/
     $crl="";
     if (count($CFG->autoview_conversionurl)>0)
      $crl=$CFG->wwwroot."/mod/autoview/convert.php";

     /******Check for the existence of the live capture licence file/jar*****/
     $live="false";
     if ( (file_exists($CFG->dirroot."/mod/autoview/avedit/autoview-livecapture.bin") && file_exists($CFG->dirroot."/mod/autoview/avedit/liveCaptureApplet.jar"))
      || count($CFG->autoview_livecapture)>0 )
      $live="true";

     $parameters = array(
      'vresource' => $CFG->wwwroot."/mod/autoview/vresource/", 
      'xmlSendURL' => $CFG->wwwroot."/mod/autoview/recieveXML.php", 
      'xmlID' => $autoview->id,
      'xmlFile' => $autoview->configfile,
      'fileBrowser' => $CFG->wwwroot."/files/index.php?id=".$course->id."&choose=form.url",
      'conversionURL' => $crl,
      'liveCaptureInstalled' => $live);

     echo process_xsl($CFG->dirroot."/mod/autoview/avedit/avedit.xml", $CFG->dirroot."/mod/autoview/avedit/avedit.xsl", $parameters);
    }
    else
     echo "You do not have permission to do this";
?>
