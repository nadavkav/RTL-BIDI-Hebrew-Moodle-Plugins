<?php
/**
*
* This page translates the AutoView config file into HTML for browser display using the XSL style sheet
*
* This code is copyright to EuroMotor AutoTrain LLP and is licenced under the GNU GPL Licence
**/

 require_once("../../config.php");
 require_once("lib.php");

 $l = optional_param('l',0,PARAM_INT);
 $editval = optional_param('edit',false,PARAM_BOOL);

 if (! $autoview = get_record("autoview", "id", $l))
  error("Course module is incorrect");

 if (! $course = get_record("course", "id", $autoview->course))
  error("Course is misconfigured");

 if (! $cm = get_coursemodule_from_instance("autoview", $autoview->id, $course->id))
  error("Course Module ID was incorrect");

 require_login($course->id);
 $context = get_context_instance(CONTEXT_MODULE, $cm->id);
 $parameters=null;

 $htmlbase=$CFG->wwwroot.'/file.php/'.$course->id.'/'; //.$autoview->configfile;
 //$pos = strrpos($htmlbase, '/');
 //$htmlbase=substr($htmlbase,0,$pos+1);

 /******Check for the existence of the live capture licence file/jar*****/
 $live="false";
 $liveCaptureURL="";

 if (file_exists($CFG->dirroot."/mod/autoview/avedit/autoview-livecapture.bin") && file_exists($CFG->dirroot."/mod/autoview/avedit/liveCaptureApplet.jar"))
 {
  $live=true;
  $liveCaptureURL=$CFG->wwwroot.'/mod/autoview/avedit/liveCaptureApplet.jar';
 }
 else
 if (count($CFG->autoview_livecapture)>0)
 {
  $liveCaptureURL=$CFG->autoview_livecapture;
  $live=true;
 }

 $exitURL="";
 if ($autoview->noframe && $editval==false)
  $exitURL=$CFG->wwwroot."/course/view.php?id=".$course->id;

 if ($editval && has_capability('moodle/legacy:editingteacher', $context))
  $parameters = array(
   'vresource' => $CFG->wwwroot.'/mod/autoview/vresource/',
   'htmlbase' => $htmlbase,
   'qtrefurl' => $CFG->wwwroot.'/mod/autoview/qtref.php?l='.$l.'&qturl=',
   'xmlsubtitle' => $CFG->wwwroot.'/mod/autoview/subtitles.php?l='.$l.'&subfile=',
   'xmlfile' => $autoview->configfile,
   'aveditdir' => $CFG->wwwroot.'/mod/autoview/avedit/',
   'extension' => $CFG->wwwroot.'/mod/autoview/avedit/extension.js',
   'liveCaptureURL' => $liveCaptureURL,
   'flashserver' => $CFG->autoview_flashserver,
   'exitURL' => $exitURL);
 else
  $parameters = array(
   'vresource' => $CFG->wwwroot.'/mod/autoview/vresource/',
   'htmlbase' => $htmlbase,
   'qtrefurl' => $CFG->wwwroot.'/mod/autoview/qtref.php?l='.$l.'&qturl=',
   'xmlsubtitle' => $CFG->wwwroot.'/mod/autoview/subtitles.php?l='.$l.'&subfile=',
   'exitURL' => $exitURL);

 echo process_xsl($CFG->dataroot.'/'.$course->id.'/'.$autoview->configfile, $CFG->dirroot.'/mod/autoview/templates/autoview.xsl',$parameters);
?>
