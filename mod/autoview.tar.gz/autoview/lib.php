<?PHP
/**
* This code is copyright to EuroMotor AutoTrain LLP and is licenced under the GNU GPL Licence
**/

/// Library of functions and constants for module AutoView

define("AUTOVIEW_MAX_NAME_LENGTH", 50);


function autoview_add_instance($autoview) {
/// Given an object containing all the necessary data, 
/// (defined by the form in mod.html) this function 
/// will create a new instance and return the id number 
/// of the new instance.

    $mainrecord->name = strip_tags($autoview->content);
    if (strlen($mainrecord->name) > AUTOVIEW_MAX_NAME_LENGTH)
        $mainrecord->name = substr($mainrecord->name, 0, AUTOVIEW_MAX_NAME_LENGTH)."...";
    else
    if (strlen($mainrecord->name) == 0)
        $mainrecord->name = "AutoView ".time();

    $mainrecord->timemodified = time();
    $mainrecord->course=$autoview->course;
    $mainrecord->content=$autoview->content;
    if ($autoview->noframe=="1")
     $mainrecord->noframe=1;
    else
     $mainrecord->noframe=0; 
    if (isset($autoview->configfile) && strlen($autoview->configfile)>0)
     $mainrecord->configfile=$autoview->configfile;
    else
     $mainrecord->configfile=str_replace(' ', '_', trim($mainrecord->name)).'.avx';
    $instance_id=insert_record("autoview", $mainrecord);
    autoview_check_configfile($mainrecord->configfile, $autoview->course);
    return $instance_id;
}


function autoview_update_instance($autoview) {
/// Given an object containing all the necessary data, 
/// (defined by the form in mod.html) this function 
/// will update an existing instance with new data.

    $mainrecord->name = strip_tags($autoview->content);
    if (strlen($mainrecord->name) > AUTOVIEW_MAX_NAME_LENGTH) {
        $mainrecord->name = substr($mainrecord->name, 0, AUTOVIEW_MAX_NAME_LENGTH)."...";
    }

    $mainrecord->id=$autoview->instance;
    $mainrecord->timemodified = time();
    $mainrecord->course=$autoview->course;
    $mainrecord->content=$autoview->content;
    $mainrecord->configfile=$autoview->configfile;
    if ($autoview->noframe=="1")
     $mainrecord->noframe=1;
    else
     $mainrecord->noframe=0;    

    $ret=update_record("autoview", $mainrecord);
    autoview_check_configfile($autoview->configfile, $autoview->course);
    return $ret;
}

function autoview_check_configfile($file, $courseid) {
    global $CFG;
    $fileloc=$CFG->dataroot.'/'.$courseid;
    // Check the directory exists and create if necessary
    if (!file_exists($fileloc))
        mkdir($fileloc, $CFG->directorypermissions);
    
    $fileloc=$fileloc.'/'.$file;
    if (!file_exists($fileloc))
        copy($CFG->dirroot.'/mod/autoview/avedit/blank.avx', $fileloc);
}


function autoview_delete_instance($id) {
/// Given an ID of an instance of this module, 
/// this function will permanently delete the instance 
/// and any data that depends on it.  

    if (! $autoview = get_record("autoview", "id", $id)) {
        return false;
    }

    $result = true;

    if (!delete_records("autoview", "id", $autoview->id)) {
        $result = false;
    }

    return $result;
}


function autoview_get_participants($autoviewid) {
//Returns the users with data in one resource
//(NONE, but must exist on EVERY mod !!)

    return false;
}

function autoview_get_coursemodule_info($coursemodule) {
/// Given a course_module object, this function returns any 
/// "extra" information that may be needed when printing
/// this activity in a course listing.
///
/// See get_array_of_activities() in course/lib.php

   return false;
}

function process_xsl($datafile, $stylesheetfile, $parameters)
{
 if (class_exists('XSLTProcessor'))
 {
  /****PHP 5 Style XSL processor****/
  $doc = new DOMDocument();
  $xsltproc = new XSLTProcessor();
  $doc->load($stylesheetfile);
  $xsltproc->importStyleSheet($doc);
  $doc->load($datafile);

  foreach ($parameters as $key => $value)
   $xsltproc->setParameter('', $key, $value);

  return $xsltproc->transformToXML($doc);
 }
 else
 if (function_exists('xslt_create'))
 {
  /****PHP 4 Sablot Style XSL processor****/
  $xsltproc = xslt_create();

  $html=xslt_process($xsltproc, $datafile, $stylesheetfile, NULL, NULL, $parameters);
 
  if (empty($html))
  {
   die('XSLT processing error: '. xslt_error($xsltproc));
  }
  xslt_free($xsltproc);
  return $html;
 }
 else
 if (function_exists('domxml_xslt_stylesheet_file'))
 {
  /****PHP 4 DOM Style XSL processor****/
  $datadoc=domxml_open_file($datafile);
  $stylesheet = domxml_xslt_stylesheet_file($stylesheetfile);
  $htmldoc=$stylesheet->process($datadoc, $parameters);
  return $htmldoc->html_dump_mem();
 }
 else
  return '<p>'.get_string('noxsl', 'autoview').'</p>';
}

function testXSL()
{
 if (method_exists('XSLTProcessor', 'setParameter') || function_exists('domxml_xslt_stylesheet_file(') ||
     function_exists('xslt_create'))
  return true;

 return false;
}

function testPeclHttp()
{
 if (function_exists('http_post_fields') && function_exists('http_parse_message'))
  return true;
 else
  return false;
}


?>

