<?php // $Id: version.php,v 1.5 2006/10/17 10:24:47 janne Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of imagegallery
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2006101002;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
