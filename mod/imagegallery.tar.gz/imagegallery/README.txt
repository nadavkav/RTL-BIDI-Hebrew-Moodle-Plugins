Image gallery - readme
===================================================

Module by Mediamaisteri Group (2005, 2006)
Janne Mikkonen <janne.mikkonen@mediamaisteri.com>

Image gallery is a module used mainly as netpublish
module's image gallery, although it can be used as
just a image gallery.
