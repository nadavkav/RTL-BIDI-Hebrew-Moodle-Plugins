<?PHP // $Id$
      // imagegallery.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['allowstudentupload'] = 'אפשרות העלאת קבצים של תלמידים';
$string['ascending'] = 'סדר יורד';
$string['back'] = 'קודם';
$string['browse'] = 'בחירה';
$string['categorynamemissing'] = 'שם סיווג חסר!!!';
$string['choosegallery'] = 'בחרו אוסף תמונות:';
$string['confirmdeletecategory'] = 'מחיקת סיווג!';
$string['confirmdeletestring'] = 'הנכם עומדים למחוק סיווג <strong>$a</strong> האם אתם בטוחים ?';
$string['confirmimagedelete'] = 'הנכם עומדים למחוק תמונות אילו! האם הנכם בטוחים ?';
$string['createcategory'] = 'יצירת סיווג חדש';
$string['createdby'] = 'נוצר על ידי';
$string['defaultcategory'] = 'סיווג ראשי';
$string['deleteimages'] = 'מחיקת תמונות';
$string['descending'] = 'סדר יורד';
$string['editcategory'] = 'עריכת סיווג: $a';
$string['filesize'] = 'גודל קובץ';
$string['height'] = 'גובה';
$string['image'] = 'תמונה';
$string['imageinfo'] = 'מאפייני התמונה';
$string['imagedeletesuccess'] = 'התמונות שנבחרו נמחקו בהצלחה!';
$string['imageheighttoolarge'] = 'גובה תמונה $a גדול מידי!';
$string['imagemovesuccessful'] = 'Images <strong>$a</strong>, moved successfully!';
$string['imagesperpage'] = 'תמונות בדף';
$string['imagewidthtoolarge'] = 'רוחב תמונה $a גדול מידי!';
$string['intro'] = 'תאור';
$string['managecategories'] = 'ניהול סיווגים';
$string['maxbytes'] = 'גודל תמונה מירבי';
$string['maxdimensions'] = 'מימדים מירביים';
$string['maxheight'] = 'גובה תמונה מירבי';
$string['maxwidth'] = 'רוחב תמונה מירבי';
$string['modulename'] = 'אוסף תמונות';
$string['modulenameplural'] = 'אוספי תמונות';
$string['moveselected'] = 'העברת תמונות מסומנות';
$string['next'] = 'הבא';
$string['noimagesincategory'] = 'לא קיימות תמונות בסיווג זה!';
$string['previous'] = 'הקודם';
$string['requirelogin'] = 'זיהוי משתמש דרוש!';
$string['resizefailed'] = 'תקלה בעת שינוי ממדי התמונה $a שינוי ממדי התמונה כשל.';
$string['resizeimage'] = 'שינוי גודל תמונה';
$string['sortbydate'] = 'סידור על פי תאריך';
$string['sortbyname'] = 'מיון על פי שם תמונה';
$string['sortbysize'] = 'מיון על פי גודל תמונה';
$string['title'] = 'כותרת';
$string['unallowedupload'] = 'אינכם מורשים להעלות תמונה לשרת!';
$string['usedropshadowinthumb'] = 'מסגרת צל';
$string['width'] = 'רוחב';
$string['uploadhelp']  = 'בחרו תמונה מהמחשב שלכם אותה אתם מעוניינים להוסיף לדף זה, הוסיפו תאור ולחצו על הכפתור - העלה';
$string['dimensionchangewarnging'] = 'שימו לב לפני שאתם משנים את מיימדיי התמונה!';
$string['imagesize'] = 'מיימדיי התמונה';
$string['noaccess'] = 'אינכם מורשים לצפות בתוכן זה, אנא פנו לצוות התמיכה של המערכת';


?>
