<?PHP // $Id: imagegallery.php,v 1.4.2.1 2006/12/05 10:05:30 janne Exp $ 
      // imagegallery.php - created with Moodle 1.5.3+ (2005060231)


$string['allowstudentupload'] = 'Salli kuvien lataus opiskelijoille';
$string['ascending'] = 'Nouseva';
$string['browse'] = 'Selaa';
$string['categorynamemissing'] = 'Kategorian nimi puuttuu!!!';
$string['confirmimagedelete'] = 'Olet poistamassa seuraavia kuvia! Haluatko varmasti jatkaa?';
$string['createcategory'] = 'Luo uusi kategoria';
$string['createdby'] = 'Luonut';
$string['decreasesize'] = 'Pienennä';
$string['defaultcategory'] = 'Oletus kategoria';
$string['deleteimages'] = 'Poista kuvia';
$string['descending'] = 'Laskeva';
$string['dimensionchangewarnging'] = 'Varoitus! Kuvan koon muuttaminen voi heikentää kuvan laatua!';
$string['editcategory'] = 'Muokkaa kategoriaa $a';
$string['filesize'] = 'Tiedostokoko';
$string['height'] = 'Korkeus';
$string['image'] = 'Kuva';
$string['imagedeletesuccess'] = 'Valitut kuvat poistettu onnistuneesti!';
$string['imageheighttoolarge'] = 'Kuvan $a korkeus on liian suuri!';
$string['imageinfo'] = 'Kuvan tiedot';
$string['imagesize'] = 'Kuvakoko';
$string['imagesperpage'] = 'Kuvia per sivu';
$string['imagewidthtoolarge'] = 'Kuvan $a leveys on liian suuri!';
$string['increasesize'] = 'Suurenna';
$string['intro'] = 'Kuvaus';
$string['managecategories'] = 'Hallitse kategorioita';
$string['maxbytes'] = 'Suurin tiedostokoko';
$string['maxdimensions'] = 'Suurin mittasuhde';
$string['maxheight'] = 'Suurin korkeus';
$string['maxwidth'] = 'Suurin leveys';
$string['modulename'] = 'Kuvagalleria';
$string['modulenameplural'] = 'Kuvagalleriat';
$string['noimagesincategory'] = 'Ei kuvia tässä kategoriassa!';
$string['requirelogin'] = 'Vaadi kirjautuminen';
$string['sortbydate'] = 'Järjestä päivämäärän mukaan';
$string['sortbyname'] = 'Järjestä nimen mukaan';
$string['sortbysize'] = 'Järjestä tiedostokoon mukaan';
$string['title'] = 'Otsikko';
$string['unallowedupload'] = 'Et voi ladata kuvia palvelimelle!';
$string['width'] = 'Leveys';
$string['uploadhelp'] = '<strong>Sallitut arvot:</strong> $a';
$string['back'] = 'Takaisin';
$string['previous'] = 'Edellinen';
$string['next'] = 'Seuraava';
$string['usedropshadowinthumb'] = 'Käytä varjostusta';
$string['moveselected'] = 'Siirrä valitut kuvat';
$string['choosegallery'] = 'Valitse kuvagalleria: ';
$string['imagemovesuccessful'] = 'Kuvat <strong>$a</strong> sirretty onnistuneesti!';
?>
