/* $Id: styles.php,v 1.5 2009-06-05 20:12:38 jfilip Exp $ */

.elluminateboundarytime {
    text-align: center;
    font-size: 0.8em;
}


.elluminaterecordingmode {
    text-align: center;
    font-size: 0.7em;
}


.elluminateeditmoderators {
    text-align: center;
    font-size: 1em;
    font-weight: bold;
}


.elluminateeditparticipants {
    text-align: center;
    font-size: 1em;
    font-weight: bold;
}


.elluminatepreload {
    text-align: center;
    font-size: 1em;
    font-weight: bold;
}


.elluminatejoinmeeting {
    text-align: center;
    font-size: 1.7em;
    font-weight: bold;
}


.elluminateverifysetup {
    text-align: center;
    font-size: 1em;
    font-weight: bold;
}

.elluminaterecording {
    text-align: center;
    font-size: 1em;
}

.elluminaterecording .description {
    font-style: italic;
}

.elluminateattendance {
    text-align: center;
    font-size: 1em;
}
.elluminaterecordingdescriptionedit {
    text-align: center;
}