<?php // $Id: version.php,v 1.1.2.2 2009/03/18 16:45:55 mchurch Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of elluminate
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2010062500;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 300;         // Period for cron to check this module (secs)

?>
