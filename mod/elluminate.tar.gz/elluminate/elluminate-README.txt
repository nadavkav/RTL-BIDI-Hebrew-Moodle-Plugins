-------------------------------------------------------------------------------
ELLUMINATE LIVE MODULE AND BLOCK.
-------------------------------------------------------------------------------
WIKI DOCUMENTATION:

For the latest updated documentation, please refer to the MoodleDocs wiki page http://docs.moodle.org/en/Elluminate_module

-------------------------------------------------------------------------------
FUNCTION:

The activity module is used to create and manage Elluminate Live! meetings.  These meetings will be created for you on the configured Elluminate Live! scheduling server.  
You can add moderators and participants to the meetings you create.

Once you have installed the module, visit the module configuration screen to add the server information for your Elluminate Live! scheduling server.

The block is used to display links to recent recordings.