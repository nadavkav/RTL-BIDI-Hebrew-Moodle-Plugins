<?php // $Id: version.php,v 1.30.2.1 2008/03/03 11:48:40 moodler Exp $

/**
 * Code fragment to define the version of kaltura
 * This fragment is called by moodle_needs_upgrading() and /admin/index.php
 *
 * @author  Your Name <ofer@homsys.co.il>
 * @version $Id: version.php,v 1.5.2.2 2009/03/19 12:23:11 mudrd8mz Exp $
 * @package mod/kaltura
 */
 


$module->version  = 2009071910;
//$module->requires = 2007101550;  // Requires this Moodle version
$module->cron     = 0;

?>
