<?PHP  // $Id: postgres7.php,v 1.2 2007/10/03 09:33:32 sarjona Exp $

function jclic_upgrade($oldversion) {
/// This function does anything necessary to upgrade 
/// older versions to match current functionality 

    global $CFG;

    return true;
}

?>
