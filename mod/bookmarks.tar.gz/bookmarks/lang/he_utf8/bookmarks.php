<?php

$string['accessdenied'] = 'אינך חבר בקבוצה זו';
$string['additem'] = 'הוספת אתר חדש';
$string['allbookmarks'] = 'כל האתרים';
$string['bookmarks'] = 'קישורי אתרים';
$string['bookmarksintro'] = 'תאור';
$string['bookmarksname'] = 'שם';
$string['canceled'] = 'הפעולה בוטלה';
$string['changegroup'] = 'שינוי';
$string['currenttags'] = 'תוויות קיימות:';
$string['description'] = 'תאור האתר';
$string['deleting'] = 'מחיקת קישור לאתר';
$string['modulenameplural'] = 'מאגרי אתרים';
$string['modulename'] = 'מאגר אתרים';
$string['mybookmarks'] = 'האתרים שלי';
$string['name'] = 'שם האתר';
$string['nogroupsset'] = 'לא נקבעו קבוצות משתמשים במרחב לימוד זה';
$string['noitems'] = 'לא קיימים פריטים';
$string['noresults'] = 'מנגנון החיפוש לא מצא קישור המתאים לבקשתכם';
$string['person'] = 'משתמש';
$string['people'] = 'משתמשים';
$string['repeatedlink'] = 'קישור זה קיים במאגר';
$string['repeatedurl'] = 'קישור זה קיים במאגר';
$string['saving'] = 'נתוני הקישור שהזנתם עודכנו במאגר הקישורים של המערכת';
$string['search'] = 'חיפוש';
$string['seen'] = 'נצפה';
$string['times'] = 'פעמים';
$string['savedby'] = 'נשמר על ידי ';

$string['searchingfor'] = 'חיפוש של: ';
$string['selectedgroup'] = 'קבוצה נוכחית:  $a';
$string['tags'] = 'תוויות האתר(מופרדות בפסיקים)';
$string['url'] = 'כתובת האתר';
$string['validurl'] = 'כתובת אתר תקנית צריכה להתחיל ב: http(s)://';
?>
