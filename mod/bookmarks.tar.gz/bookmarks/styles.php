div.bookmark {
float:right;
margin:13px;
}

div.commands {
	color:#999999;
	display:inline;
	font-size:70%;
}

h3.name{
	color:#333333;
	font-size:100%;
	margin:0.1em 0pt;
	padding:0pt;
	display:inline;
}

p.notes{
	color:#333333;
	font-size:80%;
	margin:0.1em 0pt;
	padding:0pt;
}
div.meta{
	color:#999999;
	font-size:100%;
}
a.tag {
color: #AAAAAA;

	padding: 2px;
}

div.addbookmark{
	text-align: center;
    font-size:25px;
}

div.groupsselect{
	text-align: right;

}

div.searchform{
	text-align: center;

}

div.tagcloud{
	color:#333333;
	font-size:100%;
	width: 23%;
	float: right;
	padding:10px;
}
div.middle{
	width :75%;
	float:left;

}
div.footer{
	position:static;
	clear: both;
}
#intro{
	margin-top: 15px;
}
ul#tag-cloud-list {
border:2px outset;
}

body#mod-bookmarks-edit #id_url {
text-align:left;
direction:ltr;
}