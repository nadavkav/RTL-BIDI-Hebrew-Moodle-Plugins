<?php 

$magtheme['themename'] = 'יומן חדשות';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/the_lighthouse_project.jpg';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-03.jpg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/newpaper-sheet-02.jpg';
$magtheme['frontpagecolums'] = '2';

?>