<?php

$magtheme['themename'] = 'יובלתון';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/yovalton-header.jpeg';
//$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/yovalton-small_756.jpg';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/newpaper-sheet-05.jpg';

//$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/yovalton-section-bg.jpeg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/newpaper-sheet-06.jpg';

$magtheme['frontpagecolums'] = '2';

echo <<<STYLES
<style>
.netpublish-title {
display:none;
}
</style>
STYLES;
?>