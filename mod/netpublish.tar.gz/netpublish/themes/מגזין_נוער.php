<?php 

$magtheme['themename'] = 'עיתון חדשות יומי';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/lucifix.png';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-01.jpg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-03.jpg';
$magtheme['frontpagecolums'] = '1';

?>