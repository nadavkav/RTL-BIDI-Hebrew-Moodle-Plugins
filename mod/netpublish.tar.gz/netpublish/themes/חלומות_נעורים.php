<?php 

$magtheme['themename'] = 'עיתון חדשות';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/untitled_dream.jpg';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-04.jpg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-03.jpg';
$magtheme['frontpagecolums'] = '1';

?>