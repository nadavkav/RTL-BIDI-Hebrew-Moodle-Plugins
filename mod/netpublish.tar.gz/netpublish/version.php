<?php // $Id: version.php,v 1.3.4.2 2009/08/24 08:46:22 janne Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of NEWMODULE
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2009082401;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 300;         // Period for cron to check this module (secs)

?>
