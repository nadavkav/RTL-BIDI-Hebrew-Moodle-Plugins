div.sectiontitle {
font-size:1.4em;
}

.mod-netpublish .boxwidthwide {
width:98%;
}

.magazineheader img {
margin: 0pt auto;
width: 100%;
/* height:80px;  */
height:200px;
float:right;
}

.netpublish-title {
float:right;
font-size:50px;
margin-top:-120px;
padding-right:50px;
}

.sectiontitle {
float:right;
list-style:none;
padding:5px;
}
.sectiontitle a:link, .sectiontitle a:visited {
color:#0000FF;
font-size:2em;
font-style:normal;
text-decoration:none;
}

.sectiontitle a:hover {
background-color:DarkKhaki;
}

.netpublish-article {
float:right;
padding:10px;
width:377px;
}

.netpublish-section {
float:right;
}

.netpublish-section h1 {
color:blue;
}

.netpublish-sectionlist {
padding-right: 0px;
margin-top:0px;
}

.magazineheader {
width: 1024px;
margin: 0 auto;
}

body#mod-netpublish-view .box {
width: 1002px;
margin: 0 auto;
}