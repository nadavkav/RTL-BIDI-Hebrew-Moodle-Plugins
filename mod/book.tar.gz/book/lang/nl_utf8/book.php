<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:04 skodak Exp $ 
      // book.php - created with Moodle 1.5 development (2004082300)


$string['addafter'] = 'Voeg nieuw hoofdstuk toe';
$string['chapterscount'] = 'Hoofdstukken';
$string['chaptertitle'] = 'Hoofdstuk titel';
$string['confchapterdelete'] = 'Wil je dit hoofdstuk echt verwijderen?';
$string['confchapterdeleteall'] = 'Wil je dit hoofdstuk en alle paragrafen echt verwijderen?';
$string['content'] = 'Inhoud';
$string['customtitles'] = 'Titels alleen in inhoudstafel';
$string['disableprinting'] = 'Schakel afdrukken uit';
$string['doimport'] = 'Importeer';
$string['editingchapter'] = 'Bewerk hoofdstuk';
$string['faq'] = 'Boek FAQ';
$string['fileordir'] = 'Bestand of map';
$string['import'] = 'Importeer';
$string['importinfo'] = 'Importeer het gekozen HTML-bestand of map.<br/>De hoofdstukken worden alfabetisch gerangschikt op bestandsnaam.';
$string['importing'] = 'Importeren';
$string['importingchapters'] = 'Importeren van hoofdstukken in het boek';
$string['maindirectory'] = 'Hoofdmap';
$string['modulename'] = 'Boek';
$string['modulenameplural'] = 'Boeken';
$string['navnext'] = 'Volgende';
$string['navprev'] = 'Vorige';
$string['numbering'] = 'Hoofdstuknummering';
$string['numbering0'] = 'Geen';
$string['numbering1'] = 'Nummering';
$string['numbering2'] = 'Bolletjes';
$string['numbering3'] = 'Inspringen';
$string['printbook'] = 'Druk het hele boek af';
$string['printchapter'] = 'Druk dit hoofdstuk af';
$string['printdate'] = 'Datum';
$string['printedby'] = 'Afgedrukt door';
$string['relinking'] = 'Opnieuw linken';
$string['subchapter'] = 'Paragraaf';
$string['toc'] = 'Inhoudstafel';
$string['tocwidth'] = 'Kies de breedte van de inhoudstafel voor alle boeken.';
$string['top'] = 'boven';

?>
