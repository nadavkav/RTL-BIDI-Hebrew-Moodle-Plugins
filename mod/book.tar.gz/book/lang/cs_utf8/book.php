<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:03 skodak Exp $ 
      // book.php - created with Moodle 1.3.3 + (2004052503)


$string['addafter'] = 'Přidat novou kapitolu';
$string['chapterscount'] = 'Počet kapitol';
$string['chaptertitle'] = 'Nadpis';
$string['confchapterdelete'] = 'Opravdu chcete odstranit tuto kapitolu?';
$string['confchapterdeleteall'] = 'Opravdu chcete odstranit tuto kapitolu včetně podkapitol?';
$string['content'] = 'Text';
$string['customtitles'] = 'Uživatelské nadpisy';
$string['disableprinting'] = 'Zakázat tisk';
$string['doimport'] = 'Importovat';
$string['editingchapter'] = 'Úprava kapitoly';
$string['faq'] = 'Časté otázky';
$string['fileordir'] = 'Soubor nebo adresář';
$string['import'] = 'Import';
$string['importinfo'] = 'Importovat HTML soubor nebo všechny soubory v zadané složce.<br />Kapitoly budou seřazeny abecedně podle názvů souborů.<br />Soubory s názvem ve tvaru \'sub_*.*\' jsou vždy importovány jako podkapitoly.';
$string['importing'] = 'Importuji';
$string['importingchapters'] = 'Importování kapitol';
$string['maindirectory'] = 'Hlavní složka';
$string['modulename'] = 'Kniha';
$string['modulenameplural'] = 'Knihy';
$string['navnext'] = 'Následující';
$string['navprev'] = 'Předchozí';
$string['navexit'] = 'Zpět na přehled';
$string['numbering'] = 'Číslování kapitol';
$string['numbering0'] = 'Žádné';
$string['numbering1'] = 'Čísla';
$string['numbering2'] = 'Puntíky';
$string['numbering3'] = 'Odsazené';
$string['printbook'] = 'Vytisknout celou knihu';
$string['printchapter'] = 'Vytisknout jednu kapitolu';
$string['printdate'] = 'Datum';
$string['printedby'] = 'Vytiskl(a)';
$string['relinking'] = 'Relinkuji';
$string['subchapter'] = 'Podkapitola';
$string['toc'] = 'Obsah';
$string['tocwidth'] = 'Vyberte šířku obsahu pro všechny knihy.';
$string['top'] = 'začátek';

?>
