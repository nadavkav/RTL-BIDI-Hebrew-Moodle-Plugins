<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:03 skodak Exp $ 
      // book.php - created with Moodle 1.5 unstable development (2004092000)


$string['addafter'] = 'Lisää uusi luku';
$string['chapterscount'] = 'Luvut';
$string['chaptertitle'] = 'Luvun otsikko';
$string['confchapterdelete'] = 'Haluatko varmasti poistaa tämän luvun?';
$string['confchapterdeleteall'] = 'Haluatko varmasti poistaa tämän luvun ja sen alaluvut?';
$string['content'] = 'Sisältö';
$string['customtitles'] = 'Mukautetut otsikot';
$string['disableprinting'] = 'Estä tulostus';
$string['doimport'] = 'Tuo';
$string['editingchapter'] = 'Luvun muokkaus';
$string['faq'] = 'Usein kysytyt kysymykset';
$string['fileordir'] = 'Tiedosto tai kansio';
$string['import'] = 'Tuo';
$string['importinfo'] = 'Tuo valittu HTML-tiedosto tai kansio.<br />Luvut aakkostetaan tiedostonimien mukaan.';
$string['importing'] = 'Tuodaan';
$string['importingchapters'] = 'Tuodaan kirjan lukuja';
$string['maindirectory'] = 'Päävalikko';
$string['modulename'] = 'Kirja';
$string['modulenameplural'] = 'Kirjat';
$string['navnext'] = 'Seuraava';
$string['navprev'] = 'Edellinen';
$string['numbering'] = 'Lukujen numerointi';
$string['numbering0'] = 'Ei mitään';
$string['numbering1'] = 'Numerot';
$string['numbering2'] = 'Luettelomerkit';
$string['numbering3'] = 'Sisennys';
$string['printbook'] = 'Tulosta koko kirja';
$string['printchapter'] = 'Tulosta tämä luku';
$string['printdate'] = 'Tulostettu';
$string['printedby'] = 'Tulostanut';
$string['relinking'] = 'Uudelleenlinkitys';
$string['subchapter'] = 'Alaluku';
$string['thisdirection'] = 'ltr';
$string['thislanguage'] = 'Suomi';
$string['toc'] = 'Sisällysluettelo';
$string['tocwidth'] = 'Valitse kaikkien kirjojen sisällysluetteloiden leveys.';
$string['top'] = 'Alkuun';

?>
