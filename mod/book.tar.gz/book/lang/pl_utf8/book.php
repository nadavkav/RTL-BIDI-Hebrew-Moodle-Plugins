<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:04 skodak Exp $ 
      // book.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005031000)


$string['addafter'] = 'Dadaj nowy rozdział';
$string['chapterscount'] = 'LIczba rozdziałów';
$string['chaptertitle'] = 'Tytuł rozdziału';
$string['confchapterdelete'] = 'Czy napewno chcesz usunąć ten rozdział';
$string['confchapterdeleteall'] = 'Czy napewno chcesz usunąć ten rozdział i wszystkie jego podrozdziały?';
$string['content'] = 'Zawartość';
$string['customtitles'] = 'Tytuły użytkownika';
$string['disableprinting'] = 'Wyłącz drukowanie';
$string['doimport'] = 'Import';
$string['editingchapter'] = 'Edycja rozdziału';
$string['faq'] = 'FAQ Książki';
$string['fileordir'] = 'Plik lub katalog';
$string['import'] = 'import';
$string['importinfo'] = 'Importuj wybrany plik HTML lub katalog. <br>Rozdziały są sortowane alfabetycznie wg. nazw plików.';
$string['importing'] = 'Importowanie';
$string['importingchapters'] = 'Importowanie rozdziałów do książki';
$string['maindirectory'] = 'Główny katalog';
$string['modulename'] = 'Książka';
$string['modulenameplural'] = 'Książki';
$string['navexit'] = 'Zamknij  książkę';
$string['navnext'] = 'Następny';
$string['navprev'] = 'Poprzedni';
$string['numbering'] = 'Numerowanie rodziałów';
$string['numbering0'] = 'żaden';
$string['numbering1'] = 'Liczby';
$string['numbering2'] = 'Wypunktowanie';
$string['numbering3'] = 'Wcięte';
$string['printbook'] = 'Drukuj kopletną książkę';
$string['printchapter'] = 'Drukuj ten rozdział';
$string['printdate'] = 'Data';
$string['printedby'] = 'Wydrukowane przez użytkoniwka';
$string['relinking'] = 'Ponowne tworzenie linków';
$string['subchapter'] = 'Podrozdział';
$string['toc'] = 'Spis treści';
$string['tocwidth'] = 'Ustaw szrokość spisu treści dla wszystkich książek';
$string['top'] = 'Góra';

?>
