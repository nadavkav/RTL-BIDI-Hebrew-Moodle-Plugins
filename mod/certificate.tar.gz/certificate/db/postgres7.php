<?PHP

function certificate_upgrade($oldversion) {
    global $CFG;

    return true;
}

?>
