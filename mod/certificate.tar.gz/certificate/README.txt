Certificate 4.3 2007042503

*********************************************
Latest version uploaded 04/07/07
Leonardo Terra
*********************************************
General debugging and code fixes.
Solve white screen problem when try to access view.php.
Solve problems in unenrol routine (tks to Verdon Vaillancourt).
Change TCPDF version and configurations trying to solve printing problems.
Layout adjustments.

To do:
Add Preview system to admin.
Add HTML and field options.
*********************************************
Prior Versions:
Leonardo Terra
*********************************************
Certificate 4.2 2007042502
General debugging and code fixes.
Make some improvements on admin interface.

version 4.1+ 20070425
General debugging and code fixes.
This version has been updated to work in Moodle 1.8.

Version 4.1 20070204
Corrections and improvements to date system.

Version 4.0FAT 20070204
Add new date format and calculation system.
Add new conditional emission based in total grade or activities grade.
Add Grade Letter based in course Setup.
Add new security improvements.
Add MSSQL Support.
Add backup/restore to new data base fields.
Add Cancel enrolment routine.
Make some visual and alerts improvements.
General debugging and code fixes.

Version 3.3+ 20070116
Add support on database to future features.
Add full translation to Italian - by Luigi Musina.

Version 3.3 20070116
Add conditional emission based on grade.
Add credit hour.
Add full translation to Portuguese BR. 
Add new date system.

*********************************************
Prior Versions:
Chardelle Busch
*********************************************

Version 3.2 20061012
This version has been updated to work in Moodle 1.7. 

Version 3.1 2006081700
Increased length of course name record
General debugging and code fixes
Fixed symbol printing in course name, mod name and student name

Version 3.1 2006080100
The certificate module has been re-written to better comply with standard Moodle coding and to add
new features:

Added backup/restore.
Added teacher reporting.
Added student certificate review.
Added email teachers.
Added print functions for letter size paper for border and watermark images.  Fixed (hopefully) all certificate alignment.
Reformatted border images to jpeg to make them smaller.
Created the type folder.  New types can be added without having to change the core code.
New/changed certificate options:
Save: Can choose to save students' certificates in moddata.
Delivery:  Open in browser, Force download, email (Thanks Marion DeGroot).
Print Date: Added course end date, more can be added.
Date Format:  Updated for unicode.
Print Code: Updated.
Grade Format: Added three formats


************************************
Version 3.0 updated for 1.6 by Chardelle Busch.  
Added new fpdf security feature so that downloaded certificates can 
only be printed, not edited.
Added mod grade name (Thanks Mike Churchward)

************************************
Prior Versions:

Updated by David T. Cannon, July, 2005
Updated to fpdf class
Added mod grades.
Course grade added by Patrick Jeitler

************************************
Created by Hugo Salgado, July, 2004