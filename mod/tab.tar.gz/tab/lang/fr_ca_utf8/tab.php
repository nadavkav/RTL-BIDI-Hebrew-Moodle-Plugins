<?php // $Id: tab.php,v 1.2 2008/07/01 09:44:05 moodler Exp $ 
      // tab.php - created with Moodle 1.9

$string['name'] = 'Nom';
$string['modulename'] = 'Onglet';
$string['modulenameplural'] = 'Onglets';
$string['tabname'] = 'Nom de l\'onglet';
$string['tabcontent'] = 'Content de l\'onglet';
$string['tabs'] = 'Onglets';
$string['moretabs'] = 'Utiliser plus d\'onglet';
$string['changestyle'] = 'Modifier la feuille de style';
$string['css'] = 'feuille de style';
$string['displaymenu'] = 'Utiliser le menu d\'onglet disponibles';
$string['displaymenuagree'] = 'Cochez si vous d�sirez utiliser le menu';
$string['menucss'] = 'Modifier la feuille de style du menu';
$string['menuname'] = 'Nom du menu';


?>