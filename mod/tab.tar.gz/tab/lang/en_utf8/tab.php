<?php // $Id: tab.php,v 1.2 2008/07/01 09:44:05 moodler Exp $
      // tab.php - created with Moodle 1.9

$string['name'] = 'Name';
$string['modulename'] = 'Tab display';
$string['modulenameplural'] = 'Tab displays';
$string['tabname'] = 'Tab name';
$string['tabcontent'] = 'Tab content';
$string['tabs'] = 'Tabs';
$string['moretabs'] = 'Use more tabs';
$string['changestyle'] = 'Modify stylesheet';
$string['css'] = 'Stylesheet';
$string['displaymenu'] = 'Display tab menu';
$string['displaymenuagree'] = 'Check if you would like to display menu';
$string['displayfp'] = 'Display on Course\'s FronPage?';
$string['menucss'] = 'Modify menu stylesheet';
$string['menuname'] = 'Menu name';
$string['special'] = 'Special Settings';


?>