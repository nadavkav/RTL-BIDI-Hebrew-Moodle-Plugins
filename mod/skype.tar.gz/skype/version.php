<?php 
$module->version  = 2006080702;  
$module->requires = 2006021531;  

?>
