<?
$string['skypetext'] = 'Skype';
$string['modulename'] = 'Skype';
$string['modulenameplural'] = 'Skype';
$string['participants'] = 'Participants';
$string['choosealert'] = 'Choose persons to be able to use skype';
$string['choose'] = 'Choose';
$string['moderator'] = 'Moderator';
?>