<?PHP // $Id: skype.php,v 1.1 2008/11/04 20:46:44 arborrow Exp $ 
      // skype.php - created with Moodle 1.7+ (2006101009)


$string['choose'] = 'Wybierz rozmówców';
$string['choosealert'] = 'Musisz wybrać rozmówców, aby skorzystać ze Skype';
$string['moderator'] = 'Moderator';
$string['modulename'] = 'Skype';
$string['modulenameplural'] = 'Skype';
$string['participants'] = 'Uczestnicy';
$string['skypetext'] = 'Skype';

?>
