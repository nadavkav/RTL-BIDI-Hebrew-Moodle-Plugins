<?php

function label_upgrade($oldversion) {

/// This function does anything necessary to upgrade 

/// older versions to match current functionality 

/// no upgrades yet :)

    return true;

}


?>
