<?PHP // $Id: attforblock.php,v 1.1.2.1 2008/06/20 17:37:42 dlnsk Exp $ 
      // attendanceblk.php - created with Moodle 1.5.3+ (2005060230)


$string['description'] = 'You can add only one module Attendance per course.<br />
If you remove this module it don\'t affect on attendances! You can use this module only together with block Attendance. This module need only for include grades of attendances to main course\'s grades.';
$string['modulename'] = 'Attendance (for Block)';
$string['modulenameplural'] = 'Attendances (for Block)';
$string['modulenamesimple'] = 'Attendance';

?>
