<?PHP // $Id: attforblock.php,v 1.1.2.1 2008/06/20 17:37:42 dlnsk Exp $ 
      // attendanceblk.php - created with Moodle 1.5.3+ (2005060230)


$string['description'] = 'Sólo puede añadir un módulo de Asistencia por curso.<br />
La eliminación de este módulo no afecta a la asistencia!! Debe usar este módulo junto con el bloque Asistencia. 
Este módulo se necesita sólo para incluir puntucaciones de asistencia a las untuaciones generales del curso principal.';
$string['modulename'] = 'Asistencia (para Bloque)';
$string['modulenameplural'] = 'Asistencias (para Bloque)';
$string['modulenamesimple'] = 'Asistencia';

?>
