<?php // $Id: version.php,v 1.30 2008/08/04 08:37:04 pigui Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2009012201;
$module->requires = 2007020200;  // Requires this Moodle version. 1.8 or newer
$module->cron     = 0; // How often should cron check this module (seconds)?

?>
