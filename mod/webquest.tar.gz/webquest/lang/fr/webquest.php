<?PHP // $Id: webquest.php,v 1.1 2007/02/02 18:01:45 stronk7 Exp $ webquest.php, [fr] library ,v 1.0 2007/01/16 12:00:00  darkath Exp $
//.. translated by Jean Willy Dorval. and corrected by Dariem(Demian)

$string['accumulative'] = 'Acumulative';
$string['assessmentend'] = 'Fin des evaluations';
$string['assessmentstart'] = 'Commencement des evaluations';
$string['conclussion'] = 'Conclusions';
$string['couldnotdelete'] = 'On ne peut pas effacer l\' objet seleccion�';
$string['criterion'] = 'Crit�re';
$string['deleted'] = 'L\'Objet seleccion� a �t� effac� correctement';
$string['editresources'] = 'changer les ressources';
$string['editresource'] = 'changer ressource';              
$string['edittasks'] = 'changeant des devoirs';
$string['errorbanded'] = 'Marge d\' erreur';
$string['errortable'] = 'Table d\' erreur';
$string['goedittasks'] = 'changer des devoirs';
$string['grade'] = 'Note des �valuations';
$string['gradetable'] = 'Table de note';
$string['gradingstrategy'] = 'Strat�gie d\'�valuation';
$string['insertresources'] = 'Ajouter ressources';
$string['intro'] = 'Introduction';
$string['invaliddates'] = 'Les dates que vous avez saisies sont invalides.
Veuillez utiliser le bouton Arri�re de votre navigateur pour r�afficher le formulaire et corriger les dates.';
$string['modulename'] = ' WebQuest ';
$string['modulenameplural'] = ' WebQuests ';
$string['notgraded'] = 'Pas encore califiqu�';
$string['numberofattachments'] = 'Numero d\'anexes � chaque envoie';
$string['numberofnegativeresponses'] = 'Numero de Reponses Negatives';
$string['numbertasks'] = ' N�mero de devoirs a realis�';
$string['pages'] = 'Pages';
$string['process'] = 'Proces';
$string['releaseteachergrades'] = 'Publier les notes des professeurs';
$string['resource'] = 'Ressource';
$string['resources'] = 'Ressources';
$string['rubric'] = 'Rubrique';
$string['scale10'] = 'Note jusqu\'� 10';
$string['scale100'] = 'Note jusqu\'� 100';
$string['scale20'] = 'Note jusqu\'� 20';
$string['scalecorrect'] = 'bar�me de 2 points: Correct ou Incorrect';
$string['scaleexcellent4'] = 'bar�me � 4 points: de Excelent � tr�s Mal';
$string['scaleexcellent5'] = 'bar�me � 5 points: de Excelent � tr�s Mal';
$string['scaleexcellent7'] = 'bar�me � 7 points: de Excelent � tr�s Mal';
$string['scalegood3'] = 'bar�me � 3 points: de Sufisant a Insufisant';
$string['scalepresent'] = 'bar�me � 2 points: Present ou Absent';
$string['scaleyes'] = 'bar�me � 2 points: oui ou Non';
$string['submissionend'] = 'Fin des envoies';
$string['submissionstart'] = 'Commencement des envoies';
$string['suggestedgrade'] = 'Note suger�e';
$string['suretodelres'] = '�Tu veux effacer ce ressource?';
$string['task'] = 'devoir';
$string['tasks'] = 'devoirs';
$string['taskweight'] = 'Coefficient';
$string['typeofscale'] = 'Type de bar�me';
$string['url'] = 'url';
$string['usepassword'] = 'Utiliser un mot de passe';
$string['viewresources'] = 'Visualizer ressources';
$string['warningtask'] = 'AVISO: Hay evaluaciones enviadas.<br />No cambie el n�mero de tareas, el tipo de escala o los pesos de tarea.';
$string['wellsaved'] = 'Enregistrement r�ussi';




?>