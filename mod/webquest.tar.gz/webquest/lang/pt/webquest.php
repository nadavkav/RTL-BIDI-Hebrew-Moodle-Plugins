<?PHP // $Id: webquest.php,v 1.1 2007/02/02 18:01:45 stronk7 Exp $ webquest.php, [pt] library ,v 1.0 2007/01/16 12:00:00  darkath Exp $
//translated by Katherine Sierra
$string['accumulative'] = 'Acumulativo';
$string['assessmentend'] = 'Fim das avalia��es';
$string['assessmentstart'] = 'In�cio das avalia��es';
$string['conclussion'] = 'Conclusiones';
$string['couldnotdelete'] = 'N�o foi poss�vel apagar o elemento selecionado';
$string['criterion'] = 'Crit�rio';
$string['deleted'] = 'O elemento selecionado foi apagado com sucesso';
$string['editresources'] = 'Editar recursos';
$string['editresource'] = 'Editar recurso'; 
$string['edittasks'] = 'Editando tarefas';
$string['errorbanded'] = 'Margem de erro';
$string['errortable'] = 'Tabela de Erro';
$string['goedittasks'] = 'Editar tarefas';
$string['grade'] = 'Nota';
$string['gradetable'] = 'Tabela de notas';
$string['gradingstrategy'] = 'Estrat�gia de Avalia��o';
$string['insertresources'] = 'Inserir Recurso';
$string['intro'] = 'Introdu��o ';
$string['invaliddates'] = 'As datas que voc� inseriu n�o s�o poss�veis.<br />Volte � p�gina anterior com o uso do men� de navega��o do browser e corrija as datas inseridas no forml�rio.';
$string['modulename'] = 'WebQuest';
$string['modulenameplural'] = 'WebQuests';
$string['notgraded'] = 'Nenhuma nota';
$string['numberofattachments'] = 'N�mero de Anexos previstos em trabalhos enviados';
$string['numberofnegativeresponses'] = 'N�mero de Respostas Negativas';
$string['numbertasks'] = 'N�mero de tarefas a fazer';
$string['pages'] = 'P�ginas';
$string['process'] = 'Processo';
$string['releaseteachergrades'] = 'Publicar as notas do Professor';
$string['resource'] = 'Recurso';
$string['resources'] = 'Recursos';
$string['rubric'] = 'Rubrica';
$string['scale10'] = 'Escala de 10';
$string['scale100'] = 'Escala de 100';
$string['scale20'] = 'Escala de 20';
$string['scalecorrect'] = 'Escala de 2 pontos: correto/incorreto';
$string['scaleexcellent4'] = 'Escala de 4 pontos: excelente/muito pobre';
$string['scaleexcellent5'] = 'Escala de 5 pontos: excelente/muito pobre';
$string['scaleexcellent7'] = 'Escala de 7 pontos: excelente/muito pobre';
$string['scalegood3'] = 'Escala de 3 pontos: bom/pobre';
$string['scalepresent'] = 'Escala de 2 pontos: presente/ausente';
$string['scaleyes'] = 'Escala de 2 pontos: sim/n�o';
$string['submissionend'] = 'Fim dos env�os';
$string['submissionstart'] = 'In�cio dos env�os';
$string['suggestedgrade'] = 'Nota sugerida';
$string['suretodelres'] = '�Voc� tem certeza absoluta que quer apagar este recurso?';
$string['task'] = 'Tarefa';
$string['tasks'] = 'Tarefas';
$string['taskweight'] = 'Peso da tarefa';
$string['typeofscale'] = 'Tipo de Escala';
$string['url'] = 'url';
$string['usepassword'] = 'Usar senha';
$string['viewresources'] = 'Visualizar recursos';
$string['warningtask'] = 'Aten��o: J� foram enviadas algumas avalia��es. <br /> N�o mude o n�mero de tarefas, o tipo de escala ou os pesos das tarefas.';
$string['wellsaved'] = 'Salvado com sucesso ';




?>