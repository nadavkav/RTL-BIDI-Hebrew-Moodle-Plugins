<?php // // $Id: version.php,v 1.3 2007/09/09 09:00:21 stronk7 Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of WebQuest
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007081222;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>