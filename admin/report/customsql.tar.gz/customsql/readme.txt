See http://docs.moodle.org/en/Custom_SQL_queries_report
