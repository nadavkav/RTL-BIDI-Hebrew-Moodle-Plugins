.reporttitle {
font-size:1.1em;
}

#admin-report-customsql-edit #id_querysql {
direction:ltr;
}