.yui-ac-content {
background-color: Azure;
    border: 1px solid;
}