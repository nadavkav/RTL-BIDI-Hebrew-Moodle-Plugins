<?php
	//24/8/2009 Ângelo Rigo www.u4w.com.br
	$string['any'] = 'Qualquer';
	$string['courseid'] = 'ID do Curso';
	$string['coursename'] = 'Nome do Curso';
	$string['coursesize'] = 'Tamanhos dos Cursos';
	$string['disksize'] = 'Espaço em Disco';
	$string['displaycategory'] = 'Exibir nome da categoria pai' ;
	$string['displaysize'] = 'Exibir tamanho em  ';
	$string['nothingtoreport'] = 'Nada a informar';
	$string['site'] = 'Site';
	$string['total'] = 'Total';

?>
