<?php

$string['any'] = 'Any';
$string['courseid'] = 'Course ID';
$string['coursename'] = 'Course Name';
$string['coursesize'] = 'Course Sizes';
$string['disksize'] = 'Disk Size';
$string['displaycategory'] = 'Display parent category name ';
$string['displaysize'] = 'Display size in ';
$string['nothingtoreport'] = 'Nothing to report';
$string['site'] = 'Site';
$string['total'] = 'Total';

?>
