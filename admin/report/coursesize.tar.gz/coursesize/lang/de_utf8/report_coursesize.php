<?php

$string['any'] = 'Egal';
$string['courseid'] = 'Kurs ID';
$string['coursename'] = 'Kurs Bezeichnung';
$string['coursesize'] = 'Kursgröße';
$string['disksize'] = 'Belegter Web-Space';
$string['nothingtoreport'] = 'Nichts zu berichten';
$string['site'] = 'Web-Adresse';
$string['displaycategory'] = 'Kategorie anzeigen ';
$string['displaysize'] = 'Anzeigen in ';
$string['total'] = 'Summe';

?>