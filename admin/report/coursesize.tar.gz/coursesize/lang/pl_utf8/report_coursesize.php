﻿<?php

$string['any'] = 'Wszystkie';
$string['courseid'] = 'Numer ID kursu';
$string['coursename'] = 'Nazwa Kursu';
$string['coursesize'] = 'Rozmiary Kursu';
$string['disksize'] = 'Rozmiar dysku';
$string['displaycategory'] = 'Pokaż nazwę kategorii nadrzędnej ';
$string['displaysize'] = 'Pokaż rozmiar w ';
$string['nothingtoreport'] = 'Nic do raportu';
$string['site'] = 'Strona';
$string['total'] = 'Razem';

?>
