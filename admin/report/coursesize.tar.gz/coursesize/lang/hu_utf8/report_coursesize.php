<?PHP 

$string['any'] = 'Automatikus';
$string['courseid'] = 'Kurzusazonosító';
$string['coursename'] = 'Kurzusnév';
$string['coursesize'] = 'Kurzusok mérete';
$string['disksize'] = 'Méret';
$string['displaycategory'] = 'Mutassa a szülőkategóriát?';
$string['displaysize'] = 'Mértékegység:';
$string['nothingtoreport'] = 'Nincs adat...';
$string['site'] = 'Oldal';
$string['total'] = 'Összesen:';

?>