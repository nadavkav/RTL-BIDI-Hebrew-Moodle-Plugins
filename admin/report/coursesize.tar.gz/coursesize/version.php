<?php

$plugin->version  = 2008021200;
//$plugin->requires = 2007101532;
$plugin->requires = 2007101520;


?>
