<?php

$string['enrollintocourses'] = 'Enroll into Courses';
$string['sendemail'] = 'Send eMail';
$string['enroluser'] = 'Enrol User';

?>