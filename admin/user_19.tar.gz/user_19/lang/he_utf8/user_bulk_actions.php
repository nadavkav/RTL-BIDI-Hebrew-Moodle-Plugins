<?php

$string['enrollintocourses'] = 'הרשמה לקורסים';
$string['sendemail'] = 'שליחת דואר';
$string['enroluser'] = 'רישום משתמש';

?>