<?php
/**
 * Created by Nadav Kavalerchik
 * User: nadavkav@gmail.com
 * Date: 6/12/11
 *
 * Display all Open Courses on this system
 */

$string['opencourses'] = 'קורסים זמינים לציבור הרחב';
$string['teachers'] = 'מרצים בקורס:';

?>