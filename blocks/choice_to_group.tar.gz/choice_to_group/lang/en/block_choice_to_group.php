<?php

// block_choice_to_group.php - created with Moodle 1.8+
$string['blockname'] = 'Choice to group';
$string['functions'] = 'Functions';
$string['description'] = 'Description';
$string['mode1_entry'] = 'Standard Group Creation';
$string['mode1_description'] = 'Delete existing groups and create the new groups according to choice';
$string['no_choices'] = 'No choice in this course';
$string['mode1_action'] = 'Newly assign groups/users';
$string['is_processing'] = "Processing of data";
$string['deletion_successful'] = 'Existing groups have been deleted';
$string['group_creation_successful'] = 'Group creation has been successful';
$string['group_assignment_successful'] = "Groups have been successfully assigned to course";
$string['user_assignment_successful'] = "Users have been successfully assigned to groups";
$string['add_user'] ="Add User";
$string['to_group'] = "to group";
$string['hinzu'] = "";
$string['no_users'] = "No answers in this choice";

?>