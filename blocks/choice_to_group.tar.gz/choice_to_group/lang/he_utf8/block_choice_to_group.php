<?php

// block_choice_to_group.php - created with Moodle 1.8+
$string['blockname'] = 'קבוצות משאלת סקר';
$string['functions'] = 'אפשרויות';
$string['description'] = 'תאור';
$string['mode1_entry'] = 'יצירת קבוצות רגילות';
$string['mode1_description'] = 'מחיקת קבוצות קיימות ויצירת קבוצות חדשות על פי הבחירה';
$string['mode1_description_update'] = 'יצירת קבוצות חדשות על פי הבחירה';
$string['no_choices'] = 'לא קיימת פעילות \"שאלת סקר\" בקורס זה';
$string['mode1_action'] = 'משתמשים/קבוצות חדשות';
$string['is_processing'] = "מבצע תהליך יצירת קבוצות...";
$string['deletion_successful'] = 'קבוצות קיימות נמחקו בהצלחה';
$string['group_creation_successful'] = 'קבוצות חדשות נוצרו בהצלחה';
$string['group_assignment_successful'] = "קבוצות חדשות שוייכו לקורס";
$string['user_assignment_successful'] = "משתמשים שוייכו לקבוצות חדשות בהצלחה";
$string['add_user'] ="הוספת משתמש";
$string['to_group'] = "לקבוצה";
$string['hinzu'] = "";
$string['no_users'] = 'לא קיימות תשובות בפעילות \"שאלת סקר\" זו';

?>