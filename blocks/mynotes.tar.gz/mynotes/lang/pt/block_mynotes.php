<?PHP // $Id$ block_mynotes.php (pt lang) - created by Hugo Santos

// Name and Title
$string['blockname']       = 'Mynotes';
$string['blocktitle']      = 'Bloco de notas';

//Config..
$string['configchars']      = 'N�mero de caracteres a pre-visualizar para cada nota no bloco.';

// Form strings...
$string['add']             = 'Adicionar';
$string['confirm_delete']  = 'Tem a certeza que deseja remover a nota?';
$string['delete']          = 'Remover';
$string['last_updated']    = '�ltima actualiza��o';
$string['noaccess']        = '(Sem acesso)';
$string['nonotes']         = '(Sem notas no bloco)';
$string['orderby']         = 'Ordenar por:';
$string['priority']        = 'Prioridade';
$string['save']            = 'Guardar';
$string['text']            = 'Texto';

// Errors...
$string['error_inserting'] = 'Erro ao inserir nota.';
$string['error_editing']   = 'Erro ao editar nota.';
$string['error_removing']  = 'Erro ao remover nota.';

?>
