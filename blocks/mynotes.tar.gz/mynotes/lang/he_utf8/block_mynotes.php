<?PHP // $Id$ 
      // block_mynotes.php (en lang) created by Hugo Santos

// Name and Title
$string['blockname']       = 'פתקים';
$string['blocktitle']      = 'פתקים שלי';

//Config..
$string['configchars']      = 'מספר תווים להצגה בתצוגה מקדימה של פתק';

// Form strings...
$string['add']             = 'הוספה';
$string['confirm_delete']  = 'הפתק ימחק. האם אתם בטוחים?';
$string['delete']          = 'מחיקה';
$string['last_updated']    = 'עדכון אחרון';
$string['noaccess']        = '(אין הרשאה)';
$string['nonotes']         = '(לא קיימים פתקים)';
$string['orderby']         = 'מיון על פי:';
$string['priority']        = 'עדיפות';
$string['save']            = 'שמירה';
$string['text']            = 'מלל';

// Errors...
$string['error_inserting'] = 'תקלה בעת הוספה של פתק חדש.';
$string['error_editing']   = 'תקלה בעת עריכה של פתק.';
$string['error_removing']  = 'תקלה בעת מחיקה של פתק.';

?>
