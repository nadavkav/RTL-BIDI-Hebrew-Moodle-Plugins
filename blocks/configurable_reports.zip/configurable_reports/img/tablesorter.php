
    <script type="text/javascript" id="js">
        $(document).ready(function() {
                // call the tablesorter plugin
                $("table").tablesorter();         
        });    
    </script>

