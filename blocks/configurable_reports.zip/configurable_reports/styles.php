#blocks-configurable_reports-editcomp.dir-rtl form.mform div.felement,
#blocks-configurable_reports-editcomp.dir-rtl form.mform fieldset.felement {
    direction: ltr;
}

.blocks-configurable_reports .tabrow0 li {
width:115px !important;
background:none !important;
border-top:1px solid gray;
border-right:1px solid gray;
border-left:1px solid gray;
margin-left: 3px !important;
-webkit-border-top-left-radius: 3px;
-webkit-border-top-right-radius: 3px;
-moz-border-radius-topleft: 3px;
-moz-border-radius-topright: 3px;
border-top-left-radius: 3px;
border-top-right-radius: 3px;
}

.blocks-configurable_reports #newreport {
text-align: center;
border: 2px outset gray;
width: 200px;
margin: 10px auto;
background-color: beige;
}