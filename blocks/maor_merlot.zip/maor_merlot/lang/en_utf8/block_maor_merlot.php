<?php

$string['maor_merlot'] = 'Search Maor repository';
$string['newblock'] = 'Search Maor repository';
