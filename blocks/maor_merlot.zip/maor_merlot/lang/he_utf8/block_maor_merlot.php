<?php

$string['maor_merlot'] = 'חיפוש במאגר מאור';
$string['newblock'] = 'חיפוש במאגר מאור';
