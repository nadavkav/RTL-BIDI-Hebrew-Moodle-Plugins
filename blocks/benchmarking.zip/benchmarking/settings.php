<?php  //$Id: settings.php,v 1.1.2.2 2007/12/19 17:38:49 skodak Exp $

$settings->add(new admin_setting_configtext('block_benchmarking_modules', get_string('benchmarkingmodules', 'block_benchmarking'),
                   '', get_string('modules', 'block_benchmarking'), PARAM_RAW));

?>
