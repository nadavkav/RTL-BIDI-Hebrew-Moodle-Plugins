<?php

$string['pluginname'] = 'Benchmarking';
$string['benchmarking'] = 'Benchmarking';
$string['bmlevel'] = 'This course has been benchmarked at level: ';
$string['wtotalsc'] = 'With a total score of: ';

$string['notapplicable'] = 'Not Applicable';
$string['bronze'] = 'Bronze';
$string['silver'] = 'Silver';
$string['gold'] = 'Gold';
$string['platinum'] = 'Platinum';

$string['benchmarkingmodules'] = 'Modules + Weights';
$string['modules'] = 'assignment=1,forum=2,quiz=3,wiki=3,ouwiki=3,oublog=4,data=5,label=2';


?>
