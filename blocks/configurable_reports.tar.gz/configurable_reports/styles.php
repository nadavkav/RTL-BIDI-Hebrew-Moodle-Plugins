#blocks-configurable_reports-editcomp.dir-rtl form.mform div.felement,
#blocks-configurable_reports-editcomp.dir-rtl form.mform fieldset.felement {
    direction: ltr;
}