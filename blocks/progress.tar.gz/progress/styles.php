.block_progress .progressBarProgressTable {
    width: 98%;
    margin: 0 0 2px 0;
}

.block_progress .progressBarCell {
    border: 1px solid #000000 !important;
    height: 15px;
    margin: 0;
    padding: 0;
    text-align: center;
    vertical-align: middle;
}

.block_progress .progressBarCell img {
    width: 70%;
}

.block_progress .progressEventInfo {
    font-size: x-small;
    text-align: left;
}

.block_progress #progressBarHeader {
    font-size: 8pt;
}