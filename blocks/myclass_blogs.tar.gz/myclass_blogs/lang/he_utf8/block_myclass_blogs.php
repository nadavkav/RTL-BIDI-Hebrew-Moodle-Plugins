<?php

$string['blockname'] = 'הבלוגים של חברי לכיתה';

?>