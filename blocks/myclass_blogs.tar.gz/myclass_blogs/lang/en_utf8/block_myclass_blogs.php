<?php

$string['blockname'] = 'My Class Blogs';

?>