﻿<?php

// block_choice_to_group.php - created with Moodle 1.8+
//Traducido por raul.fh@gmail.com

$string['blockname'] = 'De consulta a grupo';
$string['functions'] = 'Funciones';
$string['description'] = 'Descripción';
$string['mode1_entry'] = 'Creación de grupos estándard';
$string['mode1_description'] = 'Borrar grupos existentes i crear los nuevos grupos de acuerdo con la consulta';
$string['no_choices'] = 'No hay ninguna consulta en este curso';
$string['mode1_action'] = 'Asignar nuevos grupos o usuarios';
$string['is_processing'] = "Procesando datos...";
$string['deletion_successful'] = 'Los grupos existentes han sido borrados';
$string['group_creation_successful'] = 'La creación de grupos ha sido un éxito';
$string['group_assignment_successful'] = "La asignación del los grupos al curso ha sido un éxito";
$string['user_assignment_successful'] = "La asignación de usuarios a los grupos ha sido un éxito";
$string['add_user'] ="Añadiendo el usuario";
$string['to_group'] = "al grupo";
$string['hinzu'] = "";
$string['no_users'] = "No hay respuestas en esta consulta";

?>