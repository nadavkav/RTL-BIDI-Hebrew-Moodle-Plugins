<?php

// block_choice_to_group.php - created with Moodle 1.8+
$string['blockname'] = 'Choice to group';
$string['functions'] = 'Funktionen';
$string['description'] = 'Beschreibung';
$string['mode1_entry'] = 'Standard Gruppenerstellung';
$string['mode1_description'] = 'Hier werden alle bereits erstellten Gruppen<BR>gel&ouml;scht und neu angelegt';
$string['no_choices'] = 'Keine Abstimmungen vorhanden';
$string['mode1_action'] = 'Gruppen/Benutzer neu aufteilen';
$string['is_processing'] = "Bearbeitung wird durchgef&uuml;hrt";
$string['deletion_successful'] = 'Bereits existierende Gruppen erfolgreich gel&ouml;scht';
$string['group_creation_successful'] = 'Die Gruppen wurden erfolgreich erstellt';
$string['group_assignment_successful'] = "Die Verbindungen Gruppen <-> Kurs wurde erfolgreich erstellt";
$string['user_assignment_successful'] = "Die Benutzer wurden den Gruppen erfolgreich zugebucht";
$string['add_user'] ="F&uuml;gt Nutzer";
$string['to_group'] = "zur Gruppe";
$string['hinzu'] = "hinzu";
$string['no_users'] = "In dieser Abstimmung haben noch kein Benutzer abgestimmt";

?>