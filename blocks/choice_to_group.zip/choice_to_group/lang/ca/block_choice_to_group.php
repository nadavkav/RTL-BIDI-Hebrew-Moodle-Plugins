<?php

// block_choice_to_group.php - created with Moodle 1.8+
//traducci� de raul.fh@gmail.com

$string['blockname'] = 'De consulta a grup';
$string['functions'] = 'Funcions';
$string['description'] = 'Descripci�';
$string['mode1_entry'] = 'Creaci� est�ndard de grups';
$string['mode1_description'] = 'Esborrar grups existents i crear els nous grups d\'acord a la consulta';
$string['no_choices'] = 'No hi ha cap consulta en aquest curs';
$string['mode1_action'] = 'Asignar nous grups o usuaris';
$string['is_processing'] = "Processant les dades...";
$string['deletion_successful'] = 'S\'han esborrat els grups existents';
$string['group_creation_successful'] = 'La creaci� de grups ha estat un �xit.';
$string['group_assignment_successful'] = 'L\'assignaci� de grups al curs ha estat un �xit';
$string['user_assignment_successful'] = 'L\'assignaci� dels usuaris als grups ha estat un �xit.';
$string['add_user'] ="Afegint l'usuari";
$string['to_group'] = "al grup";
$string['hinzu'] = "";
$string['no_users'] = "No hi ha respostes en aquesta consulta";

?>