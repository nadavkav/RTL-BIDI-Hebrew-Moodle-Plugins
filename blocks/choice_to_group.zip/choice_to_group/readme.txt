/**
   @author Jochen Lackner, Markus Pusswald
   @license http://opensource.org/licenses/gpl-license.php GNU Public License
*/

Install
1. copy lang to moodledata
2. copy blocks to moodleroot
3. done