<?php

$string['blockname'] = 'הֶעָרוֹת תלמידים';
$string['instructions'] = '<div><strong>הפעלת תצוגת הערות</strong></div><div>תוסיף שכבת מידע חדשה על הדף הנוכחי המציגה את הערות המשתמשים השונים שבקרו בדף זה</div>';
$string['annotate'] = 'תצוגת הֶעָרוֹת';
$string['connect'] = 'הזדהות ראשונית';
$string['configinstructions'] = 'אנא הזינו את פרטי חשבון דיגגו הכיתתי שלכם.<br/> בו ישתמשו כל התלמידים כדי לכתוב הערות על הדפים השונים במרחב הלימוד';
$string['configusername'] = 'שם משתמש';
$string['configpassword'] = 'סיסמה';

?>