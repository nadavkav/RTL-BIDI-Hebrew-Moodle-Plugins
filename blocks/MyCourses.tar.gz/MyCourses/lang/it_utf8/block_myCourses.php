<?php //Versione: 2008081901
      //Autore, Traduttore: Rosario Carco 

$string['blocktitle'] = 'iMieiCorsi'; //Cr: can not be My courses because it collides with course_list block

$string['enrol'] = 'Tutti i corsi'; //Show Moodle's course page
$string['enablejs'] = 'Attivare JavaScript per vedere la navigazione.';

$string['hideinactivecourses'] = 'Nascondere i corsi inattivi';
$string['showinactivecourses'] = 'Mostrare i corsi inattivi';

$string['hideactivecourses'] = 'Nascondere i corsi attivi';
$string['showactivecourses'] = 'Mostrare i corsi attivi';

$string['hidemycourses'] = 'Nascondere i miei corsi';
$string['showmycourses'] = 'Mostrare i miei corsi';

?>
