<?php //Version: 2008081901
      //Author, Translator: Rosario Carco

$string['blocktitle'] = 'myCourses'; //Cr: can not be My courses because it collides with course_list block

$string['enrol'] = 'Show all courses'; //Show Moodle's course page
$string['enablejs'] = 'Enable JavaScript to show navigation.';

$string['hideinactivecourses'] = 'Hide inactive courses';
$string['showinactivecourses'] = 'Show inactive courses';

$string['hideactivecourses'] = 'Hide active courses';
$string['showactivecourses'] = 'Show active courses';

$string['hidemycourses'] = 'Hide my courses';
$string['showmycourses'] = 'Show my courses';

?>
