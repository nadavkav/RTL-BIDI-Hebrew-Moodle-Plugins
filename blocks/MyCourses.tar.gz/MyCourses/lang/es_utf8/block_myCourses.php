<?php //Version: 2008081901
      //Autor, Traductor: Rosario Carco 

$string['blocktitle'] = 'misCursos'; //Cr: can not be My courses because it collides with course_list block

$string['enrol'] = 'Todos los cursos'; //Mostrar la pagina de los cursos de Moodle
$string['enablejs'] = 'Activar JavaScript para ver la navegaci&oacute;n.';

$string['hideinactivecourses'] = 'Esconder los cursos inactivos';
$string['showinactivecourses'] = 'Mostrar los cursos inactivos';

$string['hideactivecourses'] = 'Esconder los cursos activos';
$string['showactivecourses'] = 'Mostrar los cursos activos';

$string['hidemycourses'] = 'Esconder mis cursos';
$string['showmycourses'] = 'Mostrar mis cursos';

?>
