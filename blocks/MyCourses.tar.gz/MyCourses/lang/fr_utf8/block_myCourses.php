<?php //Version: 2008081901
      //Auteur, Traducteur: Rosario Carco

$string['blocktitle'] = 'mesCours'; //Cr: can not be My courses because it collides with course_list block

$string['enrol'] = 'Montrer tous les cours'; //montrer la page des cours de moodle
$string['enablejs'] = 'Activer JavaScript pour montrer la navigation.';

$string['hideinactivecourses'] = 'Cacher les cours inactifs';
$string['showinactivecourses'] = 'Montrer les cours inactifs';

$string['hideactivecourses'] = 'Cacher les cours actifs';
$string['showactivecourses'] = 'Montrer les cours actifs';

$string['hidemycourses'] = 'Cacher mes cours';
$string['showmycourses'] = 'Montrer mes cours';

?>
