<?php

$string['pluginname'] = 'מידת השימוש ברכיבים';
$string['benchmarking'] = 'מידת השימוש ברכיבים';
$string['bmlevel'] = 'רמת השימוש ברכיבים פדגוגיים בקורס זה היא: ';
$string['wtotalsc'] = 'ניקוד כללי: ';

$string['notapplicable'] = 'טרם חושב';
$string['bronze'] = 'ברונזה';
$string['silver'] = 'כסף';
$string['gold'] = 'זהב';
$string['platinum'] = 'פלטינה';

$string['benchmarkingmodules'] = 'רשימת רכיבים + משקלים';

?>
