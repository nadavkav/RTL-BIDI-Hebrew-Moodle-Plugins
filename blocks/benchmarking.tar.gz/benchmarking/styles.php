div#pre {
    font-weight: bold;
    text-align: center;
}

div#level {
    font-size: 18px;
    font-weight: bold;
    text-align: center;
    padding-top: 4px;
    padding-bottom: 6px;
}

div#score {
    font-weight: bold;
    text-align: center;
}
