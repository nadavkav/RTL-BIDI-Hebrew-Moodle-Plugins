<?php
global $CFG;
/*  USER CONFIGURATION FILE
 *  -----------------------
 *  Please change the values below but DO NOT alter
 *  the structure of this file.
*/


// MODULE NAMES AND SCORE WEIGHTINGS
// Add modules in the format '<MODULENAME>' => <WEIGHTING>, etc...
$modulesz = array(
    'assignment' => 1,
    'forum' => 2,
    'quiz' => 3,
    'wiki' => 3,
    'ouwiki' => 3,
    'oublog' => 4,
    'data' => 5, // database
    'label' => 2,
);

$modules = array();

$modulelist = explode(',',$CFG->block_benchmarking_modules);
foreach ($modulelist as $module) {
    list($modname,$modweight) = explode('=',$module);
    $modules[$modname] = $modweight;
}

// BENCHMARKING SCORE LEVELS
// Define the levels and the scores required for each
// MUST BE IN ASCENDING ORDER
$levels = array(
    get_string('notapplicable','block_benchmarking')  => 0,
    get_string('bronze','block_benchmarking') => 20,
    get_string('silver','block_benchmarking') => 50,
    get_string('gold','block_benchmarking') => 300,
    get_string('platinum','block_benchmarking') => 500
);


// STUDENT POINTS ASSIGNMENT
// Define the number of points added per enrolled student

$stupoints = 1;


?>
