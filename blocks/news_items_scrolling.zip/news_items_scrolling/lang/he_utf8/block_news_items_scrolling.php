<?php

$string['addanewitem'] = 'הוסיפו הודעה חדשה';
$string['olditems'] = 'רשימת הודעות ישנות';
$string['more'] = 'להודעה המלאה';
$string['latestnewsscrolling'] = 'חדשות אחרונות נגללות';


?>