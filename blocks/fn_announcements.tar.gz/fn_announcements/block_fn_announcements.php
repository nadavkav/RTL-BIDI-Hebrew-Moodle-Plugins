<?php //$Id: block_fn_announcements.php,v 1.2 2008/05/27 13:17:20 mchurch Exp $

class block_fn_announcements extends block_base {
    function init () {
        $this->title = get_string('blocktitle', 'block_fn_announcements');
        $this->version = 2004052600;
    }

    function specialization() {
        global $course;

        /// Need the bigger course object.
        $this->course = $course;

        /// Set up the display title.
        if (!empty($this->config->displaytitle)) {
            $this->title = $this->config->displaytitle;
        } else {
            $this->title = get_string('displaytitle', 'block_fn_announcements');
        }
    }

    function instance_allow_config() {
        return true;
    }

    function get_content() {
        global $CFG, $USER;

        if ($this->content !== NULL) {
            return $this->content;
        }

        if (empty($this->course)) {
            $this->content = '';
            return $this->content;
        }

        require_once($CFG->dirroot.'/course/lib.php');
        require_once($CFG->dirroot.'/mod/forum/lib.php');

        $this->content = New stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        if ($this->course->newsitems) {
            $news = forum_get_course_forum($this->course->id, 'news');

            $forum_sort = "p.modified DESC";

            $fullpost = false;

            if ($cm = get_coursemodule_from_instance("forum", $news->id, $this->course->id)) {
                $groupmode = groupmode($this->course, $cm);
            } else {
                $groupmode = SEPARATEGROUPS;
            }

            $currentgroup = get_current_group($this->course->id);
            if (!$currentgroup || ($groupmode != SEPARATEGROUPS) || isteacheredit($this->course->id) ) {
                $visiblegroups = -1;
            } else {
                $visiblegroups = $currentgroup;
            }

            $this->content->text .= '<font size="-2">';

            if (forum_user_can_post_discussion($news, $currentgroup, -1, $cm)) {
                $this->content->text .= "<div align=center>";
                $this->content->text .= "<a href=\"$CFG->wwwroot/mod/forum/post.php?forum=$news->id\">";
                $this->content->text .= get_string('addanewtopic', 'block_fn_announcements')."</a>...";
                $this->content->text .= "</div>\n";
            }

            $this->content->text .= '<div class="newsframe" id="scrollingnews" onmouseover="clearTimeout(t1);" onmouseout="scrollnews();">';

            if (! $discussions = forum_get_discussions($cm, $forum_sort, 0, $fullpost, $visiblegroups) ) {
                $this->content->text .= "<p align=center><b>(".get_string("nonews", "forum").")</b></p>";
            } else {
                $strftimerecent = get_string("strftimerecent");
                $strmore = get_string("more", "forum");
                $discussioncount = 0;
                $olddiscussionlink = false;

                $this->content->text .= '<table width="100%" cellpadding="0" cellspacing="0" border="0">'."\n";
                foreach ($discussions as $discussion) {
                    $this->content->text .= '<tr>';
                    $discussioncount++;
                    if ($this->course->newsitems && ($discussioncount > $this->course->newsitems)) {
                        $olddiscussionlink = true;
                        break;
                    }
                    if (!empty($CFG->filterall)) {
                        $discussion->subject = filter_text($discussion->subject, $news->course);
                    }

                    $this->content->text .= '<td valign="top">';
                    if (forum_tp_is_post_read($USER->id, $discussion)) {
                        $this->content->text .= '<img src="'.$CFG->wwwroot.'/blocks/fn_announcements/images/announcement.gif" /> ';
                    } else {
                        $this->content->text .= '<img src="'.$CFG->wwwroot.'/blocks/fn_announcements/images/newannouncement.gif" /> ';
                    }
                    $this->content->text .= '</td>';

                    $this->content->text .= '<td class="smallinfo">';
                    $this->content->text .= $discussion->subject;
                    $this->content->text .= " <a href=\"$CFG->wwwroot/mod/forum/discuss.php?d=$discussion->discussion\">";
                    $this->content->text .= $strmore."...</a><br />";
                    $this->content->text .= '</td>';
                    $this->content->text .= '</tr>';
                }
                $this->content->text .= '</table>'."\n";

            $this->content->text .= '</div>';
	    $this->content->text .= "
	    <style type=\"text/css\">
	    div.newsframe {
	    font:22px arial;
	    width:200px;
	    height:150px;
	    border:none;
	    overflow:hidden;
	    border:0px solid black;
	    padding:15;
	    }
	    </style>
	    <script language=\"javascript\">
	    i = 0
	    var speed = 1
	    function scrollnews() {
	    i = i + speed
	    var div = document.getElementById(\"scrollingnews\")
	    div.scrollTop = i
	    if (i > div.scrollHeight - 60) {i = 0}
	    t1=setTimeout(\"scrollnews()\",100)
	    }

	    scrollnews();
	    </script>
	    ";

                if ($olddiscussionlink) {
                    $this->content->text .= '<p align="center">';
                    $this->content->text .= "<a href=\"$CFG->wwwroot/mod/forum/view.php?f=$news->id&showall=1\">";
                    $this->content->text .= get_string('olderdiscussions', 'block_fn_announcements')."</a> ...</p>";
                }
            }

            $this->content->text .= '</font>';

        }
        return $this->content;
    }

    function applicable_formats() {
        // Default case: the block can be used in all course types
        return array('all' => false,
                     'course-*' => true);
    }
}
?>