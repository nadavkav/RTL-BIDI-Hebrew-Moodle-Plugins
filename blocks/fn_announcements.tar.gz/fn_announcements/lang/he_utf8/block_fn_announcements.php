<?php
$string['addanewtopic'] = 'הוסיפו ידיעה חדשה';
$string['blocktitle'] = 'ידיעות רצות';
$string['cfgdisplaytitle'] = 'תצוגת כותרת';
$string['displaytitle'] = 'ידיעות';
$string['olderdiscussions'] = 'ידיעות נוספות';
?>