<?php
$string['addanewtopic'] = 'Add a new announcement';
$string['blocktitle'] = 'FN Announcements';
$string['cfgdisplaytitle'] = 'Display title';
$string['displaytitle'] = 'Announcements';
$string['olderdiscussions'] = 'Other announcements';
?>