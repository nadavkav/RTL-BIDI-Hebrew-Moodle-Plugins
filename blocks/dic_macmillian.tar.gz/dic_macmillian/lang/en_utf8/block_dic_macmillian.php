<?php

$string['blockname'] = 'MACMILLIAN Dictionary';
$string['instructions'] = '<div><strong>DoubleClick Dictionary is ENABLED</strong></div><div>Please use the mouse left button to double click any word you wish to get a definition for :-)</div>';

?>