<?PHP
// This code was borrowed from "block_course_menu" from an early version by Humbolt State University.

// truncates the description to fit within the given $max_size. Splitting on tags and \n's where possible
// @param $string: string to truncate
// @param $max_size: length of largest piece when done
// @param $trunc: string to append to truncated pieces

/* NOTE $max_size=21 
 * MUST BE ODD NUMBER FOR JAPANESE  However 30 seems to work
 */
function truncate_description($string, $max_size=27, $trunc = '...') {
    $split_tags = array('<br>','<BR>','<Br>','<bR>','</dt>','</dT>','</Dt>','</DT>','</p>','</P>', '<BR />', '<br />', '<bR />', '<Br />');
    $temp = $string;
    
    foreach($split_tags as $tag) {
    	list($temp) = explode($tag, $temp, 2);
    }
    $rstring = strip_tags($temp);
    
    $rstring = html_entity_decode($rstring);

    if (strlen($rstring) > $max_size) {
        $rstring = chunk_split($rstring, ($max_size-strlen($trunc)), "\n");
        $temp = explode("\n", $rstring);
        // catches new lines at the beginning
        if (trim($temp[0]) != '') {
            $rstring = trim($temp[0]).$trunc;
        }
        else {
           $rstring = trim($temp[1]).$trunc;
        }
    }
    if (strlen($rstring) > $max_size) {
        $rstring = substr($rstring, 0, ($max_size - strlen($trunc))).$trunc;
    }
    elseif($rstring == '') {
        // we chopped everything off... lets fall back to a failsafe but harsher truncation
        $rstring = substr(trim(strip_tags($string)),0,($max_size - strlen($trunc))).$trunc;
    }
    
    // single quotes need escaping
    return str_replace("'", "\\'", $rstring);
}

?>