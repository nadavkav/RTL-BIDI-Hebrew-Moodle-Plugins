.block_menu_site_and_course{
//padding: 0px 4px 4px 4px;
text-align: left;
//background-color: #ffc;
}

.block_menu_site_and_course ul{
list-style: none;
}

.block_menu_site_and_course #nav{
background-color: #777;
color: #fff;}

.block_menu_site_and_course #nav ul{
margin-left:0px;
margin-top:0px;
padding: 2px;
}

.block_menu_site_and_course #nav ul, #nav li{
margin: 0;
padding: 0;
font-size: 14px;}

.block_menu_site_and_course #nav li a{
display: block;
width: 100%;
padding: 4px 0 4px 3px;
background-color: transparent;
color: #fff;
text-decoration: none;
border-top: 1px solid #fdd;}

html>body #nav li a{
width: auto;}

.block_menu_site_and_course #nav .h{
background-color: #555;
border: none;}

.block_menu_site_and_course #nav .s{
background-color: #555;
border: none;}

.block_menu_site_and_course #nav .c{
background-color: #999;}

.block_menu_site_and_course #nav .a{
background-color: #1834F0;}

.block_menu_site_and_course #nav li a:hover{
background-color: #bbb;
color: #fff;}

// Don't show a different hover color for HOME when at HOME.
.block_menu_site_and_course #nav .s a:hover{
background-color: #555;
}

.block_menu_site_and_course #nav .first{
border: none;}

