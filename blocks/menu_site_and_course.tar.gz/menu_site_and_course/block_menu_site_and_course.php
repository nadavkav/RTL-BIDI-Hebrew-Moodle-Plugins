<?php 
/* Menu Block
 * Charles Kelly, March 2008
 * Note around line 52 there are some options you can set.
 * Based on an earlier menu of mine.
 * Last update: March 26, 2008
 */
 
class block_menu_site_and_course extends block_base {
    function init() {
        $this->title = get_string('menu','data');
        $this->content_type = BLOCK_TYPE_TEXT;
        $this->version = 2008032400;
    }
    
    function preferred_width() {
        return 210;
    }
    
    function get_content() {
        global $USER, $CFG, $COURSE;

        if ($this->content !== NULL) {
          return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';
        
        if (empty($this->instance)) {
          return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';
        $sections = get_all_sections($this->course->id);
        $sectionname = get_string("name".$this->course->format);
        $sectiongroup = $this->course->format;

    if ($COURSE->id == SITEID) {  // Site-level
          $level .= 'site';
        //NOT NEEDED HERE        } else { // Course-level
        //NOT NEEDED HERE          $level .= 'course';
        }
        
    ob_start();
    print $this->get_tab_like_button_content($level);
    $this->content->text = ob_get_contents().$text;
    ob_end_clean();        
    //     return $this->content;
    }
  
  
    function get_tab_like_button_content($level) {
    	/* Options you can set
    	 * 1 = show
    	 * 0 = don't show
    	 * NOTE: if all of these are off, there is no need to put this on the main page.
    	 */
   		 $showcalendar = 1;
         $showparticipants = 1;
         $showprofile = 1;
         $showlogin = 1;
        $this->course = get_record('course', 'id', $this->instance->pageid);
        global $CFG;
        require_once($CFG->dirroot.'/blocks/menu_site_and_course/truncate_description.php');
        $sections = get_all_sections($this->course->id);  
        if ($this->course->format == 'topics') {
          $format = 'topic';
        }
        else {
          $format = 'week';
        }

        $text = '';
        $text .= '<div id="nav"><ul>';
        
		/* ==== THE BUTTONS START HERE ==== */
        // HOME
        if ($level != 'site'){
          $text .='<li class="h"><a href="'.$CFG->wwwroot.'/">'.get_string('home', 'moodle').'</a></li>';
        } else {
        //  $text .='<li class="s"><a href="'.$CFG->wwwroot.'/">'.get_string('home', 'moodle').'</a></li>';
        }
        
        // LOGIN
        
        if ($showlogin){
        
        if (!isloggedin() or isguestuser()) { 
           $text .='<li class="h"><a href="'.$CFG->wwwroot.'/login/">'.get_string('login', 'moodle').'</a></li>';
// If you want a "logout" button, too, then uncomment the following 2 lines.
//     } else {
//          $text .='<li class="h"><a href="'.$CFG->wwwroot.'/login/logout.php">'.get_string('logout', 'moodle').'</a></li>';
        }
        
        }

        // === Course-only Items ====
        if ($level != 'site'){
       // SHOW ALL
        $text .='<li><a href="'.$CFG->wwwroot.'/course/view.php?id='.$this->course->id.'&'.$format.'=all" alt="'.get_string("showall",'moodle').'"> * '.get_string("showall",'moodle').' *</a>';


        // LESSON MENU
        if (!empty($sections)) {
          foreach($sections as $section) {
              if ($section->visible && $section->section > 0 && $section->section <= $this->course->numsections) {
                  $summary = truncate_description($section->summary);
                  if (empty($summary)) {
                    $summary = get_string("name{$this->course->format}").' '.$section->section;
                    //  $summary = "Lesson";
                  }
              $text .='<li><a href="'.$CFG->wwwroot.'/course/view.php?id='.$this->course->id.'&'.$format.'='.$section->section.'">'.$summary.'</a></li>';
          }
        }
          
    
       if (isloggedin() and !isguestuser()) { 

        // PARTICIPANTS
        if ($showparticipants){
        $text .='<li class="c"><a href="../user/index.php?id='.$this->course->id.'">'.get_string('participants', 'moodle').'</a></li>';
		}
        // GRADES   
        if ($this->course->showgrades) {
          $text .='<li class="c"><a href="';
          $text .= $CFG->wwwroot.'/grade/index.php?id='.$this->course->id;
          $text .= '">'.get_string('gradebook','grades').'</a></li>';
          }
        }
      }
}

if (isloggedin() and !isguestuser()) { 
         if ($showprofile){
        $text .='<li class="h"><a href="'.$CFG->wwwroot.'/user/view.php?id='.$USER->id.'&course='.$this->course->id.'">'.get_string('profile', 'moodle').'</a></li>';
		}
 
        // CALENDAR
		if ($showcalendar){
		     $text .='<li class="h"><a href="'.$CFG->wwwroot.'/calendar/view.php?view=upcoming&amp;course='.$this->course->id.'">'.get_string('calendar', 'calendar').'</a></li>';
		}
        
        // COURSES
        $text .='<li class="h"><a href="'.$CFG->wwwroot.'/course/">'.get_string('courses', 'moodle').'</a></li>';
        
    } 
        $text .= '</ul></div>';
    return $text;
    }

}
?>