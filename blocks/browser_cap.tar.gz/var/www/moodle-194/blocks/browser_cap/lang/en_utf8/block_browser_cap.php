<?php

$string['blockname'] = 'Browser Capabilities';
$string['support'] = 'It seems that your browser support the following plugins';
$string['javascript'] = 'JavaScript';
$string['java'] = 'Java';
$string['pdf'] = 'PDF Viewer';
$string['windowsmedia'] = 'Windows Media';
$string['real'] = 'Real Media';
$string['quicktime'] = 'Quicktime Media';
$string['flash'] = 'Flash';
$string['cookies'] = 'Cookies';

?>