<?php

$string['browser_cap'] = 'בדיקת יכולות הדפדפן';
$string['browser_support'] = 'נראה, שהדפדפן שלכם תומך בתוספים הבאים';
$string['javascript'] = 'ג\'אווה סקריפט';
$string['java'] = 'ג\'אווה';
$string['pdf'] = 'תצוגת מסמכי pdf';
$string['windowsmedia'] = 'תצוגת סרטוני wmv';
$string['real'] = 'תצוגת סרטוני rm';
$string['quicktime'] = 'תצוגת סרטוני mov';
$string['flash'] = 'תצוגת סרטוני פלאש';
$string['cookies'] = 'שימוש ב\'עוגיות\'';

?>