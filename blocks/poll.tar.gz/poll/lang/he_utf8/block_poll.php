<?php
$string['config_param'] = 'מאפיין';
$string['config_value'] = 'ערך';
$string['editblocktitle'] = 'כותרת הסקר';
$string['editmaxbarwidth'] = 'רוחב מירבי של הגרף';
$string['editpollname'] = 'שם הסקר';
$string['editpollquestion'] = 'תוכן השאלה';
$string['editpolleligible'] = 'משתמשים המורשים להשתתף';
$string['editpolloptions'] = 'אפשרות ספירה';
$string['formaltitle'] = 'סקר';
$string['option'] = 'אפשרויות';
$string['pollconfirmdelete'] = 'Are you sure you want to completely delete this poll ($a), including all response data?';
$string['pollwarning'] = 'You must be a teacher to perform this action';
$string['responses'] = 'תגובות';
$string['submit'] = 'הצבעה';
$string['tabconfigblock'] = 'עריכת הסקר';
$string['tabeditpoll'] = 'יצירה/עריכה סקר';
$string['tabmanagepolls'] = 'ניהול סקרים';
$string['tabresponses'] = 'תצוגת תגובות';

?>
