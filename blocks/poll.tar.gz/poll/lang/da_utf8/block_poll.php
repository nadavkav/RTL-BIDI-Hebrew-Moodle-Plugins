<?PHP // $Id: block_poll.php,v 1.1 2007/07/26 08:12:12 johnharald Exp $ 
      // block_poll.php - created with Moodle 1.9 dev (2007071300)


$string['config_param'] = 'Variabler';
$string['config_value'] = 'Valg';
$string['editblocktitle'] = 'Tittel på boks';
$string['editmaxbarwidth'] = 'Maksimal grafvidde';
$string['editpolleligible'] = 'Tillate respondenter';
$string['editpollname'] = 'Tittel på undersøkelse';
$string['editpolloptions'] = 'Antall svarmuligheter';
$string['editpollquestion'] = 'Spørsmålstekst';
$string['formaltitle'] = 'Spørreundersøkelse';
$string['option'] = 'Svaralternativ';
$string['pollconfirmdelete'] = 'Er du sikker på at du vil slette denne undersøkelsen ($a), inkludert alle svardata?';
$string['pollwarning'] = 'Du må minst være lærer for å gjøre dette';
$string['responses'] = 'Svar';
$string['submit'] = 'Send';
$string['tabconfigblock'] = 'Konfigurer boks';
$string['tabeditpoll'] = 'Opprett/rediger undersøkelse';
$string['tabmanagepolls'] = 'Administrer undersøkelser';
$string['tabresponses'] = 'Se svar';

?>
