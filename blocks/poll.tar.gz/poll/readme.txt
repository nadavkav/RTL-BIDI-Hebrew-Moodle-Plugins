Moodle Poll Block v1.0
Paul Holden, Greenhead College [pholden@greenhead.ac.uk]

Adds poll options to a course.

Tested in Moodle version 1.7.1

See http://gcmoodle.greenhead.ac.uk/external/poll/ for more information
