.dir-rtl #poll {
float:right;
}

.dir-ltr #poll {
float:left;
}