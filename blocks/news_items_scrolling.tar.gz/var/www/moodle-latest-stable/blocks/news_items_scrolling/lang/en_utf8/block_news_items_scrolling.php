<?php

$string['addanewitem'] = 'Add a new Item';
$string['olditems'] = 'Old Items';
$string['more'] = 'Full Item';
$string['latestnewsscrolling'] = 'Latest News - Scrolling';

?>