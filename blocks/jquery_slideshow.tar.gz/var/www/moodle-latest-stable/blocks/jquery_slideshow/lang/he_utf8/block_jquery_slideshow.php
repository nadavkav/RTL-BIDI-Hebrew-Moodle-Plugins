<?php

$string['jqueryslideshow'] = "מצגת תמונות";
$string['title'] = "מצגת תמונות";
$string['content'] =  'אנא בחרו ספריית תמונות לתצוגה';
$string['initialsetup'] =  'אנא בחרו ספריית תמונות לתצוגה';
$string['noimagesinfolder'] =  'לא נמצאו תמונות בספרייה אשר עונות על הגדרות מסנן־התמונות אשר נקבע';
$string['configtitle'] = "כותרת משבצת המצגת";
$string['configcontent'] =  'כיתוב נוסף תחת המצגת';
$string['clicktoshow']= 'הקליקו על אוסף התמונות להצגתו';
$string['configgallery']= 'בחרו ספריית תמונות לתצוגה';
$string['configheight']= 'גובה משבצת התצוגה';
$string['configwidth']= 'רוחב משבצת התצוגה';
$string['configimagedir']= 'בחרו ספריה לתצוגה';
$string['maincoursefolder']= 'ספרייה ראשית';
$string['configfilesfilter']= 'מסנן־תמונות';
$string['configfilesfilterinfo']= 'ניתן לסנן את סוג התמונות אשר יוצגו בעזרת רשימה המופרדת בקו־אנכי | לפי הדוגמא : png|jpeg|gif|jpg';
$string['configtransition']= 'אופי המעבר בין תמונות';
$string['transitionbrowser']= 'הדגמה של סוגי מעברים';
$string['openinnewwindow']= 'פתיחת ניהול תמונות בחלון חדש';
$string['configtimeout']= 'זמן השהיית המעבר בין התמונות (בשניות)';
$string['configwhattoinclude'] = 'אילו סוגיי תמונות להציג?';
$string['includejpeg'] = 'תמונות מסוג JPEG';
$string['includepng'] = 'תמונות מסוג PNG';
$string['includegif'] = 'תמונות מסוג GIF';
$string['configmaxfiles'] = 'מספר תמונות מירבי';
?>