<?php

$string['jqueryslideshow'] = "Slideshow with Transitions";
$string['title'] = "Directory Slideshow with Transitions";
$string['content'] =  'Please choose a Folder to view';
$string['initialsetup'] =  'Please choose a Folder to view';
$string['noimagesinfolder'] =  'No images found! <br/> Please try another Folder or include more File Types to view';
$string['configtitle'] = "Block's Title";
$string['configcontent'] =  'Slideshow description';
$string['clicktoshow']= 'Click the image to view it';
$string['configgallery']= 'Choose Folder';
$string['configheight']= 'Image Height';
$string['configwidth']= 'Image Width';
$string['configimagedir']= 'Choose a Folder';
$string['maincoursefolder']= 'Main Folder';
$string['configfilesfilter']= 'Image filter';
$string['configfilesfilterinfo']= 'You can filter the images by listing their types with the delimiter | see example : png|jpeg|gif|jpg';
$string['configtransition']= 'Transition type';
$string['transitionbrowser']= 'Browse Transitions';
$string['openinnewwindow']= 'Files Manager';
$string['configtimeout']= 'Delay between Slides (in seconds)';
$string['configwhattoinclude'] = 'What type of Images to include?';
$string['includejpeg'] = 'JPEG Images';
$string['includepng'] = 'PNG Images';
$string['includegif'] = 'GIF Images';
$string['configmaxfiles'] = 'Max files';

?>