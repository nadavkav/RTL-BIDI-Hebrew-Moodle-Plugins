<?php
$string['blockname'] = 'Course Menu';
$string['outline'] = 'Outline';

// Instance config options
$string['introlength'] = 'Length of section intros:';
$string['trunctext'] = 'Section intro truncation text:';
$string['introaction'] = 'Section intro links action:';
$string['introhide'] = 'Hide other sections';
$string['introscroll'] = 'Scroll screen to section';
// global settings
$string['plugin'] = 'Plugin';
$string['enabled'] = 'Enabled';
$string['visible'] = 'Visible';
$string['order'] = 'Order';

$string['plugin_settings'] = 'Plugins';
$string['configplugin_settings'] = 'Configure the installed plugins here.
Disabling a plugin will make it completely unavailable, making a plugin
invisible will hide it by default, but still allow courses to override that
setting';
