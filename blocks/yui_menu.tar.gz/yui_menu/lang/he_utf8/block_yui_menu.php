<?php
$string['outline'] = 'תצוגת כל יחידות הוראה';
$string['blockname'] = 'תפריט יחידות הוראה ופעילויות';

// Config screen options
$string['introlength'] = 'מספר התווים שיש להציג מתוך כותרת יחידת ההוראה:';
$string['trunctext'] = 'תווים שיש להוסיף לאחר תצוגת הכותרת היחידה:';
$string['introaction'] = 'הפעולה בעת בחירת יחידת הוראה:';
$string['introhide'] = 'הסתרת יחידות הוראה אחרות';
$string['introscroll'] = 'גלילת התצוגה ליחידת ההוראה שנבחרה';
?>

