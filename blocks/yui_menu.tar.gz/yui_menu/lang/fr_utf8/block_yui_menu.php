<?php
$string['blockname'] = 'Menu du cours';
$string['outline'] = 'Plan';

// Config screen options
$string['introlength'] = 'Longueur des résumés';
$string['trunctext'] = 'Texte du tronquement';
$string['introaction'] = 'Action des liens du résumé';
$string['introhide'] = 'Cacher les autres thèmes';
$string['introscroll'] = 'Faire défiler le thème à l\'écran';
?>
