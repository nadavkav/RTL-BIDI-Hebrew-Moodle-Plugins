.dir-rtl .block_sharing_cart span.commands {
float:left;
}

/*
.block_sharing_cart .list li {
border-bottom: 1px dashed gray;
}
*/