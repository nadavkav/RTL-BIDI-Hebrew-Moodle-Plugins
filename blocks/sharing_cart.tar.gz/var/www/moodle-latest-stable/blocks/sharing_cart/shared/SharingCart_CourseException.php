<?php
/**
 *  SharingCart_CourseException
 */

require_once dirname(__FILE__).'/SharingCart_Exception.php';

class SharingCart_CourseException extends SharingCart_Exception
{
}

?>