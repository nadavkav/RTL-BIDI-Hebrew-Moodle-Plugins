<?php

    require_once('../../config.php');
    require_once($CFG->libdir.'/blocklib.php');

    require_login();

    $id = required_param('id',PARAM_INT);
    $messagebody = optional_param('messagebody','',PARAM_CLEANHTML);
    $send = optional_param('send','',PARAM_ALPHA);
    $preview = optional_param('preview','',PARAM_ALPHA);
    $format = optional_param('format',FORMAT_PLAIN,PARAM_INT);
    $edit = optional_param('edit','',PARAM_ALPHA);
    $deluser = optional_param('deluser',0,PARAM_INT);

    if (!confirm_sesskey()) {
        print_error('confirmsesskeybad');
    }

    if (!$course = get_record('course','id',$id)) {
        print_error("invalidcourse");
    }

    require_login($course);
    $context = get_context_instance(CONTEXT_COURSE, $course->id);

    $block = get_record('block', 'name', 'sending_sms');
    $blockinstance = get_record('block_instance', 'blockid', $block->id, 'pageid', $course->id);
    $sendingsms = block_instance('sending_sms', $blockinstance);

    if (!$sendingsms->get_provider() || !$sendingsms->get_username() || !$sendingsms->get_password()) {
        print_error('invalidrequest');
    }

    $blockcontext = get_context_instance(CONTEXT_BLOCK, $blockinstance->id);
    $sitecontext = get_context_instance(CONTEXT_SYSTEM);
    $frontpagectx = get_context_instance(CONTEXT_COURSE, SITEID);

    if ($context->id != $frontpagectx->id) {
        require_capability('block/sending_sms:send', $blockcontext);
        require_capability('moodle/course:viewparticipants', $context);
    } else {
        require_capability('block/sending_sms:send', $sitecontext);
        require_capability('moodle/site:viewparticipants', $sitecontext);
    }

    if (empty($SESSION->smsto)) {
        $SESSION->smsto = array();
    }
    if (!array_key_exists($id,$SESSION->smsto)) {
        $SESSION->smsto[$id] = array();
    }

    if ($deluser) {
        if (array_key_exists($id,$SESSION->smsto) && array_key_exists($deluser,$SESSION->smsto[$id])) {
            unset($SESSION->smsto[$id][$deluser]);
        }
    }

    if (empty($SESSION->smsselect[$id]) || $messagebody) {
        $SESSION->smsselect[$id] = array('messagebody' => $messagebody);
    }

    $messagebody = $SESSION->smsselect[$id]['messagebody'];

    $count = 0;

    foreach ($_POST as $k => $v) {
        if (preg_match('/^(user|teacher)(\d+)$/',$k,$m)) {
            if (!array_key_exists($m[2],$SESSION->smsto[$id])) {
                if ($user = get_record_select('user','id = '.$m[2],'id,firstname,lastname,idnumber,phone1,phone2,lastaccess')) {
                    $SESSION->smsto[$id][$m[2]] = $user;
                    $SESSION->smsto[$id][$m[2]]->teacher = ($m[1] == 'teacher');
                    $count++;
                }
            }
        }
    }

    $strtitle = get_string('coursemessage', 'block_sending_sms');

    /*
    if (empty($messagebody)) {
        $formstart = "theform.messagebody";
    } else {
        $formstart = "";
    }
    */

    if ($course->category) {
        print_header("$course->shortname: $strtitle",$course->fullname,"<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a> -> <a href=\"list.php?courseid=$course->id\">".get_string("participants", 'block_sending_sms')."</a> -> ".$strtitle);
    } else {
        print_header("$course->shortname: $strtitle",$course->fullname,"<a href=\"list.php?courseid=$course->id\">".get_string("participants", 'block_sending_sms')."</a> -> ".$strtitle);
    }

    if ($count) {
        if ($count == 1) {
            $heading =  get_string('addedrecip','block_sending_sms',$count);
        } else {
            $heading = get_string('addedrecips','block_sending_sms',$count);
        }
        print_heading($heading);
    }

    if (!empty($messagebody) && !$edit && !$deluser && $send) {
        if ($smscount = count($SESSION->smsto[$id])) {

            $instance = establish_sms_instance($course->id);
            $credit = $instance->get_credit();

            $backtosms = '<p align="center"><a href="sms.php?id='.$course->id.'&sesskey='.$USER->sesskey.'">'.get_string('back', 'block_sending_sms').'</a></p>';
            $backtoparticipants = '<p align="center"><a href="list.php?courseid='.$course->id.'">'.get_string('back', 'block_sending_sms').'</a></p>';

            if ($smscount > $credit) {
                notify(get_string('morerecipients', 'block_sending_sms'));
                echo $backtosms;
            } elseif ($smscount == 1) {
                foreach ($SESSION->smsto[$id] as $user) {
                    if ($user->mobilephone) {
                        if ($instance->send($user->mobilephone, $messagebody)) {
                            $record->sender = $USER->id;
                            $record->recipients = "$user->id";
                            $record->smstext = $messagebody;
                            $record->time = time();
                            insert_record('block_sending_sms', $record);
                            unset($record);
                            notify(get_string('smsok', 'block_sending_sms'));
                            echo $backtoparticipants;
                            unset($SESSION->smsto[$id]);
                            unset($SESSION->smsselect[$id]);
                        } else {
                            notify(get_string('smserror', 'block_sending_sms'));
                            echo $backtosms;
                        }
                    } else {
                        notify(get_string('userwithoutmobile', 'block_sending_sms'));
                        echo $backtosms;
                    }
                }
            } else {
                $numbers = array();
                $recipients = array();
                $withoutnumbers = array();
                foreach ($SESSION->smsto[$id] as $user) {
                    if ($user->mobilephone) {
                        $numbers[] = $user->mobilephone;
                        $recipients[] = $user->id;
                    } else {
                        $withoutnumbers[] = fullname($user,true);
                    }
                }
                if (count($numbers)) {
                    if ($instance->send_bulk($numbers, $messagebody)) {
                        $record->sender = $USER->id;
                        $record->recipients = implode(',', $recipients);
                        $record->smstext = $messagebody;
                        $record->time = time();
                        insert_record('block_sending_sms', $record);
                        notify(get_string('smsok', 'block_sending_sms'));
                        echo $backtoparticipants;
                        unset($SESSION->smsto[$id]);
                        unset($SESSION->smsselect[$id]);
                    } else {
                        notify(get_string('smserror', 'block_sending_sms'));
                        echo $backtosms;
                    }
                } else {
                    notify(get_string('userswithoutmobile', 'block_sending_sms'));
                    echo $backtosms;
                }
                if (count($withoutnumbers)) {
                    print_box_start();
                    echo '<b>'.get_string('userswithoutmobilelist', 'block_sending_sms').'</b><br><br>';
                    foreach ($withoutnumbers as $withoutnumber) {
                        echo $withoutnumber.'<br>';
                    }
                    print_box_end();
                }

            }

            print_footer();
            exit;
        } else {
            notify(get_string('nousersyet', 'block_sending_sms'));
        }
    }

    echo '<p align="center"><a href="list.php?courseid='.$course->id.'">'.get_string("keepsearching", 'block_sending_sms').'</a>'.((count($SESSION->smsto[$id])) ? ', '.get_string('usemessageform', 'block_sending_sms') : '').'</p>';

    if ((!empty($send) || !empty($preview) || !empty($edit)) && (empty($messagebody))) {
        notify(get_string('allfieldsrequired', 'block_sending_sms'));
    }

    if (count($SESSION->smsto[$id])) {

        ?>

        <form name="theform" method="post" action="sms.php">
        <input type="hidden" name="id" value="<?php p($id) ?>" />
        <input type="hidden" name="deluser" value="" />
        <input type="hidden" name="sesskey" value="<?php p($USER->sesskey) ?>" />

        <?php 

        $instance = establish_sms_instance($course->id);
        $credit = $instance->get_credit();
        $initiallen = $instance->get_maxcharacters();

        if(strlen($messagebody) > 0) {
            $remaining = $initiallen - strlen($messagebody);
        } else {
            $remaining = $initiallen;
        }

        print_box_start();

        ?>
        <center>
        <table border="0" cellpadding="5" >

        <tr>
            <td align="center">
                <?php 
                    if (!empty($credit)) {
                        print_string('credit', 'block_sending_sms', $credit); 
                    } else {
                        print_string('badconfiguration', 'block_sending_sms'); 
                    }
                ?>
                <br><br>
            </td>
        </tr>

        <tr>
            <td align="center">
                <b>
                <?php print_string('messagebody', 'block_sending_sms'); ?>:
                </b>
            </td>
        </tr>

        <tr>
            <td align="center"><b>
            <script language="JavaScript">
            <!--
            function textCounter(field,cntfield,maxlimit) {
                if (field.value.length > maxlimit)
                    field.value = field.value.substring(0, maxlimit);
                else
                    cntfield.value = maxlimit - field.value.length;
                }
            //-->
            </script>

            <textarea id="edit-messagebody" name="messagebody" rows="10" cols="30" onKeyDown="textCounter(document.theform.messagebody,document.theform.remaining,<?php echo $initiallen; ?>)" onKeyUp="textCounter(document.theform.messagebody,document.theform.remaining,<?php echo $initiallen; ?>)"><?php echo $messagebody; ?></textarea>
            </td>
        </tr>

        <tr>
            <td align="center">
            <br>
            <?php print_string('remaining', 'block_sending_sms'); ?>
            <input readonly type="text" name="remaining" size="3" maxlength="3" value="<?php echo $remaining; ?>">
            </td>
        </tr>

        <tr><td align="center"><input type="submit" name="send" value="<?php print_string('send', 'block_sending_sms'); ?>" /></td></tr>
        </table>
        </center>


        <?php print_box_end(); ?>

        <table align="center"><tr><th colspan="4"><br><?php print_string('currentlyselectedusers', 'block_sending_sms'); ?><br><br></th></tr>

        <?php

            if (count($SESSION->smsto[$id])) {
                if (!$course->teacher) {
                    $course->teacher = get_string('defaultcourseteacher', 'block_sending_sms');
                }
                foreach ($SESSION->smsto[$id] as $key => $user) {
                    $phone = false;
                    if (empty($user->phone1) && empty($user->phone2)) {
                        $strphone = '';
                        $error = get_string('nophone', 'block_sending_sms');
                    } elseif (strpos($user->phone1, '6') === 0) {
                        $phone = $user->phone1;
                        $strphone = " ($phone)";
                    } elseif (strpos($user->phone2, '6') === 0) {
                        $phone = $user->phone2;
                        $strphone = " ($phone)";
                    } elseif (strpos($user->phone1, '00346') === 0) {
                        $phone = substr($user->phone1, 4);
                        $strphone = " ($phone)";
                    } elseif (strpos($user->phone2, '00346') === 0) {
                        $phone = substr($user->phone2, 4);
                        $strphone = " ($phone)";
                    } elseif (strpos($user->phone1, '+346') === 0) {
                        $phone = substr($user->phone1, 3);
                        $strphone = " ($phone)";
                    } elseif (strpos($user->phone2, '+346') === 0) {
                        $phone = substr($user->phone2, 3);
                        $strphone = " ($phone)";
                    } else {
                        $strphone = '';
                        $error = get_string('nomobilephone', 'block_sending_sms');
                    }
                    if ($phone) {
                        $SESSION->smsto[$id][$key]->mobilephone = $phone;
                    }
                    echo '<tr><td>'.fullname($user,true).'</td><td>'.$strphone.'</td><td>';
                    if (!empty($error)) {
                        echo '<img src="'.$CFG->pixpath.'/t/emailno.gif" alt="'.$error.'" title="'.$error.'"/>';
                        unset($error);
                    }
                    echo '</td><td><input type="submit" onClick="this.form.deluser.value='.$user->id.';" value="'.get_string('remove', 'block_sending_sms').'" /></td></tr>';
                }
            }
            else {
                echo '<tr><td colspan="3" align="center">'.get_string('nousersyet', 'block_sending_sms').'</td></tr>';
            }

        ?>

        </table>
        </form>

    <?php

    }

    print_footer();

    function establish_sms_instance($courseid) {

        $block = get_record('block', 'name', 'sending_sms');
        $blockinstance = get_record('block_instance', 'blockid', $block->id, 'pageid', $courseid);
        $sendingsms = block_instance('sending_sms', $blockinstance);

        $provider = $sendingsms->get_provider();

        require_once('providers/sms.class.php');
        require_once('providers/'.$provider.'/sms_'.$provider.'.class.php');
        $classname = 'sms_'.$provider;
        $instance = new $classname($sendingsms);

        return $instance;

    }

?>
