<?php

$string['addedrecip'] = 'Agregado $a nuevo receptor';
$string['addedrecips'] = 'Agregados $a nuevos receptores';
$string['allfieldsrequired'] = 'Todos los campos son obligatorios';
$string['backtoparticipants'] = 'Regresar a lista de participantes';
$string['back'] = 'Volver';
$string['badconfiguration'] = '<b>El bloque está mal configurado. Probablemente el nombre de usuario o la contraseña sean incorrectos. El SMS no se podrá enviar.</b>';
$string['blockname'] = 'Envío de SMS\'s';
$string['coursemessage'] = 'Redactar SMS';
$string['credit'] = '<b>Credito disponible:</b> $a SMS\'s';
$string['currentlyselectedusers'] = 'Usuarios seleccionados:';
$string['defaultcourseteacher'] = 'Profesor';
$string['keepsearching'] = 'Seguir buscando';
$string['messagebody'] = 'Texto del SMS';
$string['morerecipients'] = 'Hay mas receptores que crédito disponible';
$string['noconfiguration'] = 'El bloque no está configurado';
$string['nomobilephone'] = 'Sin teléfono móvil';
$string['nophone'] = 'Sin teléfono';
$string['notingroup'] = 'Lo sentimos, pero debe formar parte del grupo para poder ver esta lista.';
$string['nousersyet'] = 'Aún no hay usuarios';
$string['participants'] = 'Enviar SMS a participantes';
$string['password'] = 'Contraseña';
$string['remaining'] = 'Caracteres restantes: ';
$string['remove'] = 'eliminar';
$string['selectprovider'] = 'Selecciona un proveedor';
$string['send'] = 'Enviar';
$string['sender'] = 'Remitente';
$string['sending_sms:configurate'] = 'Configurar el bloque';
$string['sending_sms:send'] = 'Enviar SMSs';
$string['smserror'] = 'Se ha producido un error al enviar el SMS a los usuarios seleccionados';
$string['smsok'] = 'El SMS se ha enviado correctamente';
$string['usemessageform'] = 'o utilice el formulario de más abajo para enviar un SMS a los estudiantes seleccionados';
$string['username'] = 'Nombre de usuario';
$string['userswithoutmobile'] = 'Ninguno de los usuarios seleccionados dispone de número de teléfono movil';
$string['userswithoutmobilelist'] = 'Los siguientes usuarios no disponen de número de teléfono móvil:';
$string['userwithoutmobile'] = 'El usuario seleccionado no dispone de número de teléfono móvil';

?>
