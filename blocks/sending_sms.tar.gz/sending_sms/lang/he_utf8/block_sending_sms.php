<?php

$string['addedrecip'] = 'נוסף $a כנמען חדש';
$string['addedrecips'] = 'נוספו $a כנמענים חדשים';
$string['allfieldsrequired'] = 'All fields are required';
$string['backtoparticipants'] = 'Back to participants list';
$string['back'] = 'חזרה';
$string['badconfiguration'] = '<b>Block is not correctly configured. Probably the user\'s name or the password are incorrect. SMS will not be sent.</b>';
$string['blockname'] = 'שליחת SMS';
$string['coursemessage'] = 'כתיבת SMS';
$string['credit'] = '<b>Available credit:</b> $a SMS\'s';
$string['currentlyselectedusers'] = 'Currently selected users:';
$string['defaultcourseteacher'] = 'מורה';
$string['keepsearching'] = 'Keep searching';
$string['messagebody'] = 'SMS מלל';
$string['morerecipients'] = 'There are more recipients than available credit';
$string['noconfiguration'] = 'The block is not configured';
$string['nomobilephone'] = 'No mobile phone';
$string['nophone'] = 'No phone';
$string['notingroup'] = 'Sorry, but you need to be part of a group to see this list.';
$string['nousersyet'] = 'There are no users yet';
$string['participants'] = 'Sending SMS to participants';
$string['password'] = 'Password';
$string['remaining'] = 'Remaining characters: ';
$string['remove'] = 'remove';
$string['selectprovider'] = 'Select a provider';
$string['send'] = 'Send';
$string['sender'] = 'Sender';
$string['sending_sms:configurate'] = 'Configurate block';
$string['sending_sms:send'] = 'To send SMSs';
$string['smserror'] = 'Something went wrong while sending SMS to selected users';
$string['smsok'] = 'SMS has been sent correctly';
$string['usemessageform'] = 'or use the form below to send a SMS to the selected students';
$string['username'] = 'Username';
$string['userswithoutmobile'] = 'Selected users do not have mobile phone number';
$string['userswithoutmobilelist'] = 'Next users do not have mobile phone number:';
$string['userwithoutmobile'] = 'Selected user does not have mobile phone number';

?>
