<?php

class block_sending_sms extends block_list {

    function init() {
        $this->title = get_string('blockname','block_sending_sms');
        $this->version = 2008100100;
    }

    function get_content() {
        global $CFG;

        if ($this->content !== NULL) {
            return $this->content;
        }
        if (empty($this->instance)) {
            $this->content = '';
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->items = array();
        $this->content->icons = array();
        $this->content->footer = '';

        $context = get_context_instance(CONTEXT_BLOCK, $this->instance->id);

        if (has_capability('block/sending_sms:send', $context)) {
            if ($this->config->provider && $this->config->username && $this->config->password) {
                $this->content->items[] = '<a title="'.get_string('send', 'block_sending_sms').'" href="'.$CFG->wwwroot.'/blocks/sending_sms/list.php?courseid='.$this->instance->pageid.'">'.get_string('send','block_sending_sms').'</a>';
            } else {
                $this->content->items[] = get_string('noconfiguration', 'block_sending_sms');
            }
        } else {
            $this->content = '';
        }

        return $this->content;
    }

    function instance_allow_multiple() {
        return false;
    }

    function instance_allow_config() {

        $context = get_context_instance(CONTEXT_SYSTEM);

        if (has_capability('block/sending_sms:configurate', $context)) {
            return true;
        } else {
            return false;
        }
    }

    function get_provider() {
        return $this->config->provider;
    }

    function get_sender() {
        return $this->config->sender;
    }

    function get_username() {
        return $this->config->username;
    }

    function get_password() {
        return $this->config->password;
    }

}

?>
