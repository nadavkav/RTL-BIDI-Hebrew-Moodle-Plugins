<?php
//
// Capability definitions for the sending_sms block.
//

$block_sending_sms_capabilities = array(

    'block/sending_sms:configurate' => array(

        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK,
        'legacy' => array(
            'admin' => CAP_ALLOW
        )
    ),

    'block/sending_sms:send' => array(

        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK,
        'legacy' => array(
            'admin' => CAP_ALLOW
        )
    )
);

?>
