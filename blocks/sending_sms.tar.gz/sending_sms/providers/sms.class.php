<?php

class sms_base {

    var $library = NULL;
    var $maxcharacters = NULL;
    var $blockinstance = NULL;

/// Class Functions

    /**
     * The class constructor
     *
     */
    function sms_base($blockinstance) {
        $this->init($blockinstance);
    }

    /**
     * Fake constructor to keep PHP5 happy
     *
     */
    function __construct($blockinstance) {
        $this->sms_base($blockinstance);
    }

    function init($blockinstance) {
    }

    function get_credit() {
    }

    function send($number, $smsbody) {
    }

    function send_bulk($numbers, $smsbody) {
    }

    function get_maxcharacters() {
        return $this->maxcharacters;
    }

}

?>
