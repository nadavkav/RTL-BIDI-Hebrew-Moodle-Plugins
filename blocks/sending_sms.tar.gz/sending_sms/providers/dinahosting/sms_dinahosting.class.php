<?php

class sms_dinahosting extends sms_base {

    function init($blockinstance) {
        $this->library = 'smsSender.inc.php';
        $this->maxcharacters = 160;
        $this->blockinstance = $blockinstance;
    }

    function get_credit() {
        include_once($this->library);
        $username = $this->blockinstance->get_username();
        $password = $this->blockinstance->get_password();
        $sender = $this->blockinstance->get_sender();
        $sms=new smsSender($username,$password,$sender);
        return $sms->getCredito();
    }

    function send($number, $smsbody) {
        include_once($this->library);
        $username = $this->blockinstance->get_username();
        $password = $this->blockinstance->get_password();
        $sender = $this->blockinstance->get_sender();
        $translation = array('á'=>'a', 'é'=>'e', 'í'=>'i', 'ó'=>'o', 'ú'=>'u', 'ñ'=>'n', 'Á'=>'A', 'É'=>'E', 'Í'=>'I', 'Ó'=>'O', 'Ú'=>'Ú', 'Ñ'=>'N', '¿'=>'', '¡'=>'', '&'=>'', '#'=>'');
        $smsbody = strtr($smsbody, $translation);
        $sms=new smsSender($username,$password,$sender);
        return $sms->send($number, $smsbody);
    }

    function send_bulk($numbers, $smsbody) {
        include_once($this->library);
        $username = $this->blockinstance->get_username();
        $password = $this->blockinstance->get_password();
        $sender = $this->blockinstance->get_sender();
        $translation = array('á'=>'a', 'é'=>'e', 'í'=>'i', 'ó'=>'o', 'ú'=>'u', 'ñ'=>'n', 'Á'=>'A', 'É'=>'E', 'Í'=>'I', 'Ó'=>'O', 'Ú'=>'U', 'Ñ'=>'N', '¿'=>'', '¡'=>'', '&'=>'', '#'=>'');
        $smsbody = strtr($smsbody, $translation);
        $sms=new smsSender($username,$password,$sender);
        return $sms->sendBulk($numbers, $smsbody);
    }
}

?>
