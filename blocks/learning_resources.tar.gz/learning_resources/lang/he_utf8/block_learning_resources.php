<?php // $Id: block_learning_resources.php,v 1.1 2006/06/06 21:53:43 wildgirl Exp $ 

$string['actions'] = 'פעולות';
$string['catagory'] = 'סיווגים';
$string['global'] = 'כללי';
$string['addlink'] = 'הוספת קישור';
$string['blockname'] = 'מאגרי תוכן לימודי';
$string['learning_resources'] = 'מאגרי תוכן לימודי';
$string['defaultshow'] = 'תצוגת (בררת מחדל)';
$string['delete'] = 'מחיקה';
$string['display'] = 'תצוגה';
$string['links'] = 'קישורים';
$string['linktext'] = 'תאור הקישור';
$string['manage_links'] = 'הוספת/עריכת קישורים';
$string['modify'] = 'עריכה';
$string['newwindow_label'] = 'תצוגת קישורים בחלון חדש:';
$string['no'] = 'לא';
$string['none'] = 'אין פריטים להצגה';
$string['notes'] = 'מלל נוסף';
$string['reference'] = 'ייחוס';
$string['title_label'] = 'כותרת:';
$string['url'] = 'כתובת אינטרנט';
$string['yes'] = 'כן';
$string['course_teachers_edit_links'] = 'אפשרות עריכה של קישורים כללים על ידי מורים';

?>
