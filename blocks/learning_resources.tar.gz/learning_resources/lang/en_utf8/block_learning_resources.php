<?php // $Id: block_learning_resources.php,v 1.1 2006/06/06 21:53:43 wildgirl Exp $ 

$string['actions'] = 'Actions';
$string['catagory'] = 'Catagory';
$string['global'] = 'All';
$string['addlink'] = 'Add a link';
$string['blockname'] = 'Learning Resources';
$string['defaultshow'] = 'Show by default';
$string['delete'] = 'Delete';
$string['display'] = 'Display';
$string['links'] = 'Links';
$string['linktext'] = 'Link text';
$string['manage_links'] = 'Add/Edit Links';
$string['modify'] = 'Edit';
$string['newwindow_label'] = 'Open links in a new window:';
$string['no'] = 'No';
$string['none'] = 'There are no items to display';
$string['notes'] = 'Additional text';
$string['reference'] = 'Reference';
$string['title_label'] = 'Title:';
$string['url'] = 'URL';
$string['yes'] = 'Yes';
$string['course_teachers_edit_links'] = 'Allow course teachers to edit global links';

?>
