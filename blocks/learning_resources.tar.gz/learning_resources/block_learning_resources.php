<?php

/* Reference block by Tom Flannaghan and Andrew Walker - Alton College */

    class block_learning_resources extends block_list {
        function init() {
            $this->title = get_string('learning_resources', 'block_learning_resources');
            $this->version = 2006053011;
        }
        
        function specialization() {
            global $CFG;
            
            $this->title = !empty($CFG->block_learning_resources_title) ? $CFG->block_learning_resources_title : $this->title;
        }
        
        function get_content() {
			global $CFG,$USER;
            if ($this->content !== NULL) {
                return $this->content;
            }
            
            $this->content = new stdClass;
            $this->content->items = array();
            $this->content->icons = array();
            $this->content->footer = '';
            
            $rs = get_records('block_learning_resources');
            if (!is_array($rs)) {
                $rs = array();
            }
            $rs = stripslashes_safe($rs);
            
            $course = get_record('course', 'id', $this->instance->pageid);
            
            foreach ($rs as $link) {
                $temp = 'allow_' . $link->id;
                
                if (isset($this->config->$temp)) {
                    if ($this->config->$temp == 1) {
                        $this->add_link($link);
                    }
                } else if (($link->defaultshow == 1) & (($link->course_categorie_id == 0) | ($link->course_categorie_id == $course->category))) {
                    $this->add_link($link);
                }
            }
            
			if (isadmin() | isteacher($CFG->block_learning_resources_admin_course,$USER->id)) {
				$link->url = $CFG->wwwroot."/blocks/learning_resources/config_global_action.php";
				$link->linktext = "<b>".get_string('manage_links', 'block_learning_resources')."</b>";
				$link->notes = "";
				$this->add_link($link);
			}
            
            return $this->content;
        }
        
        function add_link($link) {
            global $CFG;
            
            $target = !empty($CFG->block_learning_resources_window) ? ' target="_blank"' : '';
        
            $this->content->items[] = '<a href="' . $link->url.'"' . $target . '>'. $link->linktext . '</a> <em>' .$link->notes . '</em>';
            $this->content->icons[] = '<img src="' . $CFG->pixpath . '/f/web.gif" height="16" width="16" alt="" />';
        }
        
        function instance_allow_config() {
            return true;
        }
        
        function has_config() {
            return true;
        }

    }
?>
