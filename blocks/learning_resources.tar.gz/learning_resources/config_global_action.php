<?php

require_once('../../config.php');

global $USER;

require_login();
if (!isadmin() & !isteacher($CFG->block_learning_resources_admin_course,$USER->id)) {
    error('ACCESS DENIED.');
}

$modify = optional_param('modify', -1);
$add = optional_param('add', -1);
$delete = optional_param('delete', -1);
if ($delete != -1) {
    delete_records('block_learning_resources', 'id', $delete);
}

if (isset($_POST['save'])) {
    
    $itemdata = new stdClass;
    $itemdata->linktext = required_param('linktext');
    $itemdata->url = required_param('url');
    $itemdata->notes = required_param('notes');
    $itemdata->defaultshow = required_param('defaultshow');
    $itemdata->course_categorie_id = required_param('course_categorie_id');
    
    $itemdata = addslashes_object($itemdata);
       
    if ($_POST['id'] == 'NEW') {
        insert_record('block_learning_resources', $itemdata);
    } else {
        $itemdata->id = required_param('id');
        update_record('block_learning_resources', $itemdata);
    }
    unset($itemdata);
}


$strconfiguration = get_string('configuration');
$stradmin = get_string('admin');
$strmanagelinks = get_string('manage_links', 'block_learning_resources');
$strlinks = get_string('links', 'block_learning_resources');
$stradd = get_string('addlink', 'block_learning_resources');


$navigation = "<a href=\"$CFG->wwwroot/$CFG->admin/index.php\">$stradmin</a> -> ".
    "<a href=\"$CFG->wwwroot/$CFG->admin/configure.php\">$strconfiguration</a> -> $strmanagelinks";
    
$rs = get_records('block_learning_resources');
if (!is_array($rs)) {
    $rs = array();
}
$rs = stripslashes_safe($rs);

if (count($rs) == 0) {
    $add = 1;
}

$content  = "<div id=\"content\">\n  <h2 class=\"main\">$strmanagelinks</h2>\n";
$content .= link_table_headings();

$editform = false;
$row = 1;
foreach ($rs as $index => $link) {
    if ($link->id == $modify) {
        $editform = true;
        $content .= link_modify_form($link, $row);
    } else {
        $content .= link_table_row($link, $row);
    }
    $row = 1 - $row;
}
if ($add != -1) {
    $content .= link_modify_form('', $row);
} else {
    $content .= "  <tr>\n   <td colspan=\"6\" align=\"center\"><hr /><a href=\"?add=true\">$stradd</a></td>\n  </tr>\n";
}
$content .= "</table>\n";

if ($editform || $add != -1) {
    $content = "<form method=\"post\" action=\"?\">" . $content . "</form>\n";
}
$content .= "</div>\n";


print_header($strmanagelinks, $strmanagelinks, $navigation);
echo $content;
print_footer();




function link_table_headings() {
    $strlinktext = get_string('linktext', 'block_learning_resources');
    $strurl = get_string('url', 'block_learning_resources');
    $strnotes = get_string('notes', 'block_learning_resources');
    $strdefaultshow = get_string('defaultshow', 'block_learning_resources');
    $strcatagory = get_string('catagory', 'block_learning_resources');
    $stractions = get_string('actions', 'block_learning_resources');
    
    $content  = "  <table class=\"generaltable generalbox\" align=\"center\" cellpadding=\"5\">\n    <tr>\n";
    $content .= "      <th class=\"header c0\" scope=\"col\">$strlinktext</th>\n";
    $content .= "      <th class=\"header c1\" scope=\"col\">$strurl</th>\n";
    $content .= "      <th class=\"header c2\" scope=\"col\">$strnotes</th>\n";
    $content .= "      <th class=\"header c3\" scope=\"col\">$strdefaultshow</th>\n";
    $content .= "      <th class=\"header c4\" scope=\"col\">$strcatagory</th>\n";
    $content .= "      <th class=\"header c5\" scope=\"col\">$stractions</th>\n";
    $content .= "  </tr>\n";
    return $content;
}

function link_table_row($link, $row = 0) {
    global $CFG;

    $strmodify = get_string('modify', 'block_learning_resources');
    $strdelete = get_string('delete', 'block_learning_resources');
    $stryes = get_string('yes', 'block_learning_resources');
    $strno = get_string('no', 'block_learning_resources');
    $strglobal = get_string('global', 'block_learning_resources');
    
    $content  = "  <tr class=\"r{$row}\">\n";
    $content .= "    <td>$link->linktext</td>\n";
    $content .= "    <td><a href=\"$link->url\">$link->url</a></td>\n";
    $content .= "    <td>$link->notes</td>\n";
            
    $content .= "    <td>";
    if ($link->defaultshow == '1') {
        $content .= "<img src=\"$CFG->pixpath/t/clear.gif\" height=\"10\" width=\"10\" alt=\"$stryes\" title=\"$stryes\" />";
    } else {
        $content .= "<img src=\"$CFG->pixpath/t/delete.gif\" height=\"11\" width=\"11\" alt=\"$strno\" title=\"$strno\" />";
    }
    $content .= "</td>\n";          
    $content .= "<td>";
    if ($link->course_categorie_id == 0){
		$content .= $strglobal;
    } else {    
		$catagories = get_records('course_categories','id',$link->course_categorie_id);
		foreach ($catagories as $catagory) {
			$content .= $catagory->name;
			
		}
    }
    $content .= "</td>";
    $content .= "    <td><a href=\"?modify=$link->id\" title=\"$strmodify\"><img src=\"$CFG->pixpath/t/edit.gif\" alt=\"$strmodify\" /></a> <a href=\"?delete=$link->id\" title=\"$strdelete\"><img src=\"$CFG->pixpath/t/delete.gif\" alt=\"$strdelete\" /></a></td>\n";           
    $content .= "  </tr>\n";
    return $content;
}

function link_modify_form($link = '', $row = 0) {
    if ($link == '') {
        $link = new stdClass;
        $link->id = 'NEW';
        $link->linktext = '';
        $link->url = '';
        $link->notes = '';
        $link->defaultshow = '1';
        $link->newwindow = '1';
        
        $strok = get_string('add');
    } else {
        $strok = get_string('edit');
    }
    
    $strcancel = get_string('cancel');
    
    
    $content  = "  <tr class=\"r{$row}\">\n    <td><input type=\"text\" name=\"linktext\" value=\"$link->linktext\" /></td>\n";
    $content .= "    <td><input type=\"text\" name=\"url\" value=\"$link->url\" /></td>\n";
    $content .= "    <td><input type=\"text\" name=\"notes\" value=\"$link->notes\" /></td>\n";
    $content .= "    <td><input type=\"hidden\" name=\"defaultshow\" value=\"0\" /><input type=\"checkbox\" name=\"defaultshow\" value=\"1\"";
    
    if ($link->defaultshow == '1') {
        $content .= ' checked="checked"';
    }
    $content .= " /></td>\n";
    $content .= "    <td><select name=\"course_categorie_id\">\n";
    $strglobal = get_string('global', 'block_learning_resources');
	$content .= "<option value=\"0\" ";
	if (0 == $link->course_categorie_id){
		$content .= "SELECTED";
	}
	$content .= ">".$strglobal."</option>";
    $catagories = get_records('course_categories');
    foreach ($catagories as $catagory) {
		$content .= "<option value=\"".$catagory->id."\" ";
		if ($catagory->id == $link->course_categorie_id){
			$content .= "SELECTED";
		}
		$content .= ">".$catagory->name."</option>";
		
    }
    $content .= "</select></td>\n";
    $content .= "    <td><input type=\"hidden\" name=\"id\" value=\"$link->id\"><input type=\"submit\" name=\"save\" value=\"$strok\" /><input type=\"submit\" value=\"$strcancel\" /></td>\n";
    return $content;
}

?>