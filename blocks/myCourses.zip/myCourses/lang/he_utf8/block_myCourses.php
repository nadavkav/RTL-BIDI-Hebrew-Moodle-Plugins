<?php //Version: 2008081901
      //Translator: Nadav Kavalerchik (nadavkav@gmail.com)

$string['blocktitle'] = 'מרחבי הלימוד שלי'; //Cr: can not be My courses because it collides with course_list block

$string['enrol'] = 'הצגת כל מרחבי הלימוד שלי'; //Show Moodle's course page
$string['enablejs'] = 'שימוש בגאווה סקריפט.';

$string['hideinactivecourses'] = 'הסתרת מרחבים לא פעילים';
$string['showinactivecourses'] = 'הצגת מרחבים לא פעילים';

$string['hideactivecourses'] = 'הסתרת מרחבים פעילים';
$string['showactivecourses'] = 'הצגת מרחבים פעילים';

$string['hidemycourses'] = 'הסתרת המרחבים שלי';
$string['showmycourses'] = 'הצגת המרחבים שלי';

?>
