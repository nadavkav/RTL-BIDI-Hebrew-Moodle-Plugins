<?php //Version: 2008081901
      //Autor, Uebersetzer: Rosario Carco

$string['blocktitle'] = 'meineKurse'; //Cr: darf nicht Meine Kurse sein, das mit course_list block kollidiert 
$string['enrol'] = 'Alle Kurse'; //KursUebersicht von Moodle anzeigen
$string['enablejs'] = 'JavaScript aktivieren, um Navigation anzuzeigen.';

$string['hideinactivecourses'] = 'Inaktive Kurse ausblenden';
$string['showinactivecourses'] = 'Inaktive Kurse anzeigen';

$string['hideactivecourses'] = 'Aktive Kurse ausblenden';
$string['showactivecourses'] = 'Aktive Kurse anzeigen';

$string['hidemycourses'] = 'Meine Kurse ausblenden';
$string['showmycourses'] = 'Meine Kurse anzeigen';

?>
