.block_mycourses .content * {
  float: left;
  text-align: left;
  overflow-y: overlay;
}

.block_mycourses .content {
  overflow-y: overlay;
}

.dir-rtl .block_mycourses .content * {
  float: right;
}

<!--.treeMenuDefault {
  width:400px;
}-->