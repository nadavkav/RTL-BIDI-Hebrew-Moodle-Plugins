.block_mycourses .content * {
  float: left;
  text-align: left;
}

.block_mycourses .content {
  overflow-y: auto;
}

.dir-rtl .block_mycourses .content * {
  float: right;
}

<!--.treeMenuDefault {
  width:400px;
}-->