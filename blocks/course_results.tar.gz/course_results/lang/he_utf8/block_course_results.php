<?PHP

$string['bestgrade'] = 'התוצאה הגבוהה ביותר:';
$string['bestgrades'] = '$a התוצאות הגבוהות ביותר:';
$string['bestgroupgrade'] = 'הקבוצה בעלת הממוצע הגבוהה ביותר:';
$string['bestgroupgrades'] = '$a הקבוצות בעלות הממוצע הגבוהה ביותר:';
$string['config_format_absolute'] = 'מספרים מוחלטים';
$string['config_format_fraction'] = 'שברים';
$string['config_format_percentage'] = 'אחוזים';
$string['config_grade_format'] = 'הצגת תוצאות כ:';
$string['config_name_format'] = 'רמת מידור לתצוגת תוצאות:';
$string['config_names_anon'] = 'תוצאות ללא-שם';
$string['config_names_full'] = 'תצוגת שם מלאה';
$string['config_names_id'] = 'תצוגת קוד מספרי';
$string['config_select_item'] = 'מאילו סוגי פעילויות יש להציג תוצאות?';
$string['config_show_best'] = 'כמה תוצאות יש להציג מהגבוהות ביותר (0 לביטול אפשרות זו)?';
$string['config_show_worst'] = 'כמב תוצאות להציג מהנמוכות ביותר (0 לביטול אפשרות זו)?';
$string['config_use_groups'] = 'תצוגת קבוצות במקום תלמידים (רק כאשר במבחן מאפשר זאת)?';
$string['configuredtoshownothing'] = 'משבצת ניהול זו אינה זמינה כיוון שלא הוגדרה עדיין. כנסו להגדרות המשבצת להפעלתה.';
$string['error_emptyitemid'] = 'תקלה: יש לבחור מבחן ממנו יוצגו הציונים.';
$string['error_emptyitemrecord'] = 'תקלה: המבחן שנבחר אינו מצוי במסד הנתונים של המערכת.';
$string['error_nogroupsexist'] = 'תקלה: בחרתם תצוגה של קבוצות אך לא הגדרו קבוצות בבוחן המבוקש.';
$string['formaltitle'] = 'תוצאות תלמידים וקבוצות';
$string['worstgrade'] = 'התוצאות הנמוכות ביותר:';
$string['worstgrades'] = '$a התוצאות הנמוכות ביותר:';
$string['worstgroupgrade'] = 'הקבוצה בעלת הממוצע הנמוך ביותר:';
$string['worstgroupgrades'] = '$a הקבוצות בעלות הממוצע הנמוך ביותר:';
$string['config_showuserpic'] = 'תצוגת תמונות תלמידים';
$string['config_title'] = 'כותרת משבצת-ניהול זו';
$string['config_header'] = 'פסקת מבוא';
$string['config_footer'] = 'פסקת סיכום';

?>