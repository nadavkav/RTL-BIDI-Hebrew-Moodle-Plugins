.block_search_metadata .searchform {
    text-align: center;
}

.block_search_metadata .searchform img {
    vertical-align: middle;
}

