<?php
$string['blockname']         = 'מרחבי־לימוד - חיפוש מהיר';
$string['quickcourselist:use']         = 'שימוש בחיפוש מהיר של מרחבי־לימוד';
$string['quickcourselist']         = 'מרחבי־לימוד - חיפוש מהיר';

?>