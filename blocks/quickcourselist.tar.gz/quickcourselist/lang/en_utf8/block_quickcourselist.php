<?php
$string['blockname']         = 'Quick Course List';
$string['quickcourselist:use']         = 'Use Quickcourse List';
$string['quickcourselist']         = 'Quick Course List';

?>