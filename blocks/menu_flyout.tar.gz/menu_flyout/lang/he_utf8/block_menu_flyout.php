<?PHP // $Id: block_menu_editor.php


$string['configcontent'] = 'תוכן';
$string['configtitle'] = 'כותרת משבצת התפריט';
$string['menu_flyout'] = 'תפריט מרחף משוכלל';
$string['leaveblanktohide'] = 'השאירו ריק להסתרת הכותרת';
$string['newhtmlblock'] = '(משבצת־תפריט חדשה)';
$string['menueditor'] = 'עריכת תפריט';
$string['linktype'] = 'סוג פריט';

$string['stepone'] = 'בחרו אפשרות אחת';
$string['steptwo'] = 'הזינו';
$string['stepthree'] = 'בחרו סוג תפריט';
$string['addmenutocourse'] = 'הוספת התפריט למרחב־הלימוד';
$string['additemtomenu'] = 'הוספת פריט לתפריט';
$string['addsubmenu'] = 'הוספת תת־תפריט';
$string['or'] = 'או';
$string['deleteall'] = 'מחיקת התפריט';
$string['linktitle'] = 'כותרת לפריט בתפריט';
$string['externalurl'] = 'כתובת אתר אינטרנט';
$string['addassubmenu'] = 'הוספה לתת־תפריט';
$string['addasmenu'] = 'הוספה לתפריט';

?>
