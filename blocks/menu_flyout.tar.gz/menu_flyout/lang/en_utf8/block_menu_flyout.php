<?PHP // $Id: block_menu_editor.php      


$string['configcontent'] = 'Content';
$string['configtitle'] = 'Block Title';
$string['menu_flyout'] = 'Menu Flyout';
$string['leaveblanktohide'] = 'Leave blank to hide the title';
$string['newhtmlblock'] = '(new Menu block)';

?>
