<?PHP  //$Id: mysql.php,
// The version option is not enabled with this file since the contribution is not registered with moodle.org

function menu_flyout_upgrade($oldversion=0) {

    global $CFG;
    
    $result = true;

    return $result;
}
