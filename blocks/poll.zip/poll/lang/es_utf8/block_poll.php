<?php
$string['config_param'] = 'Parámetro';
$string['config_value'] = 'Valor';
$string['editblocktitle'] = 'Título del bloque';
$string['editmaxbarwidth'] = 'Tamaño máximo del gráfico';
$string['editpollname'] = 'Nombre de la encuesta';
$string['editpollquestion'] = 'Texto de la pregunta';
$string['editpolleligible'] = 'Usuarios';
$string['editpolloptions'] = 'Cantidad de opciones';
$string['formaltitle'] = 'Encuesta';
$string['option'] = 'Opción';
$string['pollconfirmdelete'] = 'Está seguro que desea borrar esta encuesta ($a), incluyendo los datos de las respuestas?';
$string['pollwarning'] = 'Debe tener los permisos de edición dentro del curso para realizar esta acción';
$string['responses'] = 'Respuestas';
$string['submit'] = 'Enviar';
$string['tabconfigblock'] = 'Configurar Bloque';
$string['tabeditpoll'] = 'Crear/editar la encuesta';
$string['tabmanagepolls'] = 'Administrar encuestas';
$string['tabresponses'] = 'Ver respuestas';

?>
