<?php
$string['config_param'] = 'Parameter';
$string['config_value'] = 'Value';
$string['editblocktitle'] = 'Block title';
$string['editmaxbarwidth'] = 'Maximum graph width';
$string['editpollname'] = 'Poll name';
$string['editpollquestion'] = 'Question text';
$string['editpolleligible'] = 'Eligible users';
$string['editpolloptions'] = 'Option count';
$string['formaltitle'] = 'Poll';
$string['option'] = 'Option';
$string['pollconfirmdelete'] = 'Are you sure you want to completely delete this poll ($a), including all response data?';
$string['pollwarning'] = 'You must be a teacher to perform this action';
$string['responses'] = 'Responses';
$string['submit'] = 'Submit';
$string['tabconfigblock'] = 'Configure Block';
$string['tabeditpoll'] = 'Create/Edit Poll';
$string['tabmanagepolls'] = 'Manage Polls';
$string['tabresponses'] = 'View Responses';

?>
