<?php
error('Direct access is not allowed!');
?>
