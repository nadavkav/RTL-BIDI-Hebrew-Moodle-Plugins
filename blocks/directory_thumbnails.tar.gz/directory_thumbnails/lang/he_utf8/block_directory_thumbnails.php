<?php

$string['directorythumbnails'] = "רשימת תמונות";
$string['title'] = "מבחר תמונות";
$string['content'] =  'אנא בחרו ספריית תמונות לתצוגה';
$string['configtitle'] = "כותרת משבצת התמונות";
$string['configrandomize'] = "בחירת תמונות אקראיות";
$string['configcount'] = "מספר תמונות לתצוגה";
$string['configcontent'] =  'כיתוב נוסף תחת רשימת התמונות';
$string['clicktoshow']= 'הקליקו על אוסף התמונות להצגתו';
$string['configgallery']= 'בחרו ספריית תמונות לתצוגה';
$string['configheight']= 'גובה משבצת התמונה';
$string['configwidth']= 'רוחב משבצת התמונה';
$string['configimagedir']= 'בחרו ספריה לתצוגה';

?>