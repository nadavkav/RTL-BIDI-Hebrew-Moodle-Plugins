<?php

$string['directorythumbnails'] = "Directory Thumbnails";
$string['title'] = "Directory Thumbnails";
$string['configtitle'] = "Block's title";
$string['configrandomize'] = "Display randomized images";
$string['configcount'] = "Number of images to show";
$string['configcontent'] =  'Short Discription';
$string['configheight']= "Image's height";
$string['configwidth']= "Image's width";
$string['configimagedir']= 'Choose folder to display';

?>