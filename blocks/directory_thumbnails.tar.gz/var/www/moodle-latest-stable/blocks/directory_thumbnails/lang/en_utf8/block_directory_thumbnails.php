<?php

$string['imagegallery'] = "Image list Thumbnails";
$string['title'] = "Image List";
$string['content'] =  'Please choose a folder';
$string['configtitle'] = "Block title";
$string['configrandomize'] = "Display randomized images";
$string['configcount'] = "Number of images to show";
$string['configcontent'] =  'Slideshow sub title';
$string['configgallery']= 'Plase choose a folder with images to display';
$string['configheight']= 'Image height';
$string['configwidth']= 'Image width';
$string['configimagedir']= 'Choose folder to display';

?>