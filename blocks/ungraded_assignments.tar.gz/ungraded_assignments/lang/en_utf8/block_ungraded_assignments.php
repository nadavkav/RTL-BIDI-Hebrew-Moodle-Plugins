<?php

$string['title'] = 'Ungraded Assignments';
$string['worktobegraded'] = 'Total work to be graded:';
$string['noassignmentswaiting'] = 'No Assignments are waiting for grading';

?>