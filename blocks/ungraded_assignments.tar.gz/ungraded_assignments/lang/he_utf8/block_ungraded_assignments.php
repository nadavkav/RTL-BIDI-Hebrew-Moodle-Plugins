<?php

$string['title'] = 'משימות ממתינות לבדיקה';
$string['worktobegraded'] = 'משימות ממתינות:';
$string['noassignmentswaiting'] = 'אין משימות אשר ממתינות לבדיקה';

?>