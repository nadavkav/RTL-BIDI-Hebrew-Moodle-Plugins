<?php
$string['blockname'] = 'Mass Actions';
$string['blocktitle'] = 'Mass Actions';
$string['delete'] = 'Delete';
$string['delete_continue'] = 'Are you sure you want to delete the following module(s)?';
$string['delete_confirm'] = 'Are you REALLY sure you want to delete the following modules(s)?';
$string['moveto'] = 'Move to:';
$string['selectsection'] = 'Select all in section: ';
$string['movetosection'] = 'Move to section: ';// 'Choose a Section';
$string['javascript'] = '<div style=\"color:red; weight:bold;\">Warning: Javascript is disabled or the page has not finished loading</div><p>In order to function, javascript must be enabled </p>';
$string['massaction:canuse'] = "Can use block";
$string['unsupported'] = '<span style=\"color:red\"> This block does not support the <b> $a </b> course format </span>';
$string['hide'] = 'Hide';
$string['show'] = 'Show';
$string['indent'] = 'Move right';
$string['outdent'] = 'Move left';
$string['title'] = '<b>Mass Actions</b>';
$string['cancel'] = 'Cancel';
$string['section'] = 'Topic';
$string['select'] = 'Select items one-by-one or:';
$string['sectionzero'] = 'Section 0';
$string['selectall'] = 'Select all';
$string['deselectall'] = 'Deselect all';
$string['week'] = 'Week';
$string['topic'] = 'Topic';
$string['weekzero'] = 'Week 0';
$string['with_selected'] = 'With selected:';
?>
