<?php
$string['blockname'] = 'ניהול רכיבים כולל';
$string['blocktitle'] = 'ניהול רכיבים כולל';
$string['delete'] = 'מחיקה';
$string['delete_continue'] = 'האם אתם בטוחים שאתם מעוניינים למחוק את הרכיבים הבאים?';
$string['delete_confirm'] = 'האם אתם <b> משוכנעים </b> שאתם מעוניינים למחוק את הרכיבים הבאים?';
$string['moveto'] = 'העבירו אל:';
$string['selectsection'] = 'בחירת כל יחידות ההוראה: ';
$string['movetosection'] = 'העבירו ליחידת הוראה: ';// 'Choose a Section';
$string['javascript'] = '<div style=\"color:red; weight:bold;\">Warning: Javascript is disabled or the page has not finished loading</div><p>In order to function, javascript must be enabled </p>';
$string['massaction:canuse'] = "זמין לשימוש";
$string['unsupported'] = '<span style=\"color:red\"> רכיב זה אינו זמין עבור תצורת־התצוגה <b> $a </b> של מרחב־לימוד זה</span>';
$string['hide'] = 'הסתרה';
$string['show'] = 'הצגה';
$string['indent'] = 'הזחה לשמאל';
$string['outdent'] = 'הזחה לימין';
$string['title'] = '<b>ניהול רכיבים כולל</b>';
$string['cancel'] = 'ביטול';
$string['section'] = 'יחידת הוראה';
$string['select'] = 'בחרו רכיבים, אחד אחד או:';
$string['sectionzero'] = 'יחידת המבוא של המרחב';
$string['selectall'] = 'בחירה כוללת';
$string['deselectall'] = 'ביטול בחירה כוללת';
$string['week'] = 'שבוע';
$string['topic'] = 'יחידת הוראה';
$string['weekzero'] = 'יחידת המבוא';
$string['with_selected'] = 'עם הרכיבים המסומנים:';
?>
