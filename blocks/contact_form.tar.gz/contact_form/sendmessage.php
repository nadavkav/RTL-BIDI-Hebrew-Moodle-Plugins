<?php

    require_once($CFG->dirroot.'/lib/blocklib.php');
	
	if (! $site = get_site()) {
		redirect($CFG->wwwroot .'/'. $CFG->admin .'/index.php');
	}
	if (! $course = get_record("course", "id", $cid)) {
		error("Course is misconfigured in sendmessage.php");
	}
	
    //$messagepreface
    $debug = false;
    if ($debug) {
        echo '$cid = '.$cid.'<br />';
        echo '$bid = '.$bid.'<br />';
    }
	$comments = get_string('commentreceived', 'block_contact_form');
	// You received a comment 
	// E' giunta una nuova comunicazione
    $a->sitename = $site->shortname;
    if ($cid == 1) {
        $comments .= get_string('fromhompageof', 'block_contact_form', $a)."\n";
        // You received a comment from the home page of M19
        // E' giunta una nuova comunicazione dalla home page di M19
    } else {
        $a->coursename = $course->shortname;
        $comments .= get_string('fromcourse', 'block_contact_form', $a)."\n";
        // You received a comment from ourse xxx of M19
        // E' giunta una nuova comunicazione dal corso xxx di M19
    }
    $comments .=  "\n".$fromform->cf_mailbody;
    if ($debug) {
        echo $comments;
    }
    
    //sender infos
    $from = new object;
    $from->firstname = $fromform->cf_sendername;
    $from->lastname = '';
    $from->email = $fromform->cf_senderemail;
    $from->maildisplay = true;
    $from->mailformat = 1;
    
    if ($debug) {
        echo '<hr />';
        echo '$CFG->block_contact_form_subject_prefix = '.$CFG->block_contact_form_subject_prefix.'<br />';
        // [M19]
        echo '<hr />';
        echo '$CFG->block_contact_form_receipt = '.$CFG->block_contact_form_receipt.'<br />';
        echo '$thisblock->config->receipt = '.$thisblock->config->receipt.'<br />';
        // anche la config_instance valorizza la variable $CFG->block_contact_form_receipt
        echo '<hr />';
    }
    
    
    //define the subject starting from the pre-defined prefix
    if ($cid == 1) {
        // as afr as I understand, the next if is iuseless because
        // it was defined a default for $CFG->block_contact_form_subject_prefix
        if (!isset($CFG->block_contact_form_subject_prefix)) {
            $CFG->block_contact_form_subject_prefix = '['.strip_tags($site->shortname).']';
        } 
        $subject = $CFG->block_contact_form_subject_prefix.$fromform->cf_mailsubject;
    } else {        
        //set the subject to start with [shortname]
        $subject = '['.$course->shortname.'] '.$fromform->cf_mailsubject;
    }

if (!$debug) {
    //send emails
    $i = 0;
    if ($allhiddenrecipients) {
        foreach ($allhiddenrecipients as $thisrecipient) {
            $property = 'cf_teacher'.$i;
            if ( isset($fromform->{$property}) ) {
                if ( email_to_user($thisrecipient, $from, stripslashes_safe($subject), stripslashes_safe($comments)) ) {
                    add_to_log($cid, 'Contact Form Block', 'send mail', '', "To:$thisrecipient->firstname $thisrecipient->lastname; From:$from->firstname; Subject:$subject");
                } else {
                    echo 'An error was encountered trying to send email in comments.php. It is likely that your email settings are not configured properly. The error reported was "'. $error .'"<br />';
                    add_to_log($cid, 'Contact Form Block', 'send mail failure', '', "To:$thisrecipient->firstname $thisrecipient->lastname; From:$from->firstname; Subject:$subject");
              }
                }
          $i++;
        }
    }
	
    if ($allstandardrecipients) {
        foreach ($allstandardrecipients as $thisrecipient) {
            $property = 'cf_teacher'.$i;
            if ( isset($fromform->{$property}) ) {
                if ( email_to_user($thisrecipient, $from, stripslashes_safe($subject), stripslashes_safe($comments)) ) {
                    add_to_log($cid, 'Contact Form Block', 'send mail', '', "To:$thisrecipient->firstname $thisrecipient->lastname; From:$from->firstname; Subject:$subject");
                } else {
                    echo 'An error was encountered trying to send email in comments.php. It is likely that your email settings are not configured properly. The error reported was "'. $error .'"<br />';
                    add_to_log($cid, 'Contact Form Block', 'send mail failure', '', "To:$thisrecipient->firstname $thisrecipient->lastname; From:$from->firstname; Subject:$subject");
                    }
          }
          $i++;
        }
    }
	
    if ( $rcp == 1 ) {
        $subject = get_string('receipt', 'block_contact_form').$subject;
           if ( email_to_user($from, $from, stripslashes_safe($subject), stripslashes_safe($comments)) ) {
               add_to_log($cid, 'Contact Form Block', 'send mail', '', "To:$from->firstname; From:$from->firstname; Subject:$subject");
           } else {
               echo 'An error was encountered trying to send email in comments.php. It is likely that your email settings are not configured properly. The error reported was "'. $error .'"<br />';
               add_to_log($cid, 'Contact Form Block', 'send mail failure', '', "To:$from->firstname; From:$from->firstname; Subject:$subject");
           }
        add_to_log($cid, 'Contact Form Block', 'send mail', '', "To:$from->firstname; From:$from->firstname; Subject:$subject");
    }
} // end of: if (!$debug)
?>