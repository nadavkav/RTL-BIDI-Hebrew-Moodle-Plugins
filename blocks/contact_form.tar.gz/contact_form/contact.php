<?php // $Id: contact.php,v 1.1.2.3 2009/05/08 16:45:18 mcampbell Exp $
    global $CFG, $USER;

    require_once('../../config.php');
    require_once($CFG->libdir.'/blocklib.php');
    require_once('contact_form.php');
    require_once($CFG->dirroot.'/blocks/contact_form/locallib.php');

    $cid = optional_param('cid', 0, PARAM_INT); // course id
    $bid = optional_param('bid', 0, PARAM_INT); // block  id
    $rcp = optional_param('rcp', 0, PARAM_INT); // was receipt requested?
    
	// if you are reloading the page without resending right parameters,
	// stop here your work and redirect to the home page.
	if ($cid == 0)
		redirect($CFG->wwwroot.'/index.php');

	$debug = false;
	if ($debug) {
		echo '****** Written from contact.php ********<br />';
		echo '$cid = '.$cid.'<br />';
		echo '$bid = '.$bid.'<br />';
		echo '$rcp = '.$rcp.'<br />';
	}
    $strcontact_form  = get_string('contactform_name','block_contact_form');

    $navlinks = array();
    if ($cid == 1) {
        // sei nel corso dell'homepage
    } else {
        // sei in un corso
    	if (! $course = get_record("course", "id", $cid)) {
        	$navlinks[] = array('name' => $course->shortname, 'link' => "$CFG->wwwroot");
    	} else {
        	$navlinks[] = array('name' => $course->shortname, 'link' => "$CFG->wwwroot/course/view.php?id=$cid", 'type' => 'course');
        }
    }
    $navlinks[] = array('name' => $strcontact_form, 'link' => "", 'type' => 'block');

    $navigation = build_navigation($navlinks);
    print_header_simple($strcontact_form, "", $navigation, "", "", true, "", "");

    //----------------------------------------------------------------------------

    $allhiddenrecipients = getallhiddenrecipients($cid,$bid);
    $allstandardrecipients = getallstandardrecipients($bid);

    $mform =& new block_contact_form($CFG->wwwroot.'/blocks/contact_form/contact.php');
    if ($mform->is_cancelled()) {
        echo '<br /><div class="box generalbox boxaligncenter boxwidthnormal">';
        // form was successfully submitted. Now send and redirect.
        if ($cid == 1) {
            redirect($CFG->wwwroot.'/index.php',get_string('usercanceled','block_contact_form'));
        } else {
            redirect($CFG->wwwroot.'/course/view.php?id='.$cid,get_string('usercanceled','block_contact_form'));
        }
        echo '</div>';
    } else if ($fromform = $mform->get_data()) {
        include_once('sendmessage.php');

        echo '<br /><div class="box generalbox boxaligncenter boxwidthnormal">';
        // form was successfully submitted. Now send and redirect.
        if ($cid == 1) {
            redirect($CFG->wwwroot.'/index.php',get_string('messagesent','block_contact_form'));
        } else {
            redirect($CFG->wwwroot.'/course/view.php?id='.$cid,get_string('messagesent','block_contact_form'));
        }
        echo '</div>';
    } else {
        //this branch is executed if the form is submitted but the data doesn't validate and the form should be redisplayed
        //or on the first display of the form.
        //put data you want to fill out in the form into array $toform here then :
        echo '<br /><div class="box generalbox boxaligncenter boxwidthnormal">';
        print_string('welcome_info', 'block_contact_form');
        echo '</div>';
        $mform->display();
    }
/// Finish the page
    if (isset($course)) {
        print_footer($course);
    } else {
        print_footer();
    }
?>