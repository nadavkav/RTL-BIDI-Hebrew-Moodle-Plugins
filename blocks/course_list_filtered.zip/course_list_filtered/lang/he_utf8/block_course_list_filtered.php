<?PHP // $Id: block_course_list.php,v 1.3.4.1 2007/12/19 17:38:44 skodak Exp $
      // block_course_list.php - created with Moodle 1.7 beta + (2006101003)


$string['adminview'] = 'Admin view';
$string['allcourses'] = 'Admin user sees all courses';
$string['blockname'] = 'הקורסים שלי (על פי שנה)';
$string['filteredcourses'] = 'הקורסים שלי (על פי שנה)';
$string['configadminview'] = 'What should the admin see in the course list block?';
$string['confighideallcourseslink'] = 'Hide \"All courses\" link at the bottom of the block. Link hiding does not affects Admin\'s view';
$string['hideallcourseslink'] = 'Hide All courses link';
$string['owncourses'] = 'Admin user sees own courses';

?>
