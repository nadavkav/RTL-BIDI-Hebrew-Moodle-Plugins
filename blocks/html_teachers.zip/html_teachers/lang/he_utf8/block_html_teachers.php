<?php

$string['html_teachers'] = 'תוכן מעוצב - למרצים';
$string['configtitle'] = 'כותרת';
$string['configcontent'] = 'תוכן';
$string['leaveblanktohide'] = 'השאירו ריק, להסתרת הכותרת';
$string['newhtmlblock'] = 'טרם הוזנה כותרת';

?>