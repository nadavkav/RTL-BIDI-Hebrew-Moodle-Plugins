<?PHP
$string['save'] = 'שמירה';
$string['configtitle'] = 'כותרת משבצת הניהול';
$string['inserting'] = 'הגיגיי תלמידים';
$string['noofrow'] = 'מספר מסרים לתצוגה';
$string['noofmessage'] = 'מספר מסרים המאוחסנות ';
$string['row_allow'] = 'מספר תווים במסר';
$string['char_left'] = 'מספר תווים זמינים';
$string['noofcharbreak'] = 'מספר תווים בשורה';
$string['blockname'] = 'הגיגיי תלמידים';
$string['send'] = 'הוסיפו המסר לרשימה';
$string['setconfiguration'] = 'אנא עדכנו את הגדרות הרכיב';
$string['typehere'] = 'הקלידו את המסר שלכם כאן...';

$string['shoutbox:typemessage'] = 'הזנת מסר חדש';
$string['shoutbox:showoldmessage'] = 'הצגת מסרים ישנים';
$string['shoutbox:editownmessage'] = 'עריכת המסרים שלי';
$string['shoutbox:editallmessage'] = 'עריכת כל המספרים';
$string['shoutbox:deleteallmessage'] = 'מחיקת כל המסרים';


$string['secondrefresh'] = 'מספר אלפיות השנייה לרענות התצוגה';
$string['bgcolor1'] = ' צבע הרקע של שורה ראשונה';
$string['bgcolor2'] = 'צבע הרקע של שורה שנייה';
$string['downloadcsv'] = 'יצוא לקובץ בתצורת&nbsp;CSV';
$string['oldmessages'] = 'מסרים ישנים';
$string['charactorleft'] = 'מספר תווים זמין : ';
$string['delete'] = 'מחיקה';
$string['unchecked'] = 'ביטול בחירה';
$string['checked'] = 'בחירה&nbsp;כוללת';
$string['edit'] = 'עריכה';
?>
