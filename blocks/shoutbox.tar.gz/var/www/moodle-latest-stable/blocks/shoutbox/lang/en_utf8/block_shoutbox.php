<?PHP
$string['save'] = 'Save';
$string['configtitle'] = 'Block Title';
$string['inserting'] = 'Shoutbox';
$string['noofrow'] = 'Number of messages  to  show';
$string['noofmessage'] = 'Number of Messages stored ';
$string['row_allow'] = 'No. of chars to allow';
$string['char_left'] = 'No of chars left';
$string['noofcharbreak'] = 'No. of chars per line in textbox';
$string['blockname'] = 'Shoutbox';
$string['send'] = 'Submit your Message';
$string['setconfiguration'] = 'Please set your configuration';
$string['typehere'] = 'Type text here';

$string['shoutbox:typemessage'] = 'Type Message';
$string['shoutbox:showoldmessage'] = 'Show Old Message';
$string['shoutbox:editownmessage'] = 'Edit Own Messages';
$string['shoutbox:editallmessage'] = 'Edit All Messages';
$string['shoutbox:deleteallmessage'] = 'Delete All Messages';


$string['secondrefresh'] = 'No. of millisecs to refresh';
$string['bgcolor1'] = ' Background color of Line 1';
$string['bgcolor2'] = 'Background color of Line 2';
$string['downloadcsv'] = 'Download&nbsp;CSV';
$string['oldmessages'] = 'Old Messages';
$string['charactorleft'] = 'No. of Chars Left : ';
$string['delete'] = 'Delete';
$string['unchecked'] = 'Uncheck';
$string['checked'] = 'Select&nbsp;All';
$string['edit'] = 'Edit';
?>
