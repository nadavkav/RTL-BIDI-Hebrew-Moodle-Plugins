
.textarea_box {
	font-family: "Times New Roman", Times, serif;
	color: #000000;
	background-color: #AECEFF;
	height:100px;
	width: 200px;
	font-size: 14px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #0066FF;
	border-right-color: #0066FF;
	border-bottom-color: #0066FF;
	border-left-color: #0066FF;
}

.divcont1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9px;
	font-weight: bold;
	color: #0000FF;
}
.divcont2 {
	font-family: "Times New Roman", Times, serif;
	font-size: 12px;

	color:#999999;
}
.divcont3 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	color:#0066FF;
	background-color: #FFCCFF;
}


.divcont4 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	color:#0066FF;
	background-color: #C6D1FF;
}
