<?php // $Id: block_side_bar.php,v 1.1 2006/09/19 13:18:04 mchurch Exp $

$string['configsectionnumber'] = 'Enter new section starting number';
$string['configtitle'] = 'Enter new block title';
$string['sectionnumberwarning'] = 'WARNING: This value should be high enough that it will not ' .
                                  'interfere with regular course section values.  Also, if you ' .
                                  'already have blocks setup make sure you modify this value to ' .
                                  'something <b>larger</b> than the maximum section number ' .
                                  'already existing for a block.  If in doubt, don\'t change this ' .
                                  'number.';
$string['sidebar'] = 'Side Bar';

?>
