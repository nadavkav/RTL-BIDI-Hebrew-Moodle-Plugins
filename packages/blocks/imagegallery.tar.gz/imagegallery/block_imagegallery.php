<?php

class block_imagegallery extends block_base {

function init() {
  $this->title = get_string('imagegallery', 'block_imagegallery');
  $this->version = 2009033001;
}

function get_content() {
  global $COURSE, $CFG;

  if ($this->content !== NULL) {
  return $this->content;
  }

//   $id = $COURSE->id; //required_param('id', PARAM_INT);
//
//   if (! $course = get_record('course', 'id', $id)) {
//       error('Course ID is incorrect');
//   }

  $strgalleries = get_string('galleries','block_imagegallery');
  if (! $galleries = get_all_instances_in_course('lightboxgallery', $COURSE)) {
		$this->content = new stdClass;
		$this->content->text = get_string('thereareno', 'moodle', $strgalleries);
		$this->content->footer = get_string('pleaseaddimagegallery','block_imagegallery');
		return $this->content;
  }

  $data = '<script src="'.$CFG->wwwroot.'/blocks/imagegallery/popup.js" language="JavaScript"></script> ';
  $data .= '<ol>';
  foreach ($galleries as $gallery) {
    $galleryurl = '\''.$CFG->wwwroot.'/mod/lightboxgallery/view.php?l='.$gallery->id.'\'';
    $data .= '<li><div onclick="javascript:openFrameless('.$galleryurl.');"><b>'.$gallery->name.'</b></div></li>';
  }
  $data .= '</ol>';

  $this->content = new stdClass;
  $this->content->text = $data;
  $this->content->footer = get_string('clicktoshow','block_imagegallery');

  return $this->content;
}

function instance_allow_config() {
  return true;
}

function specialization() {
  if(!empty($this->config->title)){
    $this->title = $this->config->title;
  }else{
    $this->config->title = 'please click an images';
  }
  if(empty($this->config->text)){
    $this->config->text = 'the list of images';
  }
}

// function html_attributes() {
//   return array(
//     'class'       => 'sideblock block_'. $this->name()
//     //,'onmouseover' => "alert('Mouseover on our block!');"
//   );
// }

function applicable_formats() {
  return array(
           'site-index' => true,
          'course-view' => true,
   'course-view-social' => false,
                  'mod' => true,
             'mod-quiz' => false
  );
}

} // class block_imagegallery ends here
?>