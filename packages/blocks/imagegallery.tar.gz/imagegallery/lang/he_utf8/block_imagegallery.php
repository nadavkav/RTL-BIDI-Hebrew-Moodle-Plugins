<?php

$string['imagegallery'] = "אוסף תמונות";
$string['configtitle'] = "כותרת";
$string['configcontent'] = "תוכן";
$string['clicktoshow']= 'הקליקו על אוסף התמונות להצגתו';
$string['galleries']= 'אלבומי תמונות';
$string['pleaseaddimagegallery']= 'אנא הוסיפו אלבום תמונות אחד לפחות';

?>