<?php

$string['imagegallery'] = "Image Gallerys";
$string['configtitle'] = "title";
$string['configcontent'] = "content";
$string['clicktoshow']= 'click the gallery name to show it';

?>