<?php // $Id: setupdomain.php,v 1.3 2005/11/18 21:20:25 

	require_once('../../config.php');
	require_once('../../course/lib.php');

    $id = $_GET['id']; 
	
    if (! $course = get_record('course', 'id', $id) ) {
        error("That's an invalid course id");
    }

    require_login($course->id);

    $loggedinas = "<p class=\"logininfo\">".user_login_string($course, $USER)."</p>";

    print_header("$course->shortname: GISMO domain setup", "$course->fullname", 
                 "<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a> -> GISMO: Domain Setup");
if (isteacher($course->id) || isadmin()){
$prefix = $CFG->prefix;
$selectedelement = -1;
$selectedconcept = -1;
$element ='';
$elementmembers = array();
$alreadyinconceptlist='';

if(isset($_POST['elementid'])){
		$selectedelement=$_POST['elementid'];
}
if(isset($_POST['conceptid'])){
		$selectedconcept=$_POST['conceptid'];
}

if(isset($_POST['type'])){
	$type=$_POST['type'];
	if($type == 'Resources')
		$element.="resource";
	else if($type == 'Quizzes')
		$element.="quiz";
	else if($type == 'Assignments')
		$element.="assignment";
}
	
if(isset($_GET['sub'])){
	if($_GET['sub']=="removeconcept"){
		
		$memberconceptid = $_POST['memberconceptid'];
		$elementid = $_POST['elementid'];
		
		if($memberconceptid!=-1){
			$query="DELETE FROM ".$prefix."gismo_concept_".$element." WHERE concept_id =".$memberconceptid." and ".$element."_id = ".$elementid;
			$export = execute_sql($query,false);//mysql_query($query);
		}
	}
	else if($_GET['sub']=="concept"){
		$conceptid = $_POST['conceptid'];
		$elementid =  $_POST['elementid'];
		$domainid =  $_POST['domainid'];
		
		if($_POST['remove']){
			$selectedelement = '';
			if($conceptid!=-1){
				$query="DELETE FROM ".$prefix."gismo_concept WHERE id =".$conceptid;
				$export = execute_sql($query,false);
				
				$query="DELETE FROM ".$prefix."gismo_concept_resource WHERE concept_id =".$conceptid;
				$export = execute_sql($query,false);
				
				$query="DELETE FROM ".$prefix."gismo_concept_quiz WHERE concept_id =".$conceptid;
				$export = execute_sql($query,false);
				
				$query="DELETE FROM ".$prefix."gismo_concept_assignment WHERE concept_id =".$conceptid;
				$export = execute_sql($query,false);
			}
		}
		else if($_POST['addconcept']){
			
			if($conceptid!=-1){
				$selectedconcept = '';
				$query="SELECT * FROM ".$prefix."gismo_concept_".$element." WHERE concept_id =".$conceptid." and ".$element."_id=".$elementid;
				$export = get_records_sql($query);
				
				if(!is_array($export)){
					$query="INSERT INTO ".$prefix."gismo_concept_".$element." (id,".$element."_id, concept_id) VALUES ('','".$elementid."', '".$conceptid."')";
					$export = execute_sql($query,false);
				}
				
			}
		
		}
		else if($_POST['add']  || $_POST['text']){
			$conceptname=$_POST['text'];
			$query="INSERT INTO ".$prefix."gismo_concept ( id, course_id , name ) VALUES ('',".$course->id.", '".$conceptname."' )";
			$export =  execute_sql($query,false);
			
		}
	}
}

?>

<script type="text/javascript">
<!-- Begin
<?php 

function createElements(){
global $course, $elementmembers, $type,$selectedelement,$element,$prefix,$alreadyinconceptlist;

$query="SELECT ".$prefix."gismo_concept_".$element.".id, ".$prefix.$element.".id as e_id, ".$prefix.$element.".name as e_name, ".$prefix."gismo_concept.name as concept_name, ".$prefix."gismo_concept.id as concept_id FROM ".$prefix."gismo_concept_".$element.", ".$prefix."gismo_concept, ".$prefix.$element." WHERE ".$prefix."gismo_concept_".$element.".".$element."_id = ".$prefix.$element.".id AND ".$prefix."gismo_concept_".$element.".concept_id = ".$prefix."gismo_concept.id AND ".$prefix."gismo_concept.course_id = ".$course->id." ORDER BY ".$prefix.$element.".id, ".$prefix."gismo_concept.name";
$export = get_records_sql($query); //mysql_query($query);

$query="SELECT ".$prefix."gismo_concept_".$element.".id, ".$prefix."gismo_concept_".$element.".".$element."_id, ".$prefix."gismo_concept_".$element.".concept_id FROM ".$prefix."gismo_concept_".$element.", ".$prefix."gismo_concept WHERE ".$prefix."gismo_concept.course_id =".$course->id." ORDER BY ".$prefix."gismo_concept_".$element.".".$element."_id" ;
$alreadyinconceptlist = get_records_sql($query);

$listelementmembers = array();
//estrazione valori campi
//while($row = mysql_fetch_object($export)) {	
if(is_array($export)){
	foreach($export as $row){
		if(!isset($listelementmembers["$row->e_id"])){
			$listelementmembers["$row->e_id"] = array();
		}		
		$listelementmembers["$row->e_id"]["$row->concept_id"]= $row->concept_name;
	}
}
$query2 = "SELECT ".$prefix.$element.".id, ".$prefix.$element.".name FROM ".$prefix.$element." WHERE ".$prefix.$element.".course = $course->id GROUP BY ".$prefix.$element.".id";

$export2 = get_records_sql($query2); //mysql_query($query2);
$first = 0;

//while($row = mysql_fetch_object($export2)) {	
if(is_array($export2)){
	foreach($export2 as $row){	
	   if($first++ == 0)
			if($selectedelement==-1)
				$selectedelement = $row->id;
		if(!isset($listelementmembers["$row->id"])){
			$listelementmembers["$row->id"] = array();
		}
	}
}
$query3 = "SELECT ".$prefix."gismo_concept.id as c_id, ".$prefix."gismo_concept.name as c_name FROM ".$prefix."gismo_concept_".$element.", ".$prefix."gismo_concept, ".$prefix.$element." WHERE ".$prefix."gismo_concept.course_id = ".$course->id." AND ".$prefix."gismo_concept_".$element.".".$element."_id = ".$prefix.$element.".id AND ".$prefix."gismo_concept_".$element.".concept_id = ".$prefix."gismo_concept.id and ".$prefix.$element.".id = $selectedelement ORDER BY ".$prefix."gismo_concept.name";
$export3 = get_records_sql($query3); //mysql_query($query3);

//while($row = mysql_fetch_object($export3)) {
if(is_array($export3)){
	foreach($export3 as $row){	
		$elementmembers["$row->c_id"]->id = $row->c_id;
		$elementmembers["$row->c_id"]->name = $row->c_name;
	}
}

 //Print Elements Lists
 foreach ($listelementmembers as $elementid => $listmember) {
        echo "element$elementid = new Object();\n";
        $idstring = "element$elementid.id = new Array(";
        $namestring = "element$elementid.name = new Array(";
        $max = count($listmember);
        $count = 0;
        foreach ($listmember as $id => $name) {
            $count++;
            $idstring .= "\"$id\"";
			if(strlen($name)>25){
				$name=substr($name,0,25);
				$name.='...';
			}
            $namestring .= "\"$name\"";
            if ($count < $max) {
                $idstring .= ', ';
                $namestring .= ', ';
            }
        }
        $idstring .= ");\n";
        $namestring .= ");\n";

        echo $idstring;
        echo $namestring;
    }

}


$query='SELECT '.$prefix.'gismo_concept.id, '.$prefix.'gismo_concept.name FROM '.$prefix.'gismo_concept WHERE '.$prefix.'gismo_concept.course_id = '.$course->id.'	GROUP BY '.$prefix.'gismo_concept.name';
$conceptList = get_records_sql($query); 

//Print ConceptList
echo "conceptList = new Object();\n";
$idstring="conceptList.id = new Array(";
$namestring = "conceptList.name = new Array(";
$max = count($conceptList);
$count = 0;
if(is_array($conceptList)){
	foreach ($conceptList as $row) {
		$count++;
		$idstring .= "\"$row->id\"";
		if(strlen($row->name)>25){
			$row->name=substr($row->name,0,25);
			$row->name.='...';
		}
		$namestring .= "\"$row->name\"";
		if ($count < $max) {
			$idstring .= ', ';
			$namestring .= ', ';
		}
	}
}
$idstring .= ");\n";
$namestring .= ");\n";

echo $idstring;
echo $namestring;


if(isset($type)){	
	createElements();
}

?>

function updateElement() {   
	document.formconcept.elementid.value = document.formelement.element.value;
	document.formconcept_add.elementid.value = document.formelement.element.value;
	document.formmember.elementid.value = document.formelement.element.value;
	document.formmember_remove.elementid.value = document.formelement.element.value;
	document.formelement.elementid.value = document.formelement.element.value;
	document.elementtypeform.elementid.value = document.formelement.element.value;
	document.getElementById("membertitle").innerHTML=document.formelement.element.options[document.formelement.element.selectedIndex].text;
	
}
function updateSelectedMemberConcept() {
    document.formmember.memberconceptid.value = document.formmember.member.value;
	document.formmember_remove.memberconceptid.value = document.formmember.member.value;
}
function updateSelectedConcept() {
    document.formconcept.conceptid.value = document.formconcept.concept.value;
	document.formconcept_add.conceptid.value = document.formconcept.concept.value;
	document.formmember.conceptid.value = document.formconcept.concept.value;
    document.elementtypeform.conceptid.value = document.formconcept.concept.value;
}
function updateMembers(selected) {		
	
		eval('element=element'+selected.value); 
		ename = element.name;
    	eid = element.id;

    	document.formmember['member'].length = ename.length;

    	for (i=0;i<ename.length;i++) {
        	document.formmember['member'].options[i].value = eid[i];
        	document.formmember['member'].options[i].text  = ename[i];
    	}

		updateElement();
		updateConcepts();
}

function changeelements(){
	var selectBox = document.elementtypeform.elementtype;
	var user_input = selectBox.options[selectBox.selectedIndex].value;

	/*if(document.elementtypeform.elementtype.value!="Select..."){
		document.location.href="setupdomain.php?type="+user_input+"&id=<?php echo $id ?>";
	}*/
	document.elementtypeform.type.value = user_input;
	document.formmember.type.value = user_input;
	document.formmember_remove.type.value = user_input;
	document.formconcept.type.value = user_input;
	document.formconcept_add.type.value = user_input;
	document.formelement.type.value = user_input;
	document.elementtypeform.submit();
	
}


function checkText(){
	
	if(document.formconcept.text.value=="")
		return false;	
	else{
		document.formconcept.submittedby.value="add";
		return true;
	}
	
}

function del(value){
	document.formconcept.submittedby.value="remove";
	return true;
}

function updateConcepts(){

	eval('concept=conceptList'); 
	cname = concept.name;
	cid = concept.id;
	if(cname.length == 0)
		return false;
	
	if(document.elementtypeform.elementtype.value=='' || document.elementtypeform.elementtype.value=='Please Select...'){
				
		document.formconcept['concept'].length = cname.length;
	
		for (i=0;i<cname.length;i++) {
			document.formconcept['concept'].options[i].value = cid[i];
			document.formconcept['concept'].options[i].text  = cname[i];
		}
	}else{
		
		ename=Array();
		eid=Array();		
		if(cname.length!=0){
			document.formconcept['concept'].length = cname.length;
			
			if(document.formelement.element.selectedIndex>=0){
				eval('element=element'+document.formelement.element.options[document.formelement.element.selectedIndex].value); 
				ename = element.name;
				eid   = element.id;
				var pos=0;
				for (i=0;i<cname.length;i++) {
					var j=0;
					for(j=0;j<ename.length;j++) {
						if(cid[i]==eid[j]){
							break;
						}
					}
					if(j==ename.length){
						document.formconcept['concept'].options[pos].value =   cid[i];
						document.formconcept['concept'].options[pos++].text  = cname[i];
					}else{
						document.formconcept['concept'].length--;
					}
				}
			}
		}
		
		
	}

}

// end hiding script -->
</script>


<?php


function getSelectedName($id){
	global $type,$course,$prefix;
	$query='';
	
	if($id==-1)
		return '';
		
	if($type=='Resources'){
		$query.='select name from '.$prefix.'resource WHERE '.$prefix.'resource.id = '.$id; 
	}else if($type=='Quizzes'){
		$query.='select name from '.$prefix.'quiz WHERE '.$prefix.'quiz.id = '.$id; 
	}
	else if($type=='Assignments'){
		$query.='select name from '.$prefix.'assignment WHERE '.$prefix.'assignment.id = '.$id; 
	}
	
	$export = get_record_sql($query);
	$obj = $export->name;			

	return $obj;
}

function loadvalues($form){
	
	global $type,$course,$prefix;
	$query='';

	switch($form){
		//Resource/Quiz 0
		case 0: if($type=='Resources'){
					$query.='select * from '.$prefix.'resource WHERE '.$prefix.'resource.course = '.$course->id.' ORDER BY '.$prefix.'resource.name'; 
				}else if($type=='Quizzes'){
					$query.='select * from '.$prefix.'quiz WHERE '.$prefix.'quiz.course = '.$course->id.' ORDER BY '.$prefix.'quiz.name'; 
				}
				else if($type=='Assignments'){
					$query.='select * from '.$prefix.'assignment WHERE '.$prefix.'assignment.course = '.$course->id.' ORDER BY '.$prefix.'assignment.name'; 
				}
				
		break;
		//Concepts 1
		case 1:$query.='SELECT '.$prefix.'gismo_concept.id, '.$prefix.'gismo_concept.name
						FROM '.$prefix.'gismo_concept
						WHERE '.$prefix.'gismo_concept.course_id = '.$course->id.'
						GROUP BY '.$prefix.'gismo_concept.id
						ORDER BY '.$prefix.'gismo_concept.name';
		break;
		default: break;
	}
	
	$export = get_records_sql($query);
	$obj = array();
	$i=0;
	if(is_array($export) && count($export)!=0){
		//extract values
		foreach($export as $row){
			$objitem->id=$row->id; 
			$objitem->value=$row->name;
			$obj[$i++] = $objitem;	
			unset($objitem);		
		}
	}
	return $obj;
}

?>
<div align="center" style="padding-top:20px; "><table width="95%"  border="0" cellspacing="0" cellpadding="2">
  <tr>
   <td align="center"><h1 align="center" style="padding:0.2em; margin:0px;text-align:center;">GISMO: Domain Setup <a href="<?php echo $CFG->wwwroot; ?>/blocks/gismo/setupdomainhelp.php" onclick="return openpopup('/blocks/gismo/setupdomainhelp.php?id=<?php echo $course->id; ?>', 'popup', 'menubar=0,location=0,scrollbars,resizable,width=500,height=400', 0);"><span class="helplink"><img src=" <?php echo $CFG->pixpath."/help.gif"; ?>" alt="Domain help" height="17" width="17"></span></a></h1></td>
  </tr>
  <tr>
    <td id="domainContent" style="padding:10px; "><table width="800"  border="1" align="center" cellpadding="5" cellspacing="0" class="generalbox" style="border-width:thin; ">
      <tr><td colspan="4" class="header" align="left">For each Resource/Quiz/Assignment, select the related concepts</td></tr>
      <tr>
    <td width="240" class="header" align="center"><form action="setupdomain.php?&id=<?php echo $id ?>" method="post" name="elementtypeform" style="display:inline ">
           <input name="conceptid" type="hidden" value="<?php print "$selectedconcept"; ?>">
           <input name="elementid" type="hidden" value="<?php print "$selectedelement"; ?>">
		   <input name="type" type="hidden" id="type" value="">
		    <select name="elementtype" onChange="return changeelements()" tabindex="1">
              <?php if(!isset($type) && $type==null || $type==''){ print("<option selected>Please Select...</option>"); } ?>
              <option value="Resources" <?php if(isset($type) && $type=='Resources'){ print(" selected"); } //resource is selected ?>>Resources</option>
              <option value="Quizzes" <?php if(isset($type) && $type=='Quizzes'){ print(" selected"); } ?>>Quizzes</option>
              <option value="Assignments" <?php if(isset($type) && $type=='Assignments'){ print(" selected"); } ?>>Assignments</option>
            </select>
          </form></td>
    <td width="240" class="header"><div align="center">Concepts </div></td>
    <td  class="header" width="40">&nbsp;</td>
	<td width="240" class="header" align="center"><div style="display:inline; ">Concepts related to: </div> 
	  <div style="display:inline;" id="membertitle"><?php echo getSelectedName($selectedelement); ?></div></td>
      </tr>
      <tr>
       <td align="center" valign="top" ><form action="" method="post" name="formelement">
          <input name="elementid" type="hidden" value="<?php print "$selectedelement"; ?>">
          <input name="type" type="hidden" id="type" value="<?php print "$type"; ?>">
      <select name="element" size="20" onChange="updateMembers(this)" tabindex="11">
	    <?php if(isset($type) && $type!=null){
	  $obj=loadValues(0);
	 
	  foreach($obj as $element){
	  	$selected2 = '';
		if($selectedelement==$element->id){
			$selected2 .= ' selected ';
		}
		$ename = $element->value;
		if(strlen($ename)>30){
			$ename = substr($ename,0,30);
			$ename.='...';
		}
		
	  	print("<option $selected2 value=\"$element->id\">$ename</option>");
	  }
	  }
	  ?>
        </select>
    </form>   </td>
        <td align="center" valign="top"><form action="setupdomain.php?<?php if(isset($type) && $type!=null){print("type=".$type);} ?>&sub=concept&id=<?php echo $id ?>#domainContent" method="post" name="formconcept">
            <input name="conceptid" type="hidden" value="<?php print "$selectedconcept"; ?>">
            <input name="elementid" type="hidden" value="<?php print "$selectedelement"; ?>">
            <input name="submittedby" type="hidden" value="">
            <input name="type" type="hidden" id="type" value="<?php print "$type"; ?>">
            <select name="concept" size="20" onChange="return updateSelectedConcept()" tabindex="6">
				   <?php 
					  
				  ?>
            </select>
            <p>            
            <div ><input name="text" id="text" type="text" size="20" tabindex="7" style="display:inline; ">
              <input name="add" type="submit" id="add" value="New Concept" onClick="return checkText()" tabindex="8" style="display:inline; "></div>
</p>
            <p>
              <input name="remove" type="submit" id="remove" value="Remove Concept" onClick="return del()" tabindex="9">
            </p>
        </form></td>
        <td align="center" bgcolor="#DDDDDD" valign="top"> <p>&nbsp;</p>
          <p>&nbsp;</p>          <form action="setupdomain.php?<?php if(isset($type) && $type!=null){print("type=".$type);} ?>&sub=concept&id=<?php echo $id ?>#domainContent" method="post" name="formconcept_add">
           <input type="submit" name="addconcept" value="=>" tabindex="10">
           <input name="conceptid" type="hidden" value="<?php print "$selectedconcept"; ?>">
           <input name="elementid" type="hidden" value="<?php print "$selectedelement"; ?>">
           <input name="type" type="hidden" id="type" value="<?php print "$type"; ?>">
    </form> <p>&nbsp;</p>
    <form action="setupdomain.php?<?php if(isset($type) && $type!=null){print("type=".$type);} ?>&sub=removeconcept&id=<?php echo $id ?>#domainContent" method="post" name="formmember_remove">
    <input type="submit" name="remove" value="<=" tabindex="12">
    <input name="conceptid" type="hidden" value="<?php print "$selectedconcept"; ?>">
    <input name="elementid" type="hidden" id="elementid" value="<?php print "$selectedelement"; ?>">
    <input name="memberconceptid" type="hidden" value="-1">
    <input name="type" type="hidden" id="type" value="<?php print "$type"; ?>">
        </form></td>
       <td align="center" valign="top">
	<form action="setupdomain.php?<?php if(isset($type) && $type!=null){print("type=".$type);} ?>&sub=removeconcept&id=<?php echo $id ?>" method="post" name="formmember">
      
        <input name="conceptid" type="hidden" value="<?php print "$selectedconcept"; ?>">
        <input name="elementid" type="hidden" id="elementid" value="<?php print "$selectedelement"; ?>">
        <input name="memberconceptid" type="hidden" value="-1">
        <input name="type" type="hidden" id="type" value="<?php print "$type"; ?>">
        <select name="member" size="20" onChange="return updateSelectedMemberConcept()" tabindex="13">
	   <?php foreach($elementmembers as $element){
			    $ename = $element->name;
				if(strlen($ename)>25){
					$ename = substr($ename,0,25);
					$ename.='...';
				}
		  	 	print("<option value=\"$element->id\">$ename</option>");
			 } ?>
        </select>
	</form></td>
      </tr>
    </table></td>
  </tr>
</table>
</div>

<script type="text/javascript">updateConcepts();</script>
<?php 
}else{
	print("<h1>You must have Teaching privileges to see this page</h1>");
}
  print_footer($course);
?>
