# This file contains a complete database schema for all the
# tables used by this module, written in SQL
 
# It may also contain INSERT statements for particular data
# that may be used, especially new entries in the table log_display

#
# Table structure for table `prefix_gismo_chart_discussion_read`
#

CREATE TABLE `prefix_gismo_chart_discussion_read` (
  `id` int(11) NOT NULL default '0',
  `course_id` int(11) NOT NULL default '0',
  `student_id` int(11) NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_chart_discussion_thread`
#

CREATE TABLE `prefix_gismo_chart_discussion_thread` (
  `id` int(11) NOT NULL default '0',
  `course_id` int(11) NOT NULL default '0',
  `student_id` int(11) NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_chart_discussion_write`
#

CREATE TABLE `prefix_gismo_chart_discussion_write` (
  `id` int(11) NOT NULL default '0',
  `course_id` int(11) NOT NULL default '0',
  `student_id` int(11) NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_chart_login_access_overview`
#

CREATE TABLE `prefix_gismo_chart_login_access_overview` (
  `course_id` int(10) unsigned NOT NULL default '0',
  `student_id` int(10) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  `log_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`log_id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_chart_student_resource_detail`
#

CREATE TABLE `prefix_gismo_chart_student_resource_detail` (
  `log_id` int(11) NOT NULL default '0',
  `student_id` int(10) unsigned NOT NULL default '0',
  `resource_id` int(10) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  `view_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`student_id`,`resource_id`,`time`,`log_id`)
) TYPE=MyISAM ;
    
# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_concept`
#

CREATE TABLE `prefix_gismo_concept` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `course_id` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;


# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_concept_assignment`
#

CREATE TABLE `prefix_gismo_concept_assignment` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `assignment_id` int(11) NOT NULL default '0',
  `concept_id` int(11) NOT NULL default '0',
  `relevance` int(11) NOT NULL default '10',
  PRIMARY KEY  (`id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `concept_id` (`concept_id`)
) TYPE=MyISAM ;


# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_concept_quiz`
#

CREATE TABLE `prefix_gismo_concept_quiz` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `quiz_id` int(11) NOT NULL default '0',
  `concept_id` int(11) NOT NULL default '0',
  `relevance` int(11) NOT NULL default '10',
  PRIMARY KEY  (`id`),
  KEY `quiz_id` (`quiz_id`),
  KEY `concept_id` (`concept_id`)
) TYPE=MyISAM ;


# --------------------------------------------------------

#
# Table structure for table `prefix_gismo_concept_resource`
#

CREATE TABLE `prefix_gismo_concept_resource` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `concept_id` int(10) unsigned NOT NULL default '0',
  `resource_id` int(10) unsigned NOT NULL default '0',
  `relevance` int(11) NOT NULL default '10',
  PRIMARY KEY  (`id`),
  KEY `concept_id` (`concept_id`),
  KEY `resource_id` (`resource_id`)
) TYPE=MyISAM ;


