<?PHP  //$Id: postgres7.php,v 1.1 2004/04/19 04:30:52 paca70 Exp $
//
// This file keeps track of upgrades to Moodle's
// blocks system.
//
// Sometimes, changes between versions involve
// alterations to database structures and other
// major things that may break installations.
//
// The upgrade function in this file will attempt
// to perform all the necessary actions to upgrade
// your older installtion to the current version.
//
// If there's something it cannot do itself, it
// will tell you what you need to do.
//
// Versions are defined by backup_version.php
//
// This file is tailored to PostgreSQL

function gismo_upgrade($oldversion=0) {

    global $CFG;
    
    $result = true;

    if ($oldversion < 2004071000 and $result) {
        print "Adding GISMO Domain Tables";
		execute_sql("CREATE TABLE `{$CFG->prefix}gismo_concept` (
		  `id` int(10) unsigned NOT NULL auto_increment,
		  `course_id` int(10) unsigned NOT NULL default '0',
		  `name` varchar(255) NOT NULL default '',
		  PRIMARY KEY  (`id`)
		) ");

		execute_sql("CREATE TABLE `{$CFG->prefix}gismo_concept_assignment` (
		  `id` int(10) unsigned NOT NULL auto_increment,
		  `assignment_id` int(11) NOT NULL default '0',
		  `concept_id` int(11) NOT NULL default '0',
		  `relevance` int(11) NOT NULL default '10',
		  PRIMARY KEY  (`id`),
		  KEY `assignment_id` (`assignment_id`),
		  KEY `concept_id` (`concept_id`)
		) ");

		execute_sql("CREATE TABLE `{$CFG->prefix}gismo_concept_quiz` (
		  `id` int(10) unsigned NOT NULL auto_increment,
		  `quiz_id` int(11) NOT NULL default '0',
		  `concept_id` int(11) NOT NULL default '0',
		  `relevance` int(11) NOT NULL default '10',
		  PRIMARY KEY  (`id`),
		  KEY `quiz_id` (`quiz_id`),
		  KEY `concept_id` (`concept_id`)
		) ");

		execute_sql("CREATE TABLE `{$CFG->prefix}gismo_concept_resource` (
		  `id` int(10) unsigned NOT NULL auto_increment,
		  `concept_id` int(10) unsigned NOT NULL default '0',
		  `resource_id` int(10) unsigned NOT NULL default '0',
		  `relevance` int(11) NOT NULL default '10',
		  PRIMARY KEY  (`id`),
		  KEY `concept_id` (`concept_id`),
		  KEY `resource_id` (`resource_id`)
		) ");

        $result = true; //Nothing to do
    }

    //Finally, return result
    return $result;
}
