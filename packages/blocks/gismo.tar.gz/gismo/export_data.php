<?PHP // $Id: export_data.php,v 1.1 2004/08/26 15:23:05

require_once("../../config.php");
print_header("GISMO Exporter", "",build_navigation("GISMO Exporter"), "", "", true, '','');

$prefix = $CFG->prefix;

function getMaxStudentID(){
	global $db,$prefix;
	
	$query = "SELECT MAX(id) as id, MAX(id) as aid FROM ".$prefix."user WHERE ".$prefix."user.deleted = 0";   
	$result =  get_record_sql($query);	
	if(isset($result->id))
		return $result->id;
	else
		return 0;      
}

function getMaxCourseID(){
	global $db,$prefix;
	
	$query = "SELECT MAX(id) as id,MAX(id) as aid  from ".$prefix."course";
	
	$result =  get_record_sql($query);
	
	if(isset($result->id))
		return $result->id;
	else
		return 0;   
}

function getMaxResourcesID(){
	global $db,$prefix;
	
	$query = "SELECT MAX(id) as id, MAX(id) as aid FROM ".$prefix."resource";
	
	$result =  get_record_sql($query);
	
	if(isset($result->id))
		return $result->id;
	else
		return 0;
}

function getMaxStudentResourceDetailLogID(){
	global $db,$prefix;
	
	$query = "SELECT MAX(log_id) as id, MAX(log_id) as aid from ".$prefix."gismo_chart_student_resource_detail";
	
	$result =  get_record_sql($query);
	
	if(isset($result->id))
		return $result->id;
	else
		return 0;
}

function date_correction($data){	
	
	$ore = (int) strftime("%H",$data);
	$minuti = (int) strftime("%M",$data);
	$secondi = (int) strftime("%S",$data);
	
	$cdata = $data - ($ore * 3600 + $minuti * 60 + $secondi);
	
	return $cdata;
}

function export_table_ChartStudentResourceDetail(){
	global $db,$prefix;

	$maxLogID = getMaxLogID();
	
	$minLogID = getMaxStudentResourceDetailLogID();
	$delta = 100;
	
	if(($maxLogID - $minLogID)<100){
		$delta = $maxLogID - $minLogID;
	}

	while($minLogID < $maxLogID){	
		$query = "SELECT  ".$prefix."log.id,".$prefix."log.info, ".$prefix."log.userid, ".$prefix."log.time FROM ".$prefix."log, ".$prefix."user WHERE ".$prefix."log.module  = 'resource' AND ".$prefix."log.action='view' AND ".$prefix."log.userid = ".$prefix."user.id and ".$prefix."user.deleted = 0 and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.id ORDER BY ".$prefix."log.id";
		
		$log=array();
		$resultLog =  get_records_sql($query);
		$fields=array("id","userid","time","info");
		if(is_array($resultLog)){
			foreach($resultLog as $row){
				$line=array();
				foreach($fields as $field){
					$line["$field"]=$row->$field;
				}
				$log[]=$line;
			}
		}
		if(count($log)!=0){  
		
			$query = "SELECT log_id, MAX(time) as time ,student_id,resource_id from ".$prefix."gismo_chart_student_resource_detail group by student_id, resource_id order by time";			
			$result =  get_records_sql($query);  
			if(is_array($result)){
				foreach($result as $row){   
					if(isset($row->time)){
						$students[$row->student_id][$row->resource_id] = $row->time; 
					} 
				}   
			}
	
			$count = count($log);
			for($i = 0 ; $i<$count;$i++){
				$element=$log[$i];
				$logid=$element["id"];
				$userid=$element["userid"];
				$time=$element["time"];
				$resourceid=$element["info"];
		
				$newTime=date_correction($time);
				if(isset($students[$userid][$resourceid])){
				}
				else{
				   $students[$userid][$resourceid]=0;
				}
				
				if($students[$userid][$resourceid]<$newTime){
					$students[$userid][$resourceid]=$newTime;
					$query = "INSERT INTO ".$prefix."gismo_chart_student_resource_detail (log_id,resource_id,student_id,time,view_count) values (".$logid.",".$resourceid.",".$userid.",".$students[$userid][$resourceid].",1)";
					execute_sql($query,false);
				}else{
					$query = "UPDATE ".$prefix."gismo_chart_student_resource_detail set view_count = view_count+1, log_id=".$logid." where student_id = ".$userid." and resource_id = ".$resourceid." and time = ".$students[$userid][$resourceid];
					execute_sql($query,false);
				}
			}
		}	
		$minLogID += $delta;	
		if($minLogID>$maxLogID){
			$minLogID -= $delta;
			if($minLogID < 0)
				$minLogID = 0;
			$delta = $maxLogID - $minLogID;	
		}	
	}
}

function getLastChartLoginAccessOverview(){
	global $db,$prefix;
	
	$query = "SELECT MAX(log_id) as id, MAX(log_id) as aid  from ".$prefix."gismo_chart_login_access_overview";
	
	$result =  get_record_sql($query);
	if(isset($result->id))
		return $result->id;
	else
		return 0;  
}

function getMaxLogID(){
	global $db,$prefix;
	
	$query = "SELECT MAX(id) as id, MAX(id) as aid from ".$prefix."log";
	
	$result =  get_record_sql($query);
	
	if(isset($result->id))
		return $result->id;
	else
		return 0;
}

function export_table_ChartLoginAccessOverview(){
	global $db,$prefix; 

	$maxLogID = getMaxLogID();
	$minLogID = getLastChartLoginAccessOverview();
	
	$delta = 100;
	if(($maxLogID - $minLogID)<100){
		$delta = $maxLogID - $minLogID;
	}

	while($minLogID < $maxLogID){ 
		$query = "select ".$prefix."log.id as id,".$prefix."log.course as course,".$prefix."log.userid as userid,".$prefix."log.time as time FROM ".$prefix."log,".$prefix."user WHERE ".$prefix."log.action like '%view%' and ".$prefix."user.id = ".$prefix."log.userid and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.course,".$prefix."log.userid,".$prefix."log.time"; 
	
		$log=array();
		$resultLog =  get_records_sql($query);
		$fields=array("id","course","userid","time");
		
		if(is_array($resultLog)){
			foreach($resultLog as $row){
				$line=array();
				foreach($fields as $field){			   
					$line["$field"]=$row->$field;
				}
				$log[]=$line;			
			}
		}
		
		if(count($log)!=0){			
			$query = "SELECT log_id, MAX(time) as time ,student_id,course_id from ".$prefix."gismo_chart_login_access_overview group by student_id, course_id order by time";
			$result =  get_records_sql($query); 
			if(is_array($result)){
			   foreach($result as $row){   
				  if(isset($row->time)){
					 $students[$row->student_id][$row->course_id] = $row->time; 
				  } 
			   }   
			}		 
			$count = count($log);
			for($i = 0 ; $i<$count;$i++){	
				$element=$log["$i"];
				$logid=$element["id"];
				$userid=$element["userid"];
				$time=$element["time"];
				$courseid=$element["course"];
				
				$newTime=date_correction($time);
				if(isset($students[$userid][$courseid])){
				   //print("IS SET <br>");
				}
				else{
					$students[$userid][$courseid]=0;
					//print("IS NOT SET <br>");
				}
				if($students[$userid][$courseid]<$newTime){
					$students[$userid][$courseid]=$newTime;			
					$query = "INSERT INTO ".$prefix."gismo_chart_login_access_overview (log_id,course_id,student_id,time) values (".$logid.",".$courseid.",".$userid.",".$students[$userid][$courseid].")";
					execute_sql($query,false);
				}
			}
		}
				
		$minLogID += $delta;
		if($minLogID>$maxLogID){
			$minLogID -= $delta;
			if($minLogID < 0)
				$minLogID = 0;
			$delta = $maxLogID - $minLogID;
		}			
		
	}
}   

function getDiscussionOverviewWrite(){
	global $db,$prefix; 
	
	$query= "SELECT ".$prefix."forum_posts.id*".$prefix."forum_posts.userid*".$prefix."forum_discussions.course*rand(),".$prefix."forum_posts.id, ".$prefix."forum_posts.userid, ".$prefix."forum_posts.discussion, ".$prefix."forum_discussions.course FROM ".$prefix."forum_posts, ".$prefix."user, ".$prefix."forum_discussions WHERE ".$prefix."user.id = ".$prefix."forum_posts.userid and ".$prefix."forum_posts.discussion = ".$prefix."forum_discussions.id GROUP BY ".$prefix."forum_posts.id,".$prefix."forum_posts.userid,discussion,".$prefix."forum_discussions.course";
	
	$result = get_records_sql($query);
	if (!$result)
		return array();

	return $result;	
}

function getLastChartDiscussionOverviewRead(){
	global $db,$prefix;
	
	$query = "SELECT MAX(id) as id, MAX(id) as aid from ".$prefix."gismo_chart_discussion_read";
	  
	$result =  get_record_sql($query);
	
	if(isset($result->id))
		return $result->id;
	else
		return 0;
}

function getDiscussionOverviewRead($minLogID,$delta){
	global $db,$prefix; 

	$query= "SELECT ".$prefix."log.id, ".$prefix."log.userid, ".$prefix."log.course, ".$prefix."log.time FROM ".$prefix."log, ".$prefix."user WHERE ".$prefix."log.action='view discussion' and ".$prefix."log.userid=".$prefix."user.id and ".$prefix."user.deleted = 0 and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.id";

	$log=array();
	$resultLog =  get_records_sql($query);
	 $fields=array("id","userid","course","time");
	
	if(is_array($resultLog)){
		foreach($resultLog as $row){
			$line=array();
			foreach($fields as $field){			   
				$line["$field"]=$row->$field;
			}
			$log[]=$line;			
		}
	}
	
	return $log;
}

function getDiscussionOverviewThread(){
	global $db,$prefix; 
	$query = "SELECT ".$prefix."forum_discussions.id as id, ".$prefix."forum_discussions.timemodified as timemodified, ".$prefix."forum_discussions.userid as userid, ".$prefix."forum_discussions.course as course FROM ".$prefix."forum_discussions, ".$prefix."user WHERE ".$prefix."user.id = ".$prefix."forum_discussions.userid  GROUP BY ".$prefix."forum_discussions.id";
	
	$result = get_records_sql($query);
	if (!$result)
		return array();
	return $result;	
   
}




function export_table_ChartDiscussionOverviewWrite(){
	global $db,$prefix; 
	
	$students = getMaxStudentID();
	$courses =  getMaxCourseID();
		
	$write;
	$logid;
	
	$writeDiscussion = getDiscussionOverviewWrite();  

	foreach($writeDiscussion as $row){
		if(isset($write[$row->userid][$row->course]))
			$write[$row->userid][$row->course] = $write[$row->userid][$row->course]+1;
		else
			$write[$row->userid][$row->course] = 1;
		
		$logid[$row->userid][$row->course]=$row->id;
		$value= $write[$row->userid][$row->course];
		$user= $row->userid;
		$course= $row->course;
		$log=$logid[$row->userid][$row->course];
	}
	
	//Clear all gismo_chart_discussion_write table
	$clearQuery = "delete from ".$prefix."gismo_chart_discussion_write";
	execute_sql($clearQuery,false);
	
	
	for($i=0;$i<=$students;$i++){
		for($j=0;$j<=$courses;$j++){
			if(isset($write[$i][$j])){
				$query="INSERT into ".$prefix."gismo_chart_discussion_write (id,course_id,student_id,count) values (".$logid[$i][$j].",".$j.",".$i.",".$write[$i][$j].")";
				execute_sql($query,false);
			
			}
		}
	}
}


function export_table_ChartDiscussionOverviewRead(){
	global $db,$prefix; 
	
	$maxLogID = getMaxLogID();	
	$minLogID =  getLastChartDiscussionOverviewRead();
	
	$delta = 100;
	$students;
	while($minLogID < $maxLogID){ 	
		
		$readDiscussion  = getDiscussionOverviewRead($minLogID,$delta);	
		
		if(count($readDiscussion)!=0){ 
			if(!isset($students)){	
				$query = "SELECT id as aid, MAX(id) as id,student_id,course_id from ".$prefix."gismo_chart_discussion_read group by student_id, course_id order by id";
				$result =  get_records_sql($query); 
				if(is_array($result)){
				   foreach($result as $row){   
					  if(isset($row->id)){
						 $students[$row->student_id][$row->course_id] = $row->id; 
					  } 
				   }  				
				}   
			}
	
			$count = count($readDiscussion);
			
			for($i = 0 ; $i<$count;$i++){
				$element=$readDiscussion[$i];
				$logid=$element["id"];
				$userid=$element["userid"];
				$courseid=$element["course"];
	
				if(isset($students[$userid][$courseid])){
					//print("IS SET <br>");
					if($students[$userid][$courseid]<$logid){
						$students[$userid][$courseid]=$logid;
						$query = "UPDATE ".$prefix."gismo_chart_discussion_read set count = count+1, id=".$logid." where student_id = ".$userid." and course_id = ".$courseid;
				
						execute_sql($query,false);
					}					
				}
				else{
					$students[$userid][$courseid]=$logid;
					$query = "INSERT INTO ".$prefix."gismo_chart_discussion_read (id,course_id,student_id,count) values (".$logid.",".$courseid.",".$userid.",1)";
					execute_sql($query,false);
					// print("IS NOT SET <br>");
				}				
			}
		} 
			
		$minLogID = $minLogID + $delta;
		if($minLogID>$maxLogID){
			$minLogID = $minLogID - $delta;
			$delta = $maxLogID - $minLogID;		
		}
	//unset($students);
	}
	
}

function export_table_ChartDiscussionOverviewThread(){
	global $db,$prefix; 
	
	$threadDiscussion = getDiscussionOverviewThread();
	$logid;
	$thread;
	
	foreach($threadDiscussion as $row){	
		if(isset($thread[$row->userid][$row->course]))
			$thread[$row->userid][$row->course] = $thread[$row->userid][$row->course]+1;
		else
			$thread[$row->userid][$row->course]=1;
		
		$logid[$row->userid][$row->course]=$row->id;
		$value= $thread[$row->userid][$row->course];
		$user= $row->userid;
		$course= $row->course;
		$log=$logid[$row->userid][$row->course];
		  
	}
	
	//Clear all gismo_chart_discussion_thread table
	$clearQuery = "delete from ".$prefix."gismo_chart_discussion_thread";
	execute_sql($clearQuery,false);
	
	
	$students = getMaxStudentID();
	$courses =  getMaxCourseID();
	
	for($i=0;$i<=$students;$i++){
		for($j=0;$j<=$courses;$j++){
			if(isset($thread[$i][$j])){
				$query="INSERT into ".$prefix."gismo_chart_discussion_thread (id,course_id,student_id,count) values (".$logid[$i][$j].",".$j.",".$i.",".$thread[$i][$j].")";
				execute_sql($query,false);
			
			}
		}
	}
}

print("<h1>Starting Exporting</h1><p>");
print("<h1>Start Exporting Table Chart Student Resource Detail</h1><p>");
export_table_ChartStudentResourceDetail();
print("<h1>Finished Exporting Table Chart Student Resource Detail</h1><p>");

print("<h1>Start Exporting Table Chart Login Access Overview</h1><p>");
export_table_ChartLoginAccessOverview(); 
print("<h1>Finished Exporting Table Chart Login Access Overview</h1><p>");

print("<h1>Start Exporting Table Chart Discussion Overview Write</h1><p>");
export_table_ChartDiscussionOverviewWrite();
print("<h1>Finished Exporting Table Chart Discussion Overview Write</h1><p>");

print("<h1>Start Exporting Table Chart Discussion Overview Read</h1><p>");
export_table_ChartDiscussionOverviewRead();
print("<h1>Finished Exporting Table Chart Discussion Overview Read</h1><p>");

print("<h1>Start Exporting Table Chart Discussion Overview Thread</h1><p>");
export_table_ChartDiscussionOverviewThread();
print("<h1>Finished Exporting Table Chart Discussion Overview Thread</h1><p>");

print("<h1>Finished Exporting</h1>");

?>
