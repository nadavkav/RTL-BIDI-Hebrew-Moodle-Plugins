-------------------------------------------------------------------------------
File:     README.TXT 
Version:  1.1 
Last Modified:     17.09.04
-------------------------------------------------------------------------------

Installation instruction:
1) unzip gismo.zip in the blocks directory in moodlehome
2) go to the admin page in your moodle site
   for example: http://example.com/moodle/admin
   it will install GISMO block

3) set up a cron for the export of the data
 
File name: export_data.php

This block require continual checks to export data.

Note that the machine performing the cron does not need to be the same machine that is running Moodle. For example, if you have a limited web hosting service that does not have a cron service, then you can might choose to run cron on another server or on your home computer. All that matters is that the file is called regularly.

The load of this script is high the first time depending on the size of your DB. From the second time on it will take less time but it better if you run it during the night. Running 1 time a day the script is usually reasonable. 

The first time test that the script works by running it directly from your browser:

http://example.com/moodle/blocks/gismo/export_data.php

Now, you need to set up some of way of running the script automatically and regularly.

On Windows systems

    The simplest way is to use this little package moodle-cron-for-windows.zip which makes this whole thing very easy by installing a small Windows service. Run it and forget about it!

On web hosting services

    Your web-based control panel may have a web page that allows you to set up this cron process. For example, on Cpanel system, look for a button called "Cron jobs". In there you can put the same sort of Unix commands as listed below.

Using the command line on Unix

    There are different command line programs you can use to call the page from the command line. Not all of them may be available on a given server.

    For example, you can use a Unix utility like 'wget':

wget -q -O /dev/null http://example.com/moodle/admin/cron.php

    Note in this example that the output is thrown away (to /dev/null).

    The same thing using lynx:

lynx -dump http://example.com/moodle/blocks/gismo/export_data.php > /dev/null

    Alternatively you could use a standalone version of PHP, compiled to be run on the command line. The advantage with doing this is that your web server logs aren't filled with constant requests to cron.php. The disadvantage is that you need to have access to a command-line version of php.

/opt/bin/php /web/moodle/blocks/gismo/export_data.php

    

Using the crontab program on Unix

    All that Cpanel does is provide a web interface to a Unix utility known as crontab. If you have a command line, you can set up crontab yourself using the command:

crontab -e

    and then adding one of the above commands like:

0 1 * * * wget -q -O /dev/null http://example.com/moodle/blocks/gismo/export_data.php

    Usually, the "crontab" command will put you into the 'vi' editor. You enter "insert mode" by pressing "i", then type in the line as above, then exit insert mode by pressing ESC. You save and exit by typing ":wq", or quit without saving using ":q!" (without the quotes).

4) Enjoy it
