<?PHP // $Id: retrive_data.php,v 1.3 2005/09/25 11:23:00

require_once("../../config.php");
$action = $_GET["action"];
optional_variable($course);    // Course Module ID, or
$courseid = $_GET['course'];
require_login($courseid);

if (! $course = get_record("course", "id", $courseid)) {
            error("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><result><p>Course is misconfigured</p></result>");
}

if (isteacher($course->id) || isadmin()){
	$course = $courseid;
	$prefix = $CFG->prefix;
	
	if (is_numeric($course)) { //is course variable a number?
		
		
		/***************************
		GENERAL COURSE INFORMATIONS
		***************************/
		
		if($action == "get_course_start_date"){ //retrive course start date
			$query = "SELECT id as id, startdate as t from ".$prefix."course where id =".$course;
			
			$result =  get_records_sql($query);
			
			print_xml_values($result,array("id","t"));
			
		}else if($action == "get_course_name"){ //retrive course name
			
			$query = "SELECT fullname as n from ".$prefix."course where id = ".$course;
			
			$result =  get_records_sql($query);
			
			print_xml_values($result,array("n"));
			
		}
		
		/***************************
		LISTS INFORMATIONS
		***************************/		
		else if($action == "get_student_list"){ //retrive student data
		
			$query="SELECT ".$prefix."user.id as id, ".$prefix."user.username as sun, ".$prefix."user.firstname as sfn, ".$prefix."user.lastname  as sln FROM ".$prefix."user, ".$prefix."user_students WHERE ".$prefix."user.deleted = 0 AND ".$prefix."user.id = ".$prefix."user_students.userid and ".$prefix."user_students.course=".$course." GROUP BY ".$prefix."user.id ORDER BY sun ASC";
			
			$result =  get_records_sql($query);
			
			print_xml_values($result,array("id","sun","sfn","sln"));
			
		}else if($action == "get_resource_list"){ //retrive resource data
			$query= "SELECT ".$prefix."resource.id as id, ".$prefix."resource.name as n  FROM ".$prefix."resource WHERE ".$prefix."resource.course=".$course;
																					  
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","n"));
			
		}else if($action == "get_group_list"){ //retrive groups data
			$query =  "SELECT ".$prefix."groups.id as id, ".$prefix."groups.name as n FROM ".$prefix."groups WHERE ".$prefix."groups.courseid=".$course." ORDER BY n ASC" ;
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","n"));
		
		}else if($action == "get_student_group_list"){ //retrive students in groups data
			$query = "SELECT ".$prefix."groups_members.id,".$prefix."groups_members.groupid as gid, ".$prefix."groups_members.userid as sid FROM ".$prefix."groups, ".$prefix."groups_members, ".$prefix."user_students, ".$prefix."user WHERE ".$prefix."groups_members.userid = ".$prefix."user_students.userid AND ".$prefix."user.id = ".$prefix."user_students.userid AND ".$prefix."user.deleted = 0 and ".$prefix."groups.courseid=".$course." and ".$prefix."groups.id = ".$prefix."groups_members.groupid GROUP BY sid,gid";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("sid","gid"));
		
		}else if($action == "get_forum_list"){ //retrive forums
			$query = "SELECT id, name as n from ".$prefix."forum where course = ".$course;
			
			$result =  get_records_sql($query);
			
			print_xml_values($result,array("id","n"));
		
		}else if($action == "get_quiz_list"){ //retrive quiz data
			$query= "SELECT ".$prefix."quiz.id as id, ".$prefix."quiz.name as n, ".$prefix."quiz.timeopen as tio, ".$prefix."quiz.timeclose as tic, ".$prefix."quiz.sumgrades as sg , ".$prefix."quiz.grade as g FROM ".$prefix."quiz WHERE ".$prefix."quiz.course=".$course;
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","n","tio","tic","sg","g"));
		
		}else if($action == "get_assignment_list"){ //retrive assignment data
			$query= "SELECT ".$prefix."assignment.id as id, ".$prefix."assignment.name as n, ".$prefix."assignment.timedue as tic, ".$prefix."assignment.grade as g FROM ".$prefix."assignment WHERE ".$prefix."assignment.course=".$course." ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","n","tic","g"));
			
		}else if($action == "get_concept_list"){ //retrive concept data
			  //with this query only 1 domain per concept because the get_records_sql takes id as index value...
			
			$query="SELECT ".$prefix."gismo_concept.id as cid, ".$prefix."gismo_concept.name as cn  FROM ".$prefix."gismo_concept  WHERE ".$prefix."gismo_concept.course_id=".$course." ORDER BY ".$prefix."gismo_concept.id ASC";
			//print($query);
			
			$result =  get_records_sql($query);
			
			print_xml_values($result,array("cid","cn"));
		
		}
		
		
		/***************************
		FORUM INFORMATIONS
		***************************/
		
		else if($action == "get_discussion_post_count"){ //retrive resource data
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"student_id");
			
			$query = "select ".$prefix."gismo_chart_discussion_write.student_id as id,count as pc from ".$prefix."gismo_chart_discussion_write, ".$prefix."user_students where ".$prefix."gismo_chart_discussion_write.course_id =".$course." and ".$prefix."gismo_chart_discussion_write.student_id = ".$prefix."user_students.userid and ".$prefix."gismo_chart_discussion_write.course_id = ".$prefix."user_students.course and ($whereClause) group by id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","pc"));
			
		}else if($action == "get_discussion_thread_count"){ //retrive thread count per student
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"student_id");
			
			$query = "select ".$prefix."gismo_chart_discussion_thread.student_id as id,count as tc from ".$prefix."gismo_chart_discussion_thread,".$prefix."user_students where ".$prefix."gismo_chart_discussion_thread.course_id =".$course." and ".$prefix."gismo_chart_discussion_thread.student_id = ".$prefix."user_students.userid and ".$prefix."gismo_chart_discussion_thread.course_id = ".$prefix."user_students.course and ($whereClause) group by id";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","tc"));
			
		}else if($action == "get_discussion_read_count"){ //retrive read count per student
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"student_id");
			
			$query = "select ".$prefix."gismo_chart_discussion_read.student_id as id,count as rc from ".$prefix."gismo_chart_discussion_read,".$prefix."user_students where ".$prefix."gismo_chart_discussion_read.course_id =".$course." and ".$prefix."gismo_chart_discussion_read.student_id = ".$prefix."user_students.userid and ".$prefix."gismo_chart_discussion_read.course_id = ".$prefix."user_students.course and ($whereClause) group by id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","rc"));
		
		}
		
		/***************************
		STUDENT-RESOURCES INFORMATIONS
		***************************/
		
		else if($action == "get_student_resource_hits"){ //retrive resource hits per student
			
			$listComma = $_GET["studentList"];
			
			$list = explode(',',$listComma);
			
			$whereStudentClause = createWhereList($list,"student_id");
			
			$listComma = $_GET["resourceList"];
			
			$list = explode(',',$listComma);
			
			$whereResourceClause = createWhereList($list,"resource_id");
			
			$query = "select ".$prefix."gismo_chart_student_resource_detail.student_id as id,  SUM(view_count) as h  from ".$prefix."gismo_chart_student_resource_detail, ".$prefix."user_students, ".$prefix."resource where ".$prefix."user_students.course =".$course." and ".$prefix."gismo_chart_student_resource_detail.student_id = ".$prefix."user_students.userid and ".$prefix."gismo_chart_student_resource_detail.resource_id = ".$prefix."resource.id and  ".$prefix."resource.course = ".$course." and ($whereStudentClause) and ($whereResourceClause) group by id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","h"));
			
		}else if($action == "get_resource_student_hits"){ //retrive student hits by resources
			
			$listComma = $_GET["studentList"];
			
			$list = explode(',',$listComma);
			
			$whereStudentClause = createWhereList($list,"student_id");
			
			$listComma = $_GET["resourceList"];
			
			$list = explode(',',$listComma);
			
			$whereResourceClause = createWhereList($list,"resource_id");
			
			$query = "select ".$prefix."gismo_chart_student_resource_detail.resource_id as id,  SUM(view_count) as h  from ".$prefix."gismo_chart_student_resource_detail, ".$prefix."user_students, ".$prefix."resource where ".$prefix."user_students.course =".$course." and ".$prefix."gismo_chart_student_resource_detail.student_id = ".$prefix."user_students.userid and ".$prefix."gismo_chart_student_resource_detail.resource_id = ".$prefix."resource.id and  ".$prefix."resource.course = ".$course." and ($whereStudentClause) and ($whereResourceClause) group by id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","h"));
			
		}else if($action == "get_student_detail_access"){ //retrive detail per student
			$student= $_GET["student"];
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"resource_id");
			
			$query = " select ".$prefix."gismo_chart_student_resource_detail.log_id, resource_id as id, ".$prefix."gismo_chart_student_resource_detail.time as t from ".$prefix."gismo_chart_student_resource_detail,".$prefix."user_students, ".$prefix."resource where ".$prefix."gismo_chart_student_resource_detail.student_id = ".$student." and ".$prefix."user_students.userid = ".$student." and ".$prefix."user_students.course = ".$course." and ".$prefix."resource.course = ".$course." and ".$prefix."resource.id = resource_id and ($whereClause) group by id,t";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("t","id"));
			
		}else if($action == "get_student_detail_access_day_count"){ //retrive student detail access count per day
			$student= $_GET["student"];
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"resource_id");
			
			$query = " select ".$prefix."gismo_chart_student_resource_detail.time as t, SUM(view_count) as c from ".$prefix."gismo_chart_student_resource_detail,".$prefix."user_students, ".$prefix."resource where ".$prefix."gismo_chart_student_resource_detail.student_id = ".$student." and ".$prefix."user_students.userid = ".$student." and ".$prefix."user_students.course = ".$course." and ".$prefix."resource.course = ".$course." and ".$prefix."resource.id = resource_id and ($whereClause) group by t";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("t","c"));
			
		}else if($action == "get_resource_detail_access"){ //retrive detail per student
			$resource= $_GET["resource"];
			
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereStudentClause = createWhereList($list,"student_id");
			
			
			$query = " select ".$prefix."gismo_chart_student_resource_detail.log_id, student_id as id, ".$prefix."gismo_chart_student_resource_detail.time as t from ".$prefix."gismo_chart_student_resource_detail,".$prefix."user_students, ".$prefix."resource where ".$prefix."gismo_chart_student_resource_detail.resource_id = ".$resource." and ".$prefix."user_students.course = ".$course." and ".$prefix."user_students.course = ".$course." and ".$prefix."resource.course = ".$course." and ".$prefix."resource.id = resource_id and ($whereStudentClause) group by id,t";
			
			$result =  get_records_sql($query);
			//print("<pre>");print_r($result);print("</pre>");                                                                              
			print_xml_values($result,array("t","id"));
			
		}else if($action == "get_resource_detail_access_day_count"){ //retrive detail per student
			$resource= $_GET["resource"];
			
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereStudentClause = createWhereList($list,"student_id");
			
			$query = " select ".$prefix."gismo_chart_student_resource_detail.time as t , SUM(view_count) as c from ".$prefix."gismo_chart_student_resource_detail,".$prefix."user_students, ".$prefix."resource where ".$prefix."user_students.course = ".$course." and ".$prefix."gismo_chart_student_resource_detail.resource_id = ".$resource." and ".$prefix."user_students.course = ".$course." and ".$prefix."resource.course = ".$course." and ".$prefix."resource.id = ".$resource." and ".$prefix."gismo_chart_student_resource_detail.student_id = ".$prefix."user_students.userid and($whereStudentClause) group by t";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("t","c"));
		
		}else if($action == "get_student_resource"){ //retrive detail per student
			$resourceListTemp= $_GET["resourcelist"];
			$studentListTemp = $_GET["studentlist"];
			
			$studentList = explode(',',$studentListTemp);
			$whereStudentClause = createWhereList($studentList,"student_id");
			
			$resourceList = explode(',',$resourceListTemp);
			$whereResourceClause = createWhereList($resourceList,"resource_id");
			
			 $query = "SELECT log_id, student_id AS s, resource_id AS r, SUM(view_count) AS c FROM ".$prefix."gismo_chart_student_resource_detail WHERE ($whereStudentClause) AND ($whereResourceClause) GROUP BY student_id,resource_id ";
			
			$result =  get_records_sql($query);
			//print("<pre>");print_r($result);print("</pre>");
			print_xml_values($result,array("s","r","c"));
			
		}
		
		
		/***************************
		STUDENT LOGIN INFORMATIONS
		***************************/		
		else if($action == "get_student_login_count"){ //retrive login count per student
			
			$query = "select ".$prefix."gismo_chart_login_access_overview.student_id as id, count(student_id) as c from ".$prefix."gismo_chart_login_access_overview, ".$prefix."user_students where ".$prefix."user_students.course =".$course." and ".$prefix."gismo_chart_login_access_overview.course_id = ".$prefix."user_students.course and ".$prefix."gismo_chart_login_access_overview.student_id = ".$prefix."user_students.userid group by id";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","c"));
			
		}else if($action == "get_day_login_count"){ //retrive day login count per date
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"student_id");
			
			$query = "select ".$prefix."gismo_chart_login_access_overview.time as t, count(".$prefix."gismo_chart_login_access_overview.time) as c from ".$prefix."gismo_chart_login_access_overview,".$prefix."user_students where ".$prefix."user_students.course =".$course." and ".$prefix."gismo_chart_login_access_overview.course_id = ".$prefix."user_students.course and ".$prefix."gismo_chart_login_access_overview.student_id = ".$prefix."user_students.userid and ($whereClause)  group by t";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("t","c"));
			
		}else if($action == "get_student_login_access"){ //retrive login access per student
			
			$listComma = $_GET["list"];
			
			$list = explode(',',$listComma);
			
			$whereClause = createWhereList($list,"student_id");
			
			$query = "select ".$prefix."gismo_chart_login_access_overview.log_id,".$prefix."gismo_chart_login_access_overview.student_id as id, ".$prefix."gismo_chart_login_access_overview.time as t from ".$prefix."gismo_chart_login_access_overview, ".$prefix."user_students  where  ".$prefix."user_students.course =".$course." and ".$prefix."gismo_chart_login_access_overview.course_id = ".$prefix."user_students.course and ".$prefix."gismo_chart_login_access_overview.student_id = ".$prefix."user_students.userid  and ($whereClause) group by t,id";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("t","id"));
		
		}
		
		/***************************
		QUIZ INFORMATIONS
		***************************/
		
		else if($action == "get_quiz_list_submissions_count"){ //retrive quiz data submissions count
			
			$query= "SELECT ".$prefix."quiz.id as id,
			COUNT(".$prefix."quiz_attempts.id) as c
			FROM 
			".$prefix."quiz,
			".$prefix."quiz_attempts 
			WHERE 
			".$prefix."quiz.course=".$course." and ".$prefix."quiz_attempts.quiz=".$prefix."quiz.id GROUP BY id ORDER BY id";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","c"));
			
		}else if($action == "get_quiz_list_submissions"){ //retrive quiz data submissions
			
			$studentListTemp = $_GET["studentlist"];
			$quizListTemp = $_GET["quizlist"];
			
			$studentList = explode(',',$studentListTemp);
			$quizList = explode(',',$quizListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			$whereQuizClause = createWhereList($quizList,"quiz");
			
			$query= "SELECT ".$prefix."quiz_attempts.id as id, ".$prefix."quiz_attempts.quiz as qid, ".$prefix."quiz_attempts.userid as uid, ".$prefix."quiz_attempts.sumgrades as sg, ".$prefix."quiz_attempts.timestart as ts, ".$prefix."quiz_attempts.timefinish as tf, ".$prefix."quiz_attempts.attempt as aid
			FROM 
			".$prefix."quiz,
			".$prefix."quiz_attempts 
			WHERE 
			".$prefix."quiz.course=".$course." and ".$prefix."quiz_attempts.quiz=".$prefix."quiz.id and ($whereStudentClause) and ($whereQuizClause) GROUP BY id ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","qid","uid","sg","ts","tf","aid"));
			
		}else if($action == "get_quiz_list_submissions_final_grade"){ //retrive quiz data submissions graded
			
			$studentListTemp = $_GET["studentlist"];
			$quizListTemp = $_GET["quizlist"];
			
			$studentList = explode(',',$studentListTemp);
			$quizList = explode(',',$quizListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			$whereQuizClause = createWhereList($quizList,"quiz");
			
			$query= "SELECT ".$prefix."quiz_grades.id as id, ".$prefix."quiz_grades.quiz as qid, ".$prefix."quiz_grades.userid as uid, ".$prefix."quiz_grades.grade as g, ".$prefix."quiz_grades.timemodified as tm
			FROM 
			".$prefix."quiz,
			".$prefix."quiz_grades 
			WHERE 
			".$prefix."quiz.course=".$course." and ".$prefix."quiz_grades.quiz=".$prefix."quiz.id and ($whereStudentClause) and ($whereQuizClause) GROUP BY id ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","qid","uid","g","tm"));
		
		}else if($action == "get_quiz_list_submissions_final_grade_time"){ //retrive quiz data submissions graded
			
			$studentListTemp = $_GET["studentlist"];
			$quizListTemp = $_GET["quizlist"];
			
			$studentList = explode(',',$studentListTemp);
			$quizList = explode(',',$quizListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			$whereQuizClause = createWhereList($quizList,"quiz");
			
			$query= "SELECT ".$prefix."quiz_attempts.id as id, ".$prefix."quiz_attempts.quiz as qid, ".$prefix."quiz_attempts.userid as uid, ".$prefix."quiz_attempts.timemodified as tm
			FROM 
			".$prefix."quiz,
			".$prefix."quiz_attempts 
			WHERE 
			".$prefix."quiz.course=".$course." and ".$prefix."quiz_attempts.quiz=".$prefix."quiz.id and ($whereStudentClause) and ($whereQuizClause) GROUP BY uid,qid ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","qid","uid","tm"));
		
		}else if($action == "get_quiz_submissions_by_id"){ //retrive quiz data submissions graded
			
			$studentListTemp = $_GET["studentlist"];
			$quizID = $_GET["quiz"];
			
			$studentList = explode(',',$studentListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			
			$query= "SELECT ".$prefix."quiz_grades.id as id, ".$prefix."quiz_grades.userid as uid, ".$prefix."quiz_grades.grade as g
			FROM 
			".$prefix."quiz,
			".$prefix."quiz_grades 
			WHERE 
			".$prefix."quiz.course=".$course." and ".$prefix."quiz_grades.quiz=".$prefix."quiz.id and ($whereStudentClause) and ".$prefix."quiz_grades.quiz=".$quizID."  GROUP BY id ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","uid","g"));
		
		}
		
		/***************************
		ASSIGNMENT INFORMATIONS
		***************************/
		
		else if($action == "get_assignment_list_start_date"){ //retrive assignment data start date
			$query= "SELECT ".$prefix."log.info as id, ".$prefix."log.time as tio FROM ".$prefix."log WHERE ".$prefix."log.course=".$course." and ".$prefix."log.module='assignment' and ".$prefix."log.action='add' ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","tio"));
			
		}else if($action == "get_assignment_list_submissions_count"){ //retrive assignment data start date
			
			$query= "SELECT ".$prefix."assignment.id as id,
			COUNT(".$prefix."assignment_submissions.id) as c
			FROM 
			".$prefix."assignment,
			".$prefix."assignment_submissions 
			WHERE 
			".$prefix."assignment.course=".$course." and ".$prefix."assignment_submissions.assignment=".$prefix."assignment.id GROUP BY id ORDER BY id";
			
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","c"));
		
		}else if($action == "get_assignment_list_submissions"){ //retrive assignment data submissions
			
			$studentListTemp = $_GET["studentlist"];
			$assignmentListTemp = $_GET["assignmentlist"];
			
			$studentList = explode(',',$studentListTemp);
			$assignmentList = explode(',',$assignmentListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			$whereAssignmentClause = createWhereList($assignmentList,"assignment");
			
			$query= "SELECT ".$prefix."assignment_submissions.id as id,
			".$prefix."assignment_submissions.userid as uid,
			".$prefix."assignment_submissions.assignment as aid,
			".$prefix."assignment_submissions.timemodified as tm, 
			".$prefix."assignment_submissions.grade as g
			FROM 
			".$prefix."assignment_submissions, 
			".$prefix."assignment 
			WHERE 
			 ".$prefix."assignment_submissions.timemodified!=0 and ".$prefix."assignment.course=".$course." and ".$prefix."assignment_submissions.assignment=".$prefix."assignment.id and ($whereStudentClause) and ($whereAssignmentClause) GROUP BY id ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","uid","aid","tm","g"));
			
		}else if($action == "get_scale"){ //retrive assignment scale value
			$scale = $_GET["scale"];
			
			$query= "SELECT ".$prefix."scale.id as id,
			".$prefix."scale.scale as s,
			".$prefix."scale.name as n
			FROM 
			".$prefix."scale
			WHERE 
			".$prefix."scale.courseid=".$course." and ".$prefix."scale.id=".$scale." ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","s","n"));
			
		}else if($action == "get_assignment_submissions_by_id"){ //retrive assignment details data submissions
			
			$studentListTemp = $_GET["studentlist"];
			$assignmentID = $_GET["assignment"];
			
			$studentList = explode(',',$studentListTemp);
			$whereStudentClause = createWhereList($studentList,"userid");
			
			$query= "SELECT ".$prefix."assignment_submissions.id as id,
			".$prefix."assignment_submissions.userid as uid,
			".$prefix."assignment_submissions.grade as g
			FROM 
			".$prefix."assignment_submissions, 
			".$prefix."assignment 
			WHERE 
			 ".$prefix."assignment_submissions.timemodified!=0 and ".$prefix."assignment.course=".$course." and ".$prefix."assignment_submissions.assignment=".$prefix."assignment.id and ($whereStudentClause) and ".$prefix."assignment_submissions.assignment = ".$assignmentID." GROUP BY id ORDER BY id";
			
			$result =  get_records_sql($query);
																							
			print_xml_values($result,array("id","uid","g"));
		
		}
		/***************************
		DOMAIN INFORMATIONS
		***************************/
		else if($action == "get_resource_concept"){ //retrive resource concept data
			
			$resourceListTemp = $_GET["resourcelist"];
			$conceptListTemp = $_GET["conceptlist"];
			
			$resourceList = explode(',',$resourceListTemp);
			$conceptList = explode(',',$conceptListTemp);
			
			$whereConceptClause = createWhereList($conceptList,"concept_id");
			$whereResourceClause = createWhereList($resourceList,"resource_id");
			
			$query= "SELECT ".$prefix."gismo_concept_resource.id as id,  ".$prefix."gismo_concept_resource.resource_id as rid, ".$prefix."gismo_concept_resource.concept_id as cid
			FROM 
			".$prefix."gismo_concept_resource 
			WHERE 
			($whereConceptClause) and ($whereResourceClause) GROUP BY cid,rid ORDER BY rid";
			
			$result =  get_records_sql($query);
																						
			print_xml_values($result,array("id","cid","rid"));
		
		}else if($action == "get_quiz_concept"){ //retrive quiz concept data
		
			$quizListTemp = $_GET["quizlist"];
			$conceptListTemp = $_GET["conceptlist"];
			
			$quizList = explode(',',$quizListTemp);
			$conceptList = explode(',',$conceptListTemp);
			
			$whereConceptClause = createWhereList($conceptList,"concept_id");
			$whereQuizClause = createWhereList($quizList,"quiz_id");
			
			$query= "SELECT ".$prefix."gismo_concept_quiz.id as id,  ".$prefix."gismo_concept_quiz.quiz_id as qid, ".$prefix."gismo_concept_quiz.concept_id as cid
			FROM 
			".$prefix."gismo_concept_quiz
			WHERE 
			($whereConceptClause) and ($whereQuizClause) GROUP BY cid,qid ORDER BY qid";
			
			$result =  get_records_sql($query);
																						
			print_xml_values($result,array("id","cid","qid"));
		
		}else if($action == "get_assignment_concept"){ //retrive assignment concept data
			
			$assignmentListTemp = $_GET["assignmentlist"];
			$conceptListTemp = $_GET["conceptlist"];
			
			$assignmentList = explode(',',$assignmentListTemp);
			$conceptList = explode(',',$conceptListTemp);
			
			$whereConceptClause = createWhereList($conceptList,"concept_id");
			$whereAssignmentClause = createWhereList($assignmentList,"assignment_id");
			
			$query= "SELECT ".$prefix."gismo_concept_assignment.id as id,  ".$prefix."gismo_concept_assignment.assignment_id as aid, ".$prefix."gismo_concept_assignment.concept_id as cid
			FROM 
			".$prefix."gismo_concept_assignment
			WHERE 
			($whereConceptClause) and ($whereAssignmentClause) GROUP BY cid,aid ORDER BY aid";
			
			$result =  get_records_sql($query);
																						
			print_xml_values($result,array("id","cid","aid"));
	
		}else{
			echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><result><p>action error</p></result>";
		}
	}else{
		echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><result><p>course error</p></result>";
	}

}
else{
 	echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><result><p>not allowed to see logs</p></result>";
}
function print_xml_values($result,$fields){
header("content-type:text/xml;charset=iso-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?><result>";

if(is_array($result)){
foreach($result as $row){

$out = "<r>";

foreach($fields as $field){	

$line=$row->$field;

$line= dirify($line);

$min = 0;
$max = 1;
while($max >$min){
$min = 0;
$max = 0;
for($i=0;$i<strlen($line);$i++){
  if($line[$i]==="<"){
     $min=$i;
  }
  else if($line[$i]==">"){
     $max=$i;
     break;
  }
  
}
if($max>$min){
   $line = substr_replace($line,"",$min,$max-$min+1);
   }
} 
$out=$out."<$field>".$line."</$field>";
}
$out = $out."</r>\n";
echo "$out";
}
}
echo "</result>";
}


function dirify($s) {
	 $s = mb_convert_encoding($s,"ISO-8859-1","auto");
     $s = convert_high_ascii_new($s);  ## convert high-ASCII chars to 7bit.
     $s = strip_tags($s);       ## remove HTML tags.
     $s = preg_replace('!&[^;\s]+;!','',$s);         ## remove HTML entities.
     $s= preg_replace('!\&+!','',$s);     
	 $s= str_replace('�','\'',$s);     
     $s= str_replace('`','\'',$s);  
	 
     return $s;    
}

function convert_high_ascii_new($s) {
 	$HighASCII = array(
 		"!\xc0!" => 'A',    # A`
 		"!\xe0!" => 'a',    # a`
 		"!\xc1!" => 'A',    # A'
 		"!\xe1!" => 'a',    # a'
 		"!\xc2!" => 'A',    # A^
 		"!\xe2!" => 'a',    # a^
 		"!\xc4!" => 'Ae',   # A:
 		"!\xe4!" => 'ae',   # a:
 		"!\xc3!" => 'A',    # A~
 		"!\xe3!" => 'a',    # a~
 		"!\xc8!" => 'E',    # E`
 		"!\xe8!" => 'e',    # e`
 		"!\xc9!" => 'E',    # E'
 		"!\xe9!" => 'e',    # e'
 		"!\xca!" => 'E',    # E^
 		"!\xea!" => 'e',    # e^
 		"!\xcb!" => 'Ee',   # E:
 		"!\xeb!" => 'ee',   # e:
 		"!\xcc!" => 'I',    # I`
 		"!\xec!" => 'i',    # i`
 		"!\xcd!" => 'I',    # I'
 		"!\xed!" => 'i',    # i'
 		"!\xce!" => 'I',    # I^
 		"!\xee!" => 'i',    # i^
 		"!\xcf!" => 'Ie',   # I:
 		"!\xef!" => 'ie',   # i:
 		"!\xd2!" => 'O',    # O`
 		"!\xf2!" => 'o',    # o`
 		"!\xd3!" => 'O',    # O'
 		"!\xf3!" => 'o',    # o'
 		"!\xd4!" => 'O',    # O^
 		"!\xf4!" => 'o',    # o^
 		"!\xd6!" => 'Oe',   # O:
 		"!\xf6!" => 'oe',   # o:
 		"!\xd5!" => 'O',    # O~
 		"!\xf5!" => 'o',    # o~
 		"!\xd8!" => 'Oe',   # O/
 		"!\xf8!" => 'oe',   # o/
 		"!\xd9!" => 'U',    # U`
 		"!\xf9!" => 'u',    # u`
 		"!\xda!" => 'U',    # U'
 		"!\xfa!" => 'u',    # u'
 		"!\xdb!" => 'U',    # U^
 		"!\xfb!" => 'u',    # u^
 		"!\xdc!" => 'Ue',   # U:
 		"!\xfc!" => 'ue',   # u:
 		"!\xc7!" => 'C',    # ,C
 		"!\xe7!" => 'c',    # ,c
 		"!\xd1!" => 'N',    # N~
 		"!\xf1!" => 'n',    # n~
 		"!\xdf!" => 'ss'
 	);
 	$find = array_keys($HighASCII);
 	$replace = array_values($HighASCII);
 	$s = preg_replace($find,$replace,$s);
     return $s;
}

function createWhereList($list,$field){
   $whereString = "";

   foreach($list as $element){
     $whereString.=' '.$field.' = '.$element.' or '; 
   }

   $whereString = substr($whereString,0,count($whereString)-4);

   return $whereString;
}

?>
