<?php // $Id: help.php,v 1.0 2005/09/25 13:44:25 

	require_once('../../config.php');
	require_once('../../course/lib.php');
	optional_variable($id);    // Course Module ID, or

if ($id) {
    
        if (! $course = get_record("course", "id", $id)) {
            error("Course is misconfigured");
        }
    } else {
}

$courseid = $_GET['id'];

require_login($courseid);

if (isteacher($course->id) || isadmin()){
  print_header("GISMO: Help page");
  
?>




<strong>What is GISMO?
</strong>
<p> You are the instructor of one or more courses given at distance with the Moodle Course Management System. Maybe your students are hundreds of kilometers away, or maybe your students are local, but you see them in classroom only once or twice per semester. As you are the instructor of your course, you may probably what to know what is happening to your students: Are they reading materials? Are they regularly accessing the course? Do they engage in discussions? Are there quizzes or assignments particularly problematic? Are their submissions performed in due time?<br>
  If this is your case, GISMO can help you. GISMO is a graphical interactive student monitoring and tracking system tool that extracts tracking data from the Moodle Course Management System, and generates useful graphical representations that can be explored by course instructors to examine various aspects of distance students.</p>
<p><strong>How to get and install the software</strong></p>
<p> To install the software you need to ask the administrator of your local Moodle platform to install the block.<br>
  GISMO application can be downloaded by the Internet at the following address: http://sourceforge.net/projects/gismo/<br>
  Once your administrator has installed the software, you are ready to use it.</p>
<p><strong>Starting the GISMO</strong></p>
<p> GISMO appears like any other Moodle's block. You need to turn on the editing modality and add GISMO to your course. This block is visible only to the instructors of the course. Then you can click on the &quot;student tracking&quot; link that appears within the GISMO block to start the applet. You need a Web browser capable of running Java applets (version 1.4.x).</p>
<p><strong>Graphical representations</strong></p>
<p> In this section we describe each graphical representation that can be generated with GISMO. These can be activated by clicking on the menu items. There are 3 main categories of visualizations:</p>
<p><em> &#8729; Students<br>
&#8729; Resources<br>
&#8729; Activities<br>
&#8729; Concepts</em></p>
<p> For each category there is a specific item in the menu bar. We will illustrate each of them in the following sections.</p>
<p><strong>Welcome page</strong></p>
<p><img src="helpimages/main.png" width="500" height="330"><br>
<em>[Welcome page]</em></p>
<p> The Figure<em> [Welcome page] </em>represents the welcome page of GISMO. As you can see, there are 3 different areas in the user interface:</p>
<ul>
  <li> Graph Panel: graphs are drawn on this panel.</li>
  <li> List Panel: contains a list of students, groups, resources, quizzes, and assignments of the monitored course. For each list the instructor can select/deselect data to visualize.</li>
  <li> Time Panel: using this panel the instructor can reduce the selection on time and restrict the graph to a specific range of dates.</li>
</ul>
<p><strong>Students: Login overview</strong></p>
<p>
  <img src="helpimages/login.png" width="500" height="331"><br>
  <em>[Students:Login overview]</em></p>
<p> The Figure <em>[Students:Login overview]</em> reports a graph on the students' accesses to the course. A simple matrix formed by students&Otilde; names (on Y-axis) and dates of the course (on X-axis) is used to represent the course accesses. A corresponding mark represents at least one access to the course made by the student on the selected date. The histogram on the bottom shows the global number of hits to the course made by students on each date. With these graphs, the instructor has an overview, at a glance, of the global accesses made by students to the course with a clear identification of patterns and trends, as well as information about the attendance of a specific student of the course.</p>
<p><strong>Students: Access overview on resources</strong></p>
<p><img src="helpimages/student-access-overview.png" width="500" height="325"><br>
  <em>[Students:Access overview on resources]</em></p>
<p> The image in Figure   <em>[Students:Access overview on resources]</em> represents the global number of accesses made by students (in X-axis) to all the resources of the course (Y-axis).<br>
  If the user click with the right-button mouse on one of the bars of the histogram and select the item &quot;Details&quot; he can see the details for a specific student. This leads to the following representation.</p>
<p><strong>Students: Selected student details on resources</strong></p>
<p><img src="helpimages/resources-access.png" width="500" height="331"><br>
  <em>[Students:Selected student details on resources]</em></p>
<p> The Figure <em>[Students:Selected student details on resources]</em> reports an overview of the accesses of a student on the course's resources. Dates are represented on the X-axis; resources are represented on the Y-axis. Resources order on Y-axis reflects the resource sequence order inside the course. The histogram on the bottom represents the total number of accesses made by the student to all course's resources.</p>
<p><strong>Students: Student-resource overview</strong></p>
<p><img src="helpimages/resources.png" width="500" height="331"><br>
  <em>[Student-resource overview]</em></p>
<p> Instructors could also be interested in having the details on what resources were accessed by all the students and when. A specific representation is intended to provide this information. The Figure <em>[Student-resource overview]</em> reports student names on the Y-axis, and resource names on the X-axis. A mark is depicted if the student accessed this resource, and the color of the mark ranges from light-blue to dark-blue according to the number of times he/she accessed this resource.</p>
<p><strong>Resources: Access overview</strong></p>
<p> <img src="helpimages/resource-access-overview.png" width="500" height="325"><br>
  <em>[Resource access overview]</em></p>
<p> The image in Figure <em>[Resource access overview]</em> represents the global number of accesses made by students to each resource of the course (X-axis). Each bar of the histogram represents a particular resource of the course.<br>
  If the user click with the right-button mouse on one of the bars of the histogram and select the item &quot;Details&quot; he can see the details for a specific resource. This leads to the following representation.</p>
<p><strong>Resources: Selected resource detail</strong></p>
<p> <img src="helpimages/selected-resource-detail.png" width="500" height="325"><br>
  <em>[Selected resource detail]</em></p>
<p> The Figure <em>[Selected resource detail]</em> reports an overview of the accesses of students to this particular resource. Dates are represented on the X-axis; students are represented on the Y-axis. The histogram on the bottom represents the total number of accesses made by the student to this resource on each day.</p>
<p><strong>Activities: Discussions post count</strong></p>
<p> <img src="helpimages/discussions-post-count.png" width="500" height="325"><br>
  <em>[Activities: Discussions post count]</em></p>
<p> Instructors can be interested in knowing how many posting were made by each student of the course. Image in Figure <em>[Activities: Discussions post count]</em> is intended to give this information. Students are mapped onto X-axis. Each bar of the histogram represents the quantity of messages posted by the student in the course.</p>
<p><strong>Activities: Discussions overview</strong></p>
<p> <img src="helpimages/discussions.png" width="500" height="331"><br>
  <em>[Activities: Discussions overview]</em></p>
<p> Discussion boards data is mapped onto a 2-D scatterplot and the generated image is illustrated in Figure <em>[Activities: Discussions overview]</em>. In this chart, instructors have an overview of all the discussions in which students participated. For each student of the course the chart indicates the number of messages posted (with a square), number of messages read (with a circle) and finally the number of threads started by the student in the discussions (with the triangle).</p>
<p><strong>Activities: Assignments/Quizzes overview - time</strong></p>
<p> <img src="helpimages/assignment-overview.png" width="500" height="331"><br>
  <em>[Activities: Assignment overview - time]</em></p>
<p> The graph in Figure <em>[Activities: Assignment overview - time]</em> is dedicated to visually indicate the date of submissions of assignments and quizzes. Vertical lines correspond to deadlines of each quiz or assignment provided to students (represented here on the Y-axis), and marks denote students&Otilde; submissions.</p>
<p><strong>Activities: Assignments/Quizzes overview - Matrix</strong></p>
<p><img src="helpimages/assignment-matrix.png" width="500" height="331"><br>
  <em>[Activities: Assignments overview - matrix]</em></p>
<p> The graph in Figure <em>[Activities: Assignments overview - matrix]</em> is indented to visually indicate the grades received by students on assignments and quizzes. On the X-axis we mapped the assignments (or quizzes in the graphs dedicated to quizzes) and marks denote students&Otilde; submissions. An empty square means a submission not graded, while a coloured square reports the grade: a lower grade is depicted with a light colour, a high grade is depicted with a dark colour.</p>
<p><strong>Concepts: The domain editor</strong></p>
<p><img src="helpimages/domain-editor.png" width="500" height="366"><br>
<em>[Concepts: The domain editor]</em></p>
<p> The domain designer module can be used to define the domain model of the course. The domain model describes the entities of the course domain (i.e. the course concepts) and their relationships with resources, quizzes, and assignments. Each resource, quiz, or assignment can be related to one or more concepts from the domain model of the course. This simple approach allows GISMO to use grades received in quizzes and assignments to estimate the performance of students on each concept of the course. The domain designer editor is also integrated in the GISMO block and is visible only to the instructors of courses. Figure <em>[Concepts: The domain editor]</em> illustrates a screenshot of the editor. It allows instructors to set up the model of their courses. There are three main areas. The left panel is used to select among resources, assignments, and quizzes. The central panel contains the list of concepts added by the instructor. The right panel is used to link a specific quiz, resource, or assignment with the concepts of the domain. The instructor can create new concepts with the field at the bottom, and then add (or remove) concepts for a specific quiz or assignment by clicking on the buttons located between right and central lists.</p>
<p><strong>Concepts: Resources/quizzes/assignments - Concepts</strong></p>
<p><img src="helpimages/assignments-concepts.png" width="500" height="325"><br>
<em>[Concepts: Resources/quizzes/assignments - Concepts]</em></p>
<p>The domain model edited by the instructor can be visualized in Figure <em>[Concepts: Resources/quizzes/assignments - Concepts]</em> This picture illustrates which resources/quizzes/assignents (on Y-axis) are related with concepts of the course (on X-axis). Specific pictures are created for resources, quizzes and assignments.</p>
<p><strong>Concepts: Students - concepts on quizzes &amp; assignments</strong></p>
<p><img src="helpimages/students-concepts.png" width="500" height="325"><br>
<em>[Concepts: Students - concepts on quizzes &amp; assignments]</em></p>
<p>Once the instructor has modeled the domain of his/her course, that information can be used to draw specific graphical representations that aims at giving to the instructor an overview of the performance on the course concepts, and to compare concepts and individual students. Figure <em>[Concepts: Students - concepts on quizzes &amp; assignments]</em> illustrates a matrix that represents an estimation of the students' knowledge on the concepts of the domain. Concepts are on the X-axis, students are on the Y-axis. The performance of a student on a specific concept is mapped with the saturation of the color in cells. A good performance is depicted with a light color; a bad performance is depicted with a dark color. The performance is calculated by the mean of the normalized values of grades received by the student for quizzes or assignments that test the concept. If there are no quizzes or assignments testing a concept, then the student understanding of a concept cannot be determined by this model. </p>
<p>  
  <?php
}print_footer('none');
?>
</p>
