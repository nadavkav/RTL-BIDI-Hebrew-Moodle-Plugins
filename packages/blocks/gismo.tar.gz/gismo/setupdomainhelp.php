<?php
require_once('../../config.php');
require_once('../../course/lib.php');

optional_variable($id);  

if (! $course = get_record('course', 'id', $id) ) {
	error("That's an invalid course id");
}

require_login($course->id);

print_header();
print_simple_box_start('center', '96%');
if (isteacher($course->id) || isadmin()){

?>

<P ALIGN=CENTER><B>GISMO: Domain Setup</B></P>
<P ALIGN=left><strong>Domain example </strong></P>
<P ALIGN=left><img src="helpimages/domain_sample_small.png" width="300" height="206" border="0"><br>
<em>[Domain sample] </em></P>
<P>GISMO Domain Setup is used to link Resources / Quizzes / Assignments with "Concepts".</p>
<p>GISMO domain system it's realy easy to use, select the type of elements  (Resources, Assignments, Quizzes <em>[Domain elements]</em>) you want to link with concepts and add them using the buttons => (add) or <= (remove) <em>[Domain buttons]</em>.</p>
     <table width="80%"  border="0" align="center" cellpadding="0" cellspacing="0">
       <tr align="center" valign="middle">
         <td><img src="helpimages/domain_elementtype.png" width="133" height="95"> <br>
           <em>[Domain elements]</em> </td>
         <td><img src="helpimages/domain_buttons.png" width="100" height="116"><br>
           <em>[Domain buttons]</em></td>
       </tr>
     </table>
     <?php }else{	
	 	print("<h1>You must have Teaching privileges to see this page</h1>");
	 } 
	 print_simple_box_end(); 
	 close_window_button(); 
	 print_footer('none');?>