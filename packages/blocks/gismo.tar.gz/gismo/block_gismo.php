<?PHP //$Id: block_gismo.php,v 1.2 2005/08/26 09:03:40 
?>
<script language="JavaScript" type="text/javascript">
<!-- // Non-Static Javascript functions
function openPop(strUrl,wName){  
  var sw = screen.width;
  var sh = screen.height;
  var sw1 = screen.width*95/100;
  var sh1 = screen.height*90/100;
  var url=location.href;
  window.open(strUrl+'&sw='+sw+'&sh='+sh+'&url='+url,wName,'width='+sw1+',height='+sh1+',left=0,right=0');
}
// done hiding -->
</script>
<?PHP
class block_gismo extends block_list {
    function init() {
        $this->title = 'GISMO';
      // $this->content_type = BLOCK_TYPE_LIST;
      //$this->course = $course;
        $this->version = 2005091000;
	
    }
    function specialization(){
      $this->course = get_record('course','id',$this->instance->pageid);
    }
    function get_content() {
        global $USER, $CFG, $THEME;
		
        if($this->content !== NULL) {
            return $this->content;
        }
		
        $this->content = New object;
        $this->content->items = array();
        $this->content->icons = array();
        $this->content->footer = '';

        if (isguest()) {
            return $this->content;
        }
		$course = $this->course;
		if ($course->id!=1) {
			if (isteacher($course->id)) {
	
				$this->content->items[]='<a href="#" onClick="openPop(\'../blocks/gismo/applet.php?course='.$this->course->id.'\',\'GISMO\');">'.'Students 
Tracking...</a>';
				$this->content->icons[]='<img src="../blocks/gismo/pix/gismo.gif" height="16" width="16" alt="">';

				$this->content->items[]='<a href="../blocks/gismo/setupdomain.php?id='.$this->course->id.'">Domain Configuration</a>';
				$this->content->icons[]='<img src="../blocks/gismo/pix/domain.gif" height="16" width="16" alt="">';
	
			}
		}
		else{
			return $this->content;
		}
        return $this->content;
		
    }
}

?>