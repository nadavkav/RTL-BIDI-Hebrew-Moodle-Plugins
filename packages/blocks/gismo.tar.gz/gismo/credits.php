<?php // $Id: credits.php,v 1.0 2005/09/25 13:44:25 

	require_once('../../config.php');
	require_once('../../course/lib.php');
	optional_variable($id);    // Course Module ID, or

if ($id) {
        if (! $course = get_record("course", "id", $id)) {
            error("Course is misconfigured");
        }
    } else {
}

$courseid = $_GET['id'];

require_login($courseid);

if (isteacher($course->id) || isadmin()){
 print_header("GISMO: Credits page");
  
?>
<div align="center">
  <p>GISMO is a graphical interactive student monitoring and tracking system that extracts tracking data from an online course maintained with Moodle, and generates graphical representations that can be explored by course instructors.&nbsp; </p>
  <p>GISMO is released under GNU General Public License </p>
  <p><strong>GISMO Web site: </strong><br>
      <a href="http://gismo.sourceforge.net/">http://gismo.sourceforge.net/ </a></p>
  <p><strong>Developers: </strong><br>
      <a href="mailto:milanic@lu.unisi.ch">Christian Milani </a> &amp; <a href="mailto:mazzar@lu.unisi.ch">Riccardo Mazza </a></p>
  <p><strong>Organizations: </strong><br>
  Edukalibre project: <a href="http://www.edukalibre.org">http://www.edukalibre.org </a><br>
  University of Lugano: <a href="http://www.unisi.ch">http://www.unisi.ch </a><br>
  <a href="http://www.unisi.ch"></a>eLab: <a href="http://www.elearninglab.org">http://www.elearninglab.org </a>
  <?php } print_footer('none');?>
  </p>
  
</div>
