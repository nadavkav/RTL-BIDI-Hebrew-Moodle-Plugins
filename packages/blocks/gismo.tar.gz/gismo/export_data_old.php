<?PHP // $Id: export_data.php,v 1.1 2004/08/26 15:23:05

    require_once("../../config.php");

$db = mysql_connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass);

if ($db == FALSE)
die ("Error connecting. Verify parameters in file config.inc.php");
                                                                             
mysql_select_db($CFG->dbname, $db)
or die ("Error on Database section. Verify parameters in file config.php");

$prefix = $CFG->prefix;

function getMaxStudentID(){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id from ".$prefix."user where ".$prefix."user.deleted = 0";
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result))
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;

   
}

function getMaxCourseID(){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id from ".$prefix."course";
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result))
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;

   
}

function getMaxResourcesID(){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id FROM ".$prefix."resource";
 
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result))
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;
}

function getMaxStudentResourceDetailLogID(){
   global $db,$prefix;

   $query = "SELECT MAX(log_id) as id from ".$prefix."gismo_chart_student_resource_detail";
 $result = mysql_query($query, $db);
while ($row = mysql_fetch_array($result)){
  //print($row["id"]);
  if(isset($row["id"]))
    return $row["id"];
  else
    return 0;
}
}

function date_correction($data){	
	
	$ore = (int) strftime("%H",$data);
	$minuti = (int) strftime("%M",$data);
	$secondi = (int) strftime("%S",$data);
	
	$cdata = $data - ($ore * 3600 + $minuti * 60 + $secondi);
	
	return $cdata;
}

function export_table_ChartStudentResourceDetail(){
   global $db,$prefix;

print("Start Exporting ChartStudentResourceDetail Table<br>");

$maxLogID = getMaxLogID();

$minLogID = getMaxStudentResourceDetailLogID();

$delta = 100;

while($minLogID < $maxLogID){ 

   //$maxLog = getMaxStudentResourceDetailLogID();

   $query = "SELECT ".$prefix."log.info, ".$prefix."log.userid, ".$prefix."log.time, ".$prefix."log.id FROM ".$prefix."log, ".$prefix."user_students, ".$prefix."user WHERE ".$prefix."log.module  = 'resource' AND ".$prefix."log.action='view' AND ".$prefix."log.userid = ".$prefix."user_students.userid and ".$prefix."user.deleted = 0 and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.id ORDER BY ".$prefix."log.id";

        $log=array();
        $resultLog = mysql_query($query, $db);
        $fields=array("id","userid","time","info");
	while ($row = mysql_fetch_array($resultLog)){
     	  $line=array();
          foreach($fields as $field){
	   //print("$field is $row[$field] <br> ");
           $line["$field"]=$row[$field];
          }
	  $log[]=$line;
	//print("<br>");
       }
   if(count($log)!=0){  
        
   $query = "SELECT MAX(time) as time ,student_id,resource_id from ".$prefix."gismo_chart_student_resource_detail group by student_id, resource_id order by time";
         
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
      if(isset($row["time"])){
         $students[$row['student_id']][$row['resource_id']] = $row["time"]; 
      } 
   }   


 $count = count($log);
        for($i = 0 ; $i<$count;$i++){
//while ($row = mysql_fetch_array($resultLog)){
	    //print("<p>");
	    $element=$log[$i];//$row;
            $logid=$element["id"];
            $userid=$element["userid"];
            $time=$element["time"];
            $resourceid=$element["info"];
            
	    //print(" ChartStudentResourceDetail VALUES = ".$logid." ".$userid." ".$time." ".$resourceid."  ");

            $newTime=date_correction($time);
            if(isset($students[$userid][$resourceid])){
               //print("IS SET <br>");
            }
	    else{
               $students[$userid][$resourceid]=0;
               //print("IS NOT SET <br>");
            }
	    if($students[$userid][$resourceid]<$newTime){
	       $students[$userid][$resourceid]=$newTime;
	       $query = "INSERT INTO ".$prefix."gismo_chart_student_resource_detail (log_id,resource_id,student_id,time,view_count) values (".$logid.",".$resourceid.",".$userid.",".$students[$userid][$resourceid].",1)";
 		//print($query);
                mysql_query($query, $db);
	     }
            
            else{
               $query = "UPDATE ".$prefix."gismo_chart_student_resource_detail set view_count = view_count+1, log_id=".$logid." where student_id = ".$userid." and resource_id = ".$resourceid." and time = ".$students[$userid][$resourceid];
		//print($query);
                mysql_query($query, $db);
            }
        }
     }

     $minLogID = $minLogID + $delta;
     //print("MinLogID: ".$minLogID."<br>");
     if($minLogID>$maxLogID){
        $minLogID = $minLogID - $delta;
	$delta = $maxLogID - $minLogID;
        //print($delta);
     }
     
   }
   print("Finish Exporting ChartStudentResourceDetail Table<br>");
}

function getLastChartLoginAccessOverview(){
   global $db,$prefix;

   $query = "SELECT MAX(log_id) as id from ".$prefix."gismo_chart_login_access_overview";
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;
   }
}

function getMaxLogID(){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id from ".$prefix."log";
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;
   }
}

function export_table_ChartLoginAccessOverview(){
   global $db,$prefix; 

print("Start Exporting ChartLoginAccessOverview Table<br>");

$maxLogID = getMaxLogID();

$minLogID = getLastChartLoginAccessOverview();

$delta = 100;


while($minLogID < $maxLogID){ 
   //$last = getLastChartLoginAccessOverview();
   //print("LAST : ".$last); 
   $query = "select ".$prefix."log.id,".$prefix."log.course,".$prefix."log.userid,".$prefix."log.time FROM ".$prefix."log,".$prefix."user_students WHERE ".$prefix."log.action like '%view%' and ".$prefix."user_students.userid = ".$prefix."log.userid and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.course,".$prefix."log.userid,".$prefix."log.time"; 

        $log=array();
        $result = mysql_query($query, $db);
        $fields=array("id","course","userid","time");
	while ($row = mysql_fetch_array($result)){
     	  $line=array();
          foreach($fields as $field){
	   //print("$field is $row[$field] <br> ");
           $line["$field"]=$row[$field];
          }
	  $log[]=$line;
	//print("<p>");
       }


   $query = "SELECT MAX(time) as time ,student_id,course_id from ".$prefix."gismo_chart_login_access_overview group by student_id, course_id order by time";
         
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
      if(isset($row["time"])){
         $students[$row['student_id']][$row['course_id']] = $row["time"]; 
      } 
   }   
 $count = count($log);
        for($i = 0 ; $i<$count;$i++){
	    //print("<p>");
	    $element=$log["$i"];
            $logid=$element["id"];
            $userid=$element["userid"];
            $time=$element["time"];
            $courseid=$element["course"];
            
	    //print(" ChartLoginAccessOverview VALUES = ".$logid." ".$userid." ".$time." ".$courseid."  ");

            $newTime=date_correction($time);
            if(isset($students[$userid][$courseid])){
               //print("IS SET <br>");
            }
	    	else{
               $students[$userid][$courseid]=0;
               //print("IS NOT SET <br>");
            }
	    if($students[$userid][$courseid]<$newTime){
	       $students[$userid][$courseid]=$newTime;
	       //print("New Time: ".$newTime);
	       $query = "INSERT INTO ".$prefix."gismo_chart_login_access_overview (log_id,course_id,student_id,time) values (".$logid.",".$courseid.",".$userid.",".$students[$userid][$courseid].")";
 		//print($query);
                mysql_query($query, $db);
	     }
            
            
        }

     $minLogID = $minLogID + $delta;
     //print("MinLogID: ".$minLogID."<br>");
     if($minLogID>$maxLogID){
        $minLogID = $minLogID - $delta;
	$delta = $maxLogID - $minLogID;
        //print($delta);
     }
   }


print("Finish Exporting ChartLoginAccessOverview Table<br>");
}   

function getDiscussionOverviewWrite(){//$maxLogID){
   global $db,$prefix; 

// and ".$prefix."forum_posts.id>".$maxLogID." 

 $query= "SELECT ".$prefix."forum_posts.id, ".$prefix."forum_posts.userid, ".$prefix."forum_posts.discussion, ".$prefix."forum_discussions.course FROM ".$prefix."forum_posts, ".$prefix."user_students, ".$prefix."forum_discussions WHERE ".$prefix."user_students.userid = ".$prefix."forum_posts.userid and ".$prefix."forum_posts.discussion = ".$prefix."forum_discussions.id GROUP BY ".$prefix."forum_posts.id,".$prefix."forum_posts.userid,discussion,".$prefix."forum_discussions.course";

        //print($query);
   $result = mysql_query($query, $db);
 return $result;
    
   
}

function getLastChartDiscussionOverviewRead(){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id from ".$prefix."gismo_chart_discussion_read";
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;
   }
}

function getDiscussionOverviewRead($minLogID,$delta){
global $db,$prefix; 

   $query= "SELECT ".$prefix."log.id, ".$prefix."log.userid, ".$prefix."log.course, ".$prefix."log.time FROM ".$prefix."log,".$prefix."user_students, ".$prefix."user WHERE ".$prefix."log.action='view discussion' and ".$prefix."log.userid=".$prefix."user_students.userid and ".$prefix."user.deleted = 0 and ".$prefix."log.id > ".$minLogID." and ".$prefix."log.id < ".($minLogID+$delta)." GROUP BY ".$prefix."log.id";

//print($query."<br>");

   
        $log=array();
        $result = mysql_query($query, $db);
        $fields=array("id","userid","course","time");
	while ($row = mysql_fetch_array($result)){
     	  $line=array();
          foreach($fields as $field){
	   //print("$field is $row[$field] <br> ");
           $line["$field"]=$row[$field];
          }
	  $log[]=$line;
	//print("<br>");
       }

      return $log;//$result;
}

function getDiscussionOverviewThread(){
global $db,$prefix; 
   $query = "SELECT ".$prefix."forum_discussions.timemodified, ".$prefix."forum_discussions.userid, ".$prefix."forum_discussions.id, ".$prefix."forum_discussions.course FROM ".$prefix."forum_discussions, ".$prefix."user_students WHERE ".$prefix."user_students.userid = ".$prefix."forum_discussions.userid  GROUP BY ".$prefix."forum_discussions.id";
        
   $result = mysql_query($query, $db);
  
      return $result;
   
}




function export_table_ChartDiscussionOverviewWrite(){
   global $db,$prefix; 

print("Start Exporting ChartDiscussionOverviewWrite Table<br>");
   
   $students = getMaxStudentID();
   $courses =  getMaxCourseID();
   
   //$writeMaxLog = getMaxLogID("gismo_chart_discussion_write");
   $writeDiscussion = getDiscussionOverviewWrite();   
   //$fields=array("userid","id","course","created");
   while ($row = mysql_fetch_array($writeDiscussion)){
         if(isset($write[$row['userid']][$row['course']]))
	    $write[$row['userid']][$row['course']] = $write[$row['userid']][$row['course']]+1;
         else
            $write[$row['userid']][$row['course']] = 1;

         $logid[$row['userid']][$row['course']]=$row['id'];
	 $value= $write[$row['userid']][$row['course']];
         $user= $row['userid'];
	 $course= $row['course'];
         $log=$logid[$row['userid']][$row['course']];
         //print("WRITE: user:$user course:$course sum:$value log:$log <br>");   
            
   }

   //Clear all gismo_chart_discussion_write table
   $clearQuery = "delete from ".$prefix."gismo_chart_discussion_write";
   //print($clearQuery."<br>");
   mysql_query($clearQuery, $db);


   for($i=0;$i<=$students;$i++){
      for($j=0;$j<=$courses;$j++){
	if(isset($write[$i][$j])){
	   $query="INSERT into ".$prefix."gismo_chart_discussion_write (id,course_id,student_id,count) values (".$logid[$i][$j].",".$j.",".$i.",".$write[$i][$j].")";
           //print($query."<br>");
           mysql_query($query, $db);


/* //Old Version for speed up the export or discussion write, it don't trace if messages where deleted 
// The new version will control in the log for deleted messages action

         $query = "SELECT * FROM ".$prefix."gismo_chart_discussion_write WHERE course_id = $j and student_id = $i";

	 //print($query."<br>");
	 $result = mysql_query($query, $db);
	 
         $row1 = mysql_fetch_array($result);
		
	    if(isset($row1['id'])){
	       $query="UPDATE ".$prefix."gismo_chart_discussion_write SET count = (count+".$write[$i][$j]."), id=".$logid[$i][$j]." WHERE id=".$row1['id'];

	       //print($query);
               mysql_query($query, $db);
            }else{
               $query="INSERT into ".$prefix."gismo_chart_discussion_write (id,course_id,student_id,count) values (".$logid[$i][$j].",".$j.",".$i.",".$write[$i][$j].")";

	       //print($query);
               mysql_query($query, $db);

	    }
*/
          
	 }
      }
   }
print("Finish Exporting ChartDiscussionOverviewWrite Table<br>");

}


function export_table_ChartDiscussionOverviewRead(){
   global $db,$prefix; 

print("Start Exporting ChartDiscussionOverviewRead Table<br>");

$maxLogID = getMaxLogID();

$minLogID =  getLastChartDiscussionOverviewRead();

$delta = 100;
$students;
while($minLogID < $maxLogID){ 
    //$maxLog = getLastChartDiscussionOverviewRead();
   
    $readDiscussion  = getDiscussionOverviewRead($minLogID,$delta);

//print("ReadDiscussionCount: ".count($readDiscussion)."<br>");
   if(count($readDiscussion)!=0){ 
if(!isset($students)){
  //print("Students is not set");
  $query = "SELECT MAX(id) as id ,student_id,course_id from ".$prefix."gismo_chart_discussion_read group by student_id, course_id order by id";
         
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result)){
      if(isset($row["id"])){
         $students[$row['student_id']][$row['course_id']] = $row["id"]; 
      } 
   }   
}

 $count = count($readDiscussion);

 for($i = 0 ; $i<$count;$i++){
	    $element=$readDiscussion[$i];
            $logid=$element["id"];
            $userid=$element["userid"];
            $courseid=$element["course"];
           
            if(isset($students[$userid][$courseid])){
            if($students[$userid][$courseid]<$logid){
	       $students[$userid][$courseid]=$logid;
 	       $query = "UPDATE ".$prefix."gismo_chart_discussion_read set count = count+1, id=".$logid." where student_id = ".$userid." and course_id = ".$courseid;
		//print($query."<br>");
                mysql_query($query, $db);
	     }
	        //print("IS SET <br>");
            }
	    else{
               $students[$userid][$courseid]=$logid;
               $query = "INSERT INTO ".$prefix."gismo_chart_discussion_read (id,course_id,student_id,count) values (".$logid.",".$courseid.",".$userid.",1)";
 		//print($query."<br>");
                mysql_query($query, $db);
              // print("IS NOT SET <br>");
            }
	  
        }
     } 
   
     $minLogID = $minLogID + $delta;
     //print("MinLogID: ".$minLogID."<br>");
     if($minLogID>$maxLogID){
        $minLogID = $minLogID - $delta;
	$delta = $maxLogID - $minLogID;
        //print($delta);
     }
     //unset($students);
}
print("Finish Exporting ChartDiscussionOverviewRead Table<br>");

}

function export_table_ChartDiscussionOverviewThread(){
   global $db,$prefix; 

print("Start Exporting ChartDiscussionOverviewThread Table<br>");

   $threadDiscussion = getDiscussionOverviewThread();
   //$fields=array("id","userid","timemodified","course");
   while ($row = mysql_fetch_array($threadDiscussion)){
	 if(isset($thread[$row['userid']][$row['course']]))
	    $thread[$row['userid']][$row['course']] = $thread[$row['userid']][$row['course']]+1;
 	 else
	    $thread[$row['userid']][$row['course']]=1;

	 $logid[$row['userid']][$row['course']]=$row['id'];
	 $value= $thread[$row['userid']][$row['course']];
         $user= $row['userid'];
	 $course= $row['course'];
         $log=$logid[$row['userid']][$row['course']];
         //print("THREAD: user:$user course:$course sum:$value log:$log <br>");      
   }

   //Clear all gismo_chart_discussion_thread table
   $clearQuery = "delete from ".$prefix."gismo_chart_discussion_thread";
   //print($clearQuery."<br>");
   mysql_query($clearQuery, $db);

  
   $students = getMaxStudentID();
   $courses =  getMaxCourseID();

   for($i=0;$i<=$students;$i++){
      for($j=0;$j<=$courses;$j++){
	if(isset($thread[$i][$j])){
	   $query="INSERT into ".$prefix."gismo_chart_discussion_thread (id,course_id,student_id,count) values (".$logid[$i][$j].",".$j.",".$i.",".$thread[$i][$j].")";
           //print($query."<br>");
           mysql_query($query, $db);
          
	 }
      }
   }

print("Finish Exporting ChartDiscussionOverviewThread Table<br>");
}

/* 
function getMaxLogID($tablename){
   global $db,$prefix;

   $query = "SELECT MAX(id) as id from ".$prefix.$tablename;
      
   $result = mysql_query($query, $db);
   while ($row = mysql_fetch_array($result))
     if(isset($row['id']))
        return $row['id'];
     else
        return 0;
   
}
*/
print("<h1>Starting Exporting</h1><p>");

export_table_ChartStudentResourceDetail();
print("<h1>Finished Exporting Table Chart Student Resource Detail</h1><p>");

export_table_ChartLoginAccessOverview(); 
print("<h1>Finished Exporting Table Chart Login Access Overview</h1><p>");

export_table_ChartDiscussionOverviewThread();
print("<h1>Finished Exporting Table Chart Discussion Overview Thread</h1><p>");
export_table_ChartDiscussionOverviewWrite();
print("<h1>Finished Exporting Table Chart Discussion Overview Write</h1><p>");
export_table_ChartDiscussionOverviewRead();
print("<h1>Finished Exporting Table Chart Discussion Overview Read</h1><p>");

print("<h1>Finished Exporting</h1>");

mysql_close($db);

?>