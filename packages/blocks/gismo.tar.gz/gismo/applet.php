<?PHP // $Id: applet.php,v 1.5 2005/09/25 10:20:00
// This page contains gismo applet

    require_once("../../config.php");
	
$courseid = $_GET['course'];

 if (! $course = get_record('course', 'id', $courseid) ) {
        error("That's an invalid course id");
    }


require_login($courseid);

if (isteacher($course->id) || isadmin()){

$sw = $_GET['sw']*94.5/100;
$sh = $_GET['sh']*88/100;
print("<html>\n");
print("<head>\n");
print("<title>GISMO - Graphical Interactive Student MOnitoring system</title>\n");
print("</head>\n");
print("<body style=\"margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;\">\n");

?>
<script language="JavaScript" type="text/javascript">
<!-- hide scripting
function loadHelp() {
var load = window.open('<?php echo $CFG->wwwroot; ?>/blocks/gismo/help.php?id=<?php print $courseid ?>','','scrollbars=yes,menubar=no,height=600,width=800,resizable=yes,toolbar=no,location=no,status=no');
}
function loadCredits() {
var load = window.open('<?php echo $CFG->wwwroot; ?>/blocks/gismo/credits.php?id=<?php print $courseid ?>','','menubar=no,height=320,width=450,resizable=yes,toolbar=no,location=no,status=no');
}
// -->
</Script>

<OBJECT classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" name="Helper" width="<?php echo $sw ?>" height="2" codebase="http://java.sun.com/products/plugin/1.2.2/jinstall-1_2_2-win.cab#Version=1,2,2,0">
<PARAM name="java_code" value="appletLoader/LoadMainGUI.class">
<PARAM name="java_archive" value="LoadMainGUI.jar">
<PARAM name="type" value="application/x-java-applet;version=1.4">
<COMMENT>
<EMBED type="application/x-java-applet;version=1.4" name="Helper" width="900" height="2" pluginspage="http://java.sun.com/products/plugin/" java_code="appletLoader/LoadMainGUI.class" java_archive="LoadMainGUI.jar" />
<NOEMBED>
</NOEMBED>
</COMMENT>
</OBJECT>          

<OBJECT classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" name="Main" width="<?php echo $sw ?>" height="<?php echo $sh ?>" codebase="http://java.sun.com/products/plugin/1.2.2/jinstall-1_2_2-win.cab#Version=1,2,2,0">
<PARAM name="java_code" value="ch.unisi.GISMO.GUI.MainGUI">
<PARAM name="java_archive" value="GISMO.jar">
<PARAM name="progressbar" value="true">
<PARAM NAME ="course" VALUE ="<?php echo $courseid ?>">
<PARAM NAME ="url" VALUE ="<?php echo $CFG->wwwroot ?>">
<PARAM name ="type" value="application/x-java-applet;version=1.4">
<PARAM name="mayscript" value="true">
<PARAM name="scriptable" value="true">
<PARAM name="retrive_data_script" value="retrive_data.php">
<COMMENT>
<EMBED type="application/x-java-applet;version=1.4" name="Main" width="<?php echo $sw ?>" height="<?php echo $sh ?>" pluginspage="http://java.sun.com/products/plugin/" java_code="ch.unisi.GISMO.GUI.MainGUI.class" java_archive="GISMO.jar" course=<?php echo $courseid ?> url=<?php echo $CFG->wwwroot ?> progressbar=true  mayscript="true" scriptable="true" retrive_data_script="retrive_data.php" />
<NOEMBED>
</NOEMBED>
</COMMENT>
</OBJECT>


<?php 

print("</body>\n");
print("</html>");

}else{
print("Not allowed to see this page");
}
?>
