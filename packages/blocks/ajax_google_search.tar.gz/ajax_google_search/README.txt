$Id: README.txt,v 1.0 2008/02/223 19:31:20 jsridden $

To Install it:
    - Upload the ajax_google_search folder to your blocks directory    
    - Copy lang/XX/block_ajax_google_search files into your Moodle's lang directory.
    - Go to "Administration". Block will be installed.
    - Go to Google, create an account and get a AJAX search API key.
    - Configure your block to use the google key you have received (Administration/Blocks).
    - Links: http://www.google.com/apis/
             https://www.google.com/accounts
  
To Use it:
    - Go to your course page.
    - Enable "edit".
    - Add it from the "Add block" menu.
    - Test it.

Julian Ridden
