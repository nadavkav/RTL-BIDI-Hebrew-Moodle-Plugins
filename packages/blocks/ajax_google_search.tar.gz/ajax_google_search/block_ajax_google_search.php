<?php

class block_ajax_google_search extends block_base {

    function init() {
        $this->title = get_string('blockname','block_ajax_google_search');
        $this->content_type = BLOCK_TYPE_TEXT;
        $this->version = 2008042200;
    }

    function has_config() {
	        return true;
    }

    function get_content() {
        global $USER, $CFG, $COURSE;

        $key = $CFG->block_ajax_google_search_key;
        
        $searchgoogle = get_string('searchgoogle', 'block_ajax_google_search');
        $thissite = get_string('thissite', 'block_ajax_google_search');
        $theweb = get_string('theweb', 'block_ajax_google_search');
        $poweredby = get_string('poweredby', 'block_ajax_google_search');
        $introtext = get_string('introtext', 'block_ajax_google_search');
        
        $this->content->text = '
        
    <link href="'.$CFG->wwwroot.'/blocks/ajax_google_search/extras/style.css" type="text/css" rel="stylesheet" />
	<script src="http://www.google.com/uds/api?file=uds.js&amp;v=1.0&amp;key='.$key.'" type="text/javascript"></script>
	 
    <script type="text/javascript">
	var searchControl;
	window.onload = function() {
		onLoad();
	}
	function onLoad() {
		// Create a search control
		searchControl = new GSearchControl();
	
		// add a regular web search, with a custom label \'web\'
		var webSrearch = new GwebSearch();
		webSrearch.setUserDefinedLabel("'.$theweb.'");
		searchControl.addSearcher(webSrearch);
	
		// add a site-limited web search, with a custom label
		var siteSearch = new GwebSearch();
		siteSearch.setUserDefinedLabel("'.$thissite.'");
		siteSearch.setSiteRestriction("'.$CFG->wwwroot.'");
		searchControl.addSearcher(siteSearch);
					
	
		// setting the draw mode for the Google search
		var drawOptions = new GdrawOptions();
		// use tabbed view
		drawOptions.setDrawMode(GSearchControl.DRAW_MODE_TABBED);
		// set the input field (instead of the default one)
		drawOptions.setInput(document.getElementById(\'query\'));
		// actually write the needed markup to the page
		searchControl.draw(document.getElementById("searchcontrol"), drawOptions);
		// set the google logo container
		GSearch.getBranding(document.getElementById("branding"));
	}
	
	var query = null;
	document.onkeydown = function(event) { kd(event); };
	function kd(e) {
		// make it work on FF and IE
		if (!e) e = event;
		// use ESC to clear the search results
		if (e.keyCode == 27)
			searchControl.clearAllResults();
		// get the input field
		if (query == null)
			query = document.getElementById(\'query\');
		// and move the focus in there
		query.focus();
	}
	</script>
	
	
	<div class="introtext">'.$introtext.'</div>
	<div id="queryContainer">
		<input type="text" name="query" id="query" /><br />
		<div id="branding">'.$poweredby.' Google</div>
	</div>
	<div id="searchcontrol"></div>';

        return $this->content;

    }
}
?>