if (!window['google']) {
window['google'] = {};
}
if (!window['google']['loader']) {
window['google']['loader'] = {};
google.loader.ServiceBase = 'http://www.google.com/uds';
google.loader.ApiKey = 'notsupplied';
google.loader.KeyVerified = true;
google.loader.LoadFailure = false;
google.loader.AdditionalParams = '';
(function() { 
function s(a){if(a in y){return y[a]}return y[a]=navigator.userAgent.toLowerCase().indexOf(a)!=-1}
var y={};function B(){return s("msie")}
function C(){return s("safari")||s("konqueror")}
function N(a,b){var c=function(){}
;c.prototype=b.prototype;a.F=b.prototype;a.prototype=new c}
function K(a,b){var c=a._JSAPI_boundArgs||[];c=c.concat(Array.prototype.slice.call(arguments,2));if(typeof a._JSAPI_boundSelf!="undefined"){b=a._JSAPI_boundSelf}if(typeof a._JSAPI_boundFn!="undefined"){a=a._JSAPI_boundFn}var d=function(){var e=c.concat(Array.prototype.slice.call(arguments));return a.apply(b,e)}
;d._JSAPI_boundArgs=c;d._JSAPI_boundSelf=b;d._JSAPI_boundFn=a;return d}
function E(a){var b=new Error(a);b.toString=function(){return this.message}
;return b}
;
var j={};var t={};var D={};var R={};var p=null;var H=false;function O(a,b,c){var d=j[":"+a];if(!d){throw E("Module: '"+a+"' not found!");}else{if(c&&!c["language"]&&c["locale"]){c["language"]=c["locale"]}var e=c&&c["callback"]!=null;if(e&&!d.p()){throw E("Module: '"+a+"' must be loaded before DOM onLoad!");}else if(e){if(d.g(b,c)){window.setTimeout(c["callback"],0)}else{d.h(b,c)}}else{if(!d.g(b,c)){d.h(b,c)}}}}
function V(a,b){if(b){U(a)}else{x(window,"load",a)}}
function x(a,b,c){if(a.addEventListener){a.addEventListener(b,c,false)}else if(a.attachEvent){a.attachEvent("on"+b,c)}else{var d=a["on"+b];if(d!=null){a["on"+b]=L([c,d])}a["on"+b]=c}}
function L(a){return function(){for(var b=0;b<a.length;b++){a[b]()}}
}
var n=[];function U(a){if(n.length==0){x(window,"load",u);if(!B()&&!C()&&s("mozilla")||window.opera){window.addEventListener("DOMContentLoaded",u,false)}else if(B()){window.setTimeout(F,10)}else if(C()){window.setTimeout(G,10)}}n.push(a)}
function F(){try{if(n.length>0){document.firstChild.doScroll("left");u()}}catch(a){window.setTimeout(F,10)}}
var P={loaded:true,complete:true};function G(){if(P[document.readyState]){u()}else if(n.length>0){window.setTimeout(G,10)}}
function u(){for(var a=0;a<n.length;a++){n[a]()}n.length=0}
function T(a){var b=window.location.href;var c;var d=b.length;for(var e in a){var f=b.indexOf(e);if(f!=-1&&f<d){c=e;d=f}}p=c?a[c]:null}
function q(a,b,c){if(c){var d;if(a=="script"){d=document.createElement("script");d.type="text/javascript";d.src=b}else if(a=="css"){d=document.createElement("link");d.type="text/css";d.href=b;d.rel="stylesheet"}var e=document.getElementsByTagName("head")[0];if(!e){e=document.body.parentNode.appendChild(document.createElement("head"))}e.appendChild(d)}else{if(a=="script"){document.write('<script src="'+b+'" type="text/javascript"><\/script>')}else if(a=="css"){document.write('<link href="'+b+'" type="text/css" rel="stylesheet"></link>'
)}}}
function g(a,b){var c=a.split(/\./);var d=window;for(var e=0;e<c.length-1;e++){if(!d[c[e]]){d[c[e]]={}}d=d[c[e]]}d[c[c.length-1]]=b}
function M(a,b,c){a[b]=c}
function S(a){t=a}
g("google.load",O);g("google.setOnLoadCallback",V);g("google.loader.writeLoadTag",q);g("google.loader.setApiKeyLookupMap",T);g("google.loader.callbacks",D);g("google.loader.eval",R);g("google.loader.rfm",S);g("google_exportSymbol",g);g("google_exportProperty",M);
function i(a){this.a=a;this.m={};this.b={};this.initialLoad=true}
i.prototype.e=function(a,b){var c="";if(b!=undefined){if(b["language"]!=undefined){c+="&hl="+encodeURIComponent(b["language"])}if(b["nocss"]!=undefined){c+="&output="+encodeURIComponent("nocss="+b["nocss"])}if(b["nooldnames"]!=undefined){c+="&nooldnames="+encodeURIComponent(b["nooldnames"])}if(b["packages"]!=undefined){c+="&packages="+encodeURIComponent(b["packages"])}if(b["callback"]!=null){c+="&async=2"}if(b["other_params"]!=undefined){c+="&"+b["other_params"]}}if(!this.initialLoad){c+="&output="
+encodeURIComponent("noinitial=true");if(google[this.a]&&google[this.a].JSHash){c+="&sig="+encodeURIComponent(google[this.a].JSHash)}}if(p!=null&&!H){c+="&key="+encodeURIComponent(p);H=true}return google.loader.ServiceBase+"/?file="+this.a+"&v="+a+google.loader.AdditionalParams+c}
;i.prototype.k=function(a){var b=null;if(a){b=a["packages"]}var c=null;if(b){if(typeof b=="string"){c=[a["packages"]]}else if(b.length){c=[];for(var d=0;d<b.length;d++){if(typeof b[d]=="string"){c.push(b[d].replace(/^\s*|\s*$/,"").toLowerCase())}}}}if(!c){c=["default"]}var e=[];for(var d=0;d<c.length;d++){if(!this.m[":"+c[d]]){e.push(c[d])}}return e}
;i.prototype.h=function(a,b){var c=this.k(b);var d=b&&b["callback"]!=null;if(d){var e=new v(b["callback"])}for(var f=c.length-1;f>=0;f--){var k=c[f];if(this.b[":"+k]){c.splice(f,1)}else{this.b[":"+k]=[]}if(d){e.r(k);this.b[":"+k].push(e)}}if(c.length){if(b&&b["packages"]){b["packages"]=c.sort().join(",")}if(!b&&t[":"+this.a]!=null&&t[":"+this.a].versions[":"+a]!=null&&!google.loader.AdditionalParams&&this.initialLoad){var l=t[":"+this.a];google[this.a]=google[this.a]||{};for(var r in l.properties)
{if(r&&r.charAt(0)==":"){google[this.a][r.substring(1)]=l.properties[r]}}q("script",google.loader.ServiceBase+l.path+l.js,d);if(l.css){q("css",google.loader.ServiceBase+l.path+l.css,d)}}else{q("script",this.e(a,b),d)}if(this.initialLoad){this.initialLoad=false}}}
;i.prototype.f=function(a){for(var b=0;b<a.components.length;b++){this.m[":"+a.components[b]]=true;var c=this.b[":"+a.components[b]];if(c){for(var d=0;d<c.length;d++){c[d].t(a.components[b])}delete this.b[":"+a.components[b]]}}w("hl",this.a)}
;i.prototype.g=function(a,b){return this.k(b).length==0}
;i.prototype.p=function(){return true}
;function v(a){this.s=a;this.d={};this.i=0}
v.prototype.r=function(a){this.i++;this.d[":"+a]=true}
;v.prototype.t=function(a){if(this.d[":"+a]){this.d[":"+a]=false;this.i--;if(this.i==0){window.setTimeout(this.s,0)}}}
;function Q(a){j[":"+a.module].f(a)}
g("google.loader.loaded",Q);
function h(a,b,c,d,e,f,k){this.a=a;this.z=b;this.w=c;this.l=d;this.q=e;this.v=f;this.o=k||{};this.n=false;this.j=false;this.c=[];D[this.a]=K(this.f,this)}
N(h,i);h.prototype.h=function(a,b){var c=b&&b["callback"]!=null;if(c){this.c.push(b["callback"]);b["callback"]="google.loader.callbacks."+this.a}else{this.n=true}q("script",this.e(a,b),c)}
;h.prototype.g=function(a,b){var c=b&&b["callback"]!=null;if(c){return this.j}else{return this.n}}
;h.prototype.f=function(){this.j=true;for(var a=0;a<this.c.length;a++){window.setTimeout(this.c[a],0)}this.c=[]}
;h.prototype.e=function(a,b){var c="";if(this.l!=null){c+="&"+this.l+"="+encodeURIComponent(p?p:google.loader.ApiKey)}if(this.q!=null){c+="&"+this.q+"="+encodeURIComponent(a)}var d=this.z;if(b!=null){for(var e in b){if(this.o[":"+e]!=null){var f=b[e];var k=this.o[":"+e];if(typeof k=="string"){c+="&"+k+"="+encodeURIComponent(f)}else{c+="&"+k(f)}}else if(e=="other_params"){c+="&"+b[e]}else if(e=="base_domain"){d=d.replace(/^[^\/]*/,b[e])}}}google[this.a]={};if(!this.w&&c!=""){c="?"+c.substring(1)}w(
"el",this.a);return"http://"+d+c}
;h.prototype.p=function(){return this.v}
;
function m(){}
var A=m.u=false;var I=m.A=5;var o=m.D=[];var J=m.C=function(){if(!A){x(window,"unload",z);A=(m.u=true)}}
;var w=m.record=function(a,b){J();var c=a+(b?"|"+b:"");o.push("r"+o.length+"="+encodeURIComponent(c));var d=o.length>I?0:15000;window.setTimeout(z,d)}
;var z=m.B=function(){if(o.length){var a=new Image;a.src=google.loader.ServiceBase+"/stats?"+o.join("&")+"&nocache="+Number(new Date);o.length=0}}
;g("google.loader.recordStat",w);
j[":search"]=new i("search");j[":feeds"]=new i("feeds");j[":language"]=new i("language");j[":maps"]=new h("maps","maps.google.com/maps?file=googleapi",true,"key","v",true,{":language":"hl",":callback":function(a){return"callback="+encodeURIComponent(a)+"&async=2"}
});j[":gdata"]=new h("gdata","gd.google.com/gd/api?file=gdata.js",true,"key","v",true,{":callback":"callback"});j[":sharing"]=new h("sharing","www.google.com/s2/sharing/js",false,"key","v",false,{":locale":"hl"});j[":annotations"]=new h("annotations","www.google.com/reviews/scripts/annotations_bootstrap.js",false,"key","v",true,{":language":"hl",":country":"gl",":callback":"callback"});j[":visualization"]=new i("visualization");j[":books"]=new h("books","books.google.com/books/api.js",false,"key"
,"v",true,{":language":"hl",":callback":"callback"});

 })()

}
if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['search']) {
window['google']['search'] = {};
google.search.CurrentLocale = 'en';
google.search.ShortDatePattern = 'MDY';
google.search.Version = '1.0';
google.search.NoOldNames = false;
google.search.JSHash = '582c1116317355adf613a6a843f19ece';
google.loader.ApiKey = 'notsupplied';
google.loader.KeyVerified = true;
google.loader.LoadFailure = false;
}
google.loader.writeLoadTag("script", google.loader.ServiceBase + "/api/search/1.0/en/582c1116317355adf613a6a843f19ece/default.I.js", false);
}
var error = new Error("AJAX Search API Load Failure: Ivalid version argument: null");
error.toString = function() { return this.message; }
throw error;
