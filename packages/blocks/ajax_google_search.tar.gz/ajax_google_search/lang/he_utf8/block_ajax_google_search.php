<?php // $Id: block_googleapi_search.php,v 1.1 2005/03/22 00:43:03 stronk7 Exp $

$string['blockname'] = 'חיפוש בעזרת גוגל';

$string['poweredby'] = 'החיפוש מתבצע בעזרת...';
$string['theweb'] = 'חיפוש ברשת';
$string['thissite'] = 'חיפוש באתר זה';

$string['introtext'] = 'תוצאות החיפוש יופיע תוך כדי הקלדה. 
                        <br />השתמשו בכפתור ESC לניקוי החיפוש';

$string['adminview'] = 'This code requires you have a valid API key from google.<br>Please enter it below.';
$string['getkey'] = 'If you do not have a key, <a href=\"http://code.google.com/apis/ajaxsearch/signup.html\" target=\"_new\">click here</a> to aquire one from Google. <br>This is a free service';


?>
