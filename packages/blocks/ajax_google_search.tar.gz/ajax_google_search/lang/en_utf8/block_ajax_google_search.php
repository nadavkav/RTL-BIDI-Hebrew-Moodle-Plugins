<?php // $Id: block_googleapi_search.php,v 1.1 2005/03/22 00:43:03 stronk7 Exp $

$string['blockname'] = 'Google Search';

$string['poweredby'] = 'powered by';
$string['theweb'] = 'The Web';
$string['thissite'] = 'This Site';

$string['introtext'] = 'You can type anywhere on the page, and the search results will be updated. 
                        <br />Use ESC key to clear the search results';

$string['adminview'] = 'This code requires you have a valid API key from google.<br>Please enter it below.';
$string['getkey'] = 'If you do not have a key, <a href=\"http://code.google.com/apis/ajaxsearch/signup.html\" target=\"_new\">click here</a> to aquire one from Google. <br>This is a free service';


?>
