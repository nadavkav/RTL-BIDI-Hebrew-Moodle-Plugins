<?php // $Id: block_usage.php,v 1.5 2008/10/21 16:19:09 jcoelho Exp $

/*
 * Tables used: mdl_log; mdl_forum_posts
 * Tables edited: none
 *
 * */

class block_usage extends block_base {

    function init() {
        $this->title = get_string('blockname','block_usage');
        $this->content_type = BLOCK_TYPE_TEXT;
        $this->version = 2008102101;
        $this->cron = 1;
    }

    // global configuration ($CFG->block_usage_*)
    function has_config() {
        return true;
    }

    // instance configuration ($this->config->*)
    function instance_allow_config() {
        return true;
    }

    function after_install() {
        // set default values
        set_config('block_usage_colormsg','green');
        set_config('block_usage_colorpv','blue');
        set_config('block_usage_colorusr','orange');
        set_config('block_usage_default_graph',2);
        set_config('block_usage_graph_data','');
        set_config('block_usage_height',100);
        set_config('block_usage_ndays',30);
        set_config('block_usage_nhours',24);
        set_config('block_usage_nmonths',12);
        set_config('block_usage_onmsg',1);
        set_config('block_usage_onpv',1);
        set_config('block_usage_onusr',1);
        set_config('block_usage_typemsg',1);
        set_config('block_usage_typepv',2);
        set_config('block_usage_typeusr',1);
        set_config('block_usage_width',200);
    }

    function instance_create() {
        global $CFG,$COURSE;

        $this->config->block_usage_nmonths=$CFG->block_usage_nmonths;
        $this->config->block_usage_ndays=$CFG->block_usage_ndays;
        $this->config->block_usage_nhours=$CFG->block_usage_nhours;
        $this->config->block_usage_default_graph=$CFG->block_usage_default_graph;
        $this->config->block_usage_onpv=$CFG->block_usage_onpv;
        $this->config->block_usage_typepv=$CFG->block_usage_typepv;
        $this->config->block_usage_colorpv=$CFG->block_usage_colorpv;
        $this->config->block_usage_onusr=$CFG->block_usage_onusr;
        $this->config->block_usage_typeusr=$CFG->block_usage_typeusr;
        $this->config->block_usage_colorusr=$CFG->block_usage_colorusr;
        $this->config->block_usage_onmsg=$CFG->block_usage_onmsg;
        $this->config->block_usage_typemsg=$CFG->block_usage_typemsg;
        $this->config->block_usage_colormsg=$CFG->block_usage_colormsg;
        $this->config->block_usage_width=$CFG->block_usage_width;
        $this->config->block_usage_height=$CFG->block_usage_height;

        $this->get_data(1,$COURSE->id);
        $this->get_data(1,$COURSE->id);
        $this->instance_config_commit();

        return true;
    }

    function before_delete() {
        // delete all configuration variables
        execute_sql("DELETE FROM mdl_config WHERE name LIKE 'block_usage_%'");
        // see moodle/admin/modules.php, there is a command close to this one
        // Note: if a dynamic prefix is used, the command does not work
    }

    ///////////////////////////////////////////////
    // auxiliar functions
    ///////////////////////////////////////////////

    function short_number($value)
    {
        if($value<1000) return $value;
        $value/=1000;
        if($value<1000) {
            if($value>100) return round($value,0)."k";
            else if($value>10) return round($value,1)."k";
            return round($value,2)."k";
        }
        $value/=1000;
        if($value<1000) {
            if($value>100) return round($value,0)."M";
            else if($value>10) return round($value,1)."M";
            return round($value,2)."M";
        }
        $value/=1000;
        if($value<1000) {
            if($value>100) return round($value,0)."G";
            else if($value>10) return round($value,1)."G";
            return round($value,2)."G";
        }
        $value/=1000;
        if($value>100) return round($value,0)."T";
        else if($value>10) return round($value,1)."T";
        return round($value,2)."T";

    }

    //////////////////////////////////////////////////////////////////////////////
    // Data structure:
    // $data['valid'=0,'pv'=1,'msg'=2,'usr'=3]
    //      ['month'=0,'day'=1,'hour'=2]
    //      [1-30]
    // Note: arrays do not use key values, only numbers
    //       the keys are here only to describe the multi-dimension array
    //////////////////////////////////////////////////////////////////////////////

    // implode all data arrays to a string,
    // for saving in configuration file
    function data_to_string($value)
    {
        $varl1=array();
        for($i=0;$i<=3;$i+=1) { // vality, pv, msg, usr
            $varl2=array();
            for($j=0;$j<=2;$j+=1) { // month, day, hour
                $varl2[$j]=implode(",", $value[$i][$j]);
            }
            $varl1[$i]=implode(";",$varl2);
        }

        return implode(":",$varl1);
    }

    // explode the data configuration string
    // into data arrays with information to show on graph
    function string_to_data($value)
    {
        $ok=true;
        $return_data=array(array(array(),array(),array()),
                            array(array(),array(),array()),
                            array(array(),array(),array()),
                            array(array(),array(),array()));
        $varl1=explode(":",$value);
        if(count($varl1)==4) {
            for($i=0;$i<=3;$i+=1) { // vality, pv, msg, usr
                $varl2=explode(";",$varl1[$i]);
                if(count($varl2)==3) {
                    for($j=0;$j<=2;$j+=1) { // month, day, hour
                        $return_data[$i][$j]=explode(",",$varl2[$j]);
                    }
                } else $ok=false;
            }
        } else $ok=false;

        if(!$ok) { // init the data structure
            for($i=0;$i<=3;$i+=1)
                for($j=0;$j<=2;$j+=1)
                    $return_data[$i][$j]=array("0");
        }
        return $return_data;
    }

    ///////////////////////////////////////////////
    // queries
    ///////////////////////////////////////////////

    // Month page views query
    function month_usage_pv($i,$monthi,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    month( FROM_UNIXTIME( time ) ) AS M,
    Count(*) AS PV
FROM '.$CFG->prefix.'log
WHERE
    '.$str.'
    time >= UNIX_TIMESTAMP(
      DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.$i.' MONTH),INTERVAL DAY(CURDATE())-1 DAY) ) AND
    time < UNIX_TIMESTAMP(
      DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' MONTH),INTERVAL DAY(CURDATE())-1 DAY) )
GROUP BY M;
');
        if(!empty($result))
            foreach($result AS $month)
                if($month->M==$monthi) {
                    return $month->PV;
                }
        return 0;
    }

    // Month messages query
    function month_usage_msg($i,$monthi,$courseid) {
        global $CFG;
        $str=' WHERE ';
        if($courseid>1)
            $str='INNER JOIN '.$CFG->prefix.'forum_discussions fd
                 ON fp.discussion=fd.id
                 WHERE
                     fd.course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    month( FROM_UNIXTIME( fp.modified ) ) AS M,
    Count(*) AS MSG
FROM '.$CFG->prefix.'forum_posts fp
'.$str.'
    fp.modified >= UNIX_TIMESTAMP(
      DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.$i.' MONTH),INTERVAL DAY(CURDATE())-1 DAY) ) AND
    fp.modified < UNIX_TIMESTAMP(
      DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' MONTH),INTERVAL DAY(CURDATE())-1 DAY) )
GROUP BY M;
');
        if(!empty($result))
            foreach($result AS $month)
                if($month->M==$monthi) {
                    return $month->MSG;
                }
        return 0;
    }

    // Month users query
    function month_usage_usr($i,$monthi,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT M, Count(*) AS USR
FROM (
    SELECT
        month( FROM_UNIXTIME( time ) ) AS M,
        userid
    FROM '.$CFG->prefix.'log
    WHERE
        '.$str.'
        time >= UNIX_TIMESTAMP(
          DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.$i.' MONTH),INTERVAL DAY(CURDATE())-1 DAY) ) AND
        time < UNIX_TIMESTAMP(
          DATE_SUB(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' MONTH),INTERVAL DAY(CURDATE())-1 DAY) )
    GROUP BY M, userid
) AS AUX
GROUP BY M;
');
        if(!empty($result))
            foreach($result AS $month)
                if($month->M==$monthi) {
                    return $month->USR;
                }
        return 0;
    }

    // Day page views query
    function day_usage_pv($i,$dayi,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    day( FROM_UNIXTIME( time ) ) AS D, Count(*) AS PV
FROM '.$CFG->prefix.'log
WHERE
    '.$str.'
    time >= UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.$i.' DAY))  AND
    time < UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' DAY))
GROUP BY D;
');
        if(!empty($result))
            foreach($result AS $day)
                if($day->D==$dayi) {
                    return $day->PV;
                }
        return 0;
    }


    // Day messages query
    function day_usage_msg($i,$dayi,$courseid) {
        global $CFG;
        $str=' WHERE ';
        if($courseid>1)
            $str='INNER JOIN '.$CFG->prefix.'forum_discussions fd
                 ON fp.discussion=fd.id
                 WHERE
                     fd.course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    day( FROM_UNIXTIME( fp.modified ) ) AS D, Count(*) AS MSG
FROM '.$CFG->prefix.'forum_posts fp
'.$str.'
    fp.modified >= UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.$i.' DAY))  AND
    fp.modified < UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' DAY))
GROUP BY D
');
        if(!empty($result))
            foreach($result AS $day)
                if($day->D==$dayi) {
                    return $day->MSG;
                }
        return 0;
    }

    // Day users query
    function day_usage_usr($i,$dayi,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT D, Count(*) AS USR
FROM (
    SELECT
        day( FROM_UNIXTIME( time ) ) AS D, userid
    FROM '.$CFG->prefix.'log
    WHERE
        '.$str.'
        time >= UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.$i.' DAY))  AND
        time < UNIX_TIMESTAMP(DATE_SUB(CURDATE(),INTERVAL '.($i-1).' DAY))
    GROUP BY D, userid
) AS AUX
GROUP BY D;
');
        if(!empty($result))
            foreach($result AS $day)
                if($day->D==$dayi) {
                    return $day->USR;
                }
        return 0;
    }

    // Hour page views query
    function hour_usage_pv($i,$houri,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    hour( FROM_UNIXTIME( time ) ) AS H, Count(*) AS PV
FROM '.$CFG->prefix.'log
WHERE
    '.$str.'
    time >= UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.$i.',Minute(NOW()),Second(NOW()))))  AND
    time < UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.($i-1).',Minute(NOW()),Second(NOW()))))
GROUP BY H;
');
        if(!empty($result))
            foreach($result AS $hour)
                if($hour->H==$houri-1) {
                    return $hour->PV;
                }
        return 0;
    }

    // Hour messages query
    function hour_usage_msg($i,$houri,$courseid) {
        global $CFG;
        $str=' WHERE ';
        if($courseid>1)
            $str='INNER JOIN '.$CFG->prefix.'forum_discussions fd
                 ON fp.discussion=fd.id
                 WHERE
                     fd.course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT
    hour( FROM_UNIXTIME( fp.modified ) ) AS H, Count(*) AS MSG
FROM '.$CFG->prefix.'forum_posts fp
'.$str.'
    fp.modified >= UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.$i.',Minute(NOW()),Second(NOW()))))  AND
    fp.modified < UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.($i-1).',Minute(NOW()),Second(NOW()))))
GROUP BY H
');
        if(!empty($result))
            foreach($result AS $hour)
                if($hour->H==$houri-1) {
                    return $hour->MSG;
                }
        return 0;
    }

    // Hour users query
    function hour_usage_usr($i,$houri,$courseid) {
        global $CFG;
        $str='';
        if($courseid>1)
            $str='course='.$courseid.' AND ';
        $result = get_records_sql('
SELECT H, Count(*) AS USR
FROM (
    SELECT
        hour( FROM_UNIXTIME( time ) ) AS H, userid
    FROM '.$CFG->prefix.'log
    WHERE
        '.$str.'
        time >= UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.$i.',Minute(NOW()),Second(NOW()))))  AND
        time < UNIX_TIMESTAMP(SUBTIME(NOW(),MAKETIME('.($i-1).',Minute(NOW()),Second(NOW()))))
    GROUP BY H, userid
) AS AUX
GROUP BY H;
');
        if(!empty($result))
            foreach($result AS $hour)
                if($hour->H==$houri-1) {
                    return $hour->USR;
                }
        return 0;
    }


    // only global site usage is calculated
    function applicable_formats() {
        return array('site' => true, 'course-view' => true);
    }

    // mdl_log used in cron, when the hour, day or month changes
    function cron()
    {
        // process global site usage, and all usage instances
        // but stop if a time limit is reached (default: 60 seconds)
        $starttime =  microtime();
        if($block = get_record('block','name','usage')) {
            // process instances
            $instances = get_records('block_instance', 'blockid', $block->id, 'pageid');
            if(!empty($instances)) {
                foreach($instances as $instance) {
                    echo ' '.$instance->pageid;
                    $this->_load_instance($instance);
                    if($this->get_data(1,$instance->pageid)) {
                        $this->instance_config_commit();
                        echo '*';
                    }
                    // if takes more than 60 seconds, exist (finish updating in the next cron)
                    if(microtime_diff($starttime, microtime())>=60) {
                        echo ' time out.';
                        break;
                    }
                }
            }
        }
        return true;
    }

    function get_data($can_calculate,$courseid)
    {
        global $CFG;
        ///////////////////////////////////////////////
        // initializations
        ///////////////////////////////////////////////

        $updating=0;

        // number of elements to monitor
        $nmonths=$this->config->block_usage_nmonths;
        $ndays=$this->config->block_usage_ndays;
        $nhours=$this->config->block_usage_nhours;

        if($nmonths>12) $nmonths=12;
        if($nmonths<2) $nmonths=2;

        if($ndays>30) $ndays=30;
        if($ndays<2) $ndays=2;

        if($nhours>24) $nhours=24;
        if($nhours<2) $nhours=2;

        $monthi=array();
        $dayi=array();
        $houri=array();

        $graph_data=$this->string_to_data($this->config->block_usage_graph_data);
//        print_r($graph_data); // debug checking data structure

        ///////////////////////////////////////////////
        // Verification
        ///////////////////////////////////////////////

        // use time from the database, since the frontend
        // clock can be not sincronized
        $result=get_records_sql(
'SELECT
    Month(NOW()) AS M,
    Day(NOW()) AS D,
    Hour(NOW()) AS H');

        if(!empty($result))
            foreach($result AS $date) {
                $monthdate=$date->M;
                $daydate=$date->D;
                $hourdate=$date->H+1;  // avoid the hour 0 (equal to empty)
            }

        // $monthi (is the month i elements ago)
        for($i=1;$i<=$nmonths;$i+=1) {
            $monthi[$i]=$monthdate-$i;
            if($monthi[$i]<1) $monthi[$i]+=12;
        }

        // verify the distant month first, and only then the shortest one
        for($i=$nmonths;$i>0;$i-=1) {
            if(empty($graph_data[0][0][$i]) || // [valid=0][month=0]
                $graph_data[0][0][$i]!=$monthi[$i])
            {
                // search for the months that are not calculated
                $graph_data[0][0][$i]='';
                for($j=$i-1;$j>0;$j-=1)
                    if($graph_data[0][0][$j]==$monthi[$i]) {
                        $graph_data[1][0][$i]=$graph_data[1][0][$j]; // [pv=1]
                        $graph_data[2][0][$i]=$graph_data[2][0][$j]; // [msg=2]
                        $graph_data[3][0][$i]=$graph_data[3][0][$j]; // [usr=3]
                        $graph_data[0][0][$i]=$monthi[$i];
                        break;
                    }
                if($graph_data[0][0][$i]!=$monthi[$i]) {
                    // was not calculated
                    if($can_calculate==1) {
                        $graph_data[1][0][$i]=$this->month_usage_pv($i,$monthi[$i],$courseid);
                        $graph_data[2][0][$i]=$this->month_usage_msg($i,$monthi[$i],$courseid);
                        $graph_data[3][0][$i]=$this->month_usage_usr($i,$monthi[$i],$courseid);
                        $updating=1;
                    } else {
                        $graph_data[1][0][$i]=0;
                        $graph_data[2][0][$i]=0;
                        $graph_data[3][0][$i]=0;
                    }
                    $graph_data[0][0][$i]=$monthi[$i];
                }
            }
        }

        $dmonth=array(0,31,28,31,30,31,30,31,31,30,31,30,31);

        // diai (is the day i elements ago)
        for($i=1;$i<=$ndays;$i+=1) {
            $dayi[$i]=$daydate-$i;
            if($dayi[$i]<1) $dayi[$i]+=$dmonth[$monthi[1]];
        }

        // verify the distant day first
        for($i=$ndays;$i>0;$i-=1) {
            if(empty($graph_data[0][1][$i]) || // [valid=0][day=1]
                $graph_data[0][1][$i]!=$dayi[$i])
            {
                // search for the missing days
                $graph_data[0][1][$i]='';
                for($j=$i-1;$j>0;$j-=1)
                    if($graph_data[0][1][$j]==$dayi[$i]) {
                        $graph_data[1][1][$i]=$graph_data[1][1][$j]; // [pv=1]
                        $graph_data[2][1][$i]=$graph_data[2][1][$j]; // [msg=2]
                        $graph_data[3][1][$i]=$graph_data[3][1][$j]; // [usr=3]
                        $graph_data[0][1][$i]=$dayi[$i];
                        break;
                    }
                if($graph_data[0][1][$i]!=$dayi[$i]) {
                    // was not calculated
                    if($can_calculate==1) {
                        $graph_data[1][1][$i]=$this->day_usage_pv($i,$dayi[$i],$courseid);
                        $graph_data[2][1][$i]=$this->day_usage_msg($i,$dayi[$i],$courseid);
                        $graph_data[3][1][$i]=$this->day_usage_usr($i,$dayi[$i],$courseid);
                        $updating=1;
                    } else {
                        $graph_data[1][1][$i]=0;
                        $graph_data[2][1][$i]=0;
                        $graph_data[3][1][$i]=0;
                    }
                    $graph_data[0][1][$i]=$dayi[$i];
                }
            }
        }

        // horai (is the hour i elements ago)
        for($i=1;$i<=$nhours;$i+=1) {
            $houri[$i]=$hourdate-$i;
            if($houri[$i]<1) $houri[$i]+=24;
        }

        // verify first the distant hour
        for($i=$nhours;$i>0;$i-=1) {
            if(empty($graph_data[0][2][$i]) ||  // [valid=0][hour=2]
                $graph_data[0][2][$i]!=$houri[$i])
            {
                // search for the missing hours
                $graph_data[0][2][$i]='';
                for($j=$i-1;$j>0;$j-=1)
                    if($graph_data[0][2][$j]==$houri[$i]) {
                        $graph_data[1][2][$i]=$graph_data[1][2][$j]; // [pv=1]
                        $graph_data[2][2][$i]=$graph_data[2][2][$j]; // [msg=2]
                        $graph_data[3][2][$i]=$graph_data[3][2][$j]; // [usr=3]
                        $graph_data[0][2][$i]=$houri[$i];
                        break;
                    }
                if($graph_data[0][2][$i]!=$houri[$i]) {
                    // was not calculated
                    if($can_calculate==1) {
                        $graph_data[1][2][$i]=$this->hour_usage_pv($i,$houri[$i],$courseid);
                        $graph_data[2][2][$i]=$this->hour_usage_msg($i,$houri[$i],$courseid);
                        $graph_data[3][2][$i]=$this->hour_usage_usr($i,$houri[$i],$courseid);
                        $updating=1;
                    } else {
                        $graph_data[1][2][$i]=0;
                        $graph_data[2][2][$i]=0;
                        $graph_data[3][2][$i]=0;
                    }
                    $graph_data[0][2][$i]=$houri[$i];
                }
            }
        }

        ///////////////////////////////////////////////
        // save the data
        ///////////////////////////////////////////////

        if($updating==1) {
            $this->config->block_usage_graph_data = $this->data_to_string($graph_data);
            return true;
        } else if($can_calculate==1) {
            return false;
        }

        return $graph_data;
    }


    function get_content() {
        global $CFG,$COURSE;
        $output='';


        if ($this->content !== NULL) {
            return $this->content;
        }

        ///////////////////////////////////////////////
        // initializations
        ///////////////////////////////////////////////

        $nmonths=$this->config->block_usage_nmonths;
        $ndays=$this->config->block_usage_ndays;
        $nhours=$this->config->block_usage_nhours;

        if($nmonths>12) $nmonths=12;
        if($nmonths<2) $nmonths=2;

        if($ndays>30) $ndays=30;
        if($ndays<2) $ndays=2;

        if($nhours>24) $nhours=24;
        if($nhours<2) $nhours=2;


        // get the data without calculating
        $graph_data=$this->get_data(0,$COURSE->id);


        ///////////////////////////////////////////////
        // Build the output (graph and table)
        ///////////////////////////////////////////////

        $monthname=explode(",",get_string('monthname','block_usage'));
        $shortmonthname=explode(",",get_string('shortmonthname','block_usage'));

        ////////////////////////////////////////////////////////////////////////
        // image: pass to the graph all config information, and data information
        // one image for each scale (month/day/hour), all needed to be setup now
        // Note that the imagens will be build in graph.php, using the arguments specified here
        $imgmonth = '<img src="'.$CFG->wwwroot.'/blocks/usage/graph.php?course_id=1';
        $imgmonth .= '&nrows='.$nmonths;
        $imgmonth .= '&onpv='.$this->config->block_usage_onpv;
        $imgmonth .= '&onusr='.$this->config->block_usage_onusr;
        $imgmonth .= '&onmsg='.$this->config->block_usage_onmsg;
        $imgmonth .= '&width='.$this->config->block_usage_width;
        $imgmonth .= '&height='.$this->config->block_usage_height;
        $imgmonth .= '&colorpv='.$this->config->block_usage_colorpv;
        $imgmonth .= '&colorusr='.$this->config->block_usage_colorusr;
        $imgmonth .= '&colormsg='.$this->config->block_usage_colormsg;
        $imgmonth .= '&typepv='.$this->config->block_usage_typepv;
        $imgmonth .= '&typeusr='.$this->config->block_usage_typeusr;
        $imgmonth .= '&typemsg='.$this->config->block_usage_typemsg;
        $imgmonth .= '&msg=1';
        $imgmonth .= '&d3='.implode(";",$graph_data[2][0]);
        $imgmonth .= '&d1='.implode(";",$graph_data[1][0]);
        $imgmonth .= '&d2='.implode(";",$graph_data[3][0]);
        for($i=1;$i<=$nmonths;$i+=1) {
            if($nmonths<4)
                $imgmonth .= '&lx'.($i-1).'='.$monthname[$graph_data[0][0][$i]-1];
            else if($nmonths<=6)
                $imgmonth .= '&lx'.($i-1).'='.$shortmonthname[$graph_data[0][0][$i]-1];
            else if($graph_data[0][0][$i]==1 || $graph_data[0][0][$i]==3 || $graph_data[0][0][$i]==5 || $graph_data[0][0][$i]==7 ||
                    $graph_data[0][0][$i]==9 || $graph_data[0][0][$i]==11)
                $imgmonth .= '&lx'.($i-1).'='.$shortmonthname[$graph_data[0][0][$i]-1];
        }
        $imgmonth .= '" ALT="'.get_string('months','block_usage').'" OnClick="detmonths()"/>';

        $imgday = '<img src="'.$CFG->wwwroot.'/blocks/usage/graph.php?course_id=1';
        $imgday .= '&nrows='.$ndays;
        $imgday .= '&onpv='.$this->config->block_usage_onpv;
        $imgday .= '&onusr='.$this->config->block_usage_onusr;
        $imgday .= '&onmsg='.$this->config->block_usage_onmsg;
        $imgday .= '&width='.$this->config->block_usage_width;
        $imgday .= '&height='.$this->config->block_usage_height;
        $imgday .= '&colorpv='.$this->config->block_usage_colorpv;
        $imgday .= '&colorusr='.$this->config->block_usage_colorusr;
        $imgday .= '&colormsg='.$this->config->block_usage_colormsg;
        $imgday .= '&typepv='.$this->config->block_usage_typepv;
        $imgday .= '&typeusr='.$this->config->block_usage_typeusr;
        $imgday .= '&typemsg='.$this->config->block_usage_typemsg;
        $imgday .= '&msg=1';
        $imgday .= '&d3='.implode(";",$graph_data[2][1]);
        $imgday .= '&d1='.implode(";",$graph_data[1][1]);
        $imgday .= '&d2='.implode(";",$graph_data[3][1]);
        for($i=1;$i<=$ndays;$i+=1) {
            if($ndays<=7 || $i==7 || $i==14 || $i==21 || $i==28)
                $imgday .= '&lx'.($i-1).'='.$graph_data[0][1][$i];
        }
        $imgday .= '" ALT="'.get_string('days','block_usage').'" OnClick="detdays()"/>';

        $imghour = '<img src="'.$CFG->wwwroot.'/blocks/usage/graph.php?course_id=1';
        $imghour .= '&nrows='.$nhours;
        $imghour .= '&onpv='.$this->config->block_usage_onpv;
        $imghour .= '&onusr='.$this->config->block_usage_onusr;
        $imghour .= '&onmsg='.$this->config->block_usage_onmsg;
        $imghour .= '&width='.$this->config->block_usage_width;
        $imghour .= '&height='.$this->config->block_usage_height;
        $imghour .= '&colorpv='.$this->config->block_usage_colorpv;
        $imghour .= '&colorusr='.$this->config->block_usage_colorusr;
        $imghour .= '&colormsg='.$this->config->block_usage_colormsg;
        $imghour .= '&typepv='.$this->config->block_usage_typepv;
        $imghour .= '&typeusr='.$this->config->block_usage_typeusr;
        $imghour .= '&typemsg='.$this->config->block_usage_typemsg;
        $imghour .= '&msg=1';
        $imghour .= '&d3='.implode(";",$graph_data[2][2]);
        $imghour .= '&d1='.implode(";",$graph_data[1][2]);
        $imghour .= '&d2='.implode(";",$graph_data[3][2]);
        for($i=1;$i<=$nhours;$i+=1) {
            if($nhours<=8 || $graph_data[0][2][$i]==24 || $graph_data[0][2][$i]==6 ||
                $graph_data[0][2][$i]==12 || $graph_data[0][2][$i]==18) {
                $imghour .= '&lx'.($i-1).'='.$graph_data[0][2][$i].'h';
            }
        }
        $imghour .= '" ALT="'.get_string('hours','block_usage').'" OnClick="dethours()"/>';


        ////////////////////////////////////////////////////////////////////////
        // tables (data information to be shown when the user click on the graph)

        $tabmonth = '<table border="2"><tr><th></th><th>PV</th>';
        $tabmonth .= '<th>MSG</th>';
        $tabmonth .= '<th>USR</th></tr>';

        for($i=1;$i<=$nmonths;$i+=1) {
            $tabmonth .= '<tr><td>'.$monthname[$graph_data[0][0][$i]-1].'</td><td>';
            $tabmonth .= $this->short_number($graph_data[1][0][$i]).'</td><td>';
            $tabmonth .= $this->short_number($graph_data[2][0][$i]).'</td><td>';
            $tabmonth .= $this->short_number($graph_data[3][0][$i]).'</td></tr>';
        }
        $tabmonth .= '</table>';

        $tabday = '<table border="2"><tr><th></th><th>PV</th>';
        $tabday .= '<th>MSG</th>';
        $tabday .= '<th>USR</th></tr>';

        for($i=1;$i<=$ndays;$i+=1) {
            $tabday .= '<tr><td>'.$graph_data[0][1][$i].'</td><td>';
            $tabday .= $this->short_number($graph_data[1][1][$i]).'</td><td>';
            $tabday .= $this->short_number($graph_data[2][1][$i]).'</td><td>';
            $tabday .= $this->short_number($graph_data[3][1][$i]).'</td></tr>';
        }
        $tabday .= '</table>';

        $tabhour = '<table border="2"><tr><th></th><th>PV</th>';
        $tabhour .= '<th>MSG</th>';
        $tabhour .= '<th>USR</th></tr>';
        for($i=1;$i<=$nhours;$i+=1) {
            if($graph_data[0][2][$i]==0)
                $tabhour .= '<tr><td>24h</td><td>';
            else $tabhour .= '<tr><td>'.$graph_data[0][2][$i].'h</td><td>';
            $tabhour .= $this->short_number($graph_data[1][2][$i]).'</td><td>';
            $tabhour .= $this->short_number($graph_data[2][2][$i]).'</td><td>';
            $tabhour .= $this->short_number($graph_data[3][2][$i]).'</td></tr>';
        }
        $tabhour .= '</table>';

        $legend = '<ul><li>PV - '.get_string('pv','block_usage').'</li>';
        $legend .= '<li>MSG - '.get_string('msg','block_usage').'</li>';
        $legend .= '<li>USR - '.get_string('usr','block_usage').'</li></ul>';


        $output .= '<table><tr><td colspan="3" id="graph" name="graph">';
        if($this->config->block_usage_default_graph==1) $output.=$imgmonth.'</td></tr>';
        else if($this->config->block_usage_default_graph==3) $output.=$imghour.'</td></tr>';
        else $output .= $imgday.'</td></tr>';
        $output .= '<tr><td name="months"><input type="button" value="'.get_string('months','block_usage').'" OnClick="selmonths()"/></td>
                        <td name="days"><input type="button" value="'.get_string('days','block_usage').'" OnClick="seldays()"/></td>
                        <td name="hours"><input type="button" value="'.get_string('hours','block_usage').'" OnClick="selhours()"/></td></tr>
                    <tr><td colspan="3" id="detail" name="detail"></td></tr></table>';

        $output .= "
<script language='javascript'>
    var months, days, hours, dmonths, ddays, dhours;
    var tdgraph = document.getElementById('graph');
    var tdmonths = document.getElementById('months');
    var tddays = document.getElementById('days');
    var tdhours = document.getElementById('hours');
    var tddetail = document.getElementById('detail');
    months = '".$imgmonth."';
    days = '".$imgday."';
    hours = '".$imghour."';
    dmonths = '".$tabmonth.$legend."';
    ddays = '".$tabday.$legend."';
    dhours = '".$tabhour.$legend."';


function selmonths()
{
    tdgraph.innerHTML=months;
    tddetail.innerHTML='';
}

function seldays()
{
    tdgraph.innerHTML=days;
    tddetail.innerHTML='';
}

function selhours()
{
    tdgraph.innerHTML=hours;
    tddetail.innerHTML='';
}

function detmonths()
{
    tddetail.innerHTML=dmonths;
}

function detdays()
{
    tddetail.innerHTML=ddays;
}

function dethours()
{
    tddetail.innerHTML=dhours;
}

</script>
";


        $this->content->text = $output;
        $this->content->footer = '';

        return $this->content;
    }


}
?>
