<?PHP // $Id: block_usage.php,v 1.3 2008/10/14 14:13:18 jcoelho Exp $ 
      // block_usage.php - created with Moodle 1.9


$string['blockname'] = 'Utilização';

$string['months'] = 'Meses';
$string['days'] = 'Dias';
$string['hours'] = 'Horas';

$string['pv'] = 'Páginas vistas';
$string['msg'] = 'Mensagens';
$string['usr'] = 'Utilizadores';

$string['monthname'] = 'Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro';
$string['shortmonthname'] = 'Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez';

?>