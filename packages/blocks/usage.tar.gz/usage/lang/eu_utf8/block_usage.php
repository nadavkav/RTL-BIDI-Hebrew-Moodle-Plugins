<?PHP // $Id: block_usage.php,v 1.1 2008/11/03 16:13:40 jcoelho Exp $ 
      // block_usage.php - created with Moodle 1.9


$string['blockname'] = 'Erabilpena';

$string['months'] = 'Hileak';
$string['days'] = 'Egunak';
$string['hours'] = 'Orduak';

$string['pv'] = 'Orria ikusiak';
$string['msg'] = 'Mezuak';
$string['usr'] = 'Erabiltzaileak';

$string['monthname'] = 'Urtarrila, Otsaila, Martxoa, Apirila, Maiatza, Ekaina, Uztaila, Abuztua, Iraila, Urria, Azaroa, Abendua';
$string['shortmonthname'] = 'Urt,Ots,Mar,Api,Mai,Eka,Uzt,Abu,Ira,Urr,Aza,Abe';

?>