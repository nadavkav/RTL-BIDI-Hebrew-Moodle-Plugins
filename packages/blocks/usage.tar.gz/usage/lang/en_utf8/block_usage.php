<?PHP // $Id: block_usage.php,v 1.2 2008/10/13 23:13:05 jcoelho Exp $ 
      // block_usage.php - created with Moodle 1.9


$string['blockname'] = 'Usage';

$string['months'] = 'Months';
$string['days'] = 'Days';
$string['hours'] = 'Hours';

$string['pv'] = 'Pageviews';
$string['msg'] = 'Messages';
$string['usr'] = 'Users';

$string['monthname'] = 'January,February,March,April,May,June,July,August,September,October,November,December';
$string['shortmonthname'] = 'Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec';

?>