<?PHP // $Id: block_usage.php,v 1.2 2008/10/13 23:13:05 jcoelho Exp $
      // block_usage.php - created with Moodle 1.9


$string['blockname'] = 'שימוש במערכת (גרף)';

$string['months'] = 'חודשים';
$string['days'] = 'ימים';
$string['hours'] = 'שעות';

$string['pv'] = 'צפיות־בדף';
$string['msg'] = 'הודעות';
$string['usr'] = 'משתמשים';

$string['monthname'] = 'ינואר,פברואר,מרץ,אפריל,מאי,יוני,יולי,אוגוסט,ספטמבר,אוקטובר,נובמבר,דצמבר';
$string['shortmonthname'] = 'ינו,פבר,מרץ,אפר,מאי,יונ,יול,אוג,ספט,אוק,נוב,דצמ';

?>