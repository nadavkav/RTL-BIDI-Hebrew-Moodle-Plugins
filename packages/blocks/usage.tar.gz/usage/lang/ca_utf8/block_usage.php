﻿<?PHP // $Id: block_usage.php,v 1.1 2009/06/30 16:14:39 jcoelho Exp $
      // block_usage.php - created with Moodle 1.9


$string['blockname'] = 'Usage';

$string['months'] = 'Mesos';
$string['days'] = 'Dies';
$string['hours'] = 'Hores';

$string['pv'] = 'Pàgines visitades';
$string['msg'] = 'Missatges';
$string['usr'] = 'Usuaris';

$string['monthname'] = 'Gener,Febrer,Març,Abril,Maig,Juny,Juliol,Agost,Setembre,Octubre,Novembre,Desembre';
$string['shortmonthname'] = 'Gen,Febt,Març,Abr,Maig,Juny,Jul,Ag,Set,Oct,Nov,Des';

?>