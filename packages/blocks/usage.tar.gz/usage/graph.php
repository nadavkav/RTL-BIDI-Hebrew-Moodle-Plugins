<?PHP 

require_once("../../config.php");
require_once($CFG->libdir."/graphlib.php");

global $CFG;

// no queries to the database in this file
// configuration and data are received as arguments

$lx = array(); // names to present in X
$d1 = array(); // data 1 - pageviews
$d2 = array(); // data 2 - users
$d3 = array(); // data 3 - mensages

// scales
$maxleft=10;
$maxright=10;

// arguments
$course_id = optional_param('course_id', 1, PARAM_INT);
$nrows = optional_param('nrows', 1, PARAM_INT); 
$onpv = optional_param('onpv', 1, PARAM_INT); 
$onusr = optional_param('onusr', 1, PARAM_INT); 
$onmsg = optional_param('onmsg', 1, PARAM_INT); 
$graphwidth = optional_param('width', 200, PARAM_INT); 
$graphheight = optional_param('height', 150, PARAM_INT); 
$color1 = optional_param('colorpv', 'blue', PARAM_TEXT);
$color2 = optional_param('colorusr', 'green', PARAM_TEXT);
$color3 = optional_param('colormsg', 'red', PARAM_TEXT);
$typepv = optional_param('typepv', 1, PARAM_INT);
$typeusr = optional_param('typeusr', 1, PARAM_INT);
$typemsg = optional_param('typemsg', 1, PARAM_INT);
$msg = optional_param('msg', 0, PARAM_INT);
$y_label_left = optional_param('y_label_left', '', PARAM_TEXT);

if($onpv==1) $d1=array_reverse(explode(";",optional_param('d1', '', PARAM_TEXT)));
if($onusr==1) $d2=array_reverse(explode(";",optional_param('d2', '', PARAM_TEXT)));
if($onmsg==1) $d3=array_reverse(explode(";",optional_param('d3', '', PARAM_TEXT)));

for($i=0;$i<$nrows;$i+=1) {
    $lx[$i] = optional_param('lx'.($nrows-$i-1), '', PARAM_TEXT);
    
    // scales
    if($onpv==1 && $d1[$i]>$maxleft) $maxleft=$d1[$i];
    if($onusr==1 && $d2[$i]>$maxright) $maxright=$d2[$i];
    if($onmsg==1 && $d3[$i]>$maxright) $maxright=$d3[$i];    
}


// Draw it now
$graph = new graph($graphwidth, $graphheight);
$graph->parameter['title']             = false;
$graph->x_data                         = $lx;
$graph->y_data['d1']                   = $d1;
$graph->y_data['d2']                   = $d2;
if($msg==1) {
    $graph->y_data['d3']               = $d3;
    $graph->y_order                 = array('d1','d2','d3');
} else {
    $graph->y_order                 = array('d1','d2');
}
if($onpv==1) {
    if($typepv==2)
        $graph->y_format['d1'] = array('colour' => $color1, 'bar' => 'fill',
                'legend' => '< PV', 'y_axis' => 'left');
    else if($typepv==3)
        $graph->y_format['d1'] = array('colour' => $color1, 'area' => 'fill',
                'legend' => '< PV', 'y_axis' => 'left');
    else 
        $graph->y_format['d1'] = array('colour' => $color1, 'line' => 'line',
                    'legend' => '< PV', 'y_axis' => 'left');

}
if($onusr==1) {
    if($typeusr==2) 
        $graph->y_format['d2'] = array('colour' => $color2, 'bar' => 'fill',
                    'legend' => 'USR >', 'y_axis' => 'right');
    else if($typeusr==3)
        $graph->y_format['d2'] = array('colour' => $color2, 'area' => 'fill',
                    'legend' => 'USR >', 'y_axis' => 'right');
    else
        $graph->y_format['d2'] = array('colour' => $color2, 'line' => 'line',
                    'legend' => 'USR >', 'y_axis' => 'right');
}

if($onmsg==1) {
    if($typemsg==2) 
        $graph->y_format['d3'] = array('colour' => $color3, 'bar' => 'fill',
                        'legend' => 'MSG >', 'y_axis' => 'right');
    else if($typemsg==3)
        $graph->y_format['d3'] = array('colour' => $color3, 'area' => 'fill',
                        'legend' => 'MSG >', 'y_axis' => 'right');
    else
        $graph->y_format['d3'] = array('colour' => $color3, 'line' => 'line',
                        'legend' => 'MSG >', 'y_axis' => 'right');
}

//$graph->parameter['y_label_left']    = $y_label_left;
$graph->parameter['x_axis_angle']        = 0;
$graph->parameter['x_label_angle']      = 0;

$graph->parameter['legend'] = 'inside-right'; 
$graph->parameter['point_size'] = 4; 

$graph->parameter['y_axis_text_left']    = 1;
$graph->parameter['y_axis_text_right']   = 1;

// escalas
$maxround=1;
while($maxround*10<$maxleft) 
    $maxround*=10;
if($maxround*2>=$maxleft) {
    $maxround*=2;
} else {
    if($maxround*5>=$maxleft)
        $maxround*=5;
    else $maxround*=10;
}

if($onpv==1) {
    $graph->parameter['y_min_left'] = 0;   
    $graph->parameter['y_max_left'] = $maxround;  
    $graph->parameter['y_decimal_left'] = 0;  
}

$maxround=1;
while($maxround*10<$maxright) 
    $maxround*=10;
if($maxround*2>=$maxright) {
    $maxround*=2;
} else {
    if($maxround*5>=$maxright)
        $maxround*=5;
    else $maxround*=10;
}

if($onusr==1 || $onmsg==1) {
    $graph->parameter['y_min_right'] = 0;  
    $graph->parameter['y_max_right'] = $maxround; 
    //$graph->parameter['y_decimal_right'] = 0;  
}

$graph->parameter['shadow_offset']         = 0;
error_reporting(5); // ignore most warnings such as font problems etc
$graph->draw_stack();
?>