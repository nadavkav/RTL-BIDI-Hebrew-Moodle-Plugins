<?php // $Id: settings.php, v 0.1 9/23/2008 7:44:39 AM jstein Exp $ 
      // /blocks/openshare/settings.php - created for Moodle 1.9
/*
    function init() {
        $this->title = get_string('opensharesettings','block_openshare');
        $this->version = 2008092300;
    }

$settings->add(new admin_setting_configtext('block_openshare_license_name', get_string('licensename', 'block_openshare'), '', '', PARAM_TEXT));
$settings->add(new admin_setting_configtext('block_openshare_license_short_desc', get_string('licenseshort', 'block_openshare'), '', '', PARAM_TEXT));
$settings->add(new admin_setting_configtext('block_openshare_license_longdesc', get_string('licenselong', 'block_openshare'), '', '', PARAM_TEXTAREA));
$settings->add(new admin_setting_configtext('block_openshare_license_code', get_string('licensecode', 'block_openshare'), '', '', PARAM_AREA));
*/
?>