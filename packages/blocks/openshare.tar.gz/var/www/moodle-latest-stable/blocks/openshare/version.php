<?php // $Id: version.php, v 0.1 9/29/2008 rjspiker Exp $ 
      // /blocks/openshare/version.php - created for Moodle 1.9

	$plugin->version  = 2008092900; //Latest OpenShare version date
	$plugin->requires = 2007081300; //Tested only on this version of Moodle
?>