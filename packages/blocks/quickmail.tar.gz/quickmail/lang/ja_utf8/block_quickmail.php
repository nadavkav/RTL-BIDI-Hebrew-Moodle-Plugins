<?PHP // $Id: block_quickmail.php,v 1.6 2008/09/03 16:57:55 mark-nielsen Exp $ 
      // block_quickmail.php - created with Moodle 2.0 dev (2007101508)


$string['action'] = '操作';
$string['areyousure'] = '本当に履歴中のすべてのメールを削除してもよろしいですか?';
$string['attachment'] = '添付';
$string['attachmentalt'] = 'メールに添付ファイルを追加する';
$string['attachmenterror'] = '有効な添付ファイルではありません! 次のファイルは存在していません： <strong>$a</strong>';
$string['attachmentoptional'] = '添付 (任意)';
$string['blockname'] = 'クイックメール';
$string['check'] = 'すべてを選択';
$string['clearhistory'] = 'すべての履歴をクリア';
$string['compose'] = '作成';
$string['date'] = '日時';
$string['delete'] = '削除';
$string['deletefail'] = '削除が失敗しました。';
$string['deletesuccess'] = '正常に削除されました。';
$string['email'] = 'メール';
$string['emailfail'] = 'メールエラー:';
$string['emailfailerror'] = 'エラーが発生したため、下記のユーザにメール送信されませんでした ...';
$string['emailstop'] = 'メールアドレスが無効にされています:';
$string['history'] = '履歴';
$string['messageerror'] = 'メッセージを入力してください!';
$string['nogroupmembers'] = 'グループメンバーなし';
$string['notingroup'] = 'グループ外';
$string['quickmail:cansend'] = 'クイックメールでメールを送信できる';
$string['sendemail'] = 'メールを送信する';
$string['subjecterror'] = '題名を入力してください!';
$string['successfulemail'] = 'メールが正常に送信されました。';
$string['to'] = 'To';
$string['toerror'] = 'メールの受信者を選択してください!';
$string['uncheck'] = 'すべての選択を解除';
$string['allowstudents'] = '$a にクイックメールの使用を許可する'; // ORPHANED

?>
