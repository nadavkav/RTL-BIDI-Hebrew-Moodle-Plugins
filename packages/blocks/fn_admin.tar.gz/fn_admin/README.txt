
Block: FN Admin



############################################################################################################

How it works:

Documentation for this block is located at www.moodlefn.knet.ca



############################################################################################################

Installation:

The block is made for Moodle 1.9.x

This block follows standard Moodle Block install instructions 

-copy the folder in the into your moodle blocks folder
-copy the files in lang folder into your moodle lang folder.
-visit the Admin page in Moodle to activate it



#############################################################################################################

Notes:

This block is part of the MoodleFN series (www.moodlefn.knet.ca)

Sponsor: K-Net (www.knet.ca)
Designer: Fernando Oliveira (fernandooliveira@knet.ca)
Coder: Mike Churchward (www.oktech.ca)