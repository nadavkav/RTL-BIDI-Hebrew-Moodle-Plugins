<?php //$Id: block_fn_admin.php,v 1.2 2009/05/04 21:13:33 mchurch Exp $
$string['cfgdisplaytitle'] = 'Display title';
$string['coursesettings'] = 'FN Course Settings';
$string['showadminmenu'] = 'Show Moodle Admin Menu Items';
$string['showprofile'] = 'Show Moodle Profile Link';
$string['showunenrol'] = 'Show Moodle Enrol/Unenrol Link';
$string['blockname'] = 'Admin - Tabs layout';
?>