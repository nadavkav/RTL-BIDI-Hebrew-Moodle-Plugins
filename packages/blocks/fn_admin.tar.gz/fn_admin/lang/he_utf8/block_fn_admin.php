<?php //$Id: block_fn_admin.php,v 1.2 2009/05/04 21:13:33 mchurch Exp $
$string['cfgdisplaytitle'] = 'כותרת לתצוגה';
$string['coursesettings'] = 'מאפייני תצורת יחידות הוראה בחוצצים';
$string['showadminmenu'] = 'תצוגת פריטי תפריט ניהול של המערכת';
$string['showprofile'] = 'הצגת קישור למאפייני המשתמש';
$string['showunenrol'] = 'הצגת קישור לדף הרשמה';
$string['blockname'] = 'ניהול - תצורת חוצצים';
?>