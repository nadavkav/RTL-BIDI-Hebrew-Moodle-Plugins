<?php

$string['blockname'] = 'Selling Bee';

?>
