<?php

$string['blockname'] = 'הקלידו את המילה באנגלית';

?>
