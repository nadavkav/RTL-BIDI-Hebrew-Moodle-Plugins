Block: Most Active Courses

############################################################################################################

What it does:

List most active courses and displays button for course requests


############################################################################################################

How it works:


 Block settings located in Administration > Modules Blocks > FN Most Active Courses:

- Number of courses to display
- Number of days back for activity
- Course formats to exclude



############################################################################################################

Installation:

The block is made for Moodle 1.9.x

This block follows standard Moodle Block install instructions 

-copy the folder in the into your moodle blocks folder
-copy the files in lang folder into your moodle lang folder.
-visit the Admin page in Moodle to activate it



#############################################################################################################

Notes:

This block is part of the MoodleFN series (www.moodlefn.knet.ca)

Sponsor: K-Net (www.knet.ca)
Designer: Fernando Oliveira (fernandooliveira@knet.ca)
Coder: Mike Churchward (www.oktech.ca)



