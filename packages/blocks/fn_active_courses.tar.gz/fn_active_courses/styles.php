<?php //$Id: styles.php,v 1.1 2009/03/09 14:08:28 mchurch Exp $
/*
 * Extra styles for block.
 */
?>

.block_fn_active_courses .footer .singlebutton {
    text-align: center;
    padding-top: 1em;
}

.block_fn_active_courses .footer .singlebutton input {
    font-size: 1em;
    margin: 0;
    padding: 2px 5px;
    overflow: visible; /* seems to keep ie (inc 7) in check without anything else */
}

.block_fn_active_courses table {
    width: 100%;
}

.block_fn_active_courses table td {
    font-size: .85em;
    vertical-align: top;
}

.block_fn_active_courses td.fac_icon {
    width: 20px;
}
