<?PHP //$Id: block_fn_active_courses.php,v 1.3 2009/03/11 16:41:49 mchurch Exp $

include_once($CFG->dirroot . '/course/lib.php');

class block_fn_active_courses extends block_base {
    function init() {
        global $CFG;

        $this->title = get_string('title', 'block_fn_active_courses');
        $this->version = 2008040101;

        if (!isset($CFG->block_fn_active_courses_displaynum)) {
            $CFG->block_fn_active_courses_displaynum = 3;
        }
        if (!isset($CFG->block_fn_active_courses_activedays)) {
            $CFG->block_fn_active_courses_activedays = 10;
        }
        if (!isset($CFG->block_fn_active_courses_exclformat)) {
            $CFG->block_fn_active_courses_exclformat = array();
        } else if (!is_array($CFG->block_fn_active_courses_exclformat)) {
            $CFG->block_fn_active_courses_exclformat = explode(',', $CFG->block_fn_active_courses_exclformat);
        }
    }

    function specialization() {
        $this->title = trim(get_string('displaytitle', 'block_fn_active_courses', get_string('courses')));
    }

    function has_config() {
        return true;
    }

    /**
     * @param array $data
     * @return boolean
     */
    function config_save($data) {
        if (isset($data->format)) {
            $data->block_fn_active_courses_exclformat = implode(',', $data->format);
            unset($data->format);
        } else {
            $data->block_fn_active_courses_exclformat = '';
        }
        return parent::config_save($data);
    }

    function get_content() {
        global $THEME, $CFG, $USER;

        if($this->content !== NULL) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';

        $icon  = "<img src=\"$CFG->wwwroot/blocks/fn_active_courses/images/courseact.gif\"".
                 " class=\"icon\" alt=\"".get_string("course")."\" />";
        $timenow = time();
        $starttime = $timenow - ($CFG->block_fn_active_courses_activedays * 24 * 60 * 60);
        $userdate  = userdate($starttime);

        if (!empty($CFG->block_fn_active_courses_exclformat)) {
            $courseexcl = ' AND c.format NOT IN (';
            $first = true;
            foreach ($CFG->block_fn_active_courses_exclformat as $exclf) {
                $courseexcl .= $first ? '' : ',';
                $courseexcl .= '\''.$exclf.'\'';
                $first = false;
            }
            $courseexcl .= ') ';
        } else {
            $courseexcl = '';
        }

        $select = 'SELECT l.course, COUNT(l.course) as activecount, c.fullname ';
        $from   = 'FROM '.$CFG->prefix.'log l ';
        $join   = 'LEFT JOIN '.$CFG->prefix.'course c ON c.id = l.course ';
        $where  = 'WHERE l.time >= '.$starttime.' AND l.course != '.SITEID.' AND c.id IS NOT NULL '.$courseexcl;
        $group  = 'GROUP BY l.course ';
        $order  = 'ORDER BY activecount DESC ';
        $limit  = 'LIMIT 0, '.$CFG->block_fn_active_courses_displaynum.' ';

        $sql    = $select.$from.$join.$where.$group.$order.$limit;
        if ($records = get_records_sql($sql)) {
            $this->content->text .= '<table>'."\n";
            foreach ($records as $record) {
                $this->content->text .= '<tr>';
                $this->content->text .= '<td class="fac_icon">'.$icon.'</td>';
                $this->content->text .= '<td class="fac_link"><a title="'.$record->activecount.' actions since '.$userdate.'" '.
                                          'href="'.$CFG->wwwroot.'/course/view.php?id='.$record->course.'">'.
                                          $record->fullname.'</a></td>';
                $this->content->text .= '</tr>'."\n";
            }
            $this->content->text .= '</table>'."\n";
        }

        if ($CFG->enablecourserequests && (!isloggedin() || isguest())) {
            $this->content->footer = print_single_button($CFG->wwwroot.'/login/index.php', NULL,
                                     trim(get_string('courserequest', 'block_fn_active_courses', get_string('course'))),
                                     'get', '_self', true);
        } else if ($CFG->enablecourserequests && !has_capability('moodle/course:create', get_context_instance(CONTEXT_SYSTEM, SITEID))) {  // Print link to request a new course
            $this->content->footer = print_single_button($CFG->wwwroot.'/course/request.php', NULL,
                                     trim(get_string('courserequest', 'block_fn_active_courses', get_string('course'))),
                                     'get', '_self', true);
        }

        return $this->content;
    }

}
?>