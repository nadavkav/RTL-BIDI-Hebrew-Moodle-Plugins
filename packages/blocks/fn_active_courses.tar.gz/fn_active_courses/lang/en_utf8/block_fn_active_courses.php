<?php //$Id: block_fn_active_courses.php,v 1.1 2009/03/09 14:08:28 mchurch Exp $
$string['configactivedays'] = 'Number of days back for activity';
$string['configdisplaynum'] = 'Number of courses to display';
$string['configexclformat'] = 'Exclude these formats';
$string['courserequest'] = 'Request a $a';
$string['displaytitle'] = 'Most Active $a';
$string['title'] = 'FN Most Active Courses';
?>