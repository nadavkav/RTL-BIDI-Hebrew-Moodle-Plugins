<?php //$Id: block_fn_active_courses.php,v 1.1 2009/03/09 14:08:28 mchurch Exp $
$string['configactivedays'] = 'מספר ימים אחרונים של פעילות';
$string['configdisplaynum'] = 'מספר מרחבי לימוד להצגה';
$string['configexclformat'] = 'הסרת סוגי תצורה אילו';
$string['courserequest'] = 'בקשת מרחב לימוד חדש בשם $a';
$string['displaytitle'] = 'הפעילים ביותר $a';
$string['title'] = 'מרחבי לימוד פעילים ביותר';
?>