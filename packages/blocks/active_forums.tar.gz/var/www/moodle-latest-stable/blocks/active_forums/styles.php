.tagcloud {
    background: inherit;
    width: 99%;
    text-align:center;
}

.tagcloudlabel {
    text-align:center;
    font-size: small;
}

.tagcloudtitle {
    background: #e0e0e0;
}

div.tagcloud {
color:#333333;
float:none;
font-size:100%;
padding:0px;
width:auto;
}