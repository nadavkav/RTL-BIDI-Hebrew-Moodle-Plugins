<?php

$string['active_forums_title'] = 'Active Forums';
$string['configtitle'] = 'Block instance title';
$string['configdays'] = 'Period checked (days)';
$string['configforumtitle'] = 'Maximum name length before truncation';
$string['config_max_discussions'] = 'Maximum discussions in tag cloud';
$string['noactiveforums'] = 'No active forums';
$string['setting_title'] = 'setting the block instance title'; 
$string['setting_days'] = 'setting the period checked'; 
$string['setting_length'] = 'setting the maximum name length'; 
$string['setting_max_discussions'] = 'setting the maximum discussions'; 
$string['subtitlelabel'] = '(last $a days)';

?>