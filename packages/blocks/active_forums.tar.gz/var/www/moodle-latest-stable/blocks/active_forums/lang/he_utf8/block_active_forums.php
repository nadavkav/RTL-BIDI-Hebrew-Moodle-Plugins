<?php

$string['active_forums_title'] = 'כותרות דיונים פעילים';
$string['configtitle'] = 'כותרת משבצת־הניהול';
$string['configdays'] = 'פעילות חדשה במשך זמן של... (ימים)';
$string['configforumtitle'] = 'מספר תווים מרבי להצגה, מכותרת הדיון';
$string['config_max_discussions'] = 'מספר דיון מרבי להצגה';
$string['noactiveforums'] = 'לא קיימים דיונים פעילים';
$string['setting_title'] = 'הגדרת כותרת משבצת זו';
$string['setting_days'] = 'הגדרת תקופת הניטור של הפעילות בקבוצת הדיון';
$string['setting_length'] = 'הגדרת מספר התווים לתצוגה מתוך כותרת הדיון';
$string['setting_max_discussions'] = 'הגדרת מספר הדיונים המרבי לתצוגה';
$string['subtitlelabel'] = '($a הימים האחרונים)';

?>