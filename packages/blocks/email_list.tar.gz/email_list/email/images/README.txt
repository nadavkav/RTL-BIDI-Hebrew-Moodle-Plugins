Silk icon set 1.3

eMail get folder_add.png, printer.png, add.png, delete.png, user_green.png,
user_gray.png, user_suit.png, user_red.png icon.

_________________________________________
Mark James
http://www.famfamfam.com/lab/icons/silk/
_________________________________________

This work is licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]

This means you may use it for any purpose,
and make any changes you like.
All I ask is that you include a link back
to this page in your credits.

Are you using this icon set? Send me an email
(including a link or picture if available) to
mjames@gmail.com

Any other questions about this icon set please
contact mjames@gmail.com



eMail get answered.gif icon of the Horde project.

All rights reserved by Horde project.