.dir-rtl td.tweets {
direction:rtl;
text-align:right;
}

.dir-ltr td.tweets {
direction:ltr;
text-align:left;
}