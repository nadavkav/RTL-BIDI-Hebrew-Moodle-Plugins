<?php

$string['numoftweets'] = 'מספר \"ציוצים\" להצגה';
$string['searchterms'] = 'מילות חיפוש';
$string['blocktitle'] = '\"ציוצים\" מטוויטר';
$string['ontwitter'] = ' בטוויטר';

?>