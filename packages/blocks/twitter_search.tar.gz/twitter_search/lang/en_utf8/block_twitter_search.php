<?php

$string['numoftweets'] = 'Number of tweets shown';
$string['searchterms'] = 'Search Terms';
$string['blocktitle'] = 'Twitter Search';
$string['ontwitter'] = ' on Twitter';

?>