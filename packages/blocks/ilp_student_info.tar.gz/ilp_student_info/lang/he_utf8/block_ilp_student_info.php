<?php

$string['allow_per_student_teacher_text'] = 'Allow Student Info (Teacher only)';
$string['allow_per_student_student_text'] = 'Allow Student Info (Student only)';
$string['allow_per_student_shared_text'] = 'Allow Student Info (Shared)';
$string['allow_per_tutor_teacher_text'] = 'Allow Personal Reports (Teacher only)';
$string['allow_per_tutor_student_text'] = 'Allow Personal Reports (Student only)';
$string['allow_per_tutor_shared_text'] = 'Allow Personal Reports (Shared)';
$string['allow_per_teacher_teacher_text'] = 'Allow Subject Reports (Teacher only)';
$string['allow_per_teacher_student_text'] = 'Allow Subject Reports (Student only)';
$string['allow_per_teacher_shared_text'] = 'Allow Subject Reports (Shared)';
$string['blockname'] = 'תוכנית אישית : פרטי תלמיד';
$string['default_per_student_teacher_text'] = 'Default Student Info Teacher\'s text';
$string['default_per_student_student_text'] = 'Default Student Info Student\'s text';
$string['default_per_student_shared_text'] = 'Default Student Info Shared text';
$string['default_per_tutor_teacher_text'] = 'Default Personal Report Teacher\'s text';
$string['default_per_tutor_student_text'] = 'Default Personal Report Student\'s text';
$string['default_per_tutor_shared_text'] = 'Default Personal Report Shared text';
$string['default_per_teacher_teacher_text'] = 'Default Subject Report Teacher\'s text';
$string['default_per_teacher_student_text'] = 'Default Subject Report Student\'s text';
$string['default_per_teacher_shared_text'] = 'Default Subject Report Shared text';
$string['shared_text'] = 'Shared text';
$string['ilp_student_info'] = 'תוכנית אישית : פרטי תלמיד';
$string['ilp_student_info:view'] = 'View';
$string['ilp_student_info:viewclass'] = 'View Class';
$string['ilp_student_info:editmine'] = 'Edit My Fields';
$string['ilp_student_info:editall'] = 'Edit All Fields';
$string['student_response'] = 'Student response';
$string['tutor_comment'] = 'Tutor comment';
$string['youarebeingredirectedtoyourown'] = 'You are being redirected to your own page.';
$string['viewilp_student_info'] = 'View Student Information';
$string['viewilp_student_infos'] = 'Students Information';
$string['viewmyilp_student_info'] = 'My Information';



?>