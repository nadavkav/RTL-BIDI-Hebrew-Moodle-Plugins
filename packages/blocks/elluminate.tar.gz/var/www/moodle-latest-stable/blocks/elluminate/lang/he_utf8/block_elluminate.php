<?php // $Id: block_elluminate.php,v 1.1 2008/02/08 18:59:11 mchurch Exp $

$string['changepassword'] = 'עדכון סיסמה';
$string['changepasswordnotice'] = 'הסיסמה עודכנה בהצלחה.';
$string['changepasswordfailure'] = 'שגיאה בעת עדכון סיסמה, אנא נסו שוב.';
$string['createaccount'] = 'יצירת חשבון';
$string['elluminate'] = 'מפגש מקוון - אילומינייט';
$string['emptyfields'] = 'השדות הבאים לא הוזנו באופן תקין: $a';
$string['ihaveanaccount'] = 'I have an Elluminate Live! account';
$string['loginname'] = 'שם משתמש';
$string['manageelluminateusers'] = 'ניהול משתמשי מפגש מקוון אילומינייט';
$string['manageusers'] = 'ניהול משתמשים';
$string['myaccount'] = 'החשבון שלי';
$string['newaccount'] = 'חשבון חדש בשרות - מפגש מקוון';
$string['newaccountfailure'] = 'There was an error creating your account on the Elluminate Live! Server.';
$string['newaccountnotice'] = 'Your new account was created on the Elluminate Live! Server.';
$string['newusernotice'] = 'We are going to create a new account for you based on your ' .
                           'Moodle user information but <b>you must enter a password</b>.  You ' .
                           'can use the same password for your Moodle account or you can ' .
                           'enter a completely new one.';
$string['recentrecordings'] = 'ארכיון מפגשים מוקלטים';
$string['role'] = 'תפקיד';
$string['userid'] = 'קוד משתמש';
$string['yourelluminateaccount'] = 'חשבון מפגש מקוון - אילומינייט שלך';

?>
