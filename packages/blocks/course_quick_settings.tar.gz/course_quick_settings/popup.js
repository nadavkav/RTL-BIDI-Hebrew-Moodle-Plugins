// ==============================================================
// Script:     Amazing Frameless Popup Window - Version I
// 
// Functions:  In IE4 and later, this script launches a popup
//             window without the Windows frame or titlebar
//             (that is, a "containerless" window).  In other
//             browsers, it launches a standard popup window.
//             Position, width, and height are settable.
//             Automatic closing of the window on leaving the
//             page may also be optionally set.
// 
// Browsers:   IE4 and later
//             Degrades fully functionally in other browsers
// 
// Author:     etLux
// ==============================================================

// Amazing Frameless Popup Window - Version I
// (C) 2000 www.CodeLifter.com
// Free for all users, but leave in this  header

// set the popup window width and height

var windowW=700 // wide
var windowH=500 // high

// set the screen position where the popup should appear

var windowX = 260 // from left
var windowY = 100 // from top

// set the url of the page to show in the popup

//var urlPop = "yourpage.html"

// set the title of the page

var title =  "This Is A Frameless Popup Window"

// set this to true if the popup should close
// upon leaving the launching page; else, false

var autoclose = true

// ============================
// do not edit below this line
// ============================

s = "width="+windowW+",height="+windowH;
var beIE = document.all?true:false

function openFrameless(urlPop){
  if (beIE){
    NFW = window.open("","popFrameless","fullscreen,"+s)     
    NFW.blur()
    window.focus()       
    NFW.resizeTo(windowW,windowH)
    NFW.moveTo(windowX,windowY)
    var frameString=""+
"<html>"+
"<head>"+
"<title>"+title+"</title>"+
"</head>"+
"<frameset rows='*,0' framespacing=0 border=0 frameborder=0>"+
"<frame name='top' src='"+urlPop+"' scrolling=auto>"+
"<frame name='bottom' src='about:blank' scrolling='no'>"+
"</frameset>"+
"</html>"
    NFW.document.open();
    NFW.document.write(frameString)
    NFW.document.close()
  } else {
    NFW=window.open(urlPop,"popFrameless","scrollbars,"+s)
    NFW.blur()
    window.focus() 
    NFW.resizeTo(windowW,windowH)
    NFW.moveTo(windowX,windowY)
  }   
  NFW.focus()   
  if (autoclose){
    window.onunload = function(){NFW.close()}
  }
}
