<?php

$string['course_quick_settings'] = "עדכון מאפייני קורס";
$string['configtitle'] = "כותרת";
$string['configcontent'] = "תוכן";
$string['selecnewlanguage']= 'בחרו שפת ממשק חדשה לקורס';
$string['clicktoapply'] = "הבחירה משנה באופן מידי את מאפייני הקורס";
?>