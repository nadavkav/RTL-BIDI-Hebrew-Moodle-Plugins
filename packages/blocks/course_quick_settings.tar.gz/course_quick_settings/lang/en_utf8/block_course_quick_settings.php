<?php

$string['course_quick_settings'] = "update course settings";
$string['configtitle'] = "title";
$string['configcontent'] = "content";
$string['selecnewlanguage']= 'choose new interface language';
$string['clicktoapply'] = "choose to immidiately update";
?>