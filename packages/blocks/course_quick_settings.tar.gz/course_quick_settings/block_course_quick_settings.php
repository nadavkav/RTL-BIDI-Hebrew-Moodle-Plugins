<?php

class block_course_quick_settings extends block_base {

function init() {
  $this->title = get_string('course_quick_settings', 'block_course_quick_settings');
  $this->version = 2009052801;
}

function get_content() {
  global $COURSE, $CFG;

  if ($this->content !== NULL) {
  return $this->content;
  }

  $id = $COURSE->id; //required_param('id', PARAM_INT);

  if (! $course = get_record('course', 'id', $id)) {
      error('Course ID is incorrect');
  }

//   $strgalleries = get_string('gallerys','lightboxgallery');
//   if (! $galleries = get_all_instances_in_course('lightboxgallery', $course)) {
//       notice(get_string('thereareno', 'moodle', $strgalleries), $CFG->wwwroot . '/course/view.php?id=' . $course->id);
//       exit;
//   }
// 
//   $data = '<script src="'.$CFG->wwwroot.'/blocks/imagegallery/popup.js" language="JavaScript"></script> ';
//   $data .= '<ol>';
//   foreach ($galleries as $gallery) {
//     $galleryurl = '\''.$CFG->wwwroot.'/mod/lightboxgallery/view.php?l='.$gallery->id.'\'';
//     $data .= '<li><div onclick="javascript:openFrameless('.$galleryurl.');"><b>'.$gallery->name.'</b></div></li>';
//   }
//   $data .= '</ol>';  

  $languages=array();
  $languages[''] = get_string('forceno');
  $languages += get_list_of_languages();
//print_r($languages);
  $data = "<hr>";
// foreach($languages as $lang => $lkey) {
// //$tmplang = array_shift($languages);
// //print_r($tmplang[0]);
//   $data .= $lkey."<br/>";
// }

  $quickcourseaction    = optional_param('quickcourseaction', 'choose', PARAM_TEXT);
  $newcourselang	= optional_param('newcourselang', $course->lang , PARAM_TEXT);

  if ($quickcourseaction == 'update'){
    add_to_log($course->id, "course", "update", "edit.php?id=$course->id", $course->id);
    set_field_select('course','lang',$newcourselang,'id='.$course->id);
    //trigger events
    events_trigger('course_updated', $course);
    redirect($CFG->wwwroot."/course/view.php?id=$course->id",'',0);
  }

  $data .= '<form id="quickcoursesettings" name="quickcoursesettings" target="_new" method="post" action="view.php">';
  $data .= '<div class="block coursequicksettings"><label for="menulanguage">'.get_string('selecnewlanguage','block_course_quick_settings').'</label> ';
  $data .= choose_from_menu($languages, 'newcourselang', $course->lang, get_string('choose'),'document.quickcoursesettings.submit();','0',true);
  $data .=  '</div>';
  $data .=  '<input name="id" value="'.$course->id.'" type="hidden">';
  $data .=  '<input name="quickcourseaction" value="update" type="hidden">';
  //$data .=  '<input name="mode" value="'.$quickcourseaction.'" type="text">';
  $data .=  '</form>';

  $this->content = new stdClass;
  $this->content->text = $data;
  $this->content->footer = get_string('clicktoapply','block_course_quick_settings');
  
  return $this->content;
}

function instance_allow_config() {
  return false;
}

function specialization() {
  if(!empty($this->config->title)){
    $this->title = $this->config->title;
  }else{
    $this->config->title = 'quick change course settings';
  }
  if(empty($this->config->text)){
    $this->config->text = 'course settings';
  }
}

function html_attributes() {
    $attrs = parent::html_attributes();
    // Add your own attributes here, e.g.
    // $attrs['width'] = '50%';
    $attrs['class'] = 'sideblock block_'. $this->name() ;
    return $attrs;

/*  return array(
    'class'       => 'sideblock block_'. $this->name() 
    //,'onmouseover' => "alert('Mouseover on our block!');"
  );
*/
}

function applicable_formats() {
  return array(
           'site-index' => true,
          'course-view' => true, 
   'course-view-social' => false,
                  'mod' => true, 
             'mod-quiz' => false
  );
}

} // class block_imagegallery ends here
?>
