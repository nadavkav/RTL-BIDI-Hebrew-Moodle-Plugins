<?php  // $Id: block_notgraded.php 2007/04/17
/*
    Copyright 2006-2006 Open Technology LTD http://www.opentechnology.ru
    Authors: Alex Djachenko, Evgenij Tsygantsov
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
 * Блок отображения непроверенных ответов на вопросы типа "задание" или "эссе".
 */ 
class block_notgraded extends block_base
{
	/**
	 * Нужна для инициализации блока
	 * согласно требованиям разработчиков
	 * @return ничего не возвращает
	 */
	function init()
	{
		$this->title = get_string('notgraded', 'block_notgraded');//название модуля
		$this->version = 2007060800;//дата создания модуля
	}
	/**
	 * Выводит содержание блока на экран
	 * @return ничего не возвращает
	 */
	function get_content()
	{
		$this->content = new stdClass; // создаем новый объект для вывода
		global $CFG, $USER, $COURSE;
		if (!isset($CFG) OR !isset($USER) OR !isset($COURSE))
		{//если не можем начать работу выводим пустую строку
			$this->content->text = '';
		}
		else
		{//если все в норме
			$str=''; // результирующая строка
			if (isteacher($COURSE->id))
			{//покажем данные только преподавателю этого курса
				$courses = get_courses(); //получаем все курсы
				foreach ($courses as $val)
				{// перебираем все курсы
					if ($val->id == $COURSE->id)
					{// и находим текущий курс
						$course = $val;
					}
				}
				$users = get_course_students($COURSE->id);//список студентов курса
				if ($users)
				{//если на курсе есть ученики
					//получаем все assignments текущего курса
					$assignments = get_all_instances_in_course('assignment', $course);
					if ($assignments)
				    {//если есть информация - готовим к выводу
						$str = $this->get_assignment($assignments, $users); //получаем список непроверенных заданий
					}
					//получаем все quiz текущего курса
					$quizes = get_all_instances_in_course('quiz', $course);
					if ($quizes)
					{//если есть информация - присоединяем
						$str .= $this->get_essay($quizes, $users);
					}
					if (!$str)
					{//если непроверенных заданий нет
						$str = '<div align="center">'.get_string('not_notgraded', 'block_notgraded').'</div>';
					}
				}
			}
			$this->content->text = $str;// записываем в объект для вывода на экран
		}
		$this->content->footer = '';// надо определить, иначе Moodle будет ругаться
		if ($this->content)
		{//если есть что показать - выводим
	        return $this->content;
	    }
	}
	/**
	 * Функция для обновления содержания блока от разработчиков
	 */
	function refresh_content()
	{
    	// Nothing special here, depends on content()
    	$this->content = NULL;
    	return $this->get_content();
	}
	/**
	 * Это функция для Moodle версии 1.6.
	 * Получаем список заданий, в которых надо поставить оценку
	 * @param $assignments array массив заданий для проверки - проверены они или нет
	 * @return $str string строка с именами заданий для проверки
	 */
	function get_assignment($assignments, $users)
	{
		global $CFG, $COURSE;
		$strassignment = get_string('modulename', 'assignment'); //перевод названия модуля на местный язык
		$str='';// будет хранить результат
		$userids = implode(', ', array_keys($users));//список их id
		foreach ($assignments as $assignment)
		{//среди всех заданий ищем непроверенные
			$notgraded = get_records_sql("SELECT a.userid, a.timemodified ".
							"FROM {$CFG->prefix}assignment_submissions a ". 
							"WHERE a.userid IN ($userids)
									AND a.assignment = '{$assignment->id}'
									AND (a.teacher = 0 
									OR a.timemodified > a.timemarked)");
			if ($notgraded)
			{	//если есть задания без оценки, создаем ссылку на страницу выставления оценки
				//и прицепляем ее в конец ранее созданной ссылки
				$str .= '<div class="name">'.$strassignment. ': '.
						'<a '.($assignment->visible ? '':' class="dimmed"').
						'title="'.$strassignment.'" href="'.$CFG->wwwroot.
						'/mod/assignment/submissions.php?id='.$assignment->coursemodule.'">'.
						$assignment->name.'</a></div>';
				foreach ($notgraded as $val)
				{//прицепляем имя студента, задание которого не проверено
					$str .= '<div class="name">'.fullname($users[$val->userid]).' '.date("d.m.y", $val->timemodified).'</div>';
				}
			}
		}
		return $str;
	}
	/**
	 * возвращает имена студентов, у которых непроверены вопросы типа эссе
	 * @param $quizes array of objects содержит инфо о всех экземплярах quiz,
	 * 									которые использованы в данном курсе
	 * @param $users array массив пользователей, изучающих текущий курс
	 * @return $rez string строка содержит тип вопроса (эссе), его название,
	 * 						список фио студентов, чьи ответы надо проверить. 
	 * 						И так все вопросы типа эссе в курсе. 
	 */
	function get_essay($quizes, $users)
	{
		global $CFG, $COURSE;
		require_once ("{$CFG->dirroot}/mod/quiz/locallib.php");
		$userids = implode(', ', array_keys($users));//список их id
		$rez = '';//будет хранить строку результата
		$all_question = $this->only_essay($quizes);// получили id всех вопросов типа эссе во всех quiz
		foreach($all_question as $quiz_id=>$questions)
		{
			foreach ($questions as $q)
			{//ищем неоцененные попытки ответов
				//получаем непроверенные попытки ответов на нужный вопрос
				$attempts = get_records_sql("SELECT qa.* ".
										"FROM {$CFG->prefix}quiz_attempts qa, {$CFG->prefix}question_sessions qs ".
										"WHERE	quiz = $quiz_id ".
											"AND qa.timefinish > 0 ".
											 "AND qa.userid IN ($userids) AND qa.preview = 0 ". 
											 "AND qs.questionid = '$q->id'");
				if ($attempts)
				{//если есть ответ на quiz с нужным вопросом
					$data=array();//будет хранить данные для вывода по текущему вопросу
					$str = '';//хранит данные из $data в виде строки
					foreach ($attempts as $attempt)
					{
						$graded = $this->is_graded($attempt, $q->id);
						if (!$graded)
						{//если не проверен - запоминаем нужные данные
							$data[] = array($quiz_id, $q->id, fullname($users[$attempt->userid]), $attempt);
						}
						else
						{
							//если ответ проверен - пропускаем его
						}
					}
					if ($data)
					{//если есть что выводить - готовим к выводу
						$str = $this->get_str($data);
					}
					$rez .= $str;
				}
			}
		}
		return $rez;
	}
	/**
	 * возвращает истину если попытка ответа на вопрос оценена и 
	 * ложь если нет
	 * @param $attempt object содержит инфо о конкретной попытке ответа на вопрос с id question_id
	 * @param $question_id int id вопроса, на который пытались ответить
	 * @return bool 
	 */
	function is_graded($attempt, $question_id)
	{
		global $CFG;
		if ($CFG->version <= 2006080400)
		{// для версии 1.6
			$manual = '';
		}
		else
		{// для версии 1.7 и позднее 
			$manual = 'manual';
		}
		//получаем инфо о последнем ответе на нужный нам вопрос
		$state = get_record_sql("SELECT state.id, state.event, sess.".$manual."comment 
								FROM {$CFG->prefix}question_states state, 
									 {$CFG->prefix}question_sessions sess
								WHERE sess.newest = state.id 
									AND sess.attemptid = $attempt->uniqueid 
									AND sess.questionid = $question_id");
		if ($state)
		{//если инфо есть - проверяем проверен ли ответ
			if (!$manual)
			{//для moodle версии 1.6
				return question_state_is_graded($state) OR $state->comment;
			}
			else
			{//для moodle версии 1.7 и позже
				return question_state_is_graded($state) OR $state->manualcomment;
			}
		}
		else
		{//на всякий случай - чтобы знать причину ошибки
			return error('Could not find question state');
		}
	}
	/**
	 *  формирует строку с названием вопроса (типа эссе) и 
	 * именами тех, чьи ответы надо проверить, а также датой ответа
	 * @param $array array массив структуры quiz_id, question_id, имя_того_кто_отвечал, инфо_о_попытке
	 * @return $str string строка вида "Эссе имя_эссе ФИО_ответчика дата ответа ... ФИО_ответчика дата ответа"  
	 */
	function get_str($array)
	{
		global $CFG;
		$str = '';//строка результата
		$stressay = get_string('essay', 'quiz');//название типа вопроса на родном языке
		foreach ($array as $one)
		{//перебираем полученые данные
			list ($quiz_id, $question_id, $user, $attempt) = $one;
			$question=get_record('question', 'id', $question_id);//получаем инфо о вопросе
			if (!$str)
			{//если пишем первый раз - впишем тип и название вопроса
				$str = '<div>'.$stressay.' '.
						"<a href=\"{$CFG->wwwroot}/mod/quiz/report.php?
						 mode=grading&amp;q=$quiz_id&amp;
						 action=viewquestion&amp;questionid=$question->id\">".
						 $question->name."</a></div>";
			}// добавляем имя пользователя, чей ответ надо проверить, и дату ответа 
				$str .= '<div class="name">'.$user.' '.
						date("d.m.y", $attempt->timemodified).'</div>';
		}
		return $str;
	}
	/**
	 * перебирает переданные экземпляры модуля quiz и оставляет  только вопросы только  типа эссе
	 * @param $quizes array массив записей с информацией об экземплярах модуля типа quiz
	 * @return $all_question array массив, индексами которого являются id экземпляра quiz,
	 * а значениями массив объектов (id, qtype), где id - это id вопросов типа эссе, а qtype = essay.
	 */
	function only_essay($quizes)
	{//оставляем только нужные вопросы в каждом quiz
		$all_question = array();
		foreach ($quizes as $quiz)
		{
			$quiz_questions = quiz_questions_in_quiz($quiz->questions);//получаем строку c id вопросов
			if ($quiz_questions)
			{//если есть хоть какие-нибудь вопросы
				//получаем id вопроса и его тип
				$questions = get_records_select('question', "id IN ($quiz_questions)", 'id', 'id, qtype');
				foreach ($questions as $key=>$q)
				{//пропускаем ненужные вопросы
					if ($q->qtype != 'essay')
					{//если это не эссе, то удаляем его
						unset($questions[$key]);
					}
				}
				$all_question[$quiz->id] = $questions;//оставляем вопросы только типа эссе
			}
		}
		return $all_question;
	}
}
?>
