<?php
$string['notgraded'] = 'Para calificar: ';
$string['not_notgraded'] = 'No hay calificaciones pendientes.';
?>