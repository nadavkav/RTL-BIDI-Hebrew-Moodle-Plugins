<?php
$string['notgraded'] = 'To be graded: ';
$string['not_notgraded'] = 'All activities have been graded.';
?>