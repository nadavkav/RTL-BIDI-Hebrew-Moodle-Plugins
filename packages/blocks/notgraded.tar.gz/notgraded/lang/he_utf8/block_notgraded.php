<?php
$string['notgraded'] = 'משימות מחכות לבדיקה ';
$string['not_notgraded'] = 'כל המשימות נבדקו.';
?>