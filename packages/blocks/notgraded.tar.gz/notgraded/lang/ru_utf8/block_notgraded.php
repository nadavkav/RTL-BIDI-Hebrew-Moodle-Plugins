<?php
$string['notgraded'] = 'Надо проверить: ';
$string['not_notgraded'] = 'Проверять нечего';
?>