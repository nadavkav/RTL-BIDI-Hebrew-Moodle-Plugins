.block_participant_pix .content {
  padding: 3px;
  padding-right:15px;
}

.block_participant_pix .content a {
  margin: 0;
  padding: 0;
}

.block_participant_pix .content img {
  display: block;
  float: left;
  width: 35px;
  height: 35px;
  margin: 2px; /* adjusts spacing between pix */
  border: 1px solid white; /* adjusts to preference */
  background: white; /* adjusts to preference */
}

.block_participant_pix .more_participants {
  text-align: center;
}

.block_participant_pix .clear {
  clear: both;
  margin: 0;
  padding: 0;
}

.block_participant_pix .participantspixs {
  background-color:Silver;
  border-style:dotted;
  border-width:3px;
  width:165px;
}
