<?php 

$string['title'] = 'Social Network';
$string['max_participants'] = 'Max number of visible participants';
$string['userprofile'] = 'Show $a\' user profile';

?>
