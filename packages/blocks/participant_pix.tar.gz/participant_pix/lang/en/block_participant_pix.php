<?php 

$string['title'] = 'Participant Pix';

?>
