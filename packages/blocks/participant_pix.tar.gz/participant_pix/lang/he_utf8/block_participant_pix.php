<?php 

$string['title'] = 'רשת חברתית';
$string['max_participants'] = 'מספר משתמשים מרבי לתצוגה';
$string['userprofile'] = 'הצגת הפרטים האישיים של $a';

?>
