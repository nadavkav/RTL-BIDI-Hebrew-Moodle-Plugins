<?php // v1.4

class block_participant_pix extends block_base {

  function init() {
    global $CFG;
    $this->title = get_string('title','block_participant_pix');
    $this->version = 2009033100;
  }

  function applicable_formats() {
      return array('all' => true, 'my' => false, 'tag' => false);
  }

  function get_content() {
    if ($this->content !== NULL) {
      return $this->content;
    }

    global $COURSE, $CFG, $USER, $SITE;

    // create the content class
    $this->content = new stdClass;
    $this->content->text = '';
    $this->content->footer = '';

    if (isset($USER->groupmember[$COURSE->id])) $groups_str = 'IN ('.implode(',',$USER->groupmember[$COURSE->id]).')';
    else $groups_str = 'IS NULL';

    $display_generics = true;

    ($display_generics == false) ? $query_generics = ' AND u.picture = 1 ' : $query_generics = '';

	if(isset($this->config->max_participants)){
		$max_participants = $this->config->max_participants;
	}else{
		$max_participants = 40;
	}

    $query = "
        SELECT cx.id context
            , u.id userid
            , CONCAT(u.firstname,' ',u.lastname) name
            , u.picture picture
        FROM {$CFG->prefix}context cx
        INNER JOIN {$CFG->prefix}role_assignments ra ON (cx.id = ra.contextid)
        INNER JOIN {$CFG->prefix}user u ON (ra.userid = u.id)
        LEFT JOIN (SELECT {$CFG->prefix}groups_members.* FROM {$CFG->prefix}groups_members, {$CFG->prefix}groups WHERE {$CFG->prefix}groups.id = {$CFG->prefix}groups_members.groupid AND {$CFG->prefix}groups.courseid = {$COURSE->id}) gm ON (gm.userid = u.id)
        WHERE u.id != {$USER->id}
            AND gm.groupid {$groups_str}
            AND cx.contextlevel = 50
            AND cx.instanceid = {$COURSE->id}
            {$query_generics}
        GROUP BY userid
        ORDER BY u.lastaccess DESC
        LIMIT ".$max_participants;
    $rs = get_recordset_sql($query);

    $fellows = array();
    while ($members = rs_fetch_next_record($rs)) {
      if (!isset($contextid)) $contextid = $members->context;
      $fellows[$members->userid]['name'] = $members->name;
      $fellows[$members->userid]['picture'] = $members->picture;
    }

    $i = 0;
    foreach ($fellows AS $key => $value) {
      if ($value['picture'] == 1) $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/view.php?id='.$key.'&amp;course='.$COURSE->id.'" title="'.get_string('userprofile','block_participant_pix',$value['name']).'"><img src="'.$CFG->wwwroot.'/user/pix.php/'.$key.'/f2.jpg" alt="'.$value['name'].'"></a>';
      elseif ($display_generics == true) $this->content->text .= '<a href="'.$CFG->wwwroot.'/user/view.php?id='.$key.'&amp;course='.$COURSE->id.'" title="'.get_string('userprofile','block_participant_pix',$value['name']).'"><img src="'.$CFG->pixpath.'/u/f2.png" alt="Generic Profile Image"></a>';
      $i++;
    }

    if ($i == $max_participants) $this->content->text = '<div class="clear participantspixs">'.$this->content->text.'<div class="more_participants clear"><a href="'.$CFG->wwwroot.'/user/index.php?contextid='.$contextid.'" title="View all participants…">'.get_string('more').'…</a></div></div>';
    elseif ($this->content->text != '') $this->content->text = '<div class="clear participantspixs">'.$this->content->text.'<div class="clear"></div></div>';

    return $this->content;
  }

  function instance_allow_config() {
    return true;
  }

  function instance_config_save($data){
    $data = stripslashes_recursive($data);
    $this->config = $data;

    try{
	if($this->config->max_participants <= 0)
		throw new Exception('must be a positive number');

	if(!is_numeric($this->config->max_participants))
		throw new Exception('must be a numeric value');

	return set_field('block_instance', 'configdata', base64_encode(serialize($data)), 'id', $this->instance->id);
    }
    catch (Exception $e){
      $this->config->max_participants = 40;
      return set_field('block_instance', 'configdata', base64_encode(serialize($data)), 'id', $this->instance->id);
    }
  }
}

?>
