<?php //  by Eric Hsin
$string['blockname'] = '課程導覽選單';
$string['outline'] = '大綱';

// Config screen options
$string['introlength'] = '單元簡稱取幾個字：';
$string['trunctext'] = '縮減後的表示文字：';
$string['introaction'] = '點按單元簡稱後的動作是：';
$string['introhide'] = '收合隱藏其他單元';
$string['introscroll'] = '捲動畫面到此單元';
