<?php
// This block display a Slideshow of a lightboxgallery Album Resource
// using slideshow component ""PHP/SWF Slideshow"" written by :maani.us
// please see more info: http://www.maani.us/slideshow/
//
// notice: you'll must have a least one lightboxgallery resource in your course
//         for this block to funtion properly !
//
// code    : Nadav Kavalerchik (nadavkav@gmail.com) :-)
// version : 0.1 (2009083001)
//
class block_lightboxgallery_slideshow extends block_base {

  function init() {
    $this->title = get_string('imagegallery', 'block_lightboxgallery_slideshow');
    $this->version = 2009083001;
  }

  function get_content() {
    global $COURSE, $CFG;

    if ($this->content !== NULL) {
		return $this->content;
    }

    $id = $COURSE->id; //required_param('id', PARAM_INT);

    if (! $course = get_record('course', 'id', $id)) {
		error('Course ID is incorrect');
    }

    $strgalleries = get_string('gallerys','block_lightboxgallery_slideshow');
    if (! $galleries = get_all_instances_in_course('lightboxgallery', $course)) {
		//notice(get_string('thereareno', 'moodle', $strgalleries), $CFG->wwwroot . '/course/view.php?id=' . $course->id);
		return $this->context = get_string('thereareno', 'moodle', $strgalleries);
    }

    if(empty($this->config->width)){
      $width = 220;
    } else {
      $width = $this->config->width;
    }

    if(empty($this->config->height)){
      $height = 180;
    } else {
      $height = $this->config->height;
    }

    include_once("slideshow.php");

    if(empty($this->config->galleryid)){
      $data = get_string('content','block_lightboxgallery_slideshow');
    } else {
      $data =  "<div style=\"text-align:center;\">";
      $data .= Insert_Slideshow ( "$CFG->wwwroot/blocks/lightboxgallery_slideshow/slideshow.swf",
		"$CFG->wwwroot/blocks/lightboxgallery_slideshow/slideshowdata.php?l=".$this->config->galleryid, $width, $height );
      $data .= "</div>";
    }

    $this->content = new stdClass;
    $this->content->text = $data;
    //$this->content->footer = !empty($this->config->text) ? $this->config->text : '';

    return $this->content;
  }

  function instance_allow_config() {
    return true;
  }

  function specialization() {
    if(!empty($this->config->title)){
      $this->title = $this->config->title;
    }else{
      $this->config->title = get_string('title','block_lightboxgallery_slideshow');
    }
    if(empty($this->config->text)){
      $this->config->text = get_string('imagegallery','block_lightboxgallery_slideshow');
    }
  }

  function applicable_formats() {
    return array(
	    'all' => false,
	    'course-view' => true
    );
  }

}
?>