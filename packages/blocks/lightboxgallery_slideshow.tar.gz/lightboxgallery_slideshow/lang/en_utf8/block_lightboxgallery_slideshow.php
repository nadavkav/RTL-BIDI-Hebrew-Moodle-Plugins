<?php

$string['imagegallery'] = "lightboxgallery slideshow";
$string['title'] = "album slideshow";
$string['content'] =  'please choose lightboxgallery album';
$string['configtitle'] = "slideshow title";
$string['configcontent'] =  'slideshow sub title';
$string['configgallery']= 'plase choose a lighboxgallery for the slideshow';
$string['configheight']= 'slideshow height';
$string['configwidth']= 'slideshow width';

?>