===================
Course Date Manager
===================

Author: Brian Koontz <brian@pongonova.net>

Modified By: George A. Driscoll <gdriscoll@dcccd.edu>

See "install.txt" for installation instructions.

This Moodle block is designed to facilitate the modification of all
event parameters for each activity in a Moodle course from a single
integrated page. This would allow you, for example, to copy a course
from one semester to another, perform a mass date change operation for
X days to shift dates to a new semester, and then perform individual
date adjustments on course activities.

It works for these seven module types: Assignment, Choice, Forum, Glossary, Lesson, Quiz, and Workshop.  One or all of these module types can be selected for display and processing.  This permits you to concentrate on the events associated with one type of module at a time if you wish.

The Course Date Manager block offers users three options for changing
an event's scheduled date/time.  A list of events is presented to the
user sorted by each of the event's date/time value.  Each of the three
options operates on the event(s) selected by the user.  Events with
the same date/time value can be selected as a block.

The Adjustment option allows the user to advance the scheduled date/time
for selected events by a user controlled number of days, hours, and 
minutes.

The Specific date option permits the user to define a particular date
and time that will become the scheduled date/time for the selected events.

The Weekly Increment option operates on a list of events selected by
the user.  The user specified date/time becomes the scheduled date/time
for the first event in the list.  Subsequent events are scheduled to occur one week from each other.  This works well for a series of events that are
scheduled to occur on a weekly basis such as a weekly quiz.

The HTML portion of the block requires Javascript be enabled on your
browser. Simply add the block to each course you want to use it in. At
present, the block itself is available to any teacher assigned to a
course. At some point in the future, this will be converted to a
configurable block setting to permit restricting the use of this block
to admins and/or creators.

There are some performance issues when attempting to modify a large
number of dates using the "Select all" or "Select groups" feature.
You might receive the following error:

Fatal error: Maximum execution time of 30 seconds exceeded in
/Library/WebServer/Documents/moodle-15/lib/datalib.php on line 1237

You have one of two choices:

1.  Add the following to your moodle/config.php file:

set_time_limit(600);

2.  Break up the date change operation into smaller groupings.

* Future enhancements

--Include settings for access control

--Interface to add new modules and/or module date features without
having to modify the code base

--Fix invalid dates displayed in HTML drop-downs

