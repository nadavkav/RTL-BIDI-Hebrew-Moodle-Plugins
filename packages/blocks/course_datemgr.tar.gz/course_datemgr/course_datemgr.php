<?PHP // $Id$

/*
 * File: course_datemgr.php
 *
 * Copyright (c) 2005 Brian Koontz <brian@pongonova.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Modified 1/1/2008 George A. Driscoll <gdriscoll@dcccd.edu>
 * 
 * Added the capability to increment event dates on a weekly basis.
 * User defines a date/time and selects events from a list.  First event
 * takes on the specified date/time, next event is defined as one week
 * later, and so on and so forth for each event selected by user.
 *
 * Modified 5/22/2008 George A. Driscoll <gdriscoll@dcccd.edu>
 *
 * Added capability to select which modules are displayed/updated
 *
 */

require_once("../../config.php");
require_once("../../course/lib.php");
require_once("../../mod/assignment/lib.php");

// require_variable($id);   // course
// Replaced "require_variable($id)" With "$id = required_param ( 'id', PARAM_INT )"
// 20 December, 2007 George A. Driscoll

$id = required_param('id', PARAM_INT);

if (!isteacher($id)) {
    return '';
}

// Supported modules

$modulessupported = array("assignment", "choice", "forum", "glossary", "lesson", "quiz", "workshop");

if (!$course = get_record("course", "id", $id)) {
    error ( "Course ID is incorrect" );
}

require_course_login($course);
add_to_log($course->id, "course", "dates viewed/modified", "course_datemgr.php?id=$course->id", "$course->fullname");

// Make updates if page has been submitted

if ($data = data_submitted()) {
    if (isset($data->cancel))
    {
        redirect("$CFG->wwwroot/course/view.php?id=$course->id");
    }
    
    // Initialize All Modules To An Unchecked State
    
  	 $select_assignment = 0;
 	 $select_choice     = 0;
	 $select_forum      = 0;
	 $select_glossary   = 0;
	 $select_lesson     = 0;
	 $select_quiz       = 0;
	 $select_workshop   = 0;

    // Uncomment next for debug output
    // echo "Selection Indicators Set To Zero For All Modules.<br />";
    
    // Get the array of check box indicators

    $selection = array();

    //Ensure that at least one module type has been selected

    if ( isset($_POST["selection"]) ) {
        $selection = $_POST["selection"];

        // Identify the Modules to be displayed/updated
    
        foreach( $selection as $choice ) {
		    switch( $choice ) {
		   	    case 'assignment':
			        $select_assignment = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'assignment' Module.<br />";
			    break;
			
			    case 'choice':
				    $select_choice = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'choice' Module.<br />";
			    break;
			
			    case 'forum':
				    $select_forum = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'forum' Module.<br />";
			    break;
			
			    case 'glossary':
				    $select_glossary = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'glossary' Module.<br />";
			    break;
			
			    case 'lesson':
				    $select_lesson = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'lesson' Module.<br />";
			    break;
			
			    case 'quiz':
				    $select_quiz = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'quiz' Module.<br />";
			    break;
			
			    case 'workshop':
				    $select_workshop = 1;

                    // Uncomment next for debug output
                    // echo "Selection Indicators Set To One For 'workshop' Module.<br />";
			    break;
		    }
        }
    }
    
    // Display a message if None of the Modules have been selected
    
    $num_modules = $select_assignment + $select_choice + $select_forum + $select_glossary + $select_lesson + $select_quiz + $select_workshop;
    if ( $num_modules == 0 ) {
        $msg = get_string( "nomodules", "block_course_datemgr" );
        echo "<p align=\"center\"><font color=\"red\" size=\"+1\">$msg</font></p>";
    }
    
    $instances = array();
    $mods_to_update = array();
    $increment = 0;
    $oldvalue = 0;
    foreach($data as $key=>$val)     {
        // Uncomment next for debug output
        // echo "$key: $val<br />";

        if (preg_match("/^.*_.*_.*$/", $key)) {
            $params = explode( '_', $key );
            $modname = $params[0];
            $mods_to_update["$modname"] = 1;

            // Uncomment next for debug output
            // echo "Updating $params[0]-$params[1]-$params[2]\n";

            $dataobj->id = $params[1];

            // Some strangeness here to dynamically create object
            // attributes...

            $tmp = (array)$dataobj;
            $adj = 0;

            // What Kind Of Date Adjustment Has The User Requested?

            if (strcmp($data->adjtype, "absolute") == 0) {
                // Use a specific date

                // Uncomment next for debug output
                // echo "<br />Absolute Date Assignment<br />\n";
                $adj = make_timestamp($data->absyear, $data->absmonth,
                       $data->absday, $data->abshour, $data->absminute);

            } else if (strcmp($data->adjtype, "relative") == 0) {
                // Adjust the current date using 'daysadj', 'hoursadj', and 'minutesadj'

                // Uncomment next for debug output
                // echo "<br />Relative Date Assignment<br />\n";
                $adj = $val + $data->daysadj*3600*24 + 
                              $data->hoursadj*3600 + 
                              $data->minutesadj*60;
            } else if (strcmp($data->adjtype, "weekly") == 0) {
                // Define The Date Of The First Event With 'wkyear', 'wkmonth', etc.
                // Then Increment On A Weekly Basis From That Date.
                // Weekly Increment = 7 * 24 * 60 * 60 seconds = 604,800 seconds.

                // Uncomment next for debug output
                // echo "<br />Increment Dates Weekly: Increment = $increment<br />\n";

                if ($increment == 0)                 {
                    $adj = make_timestamp($data->wkyear, $data->wkmonth,
                           $data->wkday, $data->wkhour, $data->wkminute);
                    $oldvalue = $adj;
                    // Uncomment next for debug output
                    // echo "<br />Initial Date = $oldvalue<br />\n";
                } else {
                    $adj = $oldvalue + $increment * 604800;
                }
                $increment = $increment + 1;
            } else {
               echo "<br />Invalid Course Date Adjustment Type<br />\n";
            }
            $tmp["$params[2]"] = $adj;
            $dataobj = (object)$tmp;
            if (!update_record( "$params[0]", $dataobj)) {
                error("Could not update $params[0] entry id = $params[1] column = $params[2] value = $adj");
            }

            // Update calendar

            foreach($mods_to_update as $modname=>$v) {
                // Include module library

                require_once("$CFG->dirroot/mod/$modname/lib.php");
                $function_name = $modname."_refresh_events";
                if (function_exists($function_name)) {
                    $status = $function_name($id);
                } 
            }
        }
    }
}
else{
	// Set Default Selection Values for Module type Inclusion:
	// 1 = ON or Checked, 0 = OFF or Unchecked
	
	$select_assignment = 1;
	$select_choice     = 0;
	$select_forum      = 0;
	$select_glossary   = 0;
	$select_lesson     = 0;
	$select_quiz       = 1;
	$select_workshop   = 0;
}            

get_all_mods($course->id, $mods, $modnames, $modnamesplural, $modnamesused);

class Instance {
    var $globaldue = "";
    var $localdue = "";
    var $desc = "";
    var $modname = "";
    var $instanceid = "";
    var $field = "";

    function Instance( $globaldue, $localdue, $desc, $modname,
                       $instanceid, $field ) {
        $this->globaldue = $globaldue;
        $this->localdue = $localdue;
        $this->desc = $desc;
        $this->modname = $modname;
        $this->instanceid = $instanceid;
        $this->field = $field;
    }

    function print_inputarea($id, $name, $value="", $maxlength="") {
        // Prints a basic input text field

        $type = "text";
        $size = $maxlength-1;
        return "<input id=\"$id\" name=\"$name\" maxlength=\"$maxlength\" size=\"$size\" type=\"$type\" value=\"$value\">\n";
    }

    function print_checkbox($id, $name, $value="", $onchange="") {
        // Prints a basic input text field

        $type = "checkbox";
        return "<input id=\"$id\" name=\"$name\" type=\"$type\" value=\"$value\" onchange=\"$onchange\">\n";
    }
}

foreach(array_keys($modnamesused) as $modnameused) {
    $lcmodnameused = moodle_strtolower($modnameused);
    if (! $instances = get_all_instances_in_course($lcmodnameused, $course)) {
        notice ( "There are no $modnameused modules", "$CFG->wwwroot/course/view.php?id=$course->id" );
        die;
    }

    foreach($instances as $instance) {
        // Assignment module

        if(!strcmp($lcmodnameused, "assignment") & ( $select_assignment || ( $num_modules == 0 ) ) ) {
            if($ts = $instance->timedue) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("duedate",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timedue");
            }
            if($ts = $instance->timeavailable) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("available",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timeavailable");
            } 
        }

        // Choice module

        else if(!strcmp($lcmodnameused, "choice") & ( $select_choice || ( $num_modules == 0 ) ) ) { 
            if($ts = $instance->timeopen) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("timeopen",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timeopen");
            } 
            if($ts = $instance->timeclose) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("timeclose",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timeclose");
            }
        }

        // Forum module

        else if(!strcmp($lcmodnameused, "forum") & ( $select_forum || ( $num_modules == 0 ) ) ) {
            if($ts = $instance->assesstimestart) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessstart",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assesstimestart");
            } 
            if($ts = $instance->assesstimefinish) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessfinish",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assesstimefinish");
            }
        }

        // Glossary module

        else if(!strcmp($lcmodnameused, "glossary") & ( $select_glossary || ( $num_modules == 0 ) ) ) {
            if($ts = $instance->assesstimestart) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessstart",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assesstimestart");
            } 
            if($ts = $instance->assesstimefinish) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessfinish",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assesstimefinish");
            }
        }

        // Lesson module

        else if(!strcmp($lcmodnameused, "lesson") & ( $select_lesson || ( $num_modules == 0 ) ) ) {
            if($ts = $instance->available) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("available",'block_course_datemgr').")", $lcmodnameused, $instance->id, "available");
            } 
            if($ts = $instance->deadline) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("deadline",'block_course_datemgr').")", $lcmodnameused, $instance->id, "deadline");
            }
        }

        // Quiz module

        else if(!strcmp($lcmodnameused, "quiz") & ( $select_quiz || ( $num_modules == 0 ) ) ) { 
            if ( $ts = $instance->timeopen ) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("timeopen",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timeopen");
            } 
            if ( $ts = $instance->timeclose ) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("timeclose",'block_course_datemgr').")", $lcmodnameused, $instance->id, "timeclose");
            }
        }

        // Workshop module

        else if(!strcmp($lcmodnameused, "workshop") & ( $select_workshop || ( $num_modules == 0 ) ) ) { 
            if($ts = $instance->submissionstart) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("submissionstart",'block_course_datemgr').")", $lcmodnameused, $instance->id, "submissionstart");
            } 
            if($ts = $instance->assessmentstart) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessmentstart",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assessmentstart");
            } 
            if($ts = $instance->submissionend) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("submissionend",'block_course_datemgr').")", $lcmodnameused, $instance->id, "submissionend");
            } 
            if($ts = $instance->assessmentend) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("assessmentend",'block_course_datemgr').")", $lcmodnameused, $instance->id, "assessmentend");
            } 
            if($ts = $instance->releasegrades) {
                $table->data[] = 
                new Instance("", $ts, $instance->name." (".get_string("releasegrades",'block_course_datemgr').")", $lcmodnameused, $instance->id, "releasegrades");
            } 
        }
    }
}
echo "<br />";

// Sort table by date

$due = array();
$name = array();
foreach($table->data as $key => $instance) {
    $due[$key] = $instance->globaldue;
    $name[$key] = $instance->localdue;
}
array_multisort($due, SORT_ASC, SORT_NUMERIC, 
                $name, SORT_ASC, 
                $table->data);

$data = &$table->data;                
$instance = &$data[0];
$prev = $instance->localdue;
$instance->globaldue = $prev;

// foreach($data as &$arr) doesn't seem to work in my PHP version...

foreach ( $data as  $key=>$value_copy ) {
    if( $prev != $data[$key]->localdue) {
        $prev = $data[$key]->localdue;
        $data[$key]->globaldue = $prev;
    }
}

$printtable->data[] = array( Instance::print_checkbox("box_level0", "", "", 
                        "toggleAllBoxes()"), "", "", "" );
foreach ( $table->data as $key => $instance ) {
    $name = $instance->modname . "_" . 
            $instance->instanceid . "_" . 
            $instance->field;
    if ( $instance->globaldue ) {
        $printtable->data[] = array( "", Instance::print_checkbox("box_level1", "", "", "toggleBoxes('$instance->globaldue')"),
            Instance::print_checkbox("box_level2", $name, $instance->localdue) .  
            userdate( $instance->localdue ),
            $instance->desc );
    }
    else if ( $instance->localdue ) {
        $printtable->data[] = array( "", "", Instance::print_checkbox("box_level2", $name, $instance->localdue) . 
            userdate( $instance->localdue ),
            $instance->desc );
    }
}

$printtable->head = array (get_string("selectall",'block_course_datemgr'), get_string("selectgroups",'block_course_datemgr'), get_string("eventdate",'block_course_datemgr'), get_string("name",'block_course_datemgr'));
$printtable->align = array ("left", "left", "left", "left");
$navlinks = array();
$navlinks[] = array('name' => get_string( "course_datemgr", "block_course_datemgr" ),'link' => null, 'type' => 'misc');
$navigation = build_navigation( $navlinks );
print_header( $course->shortname, $course->fullname, $navigation );
// print_header("$course->shortname: ".get_string("datesshortname",'block_course_datemgr'), "$course->fullname", "<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a>","");
include("course_datemgr.html");
print_footer($course);

?>
