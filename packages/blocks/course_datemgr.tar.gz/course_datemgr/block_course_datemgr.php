<?PHP //$Id$

/*
 * File: block_course_datemgr.php
 *
 * Copyright (c) 2005 Brian Koontz <brian@pongonova.net>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Modified 1/1/2008 George A. Driscoll <gdriscoll@dcccd.edu>
 * Modified 5/30/2008 George A. Driscoll <gdriscoll@dcccd.edu>
 *
 */
 
class block_course_datemgr extends block_base 
{
    function init() {
        $this->title = get_string('course_datemgr', 'block_course_datemgr');
        $this->version = 2008060600;
    }

    function applicable_formats() {
        return array ( 'all'=>false, 'course-view'=>true );
    }

    function get_content() {
        global $CFG;

        if ($this->content !== NULL) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = '';

        // Hide block from non-teachers

        // if ( !isteacher ( $CFG->instance->pageid ) ) ORIGINAL LINE
        if ( !isteacher ( $this->instance->pageid ) ) {  // SUBSTITUTED 18 Dec, 2007 GAD
            $this->content->footer = '';
        } else {
            // $this->content->footer = "<a href=\"".$CFG->wwwroot."/blocks/course_datemgr/course_datemgr.php?id=".$this->instance->pageid."\" target=\"_blank\">Modify course dates...</a>";
            $this->content->footer = "<a href=\"".$CFG->wwwroot."/blocks/course_datemgr/course_datemgr.php?id=".$this->instance->pageid."\" >".get_string('modifycoursedates', 'block_course_datemgr')."</a>";
        }        

        return $this->content;
    }
}
?>
