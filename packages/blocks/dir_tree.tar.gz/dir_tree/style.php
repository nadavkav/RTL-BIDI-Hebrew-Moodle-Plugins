<?php
include_once("../../config.php");
global $CFG,$COURSE;
$strwebroot = $CFG->wwwroot;
if ($COURSE->lang == 'he_utf8' || $COURSE->lang == '') {
$strrtlicons = '-rtl';
$strrtlstyles = "background-position:right top; padding-right:22px; ";
} else {
$strrtlicons = '';
}
header('Content-type: text/css');
echo "
/*	Moodle icons debug */

.icon-wav, .icon-mp3 { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/audio.gif) no-repeat; $strrtlstyles}
.icon-avi,.icon-wmv,.icon-mov,.icon-video { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/video.gif) no-repeat; $strrtlstyles}
.icon-doc, .icon-docx, .icon-docm, .icon-word { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/word.gif) no-repeat; $strrtlstyles}
.icon-folder { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/folder.gif) no-repeat; $strrtlstyles}
.icon-jpg, .icon-gif, .icon-png, .icon-bmp, .icon-image { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/image.gif) no-repeat; $strrtlstyles}
.icon-html { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/html.gif) no-repeat; $strrtlstyles}
.icon-ppt, .icon-pptx, .icon-powerpoint { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/powerpoint.gif) no-repeat; $strrtlstyles}
.icon-pdf { display:block; height: 16px; padding-left: 20px;
		 background: transparent url($strwebroot/pix/f/pdf.gif) no-repeat; $strrtlstyles}
.icon-txt, .icon-text { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/text.gif) no-repeat; $strrtlstyles}
.icon-xls, .icon-xlsx, .icon-excel { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/excel.gif) no-repeat; $strrtlstyles}
.icon-xml { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/xml.gif) no-repeat; $strrtlstyles}
.icon-zip { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/zip.gif) no-repeat; $strrtlstyles}
.icon-unknown { display:block; height: 16px; padding-left: 20px;
		background: transparent url($strwebroot/pix/f/unknown.gif) no-repeat; $strrtlstyles}

#dirTreeResourcesYUI {
    font-size: 10pt;
}

/*
#dirTreeResourcesYUI .icon-docx, .icon-doc, .icon-txt, .icon-folder, .icon-jpg, .icon-html, .icon-wav, .icon-ppt,
.icon-pdf, .icon-zip, .icon-xls, .icon-xlsx, .icon-unknown, .icon-mp3, .icon-wmv, .icon-mov, .icon-xml {
    width: 400px;
}
*/

.htmlnodelabel { margin-left: 20px; }

.cellIcon { width: 30px; }
.cellName { width: 400px; }
.cellItemSize { width: 80px; }
.cellFolderSize { width: 80px; font-weight: bold; }
.cellDate {  }

/*
Copyright (c) 2008, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.net/yui/license.txt
version: 2.5.2
*/
/* first or middle sibling, no children */

.ygtvtn {
	width:18px; height:22px;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -5600px no-repeat;
}

/* first or middle sibling, collapsable */
.ygtvtm {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -4000px no-repeat;
}

/* first or middle sibling, collapsable, hover */
.ygtvtmh {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -4800px no-repeat;
}

/* first or middle sibling, expandable */
.ygtvtp {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -6400px no-repeat;
}

/* first or middle sibling, expandable, hover */
.ygtvtph {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -7200px no-repeat;
}

/* last sibling, no children */
.ygtvln {
	width:18px; height:22px;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -1600px no-repeat;
}

/* Last sibling, collapsable */
.ygtvlm {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 0px no-repeat;
}

/* Last sibling, collapsable, hover */
.ygtvlmh {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -800px no-repeat;
}

/* Last sibling, expandable */
.ygtvlp {
	width:18px; height:22px;
	cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -2400px no-repeat;
}

/* Last sibling, expandable, hover */
.ygtvlph {
	width:18px; height:22px; cursor:pointer ;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -3200px no-repeat;
}

/* Loading icon */
.ygtvloading {
	width:18px; height:22px;
	background: url($strwebroot/lib/yui/treeview/assets/treeview-loading.gif) 0 0 no-repeat;
}

/* the style for the empty cells that are used for rendering the depth
 * of the node */
.ygtvdepthcell {
	width:18px; height:22px;
	background: url($strwebroot/lib/yui/treeview/assets/sprite-orig$strrtlicons.gif) 0 -8000px no-repeat;
}

.ygtvblankdepthcell { width:18px; height:22px; }

/* the style of the div around each node */
.ygtvitem { }

.ygtvitem table {
    margin-bottom:0; border:none;
}

.ygtvitem th td {
    border:none;padding:0;
}

/* the style of the div around each node's collection of children */
.ygtvchildren {  }
* html .ygtvchildren { height:2%; }


/* the style of the text label in ygTextNode */
.ygtvlabel, .ygtvlabel:link, .ygtvlabel:visited, .ygtvlabel:hover {
	margin-left:2px;
	text-decoration: none;
    background-color: white; /* workaround for IE font smoothing bug */
}

.ygtvspacer { height: 22px; width: 12px; }

.dir-rtl .ygtvspacer, .dir-rtl .ygtvspacer {
/* background:transparent url(http://www.tikshuv.org.il/moodle/blocks/yui_menu/skin/n.gif) no-repeat scroll right center; */
background:none;
}

.dir-ltr .ygtvtn .ygtvspacer, .dir-ltr .ygtvln .ygtvspacer {
background:transparent url(http://www.tikshuv.org.il/moodle/blocks/yui_menu/skin/n-ltr.gif) no-repeat scroll right center;
}

";
?>
