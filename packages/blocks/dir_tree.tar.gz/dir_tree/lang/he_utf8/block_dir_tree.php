<?php
$string['title'] = 'קובציי מרחב הלימוד';
$string['default'] = 'בררת־מחדל';
$string['whatcall'] = 'אנא הזינו כותרת למשבצת ניהול קבצים זו';
$string['whichfolder'] = 'בחרו תיקייה אותה אתם מעוניינים להציג';
$string['levels'] = 'כמה תתי תיקיות יש להציג בתוך התיקייה הראשית';
$string['toplevelonly'] = 'ראשית, בלבד';
$string['toptwolevels'] = 'שתיי רמות';
$string['topthreelevels'] = 'שלוש רמות';
?>
