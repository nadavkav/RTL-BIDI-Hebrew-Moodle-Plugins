<?php
$string['title'] = 'Course Files';
$string['default'] = 'Default';
$string['whatcall'] = 'What would you like to call this block';
$string['whichfolder'] = 'Choose a folder you would like to have displayed by this block';
$string['levels'] = 'How many levels deep would you like to display the sub folders';
$string['toplevelonly'] = 'Top level, only';
$string['toptwolevels'] = 'Top Two levels';
$string['topthreelevels'] = 'Top Three levels';
?>
