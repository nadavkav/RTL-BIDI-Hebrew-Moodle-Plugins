.block_eportfolio_externalview {
  font-style: italic;
}
.block_eportfolio_commentauthor {
  font-weight: bold;
}
.block_eportfolio_bold {
  font-weight: bold;
}
.block_eportfolio_timemodified {
  font-style: italic;
  font-size: 10px;
}
.block_eportfolio_italic {
  font-style: italic;
  font-size: 10px;
}
.block_eportfolio_center {
  text-align: center;
}

.block_eportfolio_centerw {
  text-align: center;
  width:100%;
}
.block_eportfolio_export {
  text-align: left;
  width: 300px; 
  margin: 2em auto;
}
.block_eportfolio_bmukk {
  margin: 30px 10px 10px 10px;
  float: left;
}
.block_eportfolio_exabis {
  margin: 30px 10px 10px 10px;
  float: right;
}
.block_eportfolio_clear {
  clear: both;
}
.block_eportfolio_categories {
  text-align: left; 
  width: 300px; 
  margin: 2em auto;
}

.block_eportfolio_italic {
  text-style: italic; 
}

.dir-rtl .block_eportfolio_categories {
text-align:right;
}