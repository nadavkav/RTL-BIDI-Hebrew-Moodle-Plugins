<?PHP // $Id: block_birthday.php,v 1.3 2007/09/03 18:39:40 arborrow Exp $ 
      // block_birthday.php - created with Moodle 1.9 Beta + (2007083101)


$string['birthday'] = '誕生日';
$string['block_title'] = '今日の誕生日';
$string['blockhide'] = '誕生日がない場合、ブロックを隠す';
$string['blockname'] = '誕生日';
$string['blockshow'] = '誕生日がない場合、ブロックを表示する';
$string['blockvisible_info'] = '誕生日がない場合、ブロックを表示しますか?';
$string['dateformat_info'] = 'あなたのデータがユーザプロフィールに保存されるときの日付フォーマットを選択してください。デフォルトの日付フォーマットはISO形式です。';
$string['dateformateur'] = 'EUR日付フォーマット: \'%%d.%%m.%%Y\'';
$string['dateformatiso'] = 'ISO日付フォーマット: %%Y-%%m-%%d (デフォルト)';
$string['dateformatusa'] = 'USA日付フォーマット: \'%%m.%%d.%%Y\'';
$string['happybirthday'] = 'お誕生日おめでとうございます!';
$string['nobirthdays'] = '今日の誕生日はありません。';
$string['periodnminutes'] = 'ラスト $a 分';
$string['user_info_field_shortname'] = 'ユーザの誕生日を含む一意のユーザプロフィールフィールド省略名を入力してください (デフォルト省略名は「DOB」です)。';

?>
