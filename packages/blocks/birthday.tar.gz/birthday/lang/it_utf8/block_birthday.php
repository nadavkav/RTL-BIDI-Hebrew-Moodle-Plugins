﻿<?PHP // $Id: block_birthday.php,v 1.3 2007/08/31 03:42:29 arborrow Exp $ 
      // block_birthday.php - created with Moodle 1.8.2+ 

$string['birthday'] = 'Cumpleanno'; 
$string['blockname'] = 'Cumpleanno'; 
$string['blockshow'] = 'Mostra il blocco quando non ci sono compleanni';
$string['blockhide'] = 'Nasconde il blocco quando non ci sono compleanni';
$string['blockvisible_info'] = 'Mostra il blocco quando non ci sono compleanni?';
$string['block_title'] = 'Cumpleanni di oggi'; 
$string['dateformat_info'] = 'Scegli il modo in quale sara tenuto la sua informazione nel pofilo del operatore (il predefinito é  ISO).'; 
$string['dateformatiso'] = 'Il formato del dato ISO: \'%%Y-%%m-%%d\' (il predefinito)';  
$string['dateformatusa'] = 'Il formato del dato USA: \'%%m.%%d.%%Y\''; 
$string['dateformateur'] = 'Il formato del dato EUR: \'%%d.%%m.%%Y\''; 
$string['happybirthday'] = 'Tanti Auguri. Buon compleanno.'; 
$string['nobirthdays'] = 'Non ci sono cumpleanni oggi'; 
$string['periodnminutes'] = 'Gli ultimi $a minuti'; 
$string['user_info_field_shortname'] = 'L’unico nome corto del profile del campo del operatore che contiene la data di nascita del operatore (il predefinito é \'DOB\').';  

?>
