<?PHP // $Id: block_birthday.php,v 1.1 2007/08/31 04:24:16 arborrow Exp $ 
      // block_birthday.php - created with Moodle 1.8.2+ 

$string['birthday'] = 'Anniversaire';
$string['blockname'] = 'Anniversaire';
$string['blockshow'] = 'Montrer l\'ensemble lorsque il n\'y a pas d\'anniversaires';
$string['blockhide'] = 'Cacher l\'ensemble lorsque il n\'y a pas d\'anniversaires';
$string['blockvisible_info'] = 'Montrer l\'ensemble lorsque il n\'y a pas d\'anniversaires?';
$string['block_title'] = 'Les anniversaires du jour ';
$string['dateformat_info'] = 'Choisir le format de la date sur laquelle les donnees ont ete stockees dans le profile de l\'utilisateur. Le format de la date par defaut est ISO';
$string['dateformatiso'] = 'Le format de la date ISO: %%Y-%%m-%%d (par defaut)';
$string['dateformatusa'] = 'Le format de la date USA: \'%%m.%%d.%%Y\'';
$string['dateformateur'] = 'Le format de la date EUR: \'%%d.%%m.%%Y\'';
$string['happybirthday'] = 'Joyeux anniversaire';
$string['nobirthdays'] = 'Pas d\'anniversaires aujourd\'hui';
$string['user_info_field_shortname'] = 'L\'unique court nom du champ du profil de l\'utilisateur qui contient la date de naissance de l\'utilisateur (le court nom par defaut est \'DOB\').';

?>
