
<?PHP // $Id: block_birthday.php,v 1.2 2007/10/04 16:07:17 arborrow Exp $ 
      // block_birthday.php - created with Moodle 1.8.2+ 

$string['birthday'] = 'F&oumldelsedagar';
$string['blockname'] = 'F&oumldelsedagar';
$string['blockshow'] = 'Visa block aven ingen fyller ar';
$string['blockhide'] = 'Dolj block om ingen fyller ar';
$string['blockvisible_info'] = 'Ska blocket vara synligt &aumlven om ingen fyller &aringr?';
$string['block_title'] = 'Dagens F&oumldelsedagsbarn';
$string['dateformat_info'] = 'v&aumllj format f&oumlr hur data sparas i anv&aumlndarens profil\. standard format &aumlr ISO.';
$string['dateformatiso'] = 'ISO Datum format: %%Y-%%m-%%d (default)';
$string['dateformatusa'] = 'USA Datum format: \'%%m.%%d.%%Y\'';
$string['dateformateur'] = 'EUR Datum format: \'%%d.%%m.%%Y\'';
$string['happybirthday'] = 'Grattis p&aring f&oumldelsedagen!';
$string['nobirthdays'] = 'Det &aumlr ingen som fyller &aringr idag.';
$string['periodnminutes'] = 'last $a minutes';
$string['user_info_field_shortname'] = 'Den unika f&oumlrkortning f&oumlr f&aumlltet i anv&aumlndarens profil som inneh&aringller anv&aumlndarens f&oumldelsedatum (standard f&oumlrkortning &aumlr\'DOB\').';

?>
