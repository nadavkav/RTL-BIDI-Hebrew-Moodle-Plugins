﻿<?PHP // $Id: block_birthday.php,v 1.4 2007/08/31 03:42:30 arborrow Exp $ 
      // block_birthday.php - created with Moodle 1.8.2+ 

$string['birthday'] = 'Cumpleaños';
$string['blockname'] = 'Cumpleaños';
$string['blockshow'] = 'Bloque visible cuando no hay cumpleaños';
$string['blockhide'] = 'Bloque escondido cuando no hay cumpleaños';
$string['blockvisible_info'] = '¿Mostrar bloque si no hay cumpleaños?';
$string['block_title'] = 'Cumpleaños del día';
$string['dateformat_info'] = 'Escoje el formato (ISO, USA, EUR) de la fecha que utilice (por defecto es ISO). ';
$string['dateformatiso'] = 'Formato ISO: %%Y-%%m-%%d (por defecto)';
$string['dateformatusa'] = 'Formato USA: \'%%m.%%d.%%Y\'';
$string['dateformateur'] = 'Formato EUR: \'%%d.%%m.%%Y\'';
$string['happybirthday'] = '¡Feliz Cumpleaños!';
$string['nobirthdays'] = 'En este día, nadie está celebrando su cumpleaños.';
$string['periodnminutes'] = 'durante los ultimos $a minutos';
$string['user_info_field_shortname'] = 'El nombre breve del campo en el perfíl del usuario que contiene la fecha de nacimiento del usuario (por defecto es \'DOB\').';

?>
