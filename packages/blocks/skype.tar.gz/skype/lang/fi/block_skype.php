<?PHP // $Id$ Finnish translation by Petri Niemi
      // block_skype.php - created with Moodle 1.5.3+ (2005060230)


$string['addcontact'] = 'Lis�� kontakti';
$string['blocktitle'] = 'Skypen k�ytt�jien tilat';
$string['callme'] = 'Soita';
$string['chat'] = 'Aloita chat';
$string['skypefooter'] = 'Tarvitset uusimman version <a href=\'http://www.skype.com\' target=\'_blank\'>Skypest�</a>, jotta voit n�ytt�� tilasi verkossa.';
$string['studentheader'] = 'Opiskelijoiden tilat';
$string['studentskype'] = 'Opiskelijat skypess�';
$string['nostudents'] = "T�ll� kurssilla ei ole";

?>
