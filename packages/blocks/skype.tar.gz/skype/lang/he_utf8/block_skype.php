<?php //$Id$

// --------------------------------------------------------------
// Skype Presence Block v0.6 for Moodle 1.5.3
// --------------------------------------------------------------
// Created by Matt Crosslin for the University of Texas at 
// Arlington Center for Distance Education - December 2005.
// --------------------------------------------------------------

$string['blocktitle'] = "מי מחובר ב Skype";
$string['callme'] = 'התקשרו אלי';
$string['chat'] = 'התחילו צט';
$string['addcontact'] = 'הוספת חבר';
$string['studentskype'] = 'תלמידים משתמשים ב Skype';
$string['skypefooter'] = "יש צורך להוריד את גירסת <a href='http://www.skype.com' target='_blank'>Skype</a> האחרונה על מנת להראות את מצב החיבור שלכם.";
$string['studentheader'] = "מצב סקייף של הכיתה:";
$string['nostudents'] = "אין משתמשי SKYPE במרחב זה";

?>