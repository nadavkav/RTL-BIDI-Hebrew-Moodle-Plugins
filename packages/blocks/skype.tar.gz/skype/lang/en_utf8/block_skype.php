<?php //$Id$

// --------------------------------------------------------------
// Skype Presence Block v0.6 for Moodle 1.5.3
// --------------------------------------------------------------
// Created by Matt Crosslin for the University of Texas at 
// Arlington Center for Distance Education - December 2005.
// --------------------------------------------------------------

$string['blocktitle'] = "Who's On Skype";
$string['callme'] = 'Call Me';
$string['chat'] = 'Start a Chat';
$string['addcontact'] = 'Add Contact';
$string['studentskype'] = 'Students On Skype';
$string['skypefooter'] = "You will need the latest version of <a href='http://www.skype.com' target='_blank'>Skype</a> for your status to show.";
$string['studentheader'] = "Class Skype Status:";
$string['nostudents'] = "This course has no";

?>