<?php
/**
 *  SharingCart_ModuleException
 */

require_once dirname(__FILE__).'/SharingCart_Exception.php';

class SharingCart_ModuleException extends SharingCart_Exception
{
}

?>