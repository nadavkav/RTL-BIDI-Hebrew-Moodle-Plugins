<?php

$string['directoryslideshow'] = "מצגת ספריית תמונות";
$string['title'] = "מצגת תמונות מתחלפות";
$string['content'] =  'אנא בחרו ספריית תמונות לתצוגה';
$string['configtitle'] = "כותרת משבצת המצגת";
$string['configcontent'] =  'כיתוב נוסף תחת המצגת';
$string['clicktoshow']= 'הקליקו על אוסף התמונות להצגתו';
$string['configgallery']= 'בחרו ספריית תמונות לתצוגה';
$string['configheight']= 'גובה משבצת התצוגה';
$string['configwidth']= 'רוחב משבצת התצוגה';
$string['configimagedir']= 'בחרו ספריה לתצוגה';
$string['maincoursefolder']= 'ספרייה ראשית';

?>