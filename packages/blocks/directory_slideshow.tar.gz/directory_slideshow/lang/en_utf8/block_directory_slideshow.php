<?php

$string['directoryslideshow'] = "directory slideshow";
$string['title'] = "Directory Slideshow";
$string['configtitle'] = "slideshow title";
$string['configcontent'] =  'slideshow sub title';
$string['configheight']= 'slideshow height';
$string['configwidth']= 'slideshow width';
$string['configimagedir']= 'choose folder to display';
$string['maincoursefolder']= 'Course\'s Main folder';
?>