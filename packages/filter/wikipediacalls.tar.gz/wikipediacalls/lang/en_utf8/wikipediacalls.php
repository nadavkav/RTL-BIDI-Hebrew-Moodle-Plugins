<?php // $Id: wikipediacalls.php,v 1.1 2007/07/19 19:31:10 diml Exp $ 

$string['wikipediacallslinklabel'] = 'Test Wikipedia keys';
$string['wikipediakeys'] = '<u>Collected Wikipedia keys</u>';
$string['accesssettingmessage'] = 'For this function to complete must you have the across domain requesting enabled<br>(IE : Internet Options->Security->Customize level-><br>Access data sources across domains->Prompt)';
$string['okstatus'] = 'CHECKED';
$string['ambigstatus'] = 'AMBIGUOUS';
$string['nookstatus'] = 'FAILED';
$string['uncheckedstatus'] = 'UNCHECKED';
$string['checkingstatus'] = 'CHECKING';
$string['launchlink'] = 'Start the test';
$string['closewindow'] = 'Close window';

?>