<?php // $Id: wikipediacalls.php,v 1.1 2007/07/19 19:31:55 diml Exp $ 

$string['wikipediacallslinklabel'] = 'Probar las claves Wikipedia';
$string['wikipediakeys'] = '<u>CLaves Wikipedia colectadas</u>';
$string['accesssettingmessage'] = 'Para activar esta funccion, debe autorizar <br>las requestas multi-dominio<br>(IE : opciones internet->seguridad->Personalizar-><br>Autorizar el aceso a dominios multiples->Pedir)';
$string['okstatus'] = 'COMPROBADO';
$string['ambigstatus'] = 'AMBIGUO';
$string['nookstatus'] = 'NO EXISTE';
$string['uncheckedstatus'] = 'SIN COMPROBAR';
$string['checkingstatus'] = 'PROBANDO';
$string['launchlink'] = 'Comprobar';
$string['closewindow'] = 'Cerrar la pantalla';

?>