<?php // $Id: wikipediacalls.php,v 1.1 2007/07/19 19:32:08 diml Exp $ 

$string['wikipediacallslinklabel'] = 'Tester les clefs Wikipedia';
$string['wikipediakeys'] = '<u>Clefs Wikipedia collect�es</u>';
$string['accesssettingmessage'] = 'Pour activer cette fonction, vous devez avoir activ�<br>requ�tage multidomaine<br>(IE : Options internet->Param�tres de s�curit�->Personnaliser-><br>Autoriser l\\\'acces � plusieurs domaines->Demander)';
$string['okstatus'] = 'VERIFIE';
$string['ambigstatus'] = 'AMBIGU';
$string['nookstatus'] = 'INEXISTANT';
$string['uncheckedstatus'] = 'NON VERIFIE';
$string['checkingstatus'] = 'EN TEST';
$string['launchlink'] = 'D�marrer le test';
$string['closewindow'] = 'Fermer la fen�tre';

?>