<?PHP // $Id: hiddentext.php,v 1.1 2008/01/12 07:46:37 dlnsk Exp $ 
      // hiddentext.php - created with Moodle 2.0 dev (2007101506)


$string['filtername'] = '隠しテキスト';
$string['seemore'] = 'さらに表示する';

?>
