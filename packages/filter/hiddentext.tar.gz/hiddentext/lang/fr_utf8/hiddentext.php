<?PHP // $Id: hiddentext.php,v 1.1 2008/03/21 12:30:00 dlnsk Exp $ 
      // multilang.php - created with Moodle 1.4 development (2004070800)


$string['filtername'] = 'Texte caché';
$string['seemore'] = 'En savoir plus';

?>
