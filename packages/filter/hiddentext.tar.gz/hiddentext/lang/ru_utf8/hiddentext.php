<?PHP // $Id: hiddentext.php,v 1.1 2008/01/10 16:38:16 dlnsk Exp $ 
      // multilang.php - created with Moodle 1.4 development (2004070800)


$string['filtername'] = 'Cкрытый текст';
$string['seemore'] = 'Показать полностью';

?>
