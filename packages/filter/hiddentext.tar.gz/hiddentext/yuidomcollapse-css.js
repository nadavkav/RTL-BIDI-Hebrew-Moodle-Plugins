if(YAHOO && YAHOO.otorg && YAHOO.otorg.DomCollapse){
	YAHOO.otorg.DomCollapse.css = {
		triggerClass:'ht_trigger',
		hideClass:'hide',
		parentClass:'ht_parent',
		openClass:'ht_open'
	}
}
	