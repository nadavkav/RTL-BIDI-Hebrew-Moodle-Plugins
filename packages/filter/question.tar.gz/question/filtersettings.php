<?php  //$Id: filtersettings.php,v 1.1.2.2 2007/12/19 17:38:43 skodak Exp $


$settings->add(new admin_setting_configcheckbox('filter_question_plugin_enable', get_string('questionplugin','admin'), '', 1));

?>
