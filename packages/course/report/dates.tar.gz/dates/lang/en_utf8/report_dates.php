<?php
$string['summerydates'] = 'report by dates';
$string['displayreport'] = 'Show Report...';
$string['choosesummeryreport'] = 'Choose Report_By_Dates properties';
?>