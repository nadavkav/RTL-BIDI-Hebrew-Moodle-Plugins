<?php
$string['summerydates'] = 'דוח לפי תאריכים';
$string['displayreport'] = ' הצגת דוח... ';
$string['choosesummeryreport'] = " בחרו את מאפייני ה'דוח לפי תאריכים'  ";
?>