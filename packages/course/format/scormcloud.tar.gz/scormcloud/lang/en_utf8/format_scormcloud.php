<?php 

$string['formatscormcloud']='Rustici SCORM Cloud Engine';
$string['namescormcloud']='section';

?>
