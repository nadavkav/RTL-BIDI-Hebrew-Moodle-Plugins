<?php
$string['nametopoverblk'] = 'פסקאת מבוא בראש הדף';
$string['formattopoverblk'] = 'פסקאת מבוא בראש הדף';
?>