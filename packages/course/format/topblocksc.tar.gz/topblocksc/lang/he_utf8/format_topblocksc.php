<?php
$string['nametopblocksc'] = 'יחידות הוראה';
$string['formattopblocksc'] = 'משבצות ניהול ממורכזות בראש המרחב';
?>