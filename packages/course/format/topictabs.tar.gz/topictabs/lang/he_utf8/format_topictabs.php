<?PHP // $Id: format_weekstabs.php,v 1.1 2008/11/08 22:26:26 arborrow Exp $ 
      // months.php - created with Moodle 1.9 
      
$string['formattopictabs'] = 'תצורת מבנה נושאים עם חוצצים';
$string['monthhide'] = 'הסתרת חודשים';
$string['monthlyoutline'] = 'מסגרת חודשים';
$string['monthshow'] = 'הצגת חודשים';
$string['showallmonths'] = 'הצגת כל החודשים';
$string['showonlymonth'] = 'הצגת חודש זה בלבד';

?>
