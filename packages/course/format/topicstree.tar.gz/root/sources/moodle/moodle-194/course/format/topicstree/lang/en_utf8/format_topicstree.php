<?php
$string['formattopicstree']='Topics Tree format'; // Name to display for format
$string['topicstree']='section'; // Name of a section within your format
?>

