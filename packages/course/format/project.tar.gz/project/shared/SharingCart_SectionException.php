<?php
/**
 *  SharingCart_SectionException
 */

require_once dirname(__FILE__).'/SharingCart_Exception.php';

class SharingCart_SectionException extends SharingCart_Exception
{
}

?>