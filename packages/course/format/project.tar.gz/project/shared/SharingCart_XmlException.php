<?php
/**
 *  SharingCart_XmlException
 */

require_once dirname(__FILE__).'/SharingCart_Exception.php';

class SharingCart_XmlException extends SharingCart_Exception
{
}

?>