<?php 

$string['formattwocolumns'] = 'יחידות הוראה - שתי עמודות';

?>