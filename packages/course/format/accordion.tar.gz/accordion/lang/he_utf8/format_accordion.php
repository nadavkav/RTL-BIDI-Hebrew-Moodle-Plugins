<?PHP // $Id: format_weekstabs.php,v 1.1 2008/11/08 22:26:26 arborrow Exp $ 
      // months.php - created with Moodle 1.9 
      
$string['formataccordion'] = 'תצורת מבנה אקורדיון';
$string['monthhide'] = 'הסתרת חודשים';
$string['monthlyoutline'] = 'מבנה חודשי';
$string['monthshow'] = 'תצוגת חודשים';
$string['showallmonths'] = 'תצוגת כל החודשים';
$string['showonlymonth'] = 'הצגת חודש בלבד';

?>
