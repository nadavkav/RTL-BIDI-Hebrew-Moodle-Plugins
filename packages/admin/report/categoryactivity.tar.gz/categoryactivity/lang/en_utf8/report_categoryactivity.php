<?php
$string["categoryactivity"] = 'Category activity';
$string['categoryoverviewgraph'] = 'Category overview graph';
$string['statsreport15'] = 'Most active categories (top level)';
$string['statsreport16'] = 'Most active categories (each level)';
?>