<?php
$string["categoryactivity"] = 'פעילות לפי סיווג';
$string['categoryoverviewgraph'] = 'גרף פעילות לפי סיווגים';
$string['statsreport15'] = 'הסיווגים הפעילים ביותר (בסיווג הראשי)';
$string['statsreport16'] = 'הסיווגים הפעילים ביותר (בכל סיווג)';
?>