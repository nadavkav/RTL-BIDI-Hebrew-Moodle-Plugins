<?php

$plugin->version  = 2009120700;
//$plugin->requires = 2007101532;
$plugin->requires = 2007101520;  // i had to hack it , i hope it isa ok (nadavkav)

?>
