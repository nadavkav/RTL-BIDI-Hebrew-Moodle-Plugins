<?php

$string['config_available_roles'] = 'Roles that are shown in Roles\'s Capabilities report';
$string['desc_available_roles'] = 'Choose which roles will be available to user that can see the report.';
$string['legend_title'] = 'Color legends.';
$string['no_roles_selected'] = 'No roles was selected. Please select at least one role to show capabilities.';
$string['repeat_each'] = 'Repeat the header each N entries';
$string['rolescapabilities'] = 'Roles\'s capabilities';

?>
