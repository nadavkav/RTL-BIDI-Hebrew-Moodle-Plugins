<?php

// $string['fromdate'] = 'מתאריך';
// $string['todate'] = 'עד תאריך';
// $string['fromtime'] = 'משעה';
// $string['totime'] = 'עד שעה';
// $string['concurrentusers'] = 'גרף משתמשים מחוברים בדקה';

$string['chooseinstitution'] = 'אנא בחרו מוסד מהרשימה';
$string['graph_actions_per_institution'] = 'סוגי פעילויות שונים על פי מוסד: ';
$string['graph_actions_per_institution_nv'] = 'סוגי פעילויות שונים (ללא סוג הפעולה \'תצוגה\') על פי מוסד :';
$string['graph_usage_per_institution_over_time'] ='כלל הפעילות על פי חודשים במוסד :';
$string['list_most_active_teachers'] ='פעילות המורים במוסד: ';
$string['usageperinstitution'] ='גרף/דוח השימוש במוסדות';

?>