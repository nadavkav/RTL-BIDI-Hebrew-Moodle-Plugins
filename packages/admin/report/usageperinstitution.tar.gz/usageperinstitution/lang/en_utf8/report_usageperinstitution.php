<?php

$string['chooseinstitution'] = 'Please choose an Institution from the list:';
$string['graph_actions_per_institution'] = 'The different "Actions" per Institution:';
$string['graph_actions_per_institution_nv'] = 'The different "Actions" (excluding "View") per Institution:';
$string['graph_usage_per_institution_over_time'] ='General Institution usage per month:';
$string['list_most_active_teachers'] ='Most active Teachers: ';
$string['usageperinstitution'] ='Graph/Report Institution usage';

?>