<?php
$string["comparativereports"] = 'Comparative Reports';
$string['comparativereportsoverviewgraph'] = 'Comparative reports overview graph';

$string['statsreport17'] = 'Year to year activity comparison';
$string['statsreport18'] = 'Usage by hour of the day';
$string['statsreport19'] = 'Most active users';
$string['statsreport20'] = 'Particular users\' activity';
$string['statsreport21'] = 'Courses disk usage (slow)';

$string['diskusageheading'] = 'Courses disk usage';
?>