<?php
$string["comparativereports"] = 'השוואות בין תקופות מקבילות';
$string['comparativereportsoverviewgraph'] = 'גרף השוואות בין תקופות מקבילות';

$string['statsreport17'] = 'השוואת פעילות בין שנים';
$string['statsreport18'] = 'שימוש על פי שעה ביום';
$string['statsreport19'] = 'משתמשים פעילים ביותר';
$string['statsreport20'] = 'פעילות משתמשים פופולארית';
$string['statsreport21'] = 'נפח השימוש בקבצים של כל מרחב לימוד (איטי)';

$string['diskusageheading'] = 'נפח השימוש של מרחב לימוד';
?>