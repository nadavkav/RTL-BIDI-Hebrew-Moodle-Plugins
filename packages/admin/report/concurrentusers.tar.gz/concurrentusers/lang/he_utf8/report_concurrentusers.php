<?php

$string['fromdate'] = 'מתאריך';
$string['todate'] = 'עד תאריך';
$string['fromtime'] = 'משעה';
$string['totime'] = 'עד שעה';
$string['concurrentusers'] = 'גרף משתמשים מחוברים בדקה';

?>