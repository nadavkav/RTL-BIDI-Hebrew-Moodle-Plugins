<?php

$string['fromdate'] = 'From date';
$string['todate'] = 'To date';
$string['fromtime'] = 'From time';
$string['totime'] = 'To time';
$string['concurrentusers'] = 'Concurrent users per min graph';

?>