#mod-lightboxgallery-imageedit .generaltable img,
#mod-lightboxgallery-imageadd .generaltable img {
    border: 1px solid #ddd;
}

#mod-lightboxgallery-imageedit .menubar {
    margin-top: 14px;
    text-align: center;
}

#mod-lightboxgallery-imageadd #messages {
    margin: 0px 6px 0px 12px;
    padding: 0px;
}

#mod-lightboxgallery-search .generalbox {
    margin-bottom: 10px;
}
