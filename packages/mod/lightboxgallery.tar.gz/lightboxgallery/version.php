<?php 

    $module->version  = 2008111200;  // The current module version (Date: YYYYMMDDXX)
    $module->requires = 2007020200;  // Requires this Moodle version
    $module->cron     = 0;           // Period for cron to check this module (secs)

?>
