NETPUBLISH MODULE DEMO VERSION
==================================

As this module is a demo version it'll contain
some errors that are already known or unknown.

Feel free to share your opinion about this module,
how should it work etc.

or

Report bugs you'd found. You can also send mail privately to
address janne dot mikkonen at julmajanne dot com
(please set subject as netpublish module: subject, so your
 mail doesn't get into my junk mail (which is -> trash)).


Cheers,
Janne Mikkonen

CHANGE LOG
=================================
22/06/2005
- permissions moved to popup (by Mark Nielsen)
- new interface for permissions (by Mark Nielsen)
- new imagebank
- move articles feature added (by Mark Nielsen)
- Moodle version 1.4.x not supported anymore
  although it works if you add tabs class to
  weblib

