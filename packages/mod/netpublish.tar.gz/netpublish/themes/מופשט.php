<?php 

$magtheme['themename'] = 'מופשט';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/ephemeral_header02.jpg';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-04.jpg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-03.jpg';
$magtheme['frontpagecolums'] = '2';

?>