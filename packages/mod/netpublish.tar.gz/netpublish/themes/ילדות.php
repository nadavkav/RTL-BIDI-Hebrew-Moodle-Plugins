<?php 

$magtheme['themename'] = 'ילדות';
$magtheme['headerimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/header-1.jpg';
$magtheme['backgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-04.jpg';
$magtheme['articlesbackgroundimage'] = 'http://www.tikshuv.org.il/moodle/mod/netpublish/themes/paper-03.jpg';
$magtheme['frontpagecolums'] = '2';

?>