<?PHP // $Id: stampcoll.php,v 1.2 2008/04/27 22:41:58 mudrd8mz Exp $ 
      // stampcoll.php - created with Moodle 1.9 + (Build: 20080406) (2007101509)


$string['addstampbutton'] = 'Přidat';
$string['confirmdel'] = 'Opravdu chcete odstranit toto razítko?';
$string['deletestamp'] = 'Odstranit razítko';
$string['displayzero'] = 'Zobrazovat i uživatele bez razítka';
$string['editstamps'] = 'Upravit razítka';
$string['givenby'] = 'Od: $a';
$string['givento'] = 'Komu: $a';
$string['modulename'] = 'Sbírka razítek';
$string['modulenameplural'] = 'Sbírky razítek';
$string['nostampscollected'] = 'Bez razítek';
$string['nostampsincollection'] = 'Sbírka neobsahuje žádná razítka';
$string['notallowedtoviewstamps'] = 'V této sbírce nemáte oprávnění vidět razítka';
$string['nousers'] = 'Bez uživatelů';
$string['numberofcollectedstamps'] = 'Počet sesbíraných razítek: $a';
$string['numberofstamps'] = 'Razítka';
$string['numberofyourstamps'] = 'Počet vašich razítek: $a';
$string['ownstamps'] = 'Moje razítka';
$string['showupdateforms'] = 'Zobrazit formuláře pro úpravu razítek';
$string['stampcoll:collectstamps'] = 'Sbírat razítka';
$string['stampcoll:givestamps'] = 'Dávat razítka';
$string['stampcoll:managestamps'] = 'Spravovat razítka';
$string['stampcoll:viewotherstamps'] = 'Vidět razítka ostatních';
$string['stampcoll:viewownstamps'] = 'Vidět vlastní razítka';
$string['stampimage'] = 'Obrázek razítka';
$string['stampimageinfo'] = 'Doporučená velikost je 35x35 pixelů';
$string['studentsperpage'] = 'Studentů na stránku';
$string['timemodified'] = 'Poslední změna';
$string['updatestampbutton'] = 'Aktualizovat';
$string['viewstamps'] = 'Zobrazit razítka';

?>
