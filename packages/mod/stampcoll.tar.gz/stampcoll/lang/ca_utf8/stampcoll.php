<?PHP // $Id$ 

$string['addstampbutton'] = 'Afegir';
$string['confirmdel'] = 'Realment vols esborrar aquest segell?';
$string['deletestamp'] = 'Esborrar segell';
$string['displayzero'] = 'Mostrar usuaris sense segells';
$string['editstamps'] = 'Editar segells';
$string['givenby'] = 'Des de: $a';
$string['givento'] = 'Per a: $a';
$string['modulenameplural'] = 'Col·lecció de segells';
$string['modulename'] = 'Col·lecció de segells';
$string['nostampscollected'] = 'No hi ha segells';
$string['nostampsincollection'] = 'No hi ha segells en aquesta col·lecció';
$string['notallowedtoviewstamps'] = 'No estàs autoritzat per a veure els segells en aquesta col·lecció';
$string['nousers'] = 'No hi ha usuaris';
$string['numberofcollectedstamps'] = 'Segells col·leccionats: $a';
$string['numberofstamps'] = 'Segells';
$string['numberofyourstamps'] = 'Nombre de segells: $a';
$string['ownstamps'] = 'Segells propis';
$string['showupdateforms'] = 'Ensenya formulari per actualitzar els segells';
$string['stampcoll:collectstamps'] = 'Recollir segells';
$string['stampcoll:givestamps'] = 'Aceptar segells';
$string['stampcoll:managestamps'] = 'Gestionar segells';
$string['stampcoll:viewotherstamps'] = 'Veure altres \' stamps';
$string['stampcoll:viewownstamps'] = 'Veure segells propis';
$string['stampimageinfo'] = 'Tamany recomanat 35x35 pixels';
$string['stampimage'] = 'Imatge del segells';
$string['studentsperpage'] = 'Alumnes per pàgina';
$string['timemodified'] = 'Darrer canvi';
$string['updatestampbutton'] = 'Actualitzar';
$string['viewstamps'] = 'Veure segells';
?>
