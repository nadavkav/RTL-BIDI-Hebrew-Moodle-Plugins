<?php // $Id: version.php,v 1.4 2008/02/20 23:58:36 mudrd8mz Exp $

///  Stamp Collection module version

$module->version  = 2008022003;
$module->requires = 2007101508;  // Requires this Moodle version - 1.9 Beta 4
$module->cron     = 0;

?>
