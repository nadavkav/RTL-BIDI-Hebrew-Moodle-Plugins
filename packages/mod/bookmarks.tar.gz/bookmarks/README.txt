This README file is based off the original README written
by Martin Dougiamas 
However it as well as some of the code has been re-written so that the 
module will work with Moodle 1.7 and beyond (with luck)


The following steps should get you up and running with
this module template code.

1. Unzip the archive and read this file

2. The module folder MUST be lower case before Moodle will recognize
   it. 

3. Edit all the files in this directory and change all the 
   instances of newmodule to your new module name (eg widget).

4. Place the newmodule folder into the /mod folder of the moodle
   directory. 

5. As Admin goto Notifications and you should find the module's
   databases successfully created

6. Now go to Modules then to Activities in the Site Administration block
   And you should find that this newmodule has been added
   to the list of recognized modules.

7. You may now proceed to run your own code in an attempt to
   develop for moodle. Good luck with that.


For help with developing code for moodle, visit
the "Activity modules" developers forum in the online 
course called "Using Moodle" at http:/* moodle.org */

Or email Martin Dougiamas at:  martin@moodle.com

For more information about the reviser
of the original NEWMODULE template
visit http://www.welcometochrisworld.com
-Chris B Stones
February 28, 2007



