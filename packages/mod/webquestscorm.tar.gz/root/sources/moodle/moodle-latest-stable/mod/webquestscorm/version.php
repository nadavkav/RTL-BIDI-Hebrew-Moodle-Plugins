<?php 
/**
 * 
 * @author Julia Tejerina, Oscar Sanchez, Javier Gonzalez
 * @version $Id: version.php, v 2.0 2009/25/04
 * @package webquestscorm
 **/
$module->version  = 2009250420;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
