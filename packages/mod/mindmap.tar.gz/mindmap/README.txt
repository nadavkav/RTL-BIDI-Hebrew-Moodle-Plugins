Mindmap version 0.5
------------------------
By ekpenso.com

This is the Mindmap module for moodle. It is created and maintained by ekpenso.com. 
The Mindmap-Module allows you to create mindmaps. 
This module is in developement - if you experience any problems or you have feature-wishes feel free to contact us.

Quick install instructions:

- ) Copy this "/mindmap"-Folder and place it in your /mod-directory
- ) go go to your admin area and go to "notificatiosn"
- ) That's it


You can use this module for free, but it would be nice if you give us a short notice via our Feedback-form:
http://ekpenso.com/feedback  

Thanks.