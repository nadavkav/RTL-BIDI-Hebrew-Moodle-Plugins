<?php

$string['mindmap'] = 'mindmap';

$string['modulename'] = 'Mindmap';
$string['modulenameplural'] = 'Mindmaps';

$string['mindmapfieldset'] = 'Custom example fieldset';
$string['mindmapintro'] = 'Mindmap Intro';
$string['mindmapname'] = 'Mindmap Name';
$string['editable'] = 'Editable';

?>
