<?php //$Id: backuplib.php,v 1.0 2008/02/12 13:50:00 SerafimPanov Exp $
    //This php script contains all the stuff to backup/restore
    //studentsurvey mods

    //-----------------------------------------------------------

    function studentsurvey_check_backup_mods($course,$user_data=false,$backup_unique_code,$instances=null) {

        if (!empty($instances) && is_array($instances) && count($instances)) {
            $info = array();
            foreach ($instances as $id => $instance) {
                $info += studentsurvey_check_backup_mods_instances($instance,$backup_unique_code);
            }
            return $info;
        }
        return $info;
    }
    
    function studentsurvey_check_backup_mods_instances($instance,$backup_unique_code) {
        //First the course data
        $info[$instance->id.'0'][0] = '<b>'.$instance->name.'</b>';
        $info[$instance->id.'0'][1] = '';

        //Now, if requested, the user_data
        if (!empty($instance->userdata)) {
            $info[$instance->id.'1'][0] = get_string("messages","studentsurvey");
            if ($ids = chat_message_ids_by_instance ($instance->id)) { 
                $info[$instance->id.'1'][1] = count($ids);
            } else {
                $info[$instance->id.'1'][1] = 0;
            }
        }
        return $info;
    }

    function studentsurvey_backup_mods($bf,$preferences) {

        global $CFG;

        $status = true;

        //Iterate over studentsurvey table
        $studentsurveys = get_records ("studentsurvey","course",$preferences->backup_course,"id");
        if ($studentsurveys) {
            foreach ($studentsurveys as $studentsurvey) {
                if (backup_mod_selected($preferences,'studentsurvey',$studentsurvey->id)) {
                    $status = studentsurvey_backup_one_mod($bf,$preferences,$studentsurvey);
                }
            }
        }
 
        return $status;  
    }
    
    function studentsurvey_backup_one_mod($bf,$preferences,$studentsurvey) {

        global $CFG;
    
        if (is_numeric($studentsurvey)) {
            $studentsurvey = get_record('studentsurvey','id',$studentsurvey);
        }
    
        $status = true;

        //Start mod
        fwrite ($bf,start_tag("MOD",3,true));
        //Print studentsurvey data
        fwrite ($bf,full_tag("ID",4,false,$studentsurvey->id));
        fwrite ($bf,full_tag("MODTYPE",4,false,"studentsurvey"));
        fwrite ($bf,full_tag("COURSE",4,false,$studentsurvey->course));
        fwrite ($bf,full_tag("TEACHER",4,false,$studentsurvey->teacher));
        fwrite ($bf,full_tag("NAME",4,false,$studentsurvey->name));
        fwrite ($bf,full_tag("INTRO",4,false,$studentsurvey->intro));
        fwrite ($bf,full_tag("TYPE",4,false,$studentsurvey->type));
        fwrite ($bf,full_tag("GROUPMODE",4,false,$studentsurvey->groupmode));
        fwrite ($bf,full_tag("MAXSURVEY",4,false,$studentsurvey->maxsurvey));
        fwrite ($bf,full_tag("TIME",4,false,$studentsurvey->time));
        fwrite ($bf,full_tag("STUDENTSURVEYTIME",4,false,time()));
        //if we've selected to backup users info, then execute backup_studentsurvey_messages
        studentsurvey_backup_studentsurvey_cicls ($bf,$preferences,$studentsurvey);
        studentsurvey_backup_studentsurvey_questions ($bf,$preferences,$studentsurvey);
        studentsurvey_backup_studentsurvey_choice ($bf,$preferences,$studentsurvey);
        studentsurvey_backup_studentsurvey_answer ($bf,$preferences,$studentsurvey);
        //End mod
        $status =fwrite ($bf,end_tag("MOD",3,true));

        return $status;
    }
    
    
    function studentsurvey_backup_studentsurvey_cicls ($bf,$preferences,$studentsurvey) {

        global $CFG;

        $status = true;

        $datas = get_records("studentsurvey_cicls", 'instance', $studentsurvey->id);
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("STUDENTSURVEY_CICLS",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                //fwrite ($bf,full_tag("NAME",6,false,$cha_mes->name));       
                fwrite ($bf,full_tag("INSTANCE",6,false,$cha_mes->instance));       
                fwrite ($bf,full_tag("CICL",6,false,$cha_mes->cicl));       
                fwrite ($bf,full_tag("USERID",6,false,$cha_mes->userid));       
                fwrite ($bf,full_tag("TIMEMODIFIED",6,false,$cha_mes->timemodified));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("STUDENTSURVEY_CICLS",4,true));
        }
        return $status;
    }
    
    
    function studentsurvey_backup_studentsurvey_questions ($bf,$preferences,$studentsurvey) {

        global $CFG;

        $status = true;

        $datas = get_records("studentsurvey_questions", 'instance', $studentsurvey->id);
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("STUDENTSURVEY_QUESTIONS",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("INSTANCE",6,false,$cha_mes->instance));       
                fwrite ($bf,full_tag("CICL",6,false,$cha_mes->cicl));       
                fwrite ($bf,full_tag("NAME",6,false,$cha_mes->name));       
                fwrite ($bf,full_tag("USERID",6,false,$cha_mes->userid));       
                fwrite ($bf,full_tag("ANSWERS",6,false,$cha_mes->answers));       
                fwrite ($bf,full_tag("TIMEMODIFIED",6,false,$cha_mes->timemodified));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("STUDENTSURVEY_QUESTIONS",4,true));
        }
        return $status;
    }
    
    
    function studentsurvey_backup_studentsurvey_choice ($bf,$preferences,$studentsurvey) {

        global $CFG;

        $status = true;

        $datas = get_records("studentsurvey_choice");
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("STUDENTSURVEY_CHOICE",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("QUESTION",6,false,$cha_mes->question));       
                fwrite ($bf,full_tag("NAME",6,false,$cha_mes->name));       
                fwrite ($bf,full_tag("GRADE",6,false,$cha_mes->grade));       
                fwrite ($bf,full_tag("TIMEMODIFIED",6,false,$cha_mes->timemodified));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("STUDENTSURVEY_CHOICE",4,true));
        }
        return $status;
    }
    
    
    
    function studentsurvey_backup_studentsurvey_answer ($bf,$preferences,$studentsurvey) {

        global $CFG;

        $status = true;

        $datas = get_records("studentsurvey_answer");
        //If there is levels
        if ($datas) {
            //Write start tag
            $status =fwrite ($bf,start_tag("STUDENTSURVEY_ANSWER",4,true));
            //Iterate over each message
            foreach ($datas as $cha_mes) {
                //Start message
                $status =fwrite ($bf,start_tag("ROWS",5,true));
                //Print message contents
                fwrite ($bf,full_tag("ID",6,false,$cha_mes->id));       
                fwrite ($bf,full_tag("QUESTION",6,false,$cha_mes->question));       
                fwrite ($bf,full_tag("USERID",6,false,$cha_mes->userid));         
                fwrite ($bf,full_tag("ANSWERID",6,false,$cha_mes->answerid));       
                fwrite ($bf,full_tag("GRADE",6,false,$cha_mes->grade));       
                fwrite ($bf,full_tag("TIMEMODIFIED",6,false,$cha_mes->timemodified));       
                //End submission
                $status =fwrite ($bf,end_tag("ROWS",5,true));
            }
            //Write end tag
            $status =fwrite ($bf,end_tag("STUDENTSURVEY_ANSWER",4,true));
        }
        return $status;
    }
    
    

?>