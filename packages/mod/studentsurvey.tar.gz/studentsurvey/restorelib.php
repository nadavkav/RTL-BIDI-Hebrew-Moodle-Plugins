<?php //$Id: backuplib.php,v 1.0 2008/02/12 14:02:00 SerafimPanov Exp $
    //This php script contains all the stuff to backup/restore
    //studentsurvey mods

    //-----------------------------------------------------------
    //This function executes all the restore procedure about this mod
    function studentsurvey_restore_mods($mod,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get record from backup_ids
        $data = backup_getid($restore->backup_unique_code,$mod->modtype,$mod->id);

        if ($data) {

            //Now get completed xmlized object   
            $info = $data->info;

            //traverse_xmlize($info);                                                                     //Debug
            //print_object ($GLOBALS['traverse_array']);                                                  //Debug
            //$GLOBALS['traverse_array']="";                                                              //Debug
            // if necessary, write to restorelog and adjust date/time fields
            if ($restore->course_startdateoffset) {
                restore_log_date_changes('studentsurvey', $restore, $info['MOD']['#'], array('STUDENTSURVEYTIME'));
            }
            //Now, build the studentsurvey record structure
            $studentsurvey->course = $restore->course_id;
            $studentsurvey->teacher = backup_todb($info['MOD']['#']['TEACHER']['0']['#']);
            $studentsurvey->name = backup_todb($info['MOD']['#']['NAME']['0']['#']);
            $studentsurvey->intro = backup_todb($info['MOD']['#']['INTRO']['0']['#']);
            $studentsurvey->type = backup_todb($info['MOD']['#']['TYPE']['0']['#']);
            $studentsurvey->groupmode = backup_todb($info['MOD']['#']['GROUPMODE']['0']['#']);
            $studentsurvey->maxsurvey = backup_todb($info['MOD']['#']['MAXSURVEY']['0']['#']);
            $studentsurvey->time = backup_todb($info['MOD']['#']['TIME']['0']['#']);
            
            $user = backup_getid($restore->backup_unique_code,"user",$studentsurvey->teacher);
            if ($user) {
                $studentsurvey->teacher = $user->new_id;
            }

            //The structure is equal to the db, so insert the studentsurvey
            $newid = insert_record ("studentsurvey",$studentsurvey);

            //Do some output     
            //if (!defined('RESTORE_SILENTLY')) {
            //    echo "<li>".get_string("modulename","studentsurvey")." \"".format_string(stripslashes($studentsurvey->name),true)."\"</li>";
            //}
            //backup_flush(300);

            if ($newid) {
                //We have the newid, update backup_ids
                backup_putid($restore->backup_unique_code,$mod->modtype, $mod->id, $newid);
                //Now check if want to restore user data and do it.
                if (restore_userdata_selected($restore,'studentsurvey',$mod->id)) {
                    //Restore studentsurvey_messages
                    studentsurvey_restore_studentsurvey_cicls ($mod->id, $newid, $info, $restore, $studentsurvey->groupmode);
                    studentsurvey_restore_studentsurvey_questions ($mod->id, $newid, $info, $restore, $studentsurvey->groupmode);
                    studentsurvey_restore_studentsurvey_choice ($mod->id, $newid, $info, $restore);
                    studentsurvey_restore_studentsurvey_answer ($mod->id, $newid, $info, $restore);
                }
            } else {
                $status = false;
            }
        } else {
            $status = false;
        }

        return $status;
    }


    
    function studentsurvey_restore_studentsurvey_cicls ($old_studentsurvey_id, $new_studentsurvey_id,$info,$restore, $groupmode) {

        global $CFG, $oldidarray;

        $status = true;
        
        //Get the messages array 
        $messages = $info['MOD']['#']['STUDENTSURVEY_CICLS']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the studentsurvey_MESSAGES record structure
            
            $message->instance = $new_studentsurvey_id;
            $message->name = backup_todb($mes_info['#']['NAME']['0']['#']);
            $message->userid = backup_todb($mes_info['#']['USERID']['0']['#']);
            $message->timemodified = backup_todb($mes_info['#']['TIMEMODIFIED']['0']['#']);
            $message->cicl = backup_todb($mes_info['#']['CICL']['0']['#']);
            
            if ($groupmode == 0) {
                $user = backup_getid($restore->backup_unique_code,"user",$message->userid);
            }
            else
            {
                $user = backup_getid($restore->backup_unique_code,"groups",$message->userid);
            }
            if ($user) {
                $message->userid = $user->new_id;
            }

            $newidm = insert_record ("studentsurvey_cicls",$message);
            $oldidarray[$old_studentsurvey_id]['studentsurvey_cicls'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    
    
    function studentsurvey_restore_studentsurvey_questions ($old_studentsurvey_id, $new_studentsurvey_id,$info,$restore, $groupmode) {

        global $CFG, $oldidarray;

        $status = true;

        //Get the messages array 
        $messages = $info['MOD']['#']['STUDENTSURVEY_QUESTIONS']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the studentsurvey_MESSAGES record structure
            
            $message->instance = $new_studentsurvey_id;
            $message->name = backup_todb($mes_info['#']['NAME']['0']['#']);
            $message->userid = backup_todb($mes_info['#']['USERID']['0']['#']);
            $message->cicl = $oldidarray[$old_studentsurvey_id]['studentsurvey_cicls'][backup_todb($mes_info['#']['CICL']['0']['#'])];
            $message->answers = backup_todb($mes_info['#']['ANSWERS']['0']['#']);
            $message->timemodified = backup_todb($mes_info['#']['TIMEMODIFIED']['0']['#']);
            
            if ($groupmode == 0) {
                $user = backup_getid($restore->backup_unique_code,"user",$message->userid);
            }
            else
            {
                $user = backup_getid($restore->backup_unique_code,"groups",$message->userid);
            }
            
            
            $newidm = insert_record ("studentsurvey_questions",$message);
            $oldidarray[$old_studentsurvey_id]['studentsurvey_questions'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    
    
    function studentsurvey_restore_studentsurvey_choice ($old_studentsurvey_id, $new_studentsurvey_id,$info,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get the messages array 
        $messages = $info['MOD']['#']['STUDENTSURVEY_CHOICE']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the studentsurvey_MESSAGES record structure
            
            $message->question = $oldidarray[$old_studentsurvey_id]['studentsurvey_questions'][backup_todb($mes_info['#']['QUESTION']['0']['#'])];
            $message->name = backup_todb($mes_info['#']['NAME']['0']['#']);
            $message->grade = backup_todb($mes_info['#']['GRADE']['0']['#']);
            $message->timemodified = backup_todb($mes_info['#']['TIMEMODIFIED']['0']['#']);
            
            $newidm = insert_record ("studentsurvey_choice",$message);
            $oldidarray[$old_studentsurvey_id]['studentsurvey_choice'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    
    function studentsurvey_restore_studentsurvey_answer ($old_studentsurvey_id, $new_studentsurvey_id,$info,$restore) {

        global $CFG, $oldidarray;

        $status = true;

        //Get the messages array 
        $messages = $info['MOD']['#']['STUDENTSURVEY_ANSWER']['0']['#']['ROWS'];

        //Iterate over messages
        for($i = 0; $i < sizeof($messages); $i++) {
            $mes_info = $messages[$i];
            //Now, build the studentsurvey_MESSAGES record structure
            
            $message->question = $oldidarray[$old_studentsurvey_id]['studentsurvey_questions'][backup_todb($mes_info['#']['QUESTION']['0']['#'])];
            $message->answerid = $oldidarray[$old_studentsurvey_id]['studentsurvey_choice'][backup_todb($mes_info['#']['ANSWERID']['0']['#'])];
            $message->grade = backup_todb($mes_info['#']['GRADE']['0']['#']);
            $message->userid = backup_todb($mes_info['#']['USERID']['0']['#']);
            $message->timemodified = backup_todb($mes_info['#']['TIMEMODIFIED']['0']['#']);
            
            $user = backup_getid($restore->backup_unique_code,"user",$message->userid);
            if ($user) {
                $message->user = $user->new_id;
            }

            $newidm = insert_record ("studentsurvey_answer",$message);
            $oldidarray[$old_studentsurvey_id]['studentsurvey_answer'][backup_todb($mes_info['#']['ID']['0']['#'])] = $newidm;

            //Do some output
            if (($i+1) % 50 == 0) {
                if (!defined('RESTORE_SILENTLY')) {
                    echo ".";
                    if (($i+1) % 1000 == 0) {
                        echo "<br />";
                    }
                }
                backup_flush(300);
            }
        }
        
        return $status;
    }
    
    

    function studentsurvey_restore_logs($restore,$log) {

        $status = true;

        return $status;
    }
    
?>