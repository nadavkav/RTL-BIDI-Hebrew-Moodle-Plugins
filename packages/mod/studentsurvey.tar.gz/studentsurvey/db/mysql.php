<?php // $Id: mysql.php,v 1.0 2007/11/27 12:54:00 serafim panov

function studentsurvey_upgrade($oldversion) {
    global $CFG;

    if ($oldversion < 2007031000) {

       # Do something ...

    }

    return true;
}

?>
