# $Id: mysql.php,v 1.0 2007/11/27 12:54:00 serafim panov

CREATE TABLE `prefix_studentsurvey` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL default '',
  `maxsurvey` int(10) unsigned NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  `groupmode` int(2) unsigned NOT NULL default '0',
  `course` varchar(255) NOT NULL default '',
  `teacher` varchar(255) NOT NULL default '',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='studentsurvey';

CREATE TABLE `prefix_studentsurvey_cicls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `instance` int(10) unsigned NOT NULL default '0',
  `cicl` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `timemodified` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='studentsurvey cicls';

CREATE TABLE `prefix_studentsurvey_questions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `instance` int(10) unsigned NOT NULL default '0',
  `cicl` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `userid` int(10) unsigned NOT NULL default '0',
  `answers` int(10) unsigned NOT NULL default '0',
  `timemodified` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='studentsurvey questions';


CREATE TABLE `prefix_studentsurvey_choice` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `question` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `grade` varchar(255) NOT NULL default '0',
  `timemodified` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='studentsurvey choice';


CREATE TABLE `prefix_studentsurvey_answer` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `question` int(10) unsigned NOT NULL default '0',
  `userid` int(10) unsigned NOT NULL default '0',
  `answerid` varchar(255) NOT NULL default '',
  `grade` varchar(255) NOT NULL default '',
  `timemodified` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) COMMENT='studentsurvey choice';

# --------------------------------------------------------
