<?php  // $Id: mysql.php,v 1.0 2007/11/27 12:54:00 serafim panov

function studentsurvey_add_instance($studentsurvey) {

global $CFG, $USER;
    
    $id = $studentsurvey->courseid;
    $studentsurvey->timemodified = time();
    
    if ($studentsurvey->maxsurvey == "No limit") {
        $studentsurvey->maxsurvey = 0;
    }
    
    return insert_record("studentsurvey", $studentsurvey);
}




function studentsurvey_update_instance($studentsurvey, $id) {
    global $CFG;
   
    $studentsurvey->timemodified = time();
    $studentsurvey->id = $studentsurvey->instance;

    if ($studentsurvey->maxsurvey == "No limit") {
        $studentsurvey->maxsurvey = 0;
    }
    

    # May have to add extra stuff in here #

    return update_record("studentsurvey", $studentsurvey);
    
}



function studentsurvey_submit_instance($studentsurvey, $id) {

    global $CFG;
  

}



function studentsurvey_delete_instance($id) {

    global $CFG;

    if (! $studentsurvey = get_record("studentsurvey", "id", "$id")) {
        return false;
    }

    $result = true;

    # Delete any dependent records here #

    if (! delete_records("studentsurvey", "id", "$studentsurvey->id")) {
        $result = false;
    }

    return $result;
}




function studentsurvey_user_outline($course, $user, $mod, $studentsurvey) {
    return $return;
}




function studentsurvey_user_complete($course, $user, $mod, $studentsurvey) {
    return true;
}




function studentsurvey_print_recent_activity($course, $isteacher, $timestart) {
    global $CFG;

    return false;  //  True if anything was printed, otherwise false 
}




function studentsurvey_cron () {
    global $CFG;

    return true;
}




function studentsurvey_grades($studentsurveyid) {
   return NULL;
}




function studentsurvey_get_participants($studentsurveyid) {
    return false;
}




function studentsurvey_scale_used ($studentsurveyid,$scaleid) {
    $return = false;
   
    return $return;
}

function studentsurvey_alreadyanswered ($cicl) {
    global $CFG, $USER;
   
    $return = false;
        
    $questions = get_records ("studentsurvey_questions", "cicl", $cicl);
    foreach ($questions as $question) {
        if (get_record ("studentsurvey_answer", "userid", $USER->id, "question", $question->id)) {
            $return = true;
        }
    }
   
    return $return;
}


function studentsurvey_getid ($cm, $userid) {
    global $CFG, $USER;
   
    if ($cm->groupmode != 0) {
        $return = groups_db_get_groups_for_user($userid, $cm->course);
        $return = $return[0];
    }
    else
    {
        $return = $userid;
    }
   
    return $return;
}


function studentsurvey_getname ($cm, $userid) {
    global $CFG, $USER;
   
    if ($cm->groupmode != 0) {
        $return = groups_get_group_displayname($userid);
    }
    else
    {
        $userdata = get_record ("user", "id", $userid);
        $return = fullname($userdata);
    }
   
    return $return;
}


?>