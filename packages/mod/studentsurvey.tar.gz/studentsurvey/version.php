<?php // $Id: mysql.php,v 1.0 2007/11/27 12:54:00 serafim panov

$module->version  = 2007031000;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>