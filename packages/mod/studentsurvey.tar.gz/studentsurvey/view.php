<?php  // $Id: mysql.php,v 1.0 2007/11/27 12:54:00 serafim panov

    require_once("../../config.php");
    require_once("lib.php");
    require_once($CFG->dirroot.'/lib/excellib.class.php');

    $id                = optional_param('id', 0, PARAM_INT); 
    $a                 = optional_param('a');  
    $n                 = optional_param('n', 0, PARAM_INT);  
    $numberofquestions = optional_param('numberofquestions', 1, PARAM_INT);  
    $submitquestion    = optional_param('submitquestion');  
    $cicl              = optional_param('cicl', 0, PARAM_INT);  
    $answer            = optional_param('answer');  
    $submit            = optional_param('submit');  
    
    $questiontitle     = optional_param('questiontitle'); 
    $choice1           = optional_param('choice1'); 
    $choice2           = optional_param('choice2'); 
    $choice3           = optional_param('choice3'); 
    $choice4           = optional_param('choice4'); 
    $choice            = optional_param('choice'); 
    $editid            = optional_param('editid'); 


    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }
        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }
        if (! $studentsurvey = get_record("studentsurvey", "id", $cm->instance)) {
            error("Course module is incorrect");
        }
    } else {
        if (! $studentsurvey = get_record("studentsurvey", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $studentsurvey->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("studentsurvey", $studentsurvey->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }

    require_login($course->id);

    add_to_log($course->id, "studentsurvey", "view", "view.php?id=$id", "$cm->instance");
    
    if ($submit == "Add another question") {
        $numberofquestions += 1;
    } else if ($submit == "Save questions") {
        $numberofquestions = 1;
    }
    
    if ($submitquestion == "yes") {
    
        if (isteacher($cm->course)) {
            if ($editid) {
                $oldcicldata = get_record ("studentsurvey_cicls", "id", $editid);
                $userdataid = $oldcicldata->userid;
            }
            else
            {
                $userdataid = studentsurvey_getid ($cm, $USER->id);
            }
        }
        else
        {
            $userdataid = studentsurvey_getid ($cm, $USER->id);
        }
    
        if (!empty($editid)) {
            delete_records("studentsurvey_cicls", "id", $editid, "userid", $userdataid);
        }
    
        $cicldata = get_records_sql ("SELECT * FROM ".$CFG->prefix."studentsurvey_questions ORDER BY cicl desc");
        $newcicl = current($cicldata);
        $newcicl = $newcicl->cicl + 1;
        
        $newdatacicls = new object;
        $newdatacicls->instance = $cm->instance;
        $newdatacicls->userid   = $userdataid;
        $newdatacicls->cicl     = $newcicl;
        
        $needadd = false;
    
        foreach ($questiontitle as $keyquestiontitle => $questiontitle_) {
            
            if (!empty($questiontitle_)) {
                $needadd = true;

                $newdata = new object;
                $newdata->instance = $cm->instance;
                $newdata->name     = $questiontitle_;
                $newdata->userid   = $userdataid;
                $newdata->cicl     = $newcicl;
                $newdata->timemodified = time();
                
                $questionid = insert_record ("studentsurvey_questions", $newdata);
                
                $newdata = new object;
                $newdata->question = $questionid;
                $newdata->name     = $choice1[$keyquestiontitle];
                $newdata->timemodified = time();
                
                if (!empty($newdata->name)) {
                    insert_record ("studentsurvey_choice", $newdata);
                }
                
                $newdata = new object;
                $newdata->question = $questionid;
                $newdata->name     = $choice2[$keyquestiontitle];
                $newdata->timemodified = time();
                
                if (!empty($newdata->name)) {
                    insert_record ("studentsurvey_choice", $newdata);
                }
                
                $newdata = new object;
                $newdata->question = $questionid;
                $newdata->name     = $choice3[$keyquestiontitle];
                $newdata->timemodified = time();
                
                if (!empty($newdata->name)) {
                    insert_record ("studentsurvey_choice", $newdata);
                }
                
                $newdata = new object;
                $newdata->question = $questionid;
                $newdata->name     = $choice4[$keyquestiontitle];
                $newdata->timemodified = time();
                
                if (!empty($newdata->name)) {
                    insert_record ("studentsurvey_choice", $newdata);
                }
                
            }
        }
        
        if ($needadd) {
            $ciclsid = insert_record ("studentsurvey_cicls", $newdatacicls);
            if ($submit == "Add another question") {
                $a = "edit";
                $n = $ciclsid;
            }
        }
    
    }
    
    if ($a == "delete") {
        if (isteacher($cm->course)) {
            delete_records("studentsurvey_cicls", "id", $n);
            delete_records("studentsurvey_questions", "cicl", $n);
        }
        else
        {
            delete_records("studentsurvey_cicls", "id", $n, "userid", studentsurvey_getid ($cm, $USER->id));
            delete_records("studentsurvey_questions", "cicl", $n, "userid", studentsurvey_getid ($cm, $USER->id));
        }
    }
    
    if ($a == "publish") {
        $time = time();
        if (isteacher($cm->instance)) {
            set_field ("studentsurvey_cicls", "timemodified", $time, "id", $n);
        }
        else
        {
            set_field ("studentsurvey_cicls", "timemodified", $time, "id", $n, "userid", studentsurvey_getid ($cm, $USER->id));
        }
    }
    
    if ($a == "unpublish" && isteacher($cm->course)) {
        set_field ("studentsurvey_cicls", "timemodified", 0, "id", $n);
        
        if ($questionsofcicl = get_records ("studentsurvey_questions", "instance", $cm->instance, "cicl", $n)) {
            foreach ($questionsofcicl as $questionsofcicl_) {
                delete_records("studentsurvey_answer", "question", $questionsofcicl_);
            }
        }
    }
    
    if ($a == "edit") {
        if (isteacher($cm->instance)) {
            $datacicl = get_record ("studentsurvey_cicls", "id", $n);
            $dataquestions = count_records ("studentsurvey_questions", "cicl", $datacicl->cicl);
        }
        else
        {
            $datacicl = get_record ("studentsurvey_cicls", "id", $n, "userid", $USER->id);
            $dataquestions = count_records ("studentsurvey_questions", "cicl", $datacicl->cicl, "userid", studentsurvey_getid ($cm, $USER->id));
        }
        if ($submit != "Add another question") {
            $numberofquestions = $dataquestions;
        }
    }
    
    //------ EXCEL--------------//
    if ($a == 'excel') {
        $workbook = new MoodleExcelWorkbook("-");
        $myxls =& $workbook->add_worksheet('report');
        
        $format =& $workbook->add_format();
        $format->set_bold(0);
        $formatbc =& $workbook->add_format();
        $formatbc->set_bold(1);

        $exceldata['time'] = date("d.M.Y");
        $exceldata['course_shotname'] = str_replace(" ", "-", $course->shortname);
        
        $workbook->send('report_'.$exceldata['time'].'_'.$exceldata['course_shotname'].'.xls');
        
        $myxls->write_string(0, 0, 'Summary Report',$formatbc);
        $myxls->write_string(1, 0, 'Date: '.$exceldata['time'].'; Course name: '.$exceldata['course_shotname']);
        $myxls->set_row(0, 30);
        $myxls->set_column(0,1,20);
        $myxls->set_column(2,10,15);
        
        $myxls->write_string(2, 0, 'Question',$formatbc);
        $myxls->write_string(2, 1, 'Choice',$formatbc);
        $myxls->write_string(2, 2, 'Answers',$formatbc);
        $myxls->write_string(2, 3, 'Persent',$formatbc);
        
        $questions = get_records ("studentsurvey_questions", "cicl", $cicl);
        
        $row = 2;
        
        foreach ($questions as $question) {
            $j++;
            $row++;
            
            $myxls->write_string($row, 0, $j.'. "'.$question->name.'"');
        
            $choices = get_records ("studentsurvey_choice", "question", $question->id);
            
            $allcount = 0;
            
            foreach ($choices as $choice) {
                $allcount += count_records("studentsurvey_answer", "answerid", $choice->id);
            }
            
            foreach ($choices as $choice) {
                $countofchoice = count_records("studentsurvey_answer", "answerid", $choice->id);
                $row++;
                $myxls->write_string($row, 1, $choice->name);
                $myxls->write_string($row, 2, $countofchoice);
                $myxls->write_string($row, 3, (round(100*($countofchoice/$allcount), 2))."%");
            }
        }
        
        $workbook->close();
        die();
    }
    //--------------------------//
    
    
    if ($a == 'csv') {
        header("Content-type: application/octet-stream");
        header('Content-Disposition: inline; filename=result.csv');
        
        $questions = get_records ("studentsurvey_questions", "cicl", $cicl);
        
        foreach ($questions as $question) {
            $j++;
            
            echo $j.'. "'.$question->name.'"'."\n";
        
            $choices = get_records ("studentsurvey_choice", "question", $question->id);
            
            $allcount = 0;
            
            foreach ($choices as $choice) {
                $allcount += count_records("studentsurvey_answer", "answerid", $choice->id);
            }
            
            foreach ($choices as $choice) {
                $countofchoice = count_records("studentsurvey_answer", "answerid", $choice->id);
                echo ',"'.$choice->name.'",'.$countofchoice.','.(round(100*($countofchoice/$allcount), 2))."%\n";
            }
        }
        
        die();
        
    }
    
    
    if (!empty($answer)) {
        foreach ($choice as $choicekey => $choicevalue) {
        
            $answerdata = get_record ("studentsurvey_answer", "userid", $USER->id, "question", $choicekey);
            
            if (!$answerdata) {
                $addchoice = new object;
                $addchoice->question     = $choicekey;
                $addchoice->answerid     = $choicevalue;
                $addchoice->userid       = $USER->id;
                $addchoice->grade        = '';
                $addchoice->timemodified = time();
                insert_record ("studentsurvey_answer", $addchoice);
                
                $message = '<center><i><font color="green">Answers submitted!</font></i></center><br /><br />';
            }
        }
        if ($message) {
            $data = get_record ("studentsurvey_questions", "cicl", $cicl);
            set_field ("studentsurvey_questions", "answers", ($data->answers + 1), "cicl", $cicl);
        }
    }

/// Print the page header

    if ($course->category) {
        $navigation = "<a href=\"../../course/view.php?id=$course->id\">$course->shortname</a> ->";
    } else {
        $navigation = '';
    }
    
    //$studentsurvey->name = "View studentsurvey";
    $strstudentsurveys = get_string("modulenameplural", "studentsurvey");

    print_header("$course->shortname: $studentsurvey->name", "$course->fullname",
                 "$navigation <a href=index.php?id=$course->id>$strstudentsurveys</a> -> $studentsurvey->name", 
                  "", "", true, update_module_button($id, $course->id, $strstudentsurvey), 
                  navmenu($course));
                  
    
    echo "<br />";
    
    if (empty($cicl)) {
    
    print_simple_box_start('center', '100%', '#ffffff', 10);
    
    echo "<center><h3>".$studentsurvey->name."</h3>";
    echo "</center><br />".$studentsurvey->intro."";
    
    print_simple_box_end();

    echo "<br />";
    
    //------Check max survey for sudent-----------//
    
    if ((count_records("studentsurvey_cicls", "instance", $cm->instance, "userid", studentsurvey_getid ($cm, $USER->id)) < $studentsurvey->maxsurvey || $studentsurvey->maxsurvey == 0) || $a=="edit") {
        print_simple_box_start('center', '100%', '#ffffff', 10);
    
        echo '<center><h4>';
        if (empty($numberofquestions)) {
            print_string("addsurveyquestions", "studentsurvey");
        }
        else
        {
            print_string("addnewsurvey", "studentsurvey");
        }
        echo '</h4><br />';
    
        echo '<form action="view.php?id='.$id.'" method="post" id="mform1" class="mform" enctype="multipart/form-data">';
    
        if (empty($numberofquestions)) {
    
            echo '<input type="submit" value="Add" />';
    
            echo '<select name="numberofquestions" id="id_numberofquestions">';
        
            $ok = "";
        
            for ($i=1; $i < 21; $i++) {
                if ($i > 1) {
                    $ok = "s";
                }
                echo '<option value="'.$i.'">'.$i.' question'.$ok.'</option>';
            } 
        
            echo '</select>';
        
            echo ' to survey.';

        }
        else
        {
    
            echo '<input type="hidden" name="submitquestion" value="yes" />';
        
            if ($a == "edit") {
                echo '<input type="hidden" name="editid" value="'.$n.'" />';
                if (isteacher($cm->instance)) {
                    $dataoldquestions = get_records_sql ("SELECT * FROM ".$CFG->prefix."studentsurvey_questions WHERE cicl='".$datacicl->cicl."'");
                }
                else
                {
                    $dataoldquestions = get_records_sql ("SELECT * FROM ".$CFG->prefix."studentsurvey_questions WHERE cicl='".$datacicl->cicl."' and userid='".studentsurvey_getid ($cm, $USER->id)."'");
                }
                foreach ($dataoldquestions as $dataoldquestionskey => $dataoldquestionsvalue) {
                    $dataoldquestions_[] = $dataoldquestionsvalue;
                }
            }
    
            for ($i=0; $i < $numberofquestions; $i++) {
    
                print_simple_box_start('center', '550px', '#ffffff', 10);
            
                if ($a == "edit") {
                    $valuequestion        = ' value="'.$dataoldquestions_[$i]->name.'" ';
                
                    if ($dataoldquestions_[$i]->id) {
                        $choice = get_records ("studentsurvey_choice", "question", $dataoldquestions_[$i]->id);
                    }
                    else
                    {
                        $choice = array();
                    }
                    $j = 1;
                    
                    unset($valuequestionchoice);
                    foreach ($choice as $choice_) {
                        $valuequestionchoice[$j] = ' value="'.$choice_->name.'" ';
                        $j++;
                    }
                }
                else
                {
                    $valuequestion        = "";
                    $valuequestionchoice[1] = "";
                    $valuequestionchoice[2] = "";
                    $valuequestionchoice[3] = "";
                    $valuequestionchoice[4] = "";
                }
            
                echo '<table width="550px"><tr><td align="left" width="100px">'.get_string("question", "studentsurvey").' '.($i + 1).':</td><td align="left" width="450px">&nbsp;&nbsp;&nbsp;<input size="64" name="questiontitle['.($i + 1).']" type="text" id="id_questiontitle_'.($i + 1).'" '.$valuequestion.' /></td></tr>';
                echo '<tr><td align="left">'.get_string("A", "studentsurvey").'.</td><td align="left">&nbsp;&nbsp;&nbsp;<input size="54" name="choice1['.($i + 1).']" type="text" '.$valuequestionchoice[1].' /></td></tr>';
                echo '<tr><td align="left">'.get_string("B", "studentsurvey").'.</td><td align="left">&nbsp;&nbsp;&nbsp;<input size="54" name="choice2['.($i + 1).']" type="text" '.$valuequestionchoice[2].' /></td></tr>';
                echo '<tr><td align="left">'.get_string("C", "studentsurvey").'.</td><td align="left">&nbsp;&nbsp;&nbsp;<input size="54" name="choice3['.($i + 1).']" type="text" '.$valuequestionchoice[3].' /></td></tr>';
                echo '<tr><td align="left">'.get_string("D", "studentsurvey").'.</td><td align="left">&nbsp;&nbsp;&nbsp;<input size="54" name="choice4['.($i + 1).']" type="text" '.$valuequestionchoice[4].' /></td></tr></table>';

                print_simple_box_end();
        
            }
        
            echo '<input type="hidden" name="numberofquestions" value="'.$numberofquestions.'" />';
            echo '<input type="submit" value="'.get_string("addanotherquestion", "studentsurvey").'" name="submit" /><br />';
        
            echo '<input type="submit" value="'.get_string("savequestions", "studentsurvey").'" name="submit" />';
        }
    
        echo '</form></center>';
    
        print_simple_box_end();
    }

    //------Check max survey for sudent-----------//
    
    
    echo "<br />";
    
    print_simple_box_start('center', '100%', '#ffffff', 10);
    
    $table->head = array (get_string("student", "studentsurvey"), get_string("questions", "studentsurvey"), get_string("answers", "studentsurvey"), get_string("date", "studentsurvey"));
    $table->align = array ("left", "center",  "center", "left");
    $table->width = "700";
    
    $questions = get_records ("studentsurvey_cicls", "instance", $cm->instance, "timemodified");
    
    foreach ($questions as $question) {
    
        $username = studentsurvey_getname ($cm, $question->userid);
        if ($cm->groupmode == 0) {
            $username = '<a href="'.$CFG->wwwroot.'/user/view.php?id='.studentsurvey_getid ($cm, $question->userid).'&course='.$cm->course.'">'.$username.'</a>';
        }
        //$userdata = get_record ("user", "id", $question->userid);

        if ($question->timemodified == 0 && ($question->userid == $USER->id || isteacher($cm->instance))) {
            $data = get_record ("studentsurvey_questions", "cicl", $question->cicl, "userid", $question->userid);
            
            if ($question->timemodified == 0) {
                $tabledate = get_string("notpublished", "studentsurvey");
            }
            else
            {
                $tabledate = date("d M Y", $question->timemodified);
            }
            
            $table->data[] = array ($username.' <a href="?id='.$id.'&a=publish&n='.$question->id.'"  onclick="if(confirm(\'You can no longer edit your survey after you publish it. Publish?\')) return true; else return false;">['.get_string("publish", "studentsurvey").']</a> <a href="?id='.$id.'&a=edit&n='.$question->id.'">['.get_string("edit", "studentsurvey").']</a> <a href="?id='.$id.'&a=delete&n='.$question->id.'" onclick="if(confirm(\'Delete it?\')) return true; else return false;">['.get_string("delete", "studentsurvey").']</a>', count_records("studentsurvey_questions", "cicl", $question->cicl, "userid", $question->userid), $data->answers, $tabledate);
        }
        else if ($question->timemodified != 0)
        {
            if (!studentsurvey_alreadyanswered ($question->cicl)) {
                $printtext = ' <a href="view.php?id='.$id.'&cicl='.$question->cicl.'">'.get_string("takesurvey", "studentsurvey").'</a>';
            }
            else
            {
                $printtext = ' <a href="view.php?id='.$id.'&cicl='.$question->cicl.'">'.get_string("viewresults", "studentsurvey").'</a>';
            }
            
            //if ($question->userid == $USER->id || isteacher($cm->course)) {
                if (isteacher($cm->course)) {
                    $printtext .= ' <a href="?id='.$id.'&a=unpublish&n='.$question->id.'" onclick="if(confirm(\'Unpublish it?\')) return true; else return false;">['.get_string("unpublish", "studentsurvey").']</a> ';
                    $printtext .= ' <a href="?id='.$id.'&a=delete&n='.$question->id.'" onclick="if(confirm(\'Delete it?\')) return true; else return false;">['.get_string("delete", "studentsurvey").']</a>';
                    $printtext .= ' <a href="?id='.$id.'&cicl='.$question->cicl.'&a=viewresults">['.get_string("viewresults", "studentsurvey").']</a>';
                }
            //}
            
            if ($question->timemodified == 0) {
                $tabledate = get_string("notpublished", "studentsurvey");
            }
            else
            {
                $tabledate = date("d M Y", $question->timemodified);
            }
            
            $data = get_record ("studentsurvey_questions", "cicl", $question->cicl, "userid", $question->userid);
            
            $table->data[] = array ($username . $printtext, count_records("studentsurvey_questions", "cicl", $question->cicl, "userid", $question->userid), $data->answers, $tabledate);
        }
    
    }

    if (!empty($table)) {
        print_table($table);
    }
    
    print_simple_box_end();
    
    }
    else
    {
        print_simple_box_start('center', '600', '#ffffff', 10);
        
        if ($message) {
            echo $message;
        }
        
        $alreadyanswered = studentsurvey_alreadyanswered ($cicl);
        
        if (isteacher($cm->teacher) && $a == "viewresults") {
            $alreadyanswered = true;
        }
        
        $j = 0;
        
        if ($alreadyanswered == false) {
        
            echo '<a href="view.php?id='.$id.'"><< '.get_string("back", "studentsurvey").'</a>';
        
            echo '<form action="view.php?id='.$id.'&cicl='.$cicl.'" method="post" id="mform1" class="mform" enctype="multipart/form-data">';
        
            echo '<input type="hidden" name="answer" value="'.$cicl.'" />';
    
            $questions = get_records ("studentsurvey_questions", "cicl", $cicl);
        
            foreach ($questions as $question) {
            
                if (!empty($question->name)) {
            
                    $j++;
        
                    echo "<h4>".$j.". ".$question->name."</h4>";
                    echo '<table>';
              
                    $choices = get_records ("studentsurvey_choice", "question", $question->id);
             
                    foreach ($choices as $choice) {
                        echo '<tr><td><input name="choice['.$question->id.']" type="radio" value="'.$choice->id.'" /></td><td>'.$choice->name.'</td></tr>';
                    }

                    echo '</table>';
                }
            }
        
            echo '<br /><center><input type="submit" value="Submit answers" /></center>';
        
            echo '</form>';
    
        }
        else
        {
            $questions = get_records ("studentsurvey_questions", "cicl", $cicl);
            
            echo '<center><h4>';
            print_string("surveyresults", "studentsurvey");
            echo '</h4></center><br />';
            
            //echo '<center><a href="'.$CFG->wwwroot.'/user/view.php?id='.$USER->id.'&course='.$cm->course.'">Your Profile</a></center><br /><br />';
            
            echo '<a href="view.php?id='.$id.'"><< '. get_string("back", "studentsurvey") .'</a> :: <a href="?a=csv&cicl='.$cicl.'&id='.$id.'">'. get_string("downloadascsv", "studentsurvey") .'</a> :: <a href="?a=excel&cicl='.$cicl.'&id='.$id.'">'. get_string("downloadasexcel", "studentsurvey") .'</a>';
        
            foreach ($questions as $question) {
            
                $j++;
            
                echo "<h4>".$j.". ".$question->name."</h4>";
                echo '<table>';
            
                $choices = get_records ("studentsurvey_choice", "question", $question->id);
                
                $allcount = 0;
                
                foreach ($choices as $choice) {
                    $allcount += count_records("studentsurvey_answer", "answerid", $choice->id);
                }
                
                foreach ($choices as $choice) {
                    $countofchoice = count_records("studentsurvey_answer", "answerid", $choice->id);
                    echo '<tr><td>'.$choice->name.'</td><td width="30" align="center"> - <font color="red">'.$countofchoice.'</font></td><td><img src="'.$CFG->wwwroot.'/mod/studentsurvey/Yellow_dot.gif" width="'.(round(200*($countofchoice/$allcount))).'px" height="10px" /> <font color="red">'.(round(100*($countofchoice/$allcount), 2)).'%</font> </td></tr>';
                }

                echo '</table>';
                
                echo '<br /><small><b>' . get_string("totalresponses", "studentsurvey") . $allcount . '</b></small><br /><br />';
            }
        }
    
        print_simple_box_end();
        

        echo "<br />";
    }
    

    print_footer($course);

?>