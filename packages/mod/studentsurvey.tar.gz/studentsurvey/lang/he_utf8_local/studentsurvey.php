<?php 

$string['back'] = 'חזרה';
$string['downloadascsv'] = 'הורידו תוצאות בקובץ CSV';
$string['downloadasexcel'] = 'הורידו תוצאות בקובץ EXCEL';


$string['modulename'] = 'תלמידים מחברים סקר';
$string['modulenameplural'] = 'תלמידים מחברים סקר';
$string['messages'] = 'סקר שחובר על ידי תלמידים';
$string['surveydescription'] = 'תאור הסקר';

$string['addnewsurvey'] = 'הוספת סקר חדש';
$string['addsurveyquestions'] = 'הוספת שאלות חדשות לסקר';
$string['question']   = 'שאלה';
$string['surveyresults']   = 'תוצאות הסקר';
$string['totalresponses']   = 'סך כל מספר התשובות: ';
$string['maxsurvey']   = 'מספר הסקרים המירבי שתלמידים יכולים לייצר: ';
$string['viewresults']   = 'תצוגת תוצאות';

$string['publish']   = 'פרסום';
$string['unpublish']   = 'ביטול פרסום';
$string['delete']   = 'מחיקה';
$string['edit']   = 'עריכה';
$string['notpublished']   = 'לא מפורסם';

$string['addanotherquestion']   = 'הוסיפו שאלה חדשה לסקר הנוכחי';
$string['savequestions']   = 'שמירת כל השאלות של הסקר הנוכחי';

$string['A']   = 'א';
$string['B']   = 'ב';
$string['C']   = 'ג';
$string['D']   = 'ד';

$string['student']   = 'תלמידים';
$string['questions']   = 'סקרים';
$string['answers']   = 'תוצאות';
$string['date']   = 'תאריך';

?>