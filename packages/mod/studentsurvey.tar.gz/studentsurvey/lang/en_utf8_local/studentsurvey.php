<?php 

$string['modulename'] = 'Student Survey';
$string['modulenameplural'] = 'Student Survey';
$string['messages'] = 'Student Survey';
$string['surveydescription'] = 'Survey Description';

$string['addnewsurvey'] = 'Add new survey';
$string['addsurveyquestions'] = 'Add survey questions';
$string['question']   = 'Question';
$string['surveyresults']   = 'Survey Results';
$string['totalresponses']   = 'Total number of responses: ';
$string['maxsurvey']   = 'Max. # of surveys that student can create: ';

$string['back'] = 'back';
$string['downloadascsv'] = 'download as CSV file';
$string['downloadasexcel'] = 'download as EXCEL file';

$string['publish']   = 'publish';
$string['unpublish']   = 'unpublish';
$string['delete']   = 'delete';
$string['edit']   = 'edit';
$string['notpublished']   = 'not published';

$string['addanotherquestion']   = 'Add another Question';
$string['savequestions']   = 'Save all Questions';

$string['A']   = 'A';
$string['B']   = 'B';
$string['C']   = 'C';
$string['D']   = 'D';

$string['student']   = 'Students';
$string['questions']   = 'Questions';
$string['answers']   = 'Answers';
$string['date']   = 'Date';

?>