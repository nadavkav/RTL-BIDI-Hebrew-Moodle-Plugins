<?php 

$string['modulename'] = 'Student Survey';
$string['modulenameplural'] = 'Student Survey';
$string['surveydescription'] = 'Survey Description';

$string['addnewSurvey'] = 'Add new Survey';
$string['question']   = 'Question';
$string['surveyresults']   = 'Survey Results';
$string['totalresponses']   = 'Total number of responses: ';


?>