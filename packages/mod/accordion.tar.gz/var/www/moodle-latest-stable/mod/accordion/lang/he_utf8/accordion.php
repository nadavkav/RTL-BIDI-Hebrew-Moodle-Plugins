<?PHP // $Id: accord.php,v 1.2 2008/10/25 09:44:05  $
      // accord.php -

$string['accordtitle'] = 'כותרת';
$string['accordcontent'] = 'תוכן הפסקה';
$string['modulename'] = 'פסקה נחבאת';
$string['modulenameplural'] = 'פסקאות נחבות';
$string['resourcetypeaccordion'] = 'הוספת פסקה נחבאת';
$string['resourcetypeaccord'] = 'פסקה נחבאת';

?>
