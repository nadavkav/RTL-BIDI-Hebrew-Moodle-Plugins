<?PHP // $Id: jclic.php,v 1.1 2007/10/03 09:33:34 sarjona Exp $

$string['activitydone'] = 'Activitats fetes';
$string['activitysolved'] = 'Activitats encertades';
$string['attempts'] = 'Intents';
$string['avaluation'] = 'Criteri d\'avaluaci&oacute;';
$string['avaluation_score'] = 'Assolir aquesta puntuaci&oacute; mitja entre totes les activitats';
$string['avaluation_solved'] = 'Resoldre correctament aquest nombre d\'activitats diferents';
$string['description'] = 'Descripci&oacute;';
$string['height']='Al&ccedil;ada';
$string['hideall']='Mostra nom&eacute;s els resums';
$string['jclicpluginjs']='Adre&ccedil;a web on es troba el fitxer <b>jclicplugin.js</b>';
$string['lastaccess']='&Uacute;ltim acc&eacute;s';
$string['maxattempts'] = 'Nombre m&agrave;xim d\'intents';
$string['maxgrade'] = 'Puntuaci&oacute;/activitats que cal assolir';
$string['modulename'] = 'JClic';
$string['modulenameplural'] = 'JClic';
$string['msg_noattempts']= 'Ja has fet aquesta activitat el nombre m&agrave;xim de vegades';
$string['score']='Puntuaci&oacute;';
$string['sessions']='Sessions';
$string['showall']='Mostra el detall de les sessions';
$string['size']='Mides';
$string['starttime']= 'Data d\'inici';
$string['skin'] = 'Aparen&ccedil;a (<i>skin</i>)';
$string['totals']= 'Totals';
$string['totaltime']= 'Temps total';
$string['unlimited'] = 'Il&middot;limitat';
$string['url'] = 'Enlla&ccedil;';
$string['width']='Amplada';

/* Revision 20070305 */
$string['actions']='Encerts';
$string['activity']='Activitat';
$string['lap']='Temps que es deixa entre les transaccions client-servidor (expressat en segons)';
$string['msg_nosessions']='Aquesta activitat JClic encara no t&eacute; cap sessi&oacute;';
$string['show_results']='Mostra els resultats';
$string['solved']='Correcta';
$string['time']='Temps';

/* Revision 20071002 */
$string['header_jclic']='Par&agrave;metres JClic';
$string['header_score']='Par&agrave;metres d\'avaluaci&oacute;';


?>
