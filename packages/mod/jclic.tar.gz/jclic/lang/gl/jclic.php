<?PHP // $Id: jclic.php,v 1.3 2008/11/10 16:39:54 sarjona Exp $
// Traduci�n ao galego feita por Xos� Luis Barreiro Cebey - data: 2008/11/10 17:04:57
// e-mail: xoseluis@edu.xunta.es

$string['activitydone'] = 'Actividades realizadas';
$string['activitysolved'] = 'Activitades acertadas';
$string['attempts'] = 'Intentos';
$string['avaluation'] = 'Criterio de avaluaci&oacute;n';
$string['avaluation_score'] = 'Acadar unha puntuaci&oacute;n media entre todas as actividades';
$string['avaluation_solved'] = 'Resolver correctamente un n&uacute;mero de actividades diferentes';
$string['description'] = 'Descrici&oacute;n';
$string['height']='Altura';
$string['hideall']='Amosar s&oacute; os res&uacute;mos';
$string['jclicpluginjs']='URL onde se atopa o ficheiro <b>jclicplugin.js</b>';
$string['lastaccess']='&uacute;ltimo acceso';
$string['maxattempts'] = 'N&uacute;mero m&aacute;ximo de intentos';
$string['maxgrade'] = 'Puntuaci&oacute;n/actividades a acadar';
$string['modulename'] = 'JClic';
$string['modulenameplural'] = 'JClic';
$string['msg_noattempts']= 'Xa realizaches esta actividade o n&uacute;mero de veces m&aacute;ximo';
$string['score']='Puntuaci&oacute;n';
$string['sessions']='Sesi&oacute;ns';
$string['size']='Medidas';
$string['showall']='Amosar o detalle das sesi&oacute;ns';
$string['starttime']= 'Data de inicio';
$string['skin'] = 'Entorno gr&aacute;fico (<i>skin</i>)';
$string['totals']= 'Totais';
$string['totaltime']= 'Tempo total';
$string['unlimited'] = 'Ilimitado';
$string['url'] = 'Enlace';
$string['width']='Anchura';

/* Revision 20070305 */
$string['actions']='Acertos';
$string['activity']='Actividade';
$string['lap']='Tempo que se deixa entre as transacci&oacute;ns cliente-servidor (expresado en segundos)';
$string['msg_nosessions']='Esta actividade JClic ainda non ten ningunha sesi&oacute;n';
$string['show_results']='Amosar os resultados';
$string['solved']='Correcta';
$string['time']='Tempo';

/* Revision 20071002 */
$string['header_jclic']='Axustes de JClic';
$string['header_score']='Axustes de avaluaci&oacute;n';

/* Revision 20081110 */
$string['preview_jclic']='Amosar a actividade JClic';

?>
