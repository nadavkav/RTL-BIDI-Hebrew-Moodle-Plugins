<?PHP  // $Id: version.php,v 1.7 2008/11/18 13:33:29 sarjona Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of jclic
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2008110700;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)
?>
