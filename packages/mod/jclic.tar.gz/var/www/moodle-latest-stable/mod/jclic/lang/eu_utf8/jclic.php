<?PHP // $Id: jclic.php,v 1.2 2008/11/10 16:39:54 sarjona Exp $
// Translator: Abel Camacho - date: 2008/11/10 17:04:57
// e-mail: didaktika@santurtzieus.com

$string['actions'] = 'Ekintzak';
$string['activity'] = 'Jarduera';
$string['activitydone'] = 'Bukatutako jarduerak';
$string['activitysolved'] = 'Ebatzitako jarduerak';
$string['attempts'] = 'Saiakerak';
$string['avaluation'] = 'Ebaluazio-irizpideak';
$string['avaluation_score'] = 'Jarduera guztien arteko batez bestekoa egin';
$string['avaluation_solved'] = 'Jarduera ezberdinen kopuru bat ongi ebatzi';
$string['description'] = 'Deskribapena';
$string['height'] = 'Garaiera';
$string['hideall'] = 'Laburpenak baino ez erakutsi';
$string['jclicpluginjs'] = '<b>Jclicplugin.js</b> fitxategiaren URL helbidea';
$string['lap'] = 'Bezeroaren eta zerbitzariaren arteko transakzioetarako uzten den denbora (segundutan)';
$string['lastaccess'] = 'Azken sarrera';
$string['maxattempts'] = 'Gehienezko saiakera-kopurua';
$string['maxgrade'] = 'Iritsi beharreko jarduera/puntuazioa';
$string['modulename'] = 'JClic';
$string['modulenameplural'] = 'JClic';
$string['msg_noattempts'] = 'Jarduera hau ahal zen aldi guztietan egin duzu';
$string['msg_nosessions'] = 'Jarduera honetarako gehienezko saiakera-kopurua  gainditu duzu';
$string['score'] = 'Puntuazioa';
$string['sessions'] = 'Saioak';
$string['show_results'] = 'Emaitzak erakutsi';
$string['showall'] = 'Saioetako zehaztapenak erakutsi';
$string['size'] = 'Neurriak';
$string['skin'] = 'Itxura(<i>skin</i>)';
$string['solved'] = 'Zuzena';
$string['starttime'] = 'Hasiera-data';
$string['time'] = 'Denbora';
$string['totals'] = 'Guztira';
$string['totaltime'] = 'Denbora osoa';
$string['unlimited'] = 'Mugagabea';
$string['url'] = 'URLa';
$string['width'] = 'Zabalera';

/* Revision 20070305 */ 
$string['actions'] = 'Ekintzak'; 
$string['activity'] = 'Jarduera'; 
$string['lap'] = 'Bezeroaren eta zerbitzariaren arteko transakzioetarako uzten den denbora (segundutan)'; 
$string['msg_nosessions'] = 'Jarduera honetarako gehienezko saiakera-kopurua gainditu duzu'; 
$string['show_results'] = 'Emaitzak erakutsi'; 
$string['solved'] = 'Zuzena'; 
$string['time'] = 'Denbora'; 

/* Revision 20071002 */ 
$string['header_jclic']='JClic-en ezarpenak'; 
$string['header_score']='Ebaluazio-ezarpenak'; 

/* Revision 20081107 */
$string['preview_jclic']='JClic jarduera erakutsi';

?>
