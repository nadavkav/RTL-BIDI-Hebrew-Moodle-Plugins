.mod-hotquestion .author {
    color: grey;
    font-style: italic;
    font-size: 90%;
}

div#toolbar {
    text-align: center;
}
