<?php // $Id

    require_once("../../config.php");
    require_once("lib.php");
    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $blogID          = optional_param('blogID', 0, PARAM_INT);       // Blog Post ID

    if (! $cm = get_record("course_modules", "id", $id)) {
        error("Course Module ID was incorrect");
    }

    if (! $course = get_record("course", "id", $cm->course)) {
        error("Course is misconfigured");
    }

    require_login($course->id, false, $cm);

    if (isguest()) {
        error("Guests are not allowed to edit blogs", $_SERVER["HTTP_REFERER"]);
    }

    if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
        error("Course module is incorrect");
    }


/// START: Check to see if use has the right to edit this entry

    global $USER;
    global $COURSE;

/// Gets user's role for the course

$context = get_context_instance(CONTEXT_COURSE, $COURSE->id);

$levelSQL = get_record("role_assignments", "contextid", $context->id ."' AND userid = '".$USER->id);
$userBlogRole = $levelSQL->roleid;


/// Set some defaults to start with
$teacherCheck="n";
$studentCheck="n";
$editOwn = "n";
$editOthers = "n";


/// Checks to see if the user is a teacher

$levelCheck = get_record("simpleblog", "id", $cm->instance);

if ($userBlogRole == $levelCheck->teacher1 OR $userBlogRole == $levelCheck->teacher2) {
$teacherCheck="y";
} else {
$teacherCheck="n";
}

/// Checks to see if the user is a teacher and can edit own posts

if ($teacherCheck == 'y') {
	if ($userBlogRole == $levelCheck->teacher1 && $levelCheck->teacher1edit == 'y') {
	$editOwn = "y";
	} else if ($userBlogRole == $levelCheck->teacher2 && $levelCheck->teacher2edit == 'y') {
	$editOwn = "y";
	} else {
	$editOwn = "n";
	}
}

/// Checks to see if the user is a teacher and can edit other's posts

if ($teacherCheck == 'y') {
	if ($userBlogRole == $levelCheck->teacher1 && $levelCheck->teacher1others == 'y') {
	$editOthers = "y";
	} else if ($userBlogRole == $levelCheck->teacher2 && $levelCheck->teacher2others == 'y') {
	$editOthers = "y";
	} else {
	$editOthers = "n";
	}
}


/// Checks to see if the user is a student

if ($userBlogRole == $levelCheck->student1 OR $userBlogRole == $levelCheck->student2) {
$studentCheck="y";
} else {
$studentCheck="n";
}


/// Checks to see if the user is a student and can edit own posts

if ($studentCheck == 'y') {
	if ($userBlogRole == $levelCheck->student1 && $levelCheck->student1edit == 'y') {
	$editOwn = "y";
	} else if ($userBlogRole == $levelCheck->student2 && $levelCheck->student2edit == 'y') {
	$editOwn = "y";
	} else {
	$editOwn = "n";
	}
}

/// checks to see if current user is the author

$blog = get_record("simpleblog_entries", 'id', $blogID); 

if ($blog->userid == $USER->id) {
$isAuthorCheck = 'y';
} else {
$isAuthorCheck = 'n';
}

/// Gives blog author or teacher option of edit post, if settings allow

if ($teacherCheck == 'y') {
	if ($editOthers == 'y') { } else if ($editOwn == 'y' AND $isAuthorCheck == 'y') { } else {
	error("You are not allowed to edit this entry");
	}
}
if ($studentCheck == 'y') {
	if ($editOwn == 'y' AND $isAuthorCheck == 'y') { } else {
	error("You are not allowed to edit this entry");
	}
}

/// END: Check to see if use has the right to edit this entry


/// If data submitted, then process and store.

    if ($form = data_submitted()) {

    $timenow = time();

    $updateblog->id = $blogID;
    $updateblog->title = $form->title;
    $updateblog->entry = $form->entry;
    $updateblog->timemodified = $timenow;
    $updateblog->usermodified = $USER->id;

    if (! update_record ("simpleblog_entries", $updateblog) ) {
               error("Could not update entry");
    }

       redirect("view.php?id=$cm->id");
       die;
    }

/// Otherwise fill and print the form.

    $strblog = get_string("modulename", "simpleblog");
    $strblogs = get_string("modulenameplural", "simpleblog");
    $stredit = get_string("editcrumb", "simpleblog");
    if ($usehtmleditor = can_use_richtext_editor()) {
        $defaultformat = FORMAT_HTML;
    } else {
        $defaultformat = FORMAT_MOODLE;
    }

$blogs = get_record('simpleblog_entries','id', $blogID);

        $entry->entry = $blogs->entry;
        $entry->format = $defaultformat;

    print_header_simple(format_string($simpleblog->name), "",
                 "<a href=\"index.php?id=$course->id\">$strblogs</a> ->
                  <a href=\"view.php?id=$cm->id\">".format_string($simpleblog->name,true)."</a> -> $stredit", "",
                  "", true, "", navmenu($course, $cm));

    echo "<center>\n";

    echo "<br />";

    include("edit.html");

    if ($usehtmleditor) {
        use_html_editor("entry");
    }

    print_footer($course);

?>