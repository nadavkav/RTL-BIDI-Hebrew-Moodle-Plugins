<?PHP // $Id: index.php,v 1.1 2003/09/30 02:45:19 moodler Exp $

/// This page lists all the instances of simpleblog in a particular course

    require_once("../../config.php");
    require_once("lib.php");

    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID

    if (! $course = get_record("course", "id", $id)) {
        error("Course ID is incorrect");
    }

    require_login($course->id);

    add_to_log($course->id, "simpleblog", "view all", "index.php?id=$course->id", "");


/// Get all required strings

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");
    $strsimpleblog  = get_string("modulename", "simpleblog");


/// Print the header

    $navigation = "$strsimpleblogs";
    print_header_simple(format_string($simpleblog->name), "",
                 "$navigation ".format_string($simpleblog->name), "", "", true, $buttontext, navmenu($course, $cm));

/// Get all the appropriate data

    if (! $simpleblogs = get_all_instances_in_course("simpleblog", $course)) {
        notice("There are no simpleblogs", "../../course/view.php?id=$course->id");
        die;
    }

/// Print the list of instances

    $timenow = time();
    $strname  = get_string("name");
    $strweek  = get_string("week");
    $strtopic  = get_string("topic");

    if ($course->format == "weeks") {
        $table->head  = array ($strweek, $strname);
        $table->align = array ("CENTER", "RIGHT");
    } else if ($course->format == "topics") {
        $table->head  = array ($strtopic, $strname);
        $table->align = array ("CENTER", "RIGHT", "LEFT", "LEFT");
    } else {
        $table->head  = array ($strname);
        $table->align = array ("LEFT", "LEFT", "LEFT");
    }

    foreach ($simpleblogs as $simpleblog) {
        if (!$simpleblog->visible) {
            //Show dimmed if the mod is hidden
            $link = "<A class=\"dimmed\" HREF=\"view.php?id=$simpleblog->coursemodule\">$simpleblog->name</A>";
        } else {
            //Show normal if the mod is visible
            $link = "<A HREF=\"view.php?id=$simpleblog->coursemodule\">$simpleblog->name</A>";
        }

        if ($course->format == "weeks" or $course->format == "topics") {
            $table->data[] = array ($simpleblog->section, $link);
        } else {
            $table->data[] = array ($link);
        }
    }

    echo "<BR>";

    print_table($table);

/// Finish the page

    print_footer($course);

?>
