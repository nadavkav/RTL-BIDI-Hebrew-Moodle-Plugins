<?PHP // $Id: index.php,v 1.1 2003/09/30 02:45:19 moodler Exp $

/// This page lists all the instances of simpleblog in a particular course

    require_once("../../config.php");
    require_once("lib.php");

    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $blogid      = optional_param('blogid', 0, PARAM_INT);       // Blog ID
    $postid      = optional_param('postid', 0, PARAM_INT);       // Blog entry ID

    if (! $course = get_record("course", "id", $COURSE->id)) {
        error("Course ID is incorrect");
    }

    require_login($course->id);


/// Get all required strings

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");
    $strsimpleblog  = get_string("modulename", "simpleblog");
    $strimportblog  = get_string("importblog", "simpleblog");
    $strimportnotice  = get_string("importnotice", "simpleblog");

/// Print the header

    $navigation = "<a href=\"index.php?id=$course->id\">$strsimpleblogs</a> ->";
    print_header_simple(format_string($strimportblog), "",
                 "$navigation ".format_string($strimportblog), "", "", true, $buttontext, navmenu($course, $cm));

/// import a Moodle blog into course blog

echo '<div class="generalbox">' . $strimportnotice . '<br /><br />';

$importblog = get_records("post", "userid", $USER->id, "id DESC", '*', 0, 20);

foreach ($importblog as $importblogs) {
	echo '<a href="' . $CFG->wwwroot . '/mod/simpleblog/post.php?id=' . $id . '&blogid=' . $importblogs->id . '&mode=import">' . $importblogs->subject . '</a><br />';
}

echo '</div>';

/// Finish the page

    print_footer($course);

?>
