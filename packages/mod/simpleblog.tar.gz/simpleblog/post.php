<?php // $Id

    require_once("../../config.php");
    require_once("lib.php");
    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $bloguser    = optional_param('bloguser', 0, PARAM_INT);       // Blog User ID
    $title       = optional_param('title', 0);       // Blog Entry Title
    $entry       = optional_param('entry', 0);       // Blog Entry
    $createpost  = optional_param('createpost', 'no');       // Create comments variable
    $discussion  = optional_param('discussion', 0, PARAM_INT);       // Discussion ID for comments
    $mode        = optional_param('mode', 'none');       // Post mode (import, etc)
    $blogid      = optional_param('blogid', 0, PARAM_INT);       // Blog ID to import

    if ($mode == 'import') {
        $importCheck = "y";
    } else {
        $importCheck = "n";
    }
    if (! $cm = get_record("course_modules", "id", $id)) {
        error("Course Module ID was incorrect");
    }

    if (! $course = get_record("course", "id", $cm->course)) {
        error("Course is misconfigured");
    }

    require_login($course->id, false, $cm);

    if (isguest()) {
        error("Guests are not allowed to edit blogs", $_SERVER["HTTP_REFERER"]);
    }

/// Check persmissions to post based on blog level

$levelCheck = get_record("simpleblog", "id", $cm->instance);

$context = get_context_instance(CONTEXT_COURSE, $COURSE->id);

$levelSQL = get_record("role_assignments", "contextid", $context->id ."' AND userid = '".$USER->id);
$userBlogRole = $levelSQL->roleid;

if ($userBlogRole == $levelCheck->teacher1 OR $userBlogRole == $levelCheck->teacher2) {
$teacherCheck="y";
} else {
$teacherCheck="n";
}
if ($userBlogRole == $levelCheck->student1 OR $userBlogRole == $levelCheck->student2) {
$studentCheck="y";
} else {
$studentCheck="n";
}

if ($levelCheck->bloglevel == '1'){
    if ($studentCheck == 'y') {
        error("Students are not allowed to add blog entries to this blog");
    }
}
if ($levelCheck->bloglevel == '2' OR $levelCheck->bloglevel == '3'){
    if ($studentCheck == 'y' OR $teacherCheck == 'y') { } else {
        error("You are not allowed to add blog entries to this blog");
    }
}
if ($levelCheck->bloglevel == '4'){
    if ($studentCheck == 'n') { 
        error("You are not allowed to add blog entries to this blog");
    }
}

    if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
        error("Course module is incorrect");
    }

/// If data submitted, then process and store.

    if ($form = data_submitted()) {

if ($createpost == 'no') {
	$discussions->id = '0';
}

/// Create variables for a comments forum, if chosen

if ($createpost == 'yes') {

$strblogmessage = get_string("blogmessage", "simpleblog");
$strblogclick = get_string("blogclick", "simpleblog");

$blogmessage = $strblogmessage . ' <br /><br /><a href="../simpleblog/view.php?id=' . $cm->id . '">' . $strblogclick . '</a>';

    GLOBAL $USER, $CFG;

    $timenow = time();

    // Created variables for first discussion post

    $post->discussion  = 0;
    $post->parent      = 0;
    $post->userid      = $USER->id;
    $post->created     = $timenow;
    $post->modified    = $timenow;
    $post->mailed      = 0;
    $post->attachment  = "";
    $post->subject     = $form->title;
    $post->message     = $blogmessage;
    $post->forum       = $form->discussion;
    $post->course      = $course->id;
    $post->format      = '1';

    if (! $post->id = insert_record("forum_posts", $post) ) {
                error("Could not insert a new post");
    }
 
    // Now do the main entry for the comments discussion forum,
    // linking to this first post

    $discussions->course = $course->id;
    $discussions->forum = $form->discussion;
    $discussions->name = $form->title;
    $discussions->firstpost    = $post->id;
    $discussions->userid = $USER->id;
    $discussions->groupid = '-1';
    $discussions->assessed = '1';
    $discussions->timemodified = $timenow;
    $discussions->usermodified = $post->userid;

    if (! $discussions->id = insert_record("forum_discussions", $discussions) ) {
               error("Could not insert a new discussion");
    }

    $updatepath->id = $post->id;
    $updatepath->discussion = $discussions->id;

    if (! update_record ("forum_posts", $updatepath) ) {
               error("Could not set ID");
    }

}

/// Create variables for blog entry and insert in database

        $timenow = time();
		$entryDate=date("F j, Y (g:i a)");
		$searchString=date("Ym");
                $archiveDate=date("F Y");

        if ($entry) {

		$newentry->course = $course->id;
            $newentry->cmid = $cm->id;
		$newentry->userid = $USER->id;
		$newentry->title = $form->title;
            $newentry->entry = $form->entry;
            $newentry->date = $entryDate;
            $newentry->searchString = $searchString;
            $newentry->discussionPost = $discussions->id;
		$newentry->imported = $form->imported;
            if (! $newentry->cmid = insert_record("simpleblog_entries", $newentry)) {
                error("Could not insert a new blog entry");
            }

/// Searches for archive for this month's post.  If none, creates one.

$entryArchive = get_record('simpleblog_archives','cmid',$cm->id,'searchString',$searchString);

if (!$entryArchive){
            $newarchive->cmid = $cm->id;
            $newarchive->searchString = $searchString;
            $newarchive->archiveDate = $archiveDate;
		$newarchive->userid = $USER->id;
            if (!$archiveEntry =  insert_record('simpleblog_archives', $newarchive)) {
                error("Could not insert a new archive");
            }

}
            add_to_log($course->id, "simpleblog", "add entry", "view.php?id=$cm->id", "$newentry->id", $cm->id);
        }

        redirect("view.php?id=$cm->id");
        die;
    }

/// Otherwise fill and print the form.

    $strblog = get_string("modulename", "simpleblog");
    $strblogs = get_string("modulenameplural", "simpleblog");
    $stredit = get_string("blogcrumb", "simpleblog");
    if ($usehtmleditor = can_use_richtext_editor()) {
        $defaultformat = FORMAT_HTML;
    } else {
        $defaultformat = FORMAT_MOODLE;
    }

    if (empty($entry)) {
        $entry->entry = "";
        $entry->format = $defaultformat;
    }

$getDiscussion1 = get_record('course_modules','id',$id);
$sendNext = $getDiscussion1->instance;

$getDiscussion2 = get_record('simpleblog','id',$sendNext);
$discussionID = $getDiscussion2->commentforum;

    print_header_simple(format_string($simpleblog->name), "",
                 "<a href=\"index.php?id=$course->id\">$strblogs</a> ->
                  <a href=\"view.php?id=$cm->id\">".format_string($simpleblog->name,true)."</a> -> $stredit", "",
                  "", true, "", navmenu($course, $cm));

    echo "<center>\n";

    echo "<br />";

    include("post.html");

    if ($usehtmleditor) {
        use_html_editor("entry");
    }

    print_footer($course);

?>
