<?php // $Id

    require_once("../../config.php");
    require_once("lib.php");
    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $blogID          = optional_param('blogID', 0, PARAM_INT);       // Blog Post ID

    if (! $cm = get_record("course_modules", "id", $id)) {
        error("Course Module ID was incorrect");
    }

    if (! $course = get_record("course", "id", $cm->course)) {
        error("Course is misconfigured");
    }

    require_login($course->id, false, $cm);

    if (isguest()) {
        error("Guests are not allowed to add notes", $_SERVER["HTTP_REFERER"]);
    }

    if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
        error("Course module is incorrect");
    }


/// START: Check to see if use has the right to add a note

    global $USER;
    global $COURSE;

/// Gets user's role for the course

$context = get_context_instance(CONTEXT_COURSE, $COURSE->id);

$levelSQL = get_record("role_assignments", "contextid", $context->id ."' AND userid = '".$USER->id);
$userBlogRole = $levelSQL->roleid;


/// Set some defaults to start with
$teacherCheck="n";


/// Checks to see if the user is a teacher

$levelCheck = get_record("simpleblog", "id", $cm->instance);

if ($userBlogRole == $levelCheck->teacher1 OR $userBlogRole == $levelCheck->teacher2) {
$teacherCheck="y";
} else {
$teacherCheck="n";
}

if ($teacherCheck == 'y') { } else {
	error("You are not allowed to add a note");
}

/// END: Check to see if use has the right to add a note

/// If data submitted, then process and store.

    if ($form = data_submitted()) {
    $timenow = time();

    $updateblog->id = $blogID;
    $updateblog->note = $form->entry;
    $updateblog->notemodified = $timenow;
    $updateblog->noteid = $USER->id;

    if (! update_record ("simpleblog_entries", $updateblog) ) {
               error("Could add note");
    }

       redirect("view.php?id=$cm->id");
       die;
    }

/// Otherwise fill and print the form.

    $strblog = get_string("modulename", "simpleblog");
    $strblogs = get_string("modulenameplural", "simpleblog");
    $stredit = get_string("editcrumb", "simpleblog");
    $straddnote = get_string("addnote", "simpleblog");
    if ($usehtmleditor = can_use_richtext_editor()) {
        $defaultformat = FORMAT_HTML;
    } else {
        $defaultformat = FORMAT_MOODLE;
    }

$blogs = get_record('simpleblog_entries','id', $blogID);

        $entry->entry = $blogs->note;
        $entry->format = $defaultformat;

    print_header_simple(format_string($simpleblog->name), "",
                 "<a href=\"index.php?id=$course->id\">$strblogs</a> ->
                  <a href=\"view.php?id=$cm->id\">".format_string($simpleblog->name,true)."</a> -> $straddnote", "",
                  "", true, "", navmenu($course, $cm));

    echo "<center>\n";

    echo "<br />";

    include("note.html");

    if ($usehtmleditor) {
        use_html_editor("entry");
    }

    print_footer($course);

?>