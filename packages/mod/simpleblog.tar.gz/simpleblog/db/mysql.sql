#
# Table structure for table `simpleblog`
#

CREATE TABLE prefix_simpleblog (
  id int(10) unsigned NOT NULL auto_increment,
  course int(10) unsigned NOT NULL default '0',
  intro text NOT NULL,
  name varchar(255) NOT NULL default '',
  menuvisible int(2) NOT NULL default '0',
  commentforum int(10) NOT NULL default '0',
  bloglevel int(2) NOT NULL default '1',
  teacher1 char(3) NOT NULL default '0',
  teacher1edit char(1) NOT NULL default 'y',
  teacher1others char(1) NOT NULL default 'y',
  teacher2 char(3) NOT NULL default '0',
  teacher2edit char(1) NOT NULL default 'y',
  teacher2others char(1) NOT NULL default 'y',
  student1 char(3) NOT NULL default '0',
  student1edit char(1) NOT NULL default 'y',
  student2 char(3) NOT NULL default '0',
  student2edit char(1) NOT NULL default 'y',
  PRIMARY KEY  (id),
  KEY course (course)
) TYPE=MyISAM COMMENT='Defines simpleblog';


#
# Table structure for table `simpleblog_archives`
#


CREATE TABLE prefix_simpleblog_archives (
  id int(10) NOT NULL auto_increment,
  cmid int(10) NOT NULL default '0',
  userid int(10) NOT NULL default '0',
  searchString varchar(6) NOT NULL default '',
  archiveDate varchar(50) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM COMMENT='Holds simpleblog archives';

#
# Table structure for table `simpleblog_entries`
#


CREATE TABLE prefix_simpleblog_entries (
  id int(10) unsigned NOT NULL auto_increment,
  course int(10) unsigned NOT NULL default '0',
  cmid int(10) NOT NULL default '0',
  userid int(10) unsigned NOT NULL default '0',
  title varchar(255) NOT NULL default '',
  entry text NOT NULL,
  date varchar(50) NOT NULL default '',
  searchString varchar(6) NOT NULL default '',
  discussionPost int(10) NOT NULL default '0',
  timemodified bigint(10) NOT NULL default '0',
  usermodified bigint(10) NOT NULL,
  note text NOT NULL,
  notemodified bigint(10) NOT NULL default '0',
  noteid bigint(10) NOT NULL,
  imported varchar(1) NOT NULL default 'n',
  PRIMARY KEY  (id),
  KEY course (course)
) TYPE=MyISAM COMMENT='Holds simpleblog entries';