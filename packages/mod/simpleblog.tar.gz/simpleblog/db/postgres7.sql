--
-- Table structure for table `simpleblog`
--

CREATE TABLE prefix_simpleblog (
  id SERIAL NOT NULL,
  course int4 NOT NULL default '0',
  intro text NOT NULL,
  name varchar(255) NOT NULL default '',
  menuvisible int2 NOT NULL default '0',
  commentforum int4 NOT NULL default '0',
  bloglevel int2 NOT NULL default '1',
  teacher1 char(3) NOT NULL default '0',
  teacher1edit char(1) NOT NULL default 'y',
  teacher1others char(1) NOT NULL default 'y',
  teacher2 char(3) NOT NULL default '0',
  teacher2edit char(1) NOT NULL default 'y',
  teacher2others char(1) NOT NULL default 'y',
  student1 char(3) NOT NULL default '0',
  student1edit char(1) NOT NULL default 'y',
  student2 char(3) NOT NULL default '0',
  student2edit char(1) NOT NULL default 'y',
  PRIMARY KEY  (id)
);


--
-- Table structure for table `simpleblog_archives`
--


CREATE TABLE prefix_simpleblog_archives (
  id SERIAL NOT NULL,
  cmid int4 NOT NULL default '0',
  userid int4 NOT NULL default '0',
  searchString varchar(6) NOT NULL default '',
  archiveDate varchar(50) NOT NULL default '',
  PRIMARY KEY  (id)
);

--
-- Table structure for table `simpleblog_entries`
--


CREATE TABLE prefix_simpleblog_entries (
  id SERIAL NOT NULL,
  course int4 NOT NULL default '0',
  cmid int4 NOT NULL default '0',
  userid int4 NOT NULL default '0',
  title varchar(255) NOT NULL default '',
  entry text NOT NULL,
  date varchar(50) NOT NULL default '',
  searchString varchar(6) NOT NULL default '',
  discussionPost int4 NOT NULL default '0',
  timemodified bigint NOT NULL default '0',
  usermodified bigint NOT NULL,
  note text NOT NULL,
  notemodified bigint NOT NULL default '0',
  noteid bigint NOT NULL,
  imported varchar(1) NOT NULL default 'n',
  PRIMARY KEY  (id)
);