<?php // $Id: mssql.php,v 0.7 2008/05/28 10:33:45 matt-crosslin Exp $
/**
 * Upgrade procedures for simpleblog
 *
 * @author 
 * @version $Id: mssql.php,v 0.7 2008/05/28 10:33:45 matt-crosslin Exp $
 * @package NEWMODULE
 **/

/**
 * This function does anything necessary to upgrade 
 * older versions to match current functionality 
 *
 * @uses $CFG
 * @param int $oldversion The prior version number
 * @return boolean Success/Failure
 **/

function simpleblog_upgrade($oldversion) {
   global $CFG;

   if ($oldversion < 2006012700) {
        execute_sql(" CREATE TABLE ".$CFG->prefix."simpleblog (
		  id int(10) unsigned NOT NULL auto_increment,
		  course int(10) unsigned NOT NULL default '0',
		  intro text NOT NULL,
		  name varchar(255) NOT NULL default '',
		  menuvisible int(2) NOT NULL default '0',
		  commentforum int(10) NOT NULL default '0',
		  bloglevel int(2) NOT NULL default '1',
		  PRIMARY KEY  (id),
		  KEY course (course)
		  ) TYPE=MyISAM COMMENT='Defines simpleblog'");

        execute_sql(" CREATE TABLE ".$CFG->prefix."simpleblog_archives (
		  id int(10) NOT NULL auto_increment,
		  cmid int(10) NOT NULL default '0',
		  userid int(10) NOT NULL default '0',
		  searchString varchar(6) NOT NULL default '',
		  archiveDate varchar(50) NOT NULL default '',
		  PRIMARY KEY  (id)
		  ) TYPE=MyISAM COMMENT='Holds simpleblog archives';");

        execute_sql(" CREATE TABLE ".$CFG->prefix."simpleblog_entries (
		  id int(10) unsigned NOT NULL auto_increment,
		  course int(10) unsigned NOT NULL default '0',
		  cmid int(10) NOT NULL default '0',
		  userid int(10) unsigned NOT NULL default '0',
		  title varchar(255) NOT NULL default '',
		  entry text NOT NULL,
		  date varchar(50) NOT NULL default '',
		  searchString varchar(6) NOT NULL default '',
		  discussionPost int(10) NOT NULL default '0',
		  PRIMARY KEY  (id),
		  KEY course (course)
		  ) TYPE=MyISAM COMMENT='Holds simpleblog entries';");

    }

   if ($oldversion < 2006022400) {
       execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `bloglevel` INT(2) NOT NULL DEFAULT '1' AFTER `commentforum`");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_archives` ADD `userid` INT(10) NOT NULL DEFAULT '0' AFTER `cmid`");
   }

   if ($oldversion < 2006031000) {
       execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_archives` CHANGE `user` `userid` INT( 10 ) NOT NULL DEFAULT '0'");
       execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` CHANGE `user` `userid` INT( 10 ) NOT NULL DEFAULT '0'");
   }

   if ($oldversion < 2007101200) {
   }

   if ($oldversion < 2007122100) {
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher1` CHAR(3) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher1edit` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher1others` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher2` CHAR(3) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher2edit` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `teacher2others` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `student1` CHAR(3) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `student1edit` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `student2` CHAR(3) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog` ADD `student2edit` CHAR(1) NOT NULL DEFAULT 'y'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `timemodified` BIGINT(10) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `usermodified` BIGINT(10) NOT NULL");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `note` TEXT");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `notemodified` BIGINT(10) NOT NULL DEFAULT '0'");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `noteid` BIGINT(10) NOT NULL");
	 execute_sql("ALTER TABLE `".$CFG->prefix."simpleblog_entries` ADD `imported` VARCHAR(1) NOT NULL DEFAULT 'n'");
   }

    return true;

}
?>