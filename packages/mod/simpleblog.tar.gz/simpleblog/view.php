<?php 

/// This page prints a particular instance of simpleblog

    require_once("../../config.php");
    require_once("lib.php");
    require_once("../../blog/lib.php");

    $view          = optional_param('view', '');       // Blog View Mode
    $searchString          = optional_param('searchString');       // Search String ID
    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    optional_variable($a);     // simpleblog ID
    $blogpage  = optional_param('blogpage', 0, PARAM_INT);
    $filtertype  = optional_param('filtertype', 0, PARAM_INT);
    $filterselect  = optional_param('filterselect', 0, PARAM_INT);

    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }
    
        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }
    
        if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
            error("Course module is incorrect");
        }

    } else {
        if (! $simpleblog = get_record("simpleblog", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $simpleblog->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("simpleblog", $simpleblog->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }

    require_course_login($course);


    add_to_log($course->id, "simpleblog", "view", "view.php?id=$cm->id", "$simpleblog->id");

/// Checks user level

$context = get_context_instance(CONTEXT_COURSE, $COURSE->id);

$levelSQL = get_record("role_assignments", "contextid", $context->id ."' AND userid = '".$USER->id);
$userBlogRole = $levelSQL->roleid;

$levelCheck = get_record("simpleblog", "id", $cm->instance);

if ($userBlogRole == $levelCheck->teacher1 OR $userBlogRole == $levelCheck->teacher2) {
$teacherCheck="y";
} else {
$teacherCheck="n";
}

if ($userBlogRole == $levelCheck->student1 OR $userBlogRole == $levelCheck->student2) {
$studentCheck="y";
} else {
$studentCheck="n";
}

/// Gets language strings

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");
    $strsimpleblog  = get_string("modulename", "simpleblog");
    $strnoarchives  = get_string("noarchives", "simpleblog");
    $strarchivetitle  = get_string("archivetitle", "simpleblog");
    $strnoblog  = get_string("noblog", "simpleblog");
    $strposted  = get_string("posted", "simpleblog");
    $strdate  = get_string("date", "simpleblog");
    $streditentry  = get_string("editentry", "simpleblog");
    $strbacktoblog  = get_string("backtoblog", "simpleblog");
    $strarchivefor  = get_string("archivefor", "simpleblog");
    $straddentry  = get_string("addentry", "simpleblog");
    $strviewcomments  = get_string("viewcomments", "simpleblog");
    $strviewteacherblog  = get_string("teacherblog", "simpleblog");
    $strviewstudentblog  = get_string("studentblog", "simpleblog");
    $strviewlastpost  = get_string("lastpost", "simpleblog");
    $strviewlastdate  = get_string("lastdate", "simpleblog");
    $strviewnoresult  = get_string("noresult", "simpleblog");
    $straddyours  = get_string("addyours", "simpleblog");
    $strblogauthor  = get_string("blogauthor", "simpleblog");
    $stronlyteachers  = get_string("onlyteachers", "simpleblog");
    $strexport  = get_string("export", "simpleblog");

/// Print the page header

    $navigation = "<a href=\"index.php?id=$course->id\">$strsimpleblogs</a> ->";
    print_header_simple(format_string($simpleblog->name), "",
                 "$navigation ".format_string($simpleblog->name), "", "", true, update_module_button($cm->id, $course->id, $strsimpleblog), navmenu($course, $cm));

/// Print the main part of the page

/// Checks to see if the blog is set-up for private student posts.  If so, prints the specific users blog only

/// ******** Start of Blog Level 4 ***********

if ($levelCheck->bloglevel == '4'){

/// If the user is a teacher, then it gives the user a list of blogs to view

if ($teacherCheck == 'y') {

?>

<div align="center"><h2><?php echo $simpleblog->name; ?></h2>
<?php echo "$simpleblog->intro<br /><br />"; ?>

<table cellpadding="2" cellspacing="2" border="0" width="80%" class="generaltable">

<?php
$student2SQL = "SELECT * FROM {$CFG->prefix}role_assignments WHERE (roleid = $levelCheck->student1 OR roleid = $levelCheck->student2) AND contextid = $context->id";
$students = get_records_sql($student2SQL);

if (!$students) { }
else {
foreach ($students as $student)
{
$studentprofile = get_record('user','id',$student->userid);
$lastentry = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '". $student->userid, "id DESC", '*', 0, 1);

if (!$lastentry)
{
$lastentrytitle = $strviewnoresult;
$lastentrydate = $strviewnoresult;
}
else
{
foreach ($lastentry as $lastentries)
{
$lastentrytitle = $lastentries->title;
$lastentrydate = $lastentries->date;
}
}
echo '<tr><td class="cell c0">';
print_user_picture($studentprofile->id, $course->id, $studentprofile->picture);
echo '&nbsp;&nbsp;<a href="viewStudent.php?id=' . $cm->id . '&bloguser=' . $studentprofile->id . '">' . $studentprofile->firstname . ' ' . $studentprofile->lastname . '</a></td>';
echo '<td class="cell c1">' . $lastentrytitle . '</td>';
echo '<td class="cell c2">' . $lastentrydate . '</td></tr>';
}
echo '</table></div>';
}
}
/// If not a teacher, then gives the user the opportunity to view and edit their blog

else
{

simpleblog_entry_list ($id, $levelCheck->bloglevel, $view, $cm, $searchString, $simpleblog, $blogpage, $filtertype, $filterselect);

/// ******** End of Blog Level 4 ***********

}
}

/// Checks to see if the blog allows students to post.  If so, prints a user list
/// ******** Start of Blog Level 3 ***********

elseif ($levelCheck->bloglevel == '3'){

/// Gives users a direct link to enter a post

echo '<div align="center">';
echo '<h2>' . $simpleblog->name . '</h2>';
echo $simpleblog->intro . '<br /><br />';

if ($teacherCheck == 'y' OR $studentCheck == 'y') {
echo '<a href="' . $CFG->wwwroot . '/mod/simpleblog/blogpost.php?id=' . $cm->id . '&bloguser=' . $USER->id . '">' . $straddyours . '</a><br /><br />';
}

/// Creates a list of teacher blogs

$teacher3SQL = "SELECT * FROM {$CFG->prefix}role_assignments WHERE (roleid = $levelCheck->teacher1 OR roleid = $levelCheck->teacher2) AND contextid = $context->id";
$teachers = get_records_sql($teacher3SQL);
$getRoleNameTeacher1 = get_record("role", "id", $levelCheck->teacher1);
$getRoleNameTeacher2 = get_record("role", "id", $levelCheck->teacher2);

$student3SQL = "SELECT * FROM {$CFG->prefix}role_assignments WHERE (roleid = $levelCheck->student1 OR roleid = $levelCheck->student2) AND contextid = $context->id";
$students = get_records_sql($student3SQL);
$getRoleNameStudent1 = get_record("role", "id", $levelCheck->student1);
$getRoleNameStudent2 = get_record("role", "id", $levelCheck->student2);

echo '<table cellpadding="2" cellspacing="2" border="0" width="80%" class="generaltable"><tr><th class="header c0" align="left">';
echo '<b>' . $getRoleNameTeacher1->name;
if ($levelCheck->teacher2 == '0') { } else {
echo ' &amp; ' . $getRoleNameTeacher2->name;
}
echo ' ' . $strviewteacherblog . ':</b></th>';
echo '<th class="header c1" align="left">' . $strviewlastpost . '</th><th class="header c2" align="left">' . $strviewlastdate . '</th></tr>';

if (!$teachers) { }
else {
foreach ($teachers as $teacher)
{
$profile = get_record('user','id',$teacher->userid);
$lastentry = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '". $teacher->userid, "id DESC", '*', 0, 1);

if (!$lastentry)
{
$lastentrytitle = $strviewnoresult;
$lastentrydate = $strviewnoresult;
}
else
{
foreach ($lastentry as $lastentries)
{
$lastentrytitle = $lastentries->title;
$lastentrydate = $lastentries->date;
}
}
echo '<tr><td class="cell c0">';
print_user_picture($profile->id, $course->id, $profile->picture);
echo '&nbsp;&nbsp;<a href="blog.php?id=' . $cm->id . '&bloguser=' . $profile->id . '">' . $profile->firstname . ' ' . $profile->lastname . '</a></td>';
echo '<td class="cell c1">' . $lastentrytitle . '</td>';
echo '<td class="cell c2">' . $lastentrydate . '</td></tr>';
}

echo '<tr><th class="header c0" align="left">';
echo '<b>' . $getRoleNameStudent1->name;
if ($levelCheck->student2 == '0') { } else {
echo ' &amp; ' . $getRoleNameStudent2->name;
}
echo ' ' . $strviewstudentblog . ':</b></th>';
echo '<th class="header c1" align="left">' . $strviewlastpost . '</th><th class="header c2" align="left">' . $strviewlastdate . '</th></tr>';
}

/// Creates a list of student blogs

if (!$students) { }
else {
foreach ($students as $student)
{
$studentprofile = get_record('user','id',$student->userid);
$lastentry = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '". $student->userid, "id DESC", '*', 0, 1);

if (!$lastentry)
{
$lastentrytitle = $strviewnoresult;
$lastentrydate = $strviewnoresult;
}
else
{
foreach ($lastentry as $lastentries)
{
$lastentrytitle = $lastentries->title;
$lastentrydate = $lastentries->date;
}
}
echo '<tr><td  class="cell c0">';
print_user_picture($studentprofile->id, $course->id, $studentprofile->picture);
echo '&nbsp;&nbsp;<a href="blog.php?id=' . $cm->id . '&bloguser=' . $studentprofile->id . '">' . $studentprofile->firstname . ' ' . $studentprofile->lastname . '</a></td>';
echo '<td class="cell c0">' . $lastentrytitle . '</td>';
echo '<td class="cell c0">' . $lastentrydate . '</td></tr>';
}
echo '</table></div>';
}

/// ******** End of Blog Level 3 ***********

}
else
{
/// If the blog is "teacher only" or community access, then just prints blog entries

/// ******** Blog Level 2 or 1 ***********

simpleblog_entry_list ($id, $levelCheck->bloglevel, $view, $cm, $searchString, $simpleblog, $blogpage, $filtertype, $filterselect);

}
/// ******** End of Blog Level 2 or 1 ***********

/// Finish the page
    print_footer($course);

?>