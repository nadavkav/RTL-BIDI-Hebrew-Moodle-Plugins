<?PHP

/// This page prints a particular instance of simpleblog


    require_once("../../config.php");
    require_once("lib.php");
    require_once("../../blog/lib.php");

    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $bloguser          = optional_param('bloguser', 0, PARAM_INT);       // Blog User ID
    $view          = optional_param('view', '');       // Blog View Mode
    $searchString          = optional_param('searchString');       // Search String ID
    optional_variable($a);     // simpleblog ID
    $blogpage  = optional_param('blogpage', 0, PARAM_INT);
    $filtertype  = optional_param('filtertype', 0, PARAM_INT);
    $filterselect  = optional_param('filterselect', 0, PARAM_INT);

    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }
    
        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }
    
        if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
            error("Course module is incorrect");
        }

    } else {
        if (! $simpleblog = get_record("simpleblog", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $simpleblog->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("simpleblog", $simpleblog->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }

    require_login($course->id);

    add_to_log($course->id, "simpleblog", "view", "view.php?id=$cm->id", "$simpleblog->id");

/// Checks blog level and gets language string

    $levelCheck = get_record("simpleblog", "id", $cm->instance);

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");

/// Print the page header

    $navigation = "<a href=\"index.php?id=$course->id\">$strsimpleblogs</a> ->";
    print_header_simple(format_string($simpleblog->name), "",
                 "$navigation ".format_string($simpleblog->name), "", "", true, $buttontext, navmenu($course, $cm));

/// Print the main part of the page

simpleblog_entry_list ($id, $levelCheck->bloglevel, $view, $cm, $searchString, $simpleblog, $blogpage, $filtertype, $filterselect, $bloguser);

/// Finish the page
    print_footer($course);

?>
