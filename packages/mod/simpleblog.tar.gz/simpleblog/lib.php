<?PHP 

/// Library of functions and constants for module simpleblog


$simpleblog_CONSTANT = 7;     /// for example


function simpleblog_add_instance($simpleblog) {
/// Given an object containing all the necessary data, 
/// (defined by the form in mod.html) this function 
/// will create a new instance and return the id number 
/// of the new instance.

    $simpleblog->timemodified = time();

  
    return insert_record("simpleblog", $simpleblog);
}


function simpleblog_update_instance($simpleblog) {
/// Given an object containing all the necessary data, 
/// (defined by the form in mod.html) this function 
/// will update an existing instance with new data.

    $simpleblog->timemodified = time();
    $simpleblog->id = $simpleblog->instance;

    # May have to add extra stuff in here #

    return update_record("simpleblog", $simpleblog);
}


function simpleblog_delete_instance($id) {
/// Given an ID of an instance of this module, 
/// this function will permanently delete the instance 
/// and any data that depends on it.  

    if (! $simpleblog = get_record("simpleblog", "id", "$id")) {
        return false;
    }

    $result = true;

    # Delete any dependent records here #

    if (! delete_records("simpleblog", "id", "$simpleblog->id")) {
        $result = false;
    }

    return $result;
}

function simpleblog_user_outline($course, $user, $mod, $simpleblog) {
/// Return a small object with summary information about what a 
/// user has done with a given particular instance of this module
/// Used for user activity reports.
/// $return->time = the time they did it
/// $return->info = a short text description

    return $return;
}

function simpleblog_user_complete($course, $user, $mod, $simpleblog) {
/// Print a detailed representation of what a  user has done with 
/// a given particular instance of this module, for user activity reports.

    return true;
}

function simpleblog_print_recent_activity($course, $isteacher, $timestart) {
/// Given a course and a time, this module should find recent activity 
/// that has occurred in simpleblog activities and print it out. 
/// Return true if there was output, or false is there was none.

    global $CFG;

    return false;  //  True if anything was printed, otherwise false 
}

function simpleblog_cron () {
/// Function to be run periodically according to the moodle cron
/// This function searches for things that need to be done, such 
/// as sending out mail, toggling flags etc ... 

    global $CFG;

    return true;
}

function simpleblog_grades($simpleblogid) {
/// Must return an array of grades for a given instance of this module, 
/// indexed by user.  It also returns a maximum allowed grade.
///
///    $return->grades = array of grades;
///    $return->maxgrade = maximum allowed grade;
///
///    return $return;

   return NULL;
}

function simpleblog_get_participants($simpleblogid) {
//Must return an array of user records (all data) who are participants
//for a given instance of simpleblog. Must include every user involved
//in the instance, independient of his role (student, teacher, admin...)
//See other modules as example.

    return false;
}

function simpleblog_scale_used ($simpleblogid,$scaleid) {
//This function returns if a scale is being used by one simpleblog
//it it has support for grading and scales. Commented code should be
//modified if necessary. See forum, glossary or journal modules
//as reference.
   
    $return = false;

    //$rec = get_record("simpleblog","id","$simpleblogid","scale","-$scaleid");
    //
    //if (!empty($rec)  && !empty($scaleid)) {
    //    $return = true;
    //}
   
    return $return;
}


function simpleblog_entry_list ($id, $blogLevel, $view, $cm, $searchString, $simpleblog, $blogpage, $filtertype, $filterselect, $bloguser) {
/// Prints out an actual list of the recent blog entries 
///

    global $CFG;
    global $USER;
    global $COURSE;

/// Gets user's role for the course

$context = get_context_instance(CONTEXT_COURSE, $COURSE->id);

$levelSQL = get_record("role_assignments", "contextid", $context->id ."' AND userid = '".$USER->id);
$userBlogRole = $levelSQL->roleid;


/// Set some defaults to start with
$teacherCheck="n";
$studentCheck="n";
$editOwn = "n";
$editOthers = "n";


/// Checks to see if the user is a teacher

$levelCheck = get_record("simpleblog", "id", $cm->instance);

if ($userBlogRole == $levelCheck->teacher1 OR $userBlogRole == $levelCheck->teacher2) {
$teacherCheck="y";
} else {
$teacherCheck="n";
}

/// Checks to see if the user is a teacher and can edit own posts

if ($teacherCheck == 'y') {
	if ($userBlogRole == $levelCheck->teacher1 && $levelCheck->teacher1edit == 'y') {
	$editOwn = "y";
	} else if ($userBlogRole == $levelCheck->teacher2 && $levelCheck->teacher2edit == 'y') {
	$editOwn = "y";
	} else {
	$editOwn = "n";
	}
}

/// Checks to see if the user is a teacher and can edit other's posts

if ($teacherCheck == 'y') {
	if ($userBlogRole == $levelCheck->teacher1 && $levelCheck->teacher1others == 'y') {
	$editOthers = "y";
	} else if ($userBlogRole == $levelCheck->teacher2 && $levelCheck->teacher2others == 'y') {
	$editOthers = "y";
	} else {
	$editOthers = "n";
	}
}


/// Checks to see if the user is a student

if ($userBlogRole == $levelCheck->student1 OR $userBlogRole == $levelCheck->student2) {
$studentCheck="y";
} else {
$studentCheck="n";
}


/// Checks to see if the user is a student and can edit own posts

if ($studentCheck == 'y') {
	if ($userBlogRole == $levelCheck->student1 && $levelCheck->student1edit == 'y') {
	$editOwn = "y";
	} else if ($userBlogRole == $levelCheck->student2 && $levelCheck->student2edit == 'y') {
	$editOwn = "y";
	} else {
	$editOwn = "n";
	}
}


/// Gets language scripts

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");
    $strsimpleblog  = get_string("modulename", "simpleblog");
    $strnoarchives  = get_string("noarchives", "simpleblog");
    $strarchivetitle  = get_string("archivetitle", "simpleblog");
    $strnoblog  = get_string("noblog", "simpleblog");
    $strposted  = get_string("posted", "simpleblog");
    $strdate  = get_string("date", "simpleblog");
    $streditentry  = get_string("editentry", "simpleblog");
    $strbacktoblog  = get_string("backtoblog", "simpleblog");
    $strarchivefor  = get_string("archivefor", "simpleblog");
    $straddentry  = get_string("addentry", "simpleblog");
    $strviewcomments  = get_string("viewcomments", "simpleblog");
    $strviewteacherblog  = get_string("teacherblog", "simpleblog");
    $strviewstudentblog  = get_string("studentblog", "simpleblog");
    $strviewlastpost  = get_string("lastpost", "simpleblog");
    $strviewlastdate  = get_string("lastdate", "simpleblog");
    $strviewnoresult  = get_string("noresult", "simpleblog");
    $straddyours  = get_string("addyours", "simpleblog");
    $strbacktolist  = get_string("backtolist", "simpleblog");
    $strblogauthor  = get_string("blogauthor", "simpleblog");
    $stronlyteachers  = get_string("onlyteachers", "simpleblog");
    $strexport  = get_string("export", "simpleblog");
    $strlastedit  = get_string("lastedit", "simpleblog");
    $strby = get_string("by", "simpleblog");
    $straddnote = get_string("addnote", "simpleblog");
    $strnoteadded = get_string("noteadded", "simpleblog");
    $strblogoptions = get_string("blogoptions", "simpleblog");
    $strimportblog = get_string("importblog", "simpleblog");
    $strwasimported = get_string("wasimported", "simpleblog");

/// Gets Author's Name for level 3 or 4 blogs

if ($blogLevel == '4'){
	if (!$bloguser) {
		$bloguser = $USER->id;
	}
	$username = get_record('user','id',$bloguser);
	$name= "$username->firstname $username->lastname";
	echo '<div align="center"><h2>' . $strblogauthor . ': ' . $name . ' &nbsp;|&nbsp; ' . $stronlyteachers . '</h2></div>';
}

if ($blogLevel == '3'){
	$username = get_record('user','id',$bloguser);
	$name= "$username->firstname $username->lastname";
	echo '<div align="center"><h2>' . $strblogauthor . ': ' . $name . ' &nbsp;|&nbsp; <a href="view.php?id=' . $id . '">' . $strbacktolist . '</a></h2></div>';
}


echo '<br /><table cellpadding="0" cellspacing="2" border="0" width="100%"><tr><td valign="top">';

if (!isset($view)) {
    $view = '';
}

/// author check for level 3 or 4 blogs

if ($blogLevel == '4' or $blogLevel == '3'){
	if ($bloguser == $USER->id) {
	$isLevelAuthorCheck = 'y';
	} else {
	$isLevelAuthorCheck = 'n';
	}
}

/// If the user is viewing an archive, the blog uses this search and the user sees this

IF ($view == 'archive')

{

$title = get_record('simpleblog_archives', 'cmid', $cm->id, 'searchString', $searchString);

if ($blogLevel == '4' or $blogLevel == '3') {
	echo '<h2 class="headingblock header ">' . $strarchivefor . ' ' . $title->archiveDate . '</b></h2><br /><span class="author">&nbsp;&nbsp;[ <a href="' . $_SERVER['PHP_SELF'] . '?id='.$id.'&amp;bloguser=' . $bloguser . '">' . $strbacktoblog . '</a> ]</span>';
	$blogs = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '".$bloguser."' AND searchString = '". $searchString, "id DESC");
} else {
	echo '<h2 class="headingblock header ">' . $strarchivefor . ' ' . $title->archiveDate . '</b></h2><br /><span class="author">&nbsp;&nbsp;[ <a href="' . $_SERVER['PHP_SELF'] . '?id='.$id.'">' . $strbacktoblog . '</a> ]</span>';
	$blogs = get_records("simpleblog_entries", "cmid", $cm->id ."' AND searchString = '". $searchString, "id DESC");
}

}

ELSE

{


/// If not archive view, then searches for most recent posts

if ($blogLevel == '4' or $blogLevel == '3') {
	if ($simpleblog->menuvisible == "99") {
	$blogs = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '".$bloguser, 'id DESC'); 
	} else {
	$start = $blogpage * $simpleblog->menuvisible;
	$blogs = get_records("simpleblog_entries", "cmid", $cm->id ."' AND userid = '".$bloguser, 'id DESC', '*', $start, $simpleblog->menuvisible);
	}
} else {
	if ($simpleblog->menuvisible == "99") {
	$blogs = get_records("simpleblog_entries", 'cmid', $cm->id, 'id DESC'); 
	} else {
	$start = $blogpage * $simpleblog->menuvisible;
	$blogs = get_records("simpleblog_entries", 'cmid', $cm->id, 'id DESC LIMIT ' .$start. ','  .$simpleblog->menuvisible); 
	}
}

}

if (!$blogs) {

echo $strnoblog;

}

ELSE

{


/// paging bar
if ($blogLevel == '4' or $blogLevel == '3') {
	IF ($view == 'archive') { } else {
	   $blogcount = get_records("simpleblog_entries", 'cmid', $cm->id ."' AND userid = '".$bloguser); 
         $totalentries = count($blogcount);
         print_paging_bar($totalentries, $blogpage, $simpleblog->menuvisible, get_baseurl($filtertype, $filterselect), 'blogpage');
	}
} else {
	IF ($view == 'archive') { } else {
	   $blogcount = get_records("simpleblog_entries", 'cmid', $cm->id); 
         $totalentries = count($blogcount);
         print_paging_bar($totalentries, $blogpage, $simpleblog->menuvisible, get_baseurl($filtertype, $filterselect), 'blogpage');
	}
}

foreach ($blogs as $blog) {


/// Gets author name for each post for blog level 1 or 2

if ($blogLevel == '1' or $blogLevel == '2'){
	$username = get_record('user','id',$blog->userid);
	$name= "$username->firstname $username->lastname";
}


/// checks to see if current user is the author

if ($blogLevel == '1' or $blogLevel == '2'){
	if ($blog->userid == $USER->id) {
	$isAuthorCheck = 'y';
	} else {
	$isAuthorCheck = 'n';
	}
}

/// Prints the blog entry

echo '<table cellspacing="0" class="forumpost" width="100%"><tr class="header starter"><td class="picture left">';
print_user_picture($username->id, $course->id, $username->picture);
echo '</td><td class="topic"><div class="subject"> ' . $blog->title;


/// Blog post info and content is printed

echo '<div class="author">' . $strposted . ' <a href="../../user/view.php?id=' . $USER->id . '&course=' . $cm->id . '">' . $name . '</a> - ' . $blog->date .'</div>';
echo '</td></tr><tr><td class="left side">&nbsp;</td><td class="content">';
if ($blog->timemodified == '0') { } else {
	$lastEdited = userdate($blog->timemodified, $format='', $timezone=99, $fixday = true);
	$editname = get_record('user','id',$blog->usermodified);
	$editorname = "$editname->firstname $editname->lastname";
	echo '<div class="commands" style="padding: 0px;"><i>' . $strlastedit . ' ' . $lastEdited . ' ' . $strby . ' ' . $editorname . '</i></div>';
		if ($blog->imported == 'n') { echo '<br />'; } 
}
if ($blog->imported == 'y') {
	echo '<div class="commands" style="padding: 0px;"><i>' . $strwasimported . '</i></div><br />';
}
echo $blog->entry;


/// Notes section

if ($isAuthorCheck == 'y' OR $teacherCheck == 'y' OR $isLevelAuthorCheck == 'y') {
	if ($blog->notemodified == '0') { } else {
		$noteEdited = userdate($blog->notemodified, $format='', $timezone=99, $fixday = true);
		$notename = get_record('user','id',$blog->noteid);
		$notername = "$notename->firstname $notename->lastname";
		echo '<hr style="margin-top:10px;" /><table><tr><td valign="top">';
		print_user_picture($notename->id, $course->id, $notename->picture);
		echo '</td><td>&nbsp;</td><td valign="top"><div class="commands" style="padding: 0px; text-align:left"><b>' . $strnoteadded . ' ' . $noteEdited . ' ' . $strby . ' ' . $notername . ':</b><br />' . $blog->note . '</div></td></tr></table>';
	}
}


/// Action bar

if ($blog->discussionPost == '0' AND $editOthers == 'n' AND $isAuthorCheck == 'n' AND $teacherCheck == 'n') { } else {
	echo '<hr style="margin-top:10px;" /><div class="commands" style="text-align:left; padding:0px;">';
}

/// Gives blog author or teacher option of edit post, if settings allow

if ($teacherCheck == 'y') {
	if ($editOthers == 'y') {
	echo '<a href="edit.php?id='.$cm->id.'&blogID='.$blog->id.'">'.$streditentry.'</a>&nbsp;|&nbsp; ';
	}
}
if ($teacherCheck == 'y' AND $editOthers == 'n') {
	if ($editOwn == 'y' AND $isAuthorCheck == 'y') {
	echo '<a href="edit.php?id='.$cm->id.'&blogID='.$blog->id.'">'.$streditentry.'</a>&nbsp;|&nbsp; ';
	}
}
if ($studentCheck == 'y') {
	if ($editOwn == 'y' AND $isAuthorCheck == 'y') {
	echo '<a href="edit.php?id='.$cm->id.'&blogID='.$blog->id.'">'.$streditentry.'</a>&nbsp;|&nbsp; ';
	}
}


/// Gives user the option of exporting entry to Moodle blog

if ($isAuthorCheck == 'y') {
echo '<a href="export.php?id=' . $COURSE->id . '&blogid=' . $id . '&postid='.$blog->id.'">' . $strexport . '</a> &nbsp;|&nbsp; ';
}


/// Gives teacher the option of adding a note

if ($teacherCheck == 'y') {
echo '<a href="note.php?id='.$cm->id.'&blogID='.$blog->id.'">'.$straddnote.'</a> &nbsp;|&nbsp; ';
}


echo '</div>';


/// comments bar

echo '<div class="commands">';

if ($blog->discussionPost == '0') {}

else {

$commentCount = count_records("forum_posts", "discussion", $blog-> discussionPost);
$trueCount = $commentCount - 1;

if ($trueCount == 1) {
     $strcommentname  = get_string("comment", "simpleblog");
}
else {
    $strcommentname  = get_string("comments", "simpleblog");
}

echo $trueCount . ' ' . $strcommentname . ' &nbsp;|&nbsp; <a href="../forum/discuss.php?d=' . $blog->discussionPost . '">' . $strviewcomments . '</a>';
}

echo '</div></td></tr></table>';

} 
}


/// paging bar
IF ($view == 'archive') { } else {
	print_paging_bar($totalentries, $blogpage, $simpleblog->menuvisible, get_baseurl($filtertype, $filterselect), 'blogpage');
}


/// BEGIN SIDEBAR

echo '</td><td width="6"></td><td valign="top" style="padding-top:14px; width: 210px;">';


/// About the blog block

echo '<div><div class="block_about_courseblog sideblock"><div class="header"><div class="title"><h2>' . $simpleblog->name . '</h2></div></div>';
echo '<div class="content">' . $simpleblog->intro . '</div></div>';

/// Add new entry block

/// Gives teachers a button to enter a blog entry for blog level 1 or 2

$showEditBlock = "n";

if ($blogLevel == '1' or $blogLevel == '2') {
	if ($teacherCheck == 'y') {
	$showEditBlock = "y";
	}
}
if ($blogLevel == '2') {
	if ($studentCheck == 'y') {
	$showEditBlock = "y";
	}
}
if ($blogLevel == '4' or $blogLevel == '3') {
	if ($isAuthorCheck == 'y' or $isLevelAuthorCheck == 'y') {
	$showEditBlock = "y";
	}
}

/// Show the block

if ($showEditBlock == 'y') {
	echo '<div><div class="block_about_courseblog sideblock"><div class="header"><div class="title"><h2>' . $strblogoptions . '</h2></div></div>';
	echo '<div class="content">';
	echo '<a href="' . $CFG->wwwroot . '/mod/simpleblog/post.php?id=' . $cm->id . '">' . $straddentry . '</a><br />';
	echo '<a href="' . $CFG->wwwroot . '/mod/simpleblog/import.php?id=' . $cm->id . '">' . $strimportblog . '</a><br />';
	echo '</div></div>';
}


/// Prints archives table
echo '<div><div class="block_about_courseblog sideblock"><div class="header"><div class="title"><h2>' . $strarchivetitle . '</h2></div></div>';
echo '<div class="content">';

if ($blogLevel == '4' or $blogLevel == '3') {
	if ($archives = get_records("simpleblog_archives", "cmid", $cm->id ."' AND userid = '".$bloguser, 'id DESC')) {
	foreach ($archives as $arc) {
		echo '<a href="' . $_SERVER['PHP_SELF'] . '?id=' .$id. '&amp;bloguser=' . $bloguser . '&amp;view=archive&amp;searchString=' . $arc->searchString . '">' . $arc->archiveDate . '</a> <br />';
	}
	} else {
	echo $strnoarchives;
	}
} else {
	if ($archives = get_records("simpleblog_archives", 'cmid', $cm->id, 'id DESC')) {
	foreach ($archives as $arc) {
		echo '<a href="' . $_SERVER['PHP_SELF'] . '?id=' .$id. '&amp;view=archive&amp;searchString=' . $arc->searchString . '">' . $arc->archiveDate . '</a> <br />';
	}
	} else {
	echo $strnoarchives;
	}
}
echo '</div></div>';

/// End of the blog area of the page

echo '</td></tr></table>';

return;
}
?>
