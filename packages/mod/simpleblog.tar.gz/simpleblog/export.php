<?PHP // $Id: index.php,v 1.1 2003/09/30 02:45:19 moodler Exp $

/// This page lists all the instances of simpleblog in a particular course

    require_once("../../config.php");
    require_once("lib.php");

    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $blogid      = optional_param('blogid', 0, PARAM_INT);       // Blog ID
    $postid      = optional_param('postid', 0, PARAM_INT);       // Blog entry ID

    if (! $course = get_record("course", "id", $id)) {
        error("Course ID is incorrect");
    }

    require_login($course->id);


/// Get all required strings

    $strsimpleblogs = get_string("modulenameplural", "simpleblog");
    $strsimpleblog  = get_string("modulename", "simpleblog");
    $strexportconfirm  = get_string("exportconfirm", "simpleblog");
    $strexportheader  = get_string("exportheader", "simpleblog");
    $strexportreturn  = get_string("exportreturn", "simpleblog");
    $strexportmoodleblog  = get_string("exportmoodleblog", "simpleblog");

/// Print the header

    print_header_simple(format_string($strexportheader), "",
                 "$navigation ".format_string($strexportheader), "", "", true, $buttontext, navmenu($course, $cm));

/// export the appropriate data to Moodle blog

$blogs = get_record("simpleblog_entries", 'id', $postid); 

    $post->subject = $blogs->title;
    $post->summary = addslashes($blogs->entry);
    $post->publishstate = 'draft';
    $post->module = 'blog';
    $post->userid = $USER->id;
    $post->lastmodified = time();
    $post->created = time();

    if (! $post->id = insert_record("post", $post) ) {
                error("Could not export to Moodle blog");
    } else {
	echo "<div align='center'><br /><br />$strexportconfirm<br /><br />";
	echo '<a href="view.php?id=' . $blogid . '">' . $strexportreturn . '</a><br /><br />';
	echo '<a href="../../blog/index.php?userid=' . $USER->id . '&courseid=' . $id . '">' . $strexportmoodleblog . '</a></div>';
    }


/// Finish the page

    print_footer($course);

?>
