<?php // $Id

    require_once("../../config.php");
    require_once("lib.php");
    $id          = optional_param('id', 0, PARAM_INT);       // Course Module ID
    $bloguser          = optional_param('bloguser', 0, PARAM_INT);       // Blog User ID
    $title          = optional_param('title', 0);       // Blog Entry Title
    $entry          = optional_param('entry', 0);       // Blog Entry
    $createpost          = optional_param('createpost', 'no');       // Create comments variable
    $discussion          = optional_param('discussion', 0, PARAM_INT);       // Discussion ID for comments

    if (! $cm = get_record("course_modules", "id", $id)) {
        error("Course Module ID was incorrect");
    }

    if (! $course = get_record("course", "id", $cm->course)) {
        error("Course is misconfigured");
    }

    require_login($course->id, false, $cm);

    if (isguest()) {
        error("Guests are not allowed to edit blogs", $_SERVER["HTTP_REFERER"]);
    }

/// Checks permissions for blog editing based on blog level

    $levelCheck = get_record("simpleblog", "id", $cm->instance);

	if ($bloguser == $USER->id) {
	}
	else {
        error("You are not allowed to edit this blog");
	}

    if (!isteacher($course->id)) {
	if (!isstudent($course->id)) {
        error("You are not allowed to edit this blog");
    }
	}

    if (! $simpleblog = get_record("simpleblog", "id", $cm->instance)) {
        error("Course module is incorrect");
    }

/// If data submitted, then process and store.

    if ($form = data_submitted()) {

if ($createpost == 'no') {
	$discussions->id = '0';
}

/// creates variables for comments section, if selected

if ($createpost == 'yes') {

$strblogmessage = get_string("blogmessage", "simpleblog");
$strblogclick = get_string("blogclick", "simpleblog");

$username = get_record('user','id',$bloguser);
$name= "$username->firstname $username->lastname";

$blogmessage = $strblogmessage . ' <br /><br /><a href="../simpleblog/blog.php?id=' . $cm->id . '&bloguser=' . $USER->id . '">' . $strblogclick . '</a>';

    GLOBAL $USER, $CFG;

    $timenow = time();

    // Post information for comments forum 

    $post->discussion  = 0;
    $post->parent      = 0;
    $post->userid      = $USER->id;
    $post->created     = $timenow;
    $post->modified    = $timenow;
    $post->mailed      = 0;
    $post->attachment  = "";
    $post->subject     = $form->title;
    $post->message     = $blogmessage;
    $post->forum       = $form->discussion;
    $post->course      = $course->id;
    $post->format      = '1';

    if (! $post->id = insert_record("forum_posts", $post) ) {
                error("Could not insert a new post");
    }
 
    // Now do the main entry for the comments discussion,
    // linking to this first post

    $discussions->course = $course->id;
    $discussions->forum = $form->discussion;
    $discussions->name = "$name: $form->title";
    $discussions->firstpost    = $post->id;
    $discussions->userid = $USER->id;
    $discussions->groupid = '-1';
    $discussions->assessed = '1';
    $discussions->timemodified = $timenow;
    $discussions->usermodified = $post->userid;

    if (! $discussions->id = insert_record("forum_discussions", $discussions) ) {
               error("Could not insert a new discussion");
    }

    $updatepath->id = $post->id;
    $updatepath->discussion = $discussions->id;

    if (! update_record ("forum_posts", $updatepath) ) {
               error("Could not set ID");
    }

}

/// Set variables for blog post and create entry

        $timenow = time();
		$entryDate=date("F j, Y (g:i a)");
		$searchString=date("Ym");
                $archiveDate=date("F Y");

        if ($entry) {

			$newentry->course = $course->id;
            $newentry->cmid = $cm->id;
			$newentry->userid = $USER->id;
			$newentry->title = $form->title;
            $newentry->entry = $form->entry;
            $newentry->date = $entryDate;
            $newentry->searchString = $searchString;
            $newentry->discussionPost = $discussions->id;
            //print_r($newentry);
            //exit;
            if (! $newentry->cmid = insert_record("simpleblog_entries", $newentry)) {
                error("Could not insert a new blog entry");
            }

$entryArchive = get_record('simpleblog_archives', 'cmid',$cm->id, 'userid',$USER->id,'searchString',$searchString);

/// Searches for archive for this month's post.  If none, creates one.

if (!$entryArchive){
            $newarchive->cmid = $cm->id;
            $newarchive->searchString = $searchString;
            $newarchive->archiveDate = $archiveDate;
			$newarchive->userid = $USER->id;
            if (!$archiveEntry =  insert_record('simpleblog_archives', $newarchive)) {
                error("Could not insert a new archive");
            }

}
            add_to_log($course->id, "simpleblog", "add entry", "view.php?id=$cm->id", "$newentry->id", $cm->id);
        }

        redirect("blog.php?id=$cm->id&bloguser=$bloguser");
        die;
    }

/// Otherwise fill and print the form.

    $strblog = get_string("modulename", "simpleblog");
    $strblogs = get_string("modulenameplural", "simpleblog");
    $stredit = get_string("blogcrumb", "simpleblog");
    if ($usehtmleditor = can_use_richtext_editor()) {
        $defaultformat = FORMAT_HTML;
    } else {
        $defaultformat = FORMAT_MOODLE;
    }

    if (empty($entry)) {
        $entry->entry = "";
        $entry->format = $defaultformat;
    }

$getDiscussion1 = get_record('course_modules','id',$id);
$sendNext = $getDiscussion1->instance;

$getDiscussion2 = get_record('simpleblog','id',$sendNext);
$discussionID = $getDiscussion2->commentforum;

    print_header_simple(format_string($simpleblog->name), "",
                 "<a href=\"index.php?id=$course->id\">$strblogs</a> ->
                  <a href=\"view.php?id=$cm->id\">".format_string($simpleblog->name,true)."</a> -> $stredit", "",
                  "", true, "", navmenu($course, $cm));

    echo "<center>\n";

    echo "<br />";

    include("blogpost.html");

    if ($usehtmleditor) {
        use_html_editor("entry");
    }

    print_footer($course);

?>
