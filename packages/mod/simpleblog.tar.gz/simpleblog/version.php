<?PHP // 

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of simpleblog
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007122100;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
