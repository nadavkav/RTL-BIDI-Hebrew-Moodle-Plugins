<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:03 skodak Exp $ 
      // book.php - created with Moodle 1.4.4 (2004083140)


$string['addafter'] = 'Дадаць  новы раздзел';
$string['chapterscount'] = 'Раздзелы';
$string['chaptertitle'] = 'Назва раздзела';
$string['confchapterdelete'] = 'Вы сапраўды жадаеце выдаліць гэты раздзел?';
$string['confchapterdeleteall'] = 'Ці сапраўды Вы жадаеце выдаліць гэты раздзел і ўсе параграфы?';
$string['content'] = 'Змест';
$string['customtitles'] = 'Прыватныя назвы';
$string['disableprinting'] = 'Забараніць друкаванне';
$string['doimport'] = 'Імпарт';
$string['editingchapter'] = 'Рэдагаваць радзел';
$string['faq'] = 'FAQ па падручніку';
$string['fileordir'] = 'Файл або тэчка';
$string['import'] = 'Імпарт';
$string['importinfo'] = 'Імпартаваць вылучаны HTML файл або тэчку. <br /> Раздзелы адсартуюцца па алфавіту па назве файлаў.';
$string['importing'] = 'Імпартаванне';
$string['importingchapters'] = 'Імпартаванне радзелаў у кнігу';
$string['maindirectory'] = 'Галоўная тэчка';
$string['modulename'] = 'Падручнік';
$string['modulenameplural'] = 'Падручнікі';
$string['navexit'] = 'Выйсці з падручніка';
$string['navnext'] = 'Далей';
$string['navprev'] = 'Назад';
$string['numbering'] = 'Нумарацыя раздзела';
$string['numbering0'] = 'Няма';
$string['numbering1'] = 'Нумары';
$string['numbering2'] = 'Маркеры';
$string['numbering3'] = 'Павялічыць водступ';
$string['printbook'] = 'Друкаваць увесь падручнік';
$string['printchapter'] = 'Друкаваць раздзел';
$string['printdate'] = 'Дата';
$string['printedby'] = 'Надрукаваны';
$string['relinking'] = 'Перакампанаваць';
$string['subchapter'] = 'Параграф';
$string['toc'] = 'Змест';
$string['tocwidth'] = 'Вызначыць шырыню зместу для ўсіх падручнікаў';
$string['top'] = 'наверх';

?>
