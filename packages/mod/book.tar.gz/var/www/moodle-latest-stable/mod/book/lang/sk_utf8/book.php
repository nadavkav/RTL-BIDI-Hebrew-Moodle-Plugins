<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:00 skodak Exp $ 
      // book.php - created with Moodle 1.3.3 + (2004052503)


$string['addafter'] = 'Pridať novú kapitolu';
$string['chapterscount'] = 'Počet kapitol';
$string['chaptertitle'] = 'Nadpis';
$string['confchapterdelete'] = 'Naozaj chcete odstrániť túto kapitolu?';
$string['confchapterdeleteall'] = 'Naozaj chcete odstrániť túto kapitolu včítane podkapitol?';
$string['content'] = 'Text';
$string['customtitles'] = 'Užívateľské nadpisy';
$string['disableprinting'] = 'Zakázať tlač';
$string['doimport'] = 'Importovať';
$string['editingchapter'] = 'Úprava kapitoly';
$string['faq'] = 'Časté otázky';
$string['fileordir'] = 'Súbor alebo adresár';
$string['import'] = 'Import';
$string['importinfo'] = 'Importovat HTML súbor alebo všetky súbory v zadanej zložke.<br />Kapitoly budú striedené abecedne podľa názvov súborov.';
$string['importing'] = 'Importujej';
$string['importingchapters'] = 'Importovanie kapitol';
$string['maindirectory'] = 'Hlavná zložka';
$string['modulename'] = 'Kniha';
$string['modulenameplural'] = 'Knihy';
$string['navnext'] = 'Následujúci';
$string['navprev'] = 'Predchádzajúci';
$string['navexit'] = 'Späť na prehľad';
$string['numbering'] = 'Číslovanie kapitol';
$string['numbering0'] = 'Žiadne';
$string['numbering1'] = 'Čísla';
$string['numbering2'] = 'Odrážky';
$string['numbering3'] = 'Odsadené';
$string['printbook'] = 'Vytlačiť celú knihu';
$string['printchapter'] = 'Vytlačiť jednu kapitolu';
$string['printdate'] = 'Dátum';
$string['printedby'] = 'Vytlačil(a)';
$string['relinking'] = 'Relinkujem';
$string['subchapter'] = 'Podkapitola';
$string['toc'] = 'Obsah';
$string['tocwidth'] = 'Vyberte šírku obsahu pre všetky knihy.';
$string['top'] = 'začiatok';

?>
