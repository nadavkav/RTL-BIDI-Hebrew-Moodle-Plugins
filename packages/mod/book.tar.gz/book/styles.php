/* $Id: styles.php,v 1.1.2.2 2008/08/13 23:22:32 skodak Exp $*/
/* later should be defined in themes*/


.book_chapter_title {
    font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif;
    text-align: left;
    font-size: large;
    font-weight: bold;

    margin-left: 0px;
    margin-bottom: 20px;
}

.book_content {
    text-align: left;
}

img.bigicon {
  vertical-align:middle;
  margin-right:4px;
  margin-left:4px;
  width:24px;
  height:24px;
  border:0px;
}

#mod-book-view table.booktable {
    border:0;
}

#mod-book-view .bookexport {
    float:left;
}

#mod-book-view .booknav {
    float:right;
}

#mod-book-view table.booktable tr.tocandchapter {
    vertical-align:text-top;
}

#mod-book-view div.faq {
  font-size: 0.7em;
}
 
/* == TOC styles == */

/* toc style NONE */
.book_toc_none {
  font-size: 0.8em;
}
.book_toc_none ul {
    margin-left: 5px;
    padding-left: 0px;
}
.book_toc_none ul ul {
    margin-left: 0px;
    padding-left: 0px;
}
.book_toc_none li {
    margin-top: 5px;
    list-style: none;
}
.book_toc_none li li {
    margin-top: 0px;
    list-style: none;
}


/* toc style NUMBERED */
.book_toc_numbered {
  font-size: 0.8em;
}
.book_toc_numbered ul {
    margin-left: 5px;
    padding-left: 0px;
}
.book_toc_numbered ul ul {
    margin-left: 0px;
    padding-left: 0px;
}
.book_toc_numbered li {
    margin-top: 5px;
    list-style: none;
}
.book_toc_numbered li li {
    margin-top: 0px;
    list-style: none;
}


/*toc style BULLETS */
.book_toc_bullets {
  font-size: 0.8em;
}
.book_toc_bullets ul {
    margin-left: 5px;
    padding-left: 0px;
}
.book_toc_bullets ul ul {
    margin-left: 20px;
    padding-left: 0px;
}
.book_toc_bullets li {
    margin-top: 5px;
    list-style: none;
}
.book_toc_bullets li li {
    margin-top: 0px;
    list-style: circle;
}


/* toc style INDENTED*/
.book_toc_indented {
  font-size: 0.8em;
}
.book_toc_indented ul {
    margin-left: 5px;
    padding-left: 0px;
}
.book_toc_indented ul ul {
    margin-left: 15px;
    padding-left: 0px;
}
.book_toc_indented li {
    margin-top: 5px;
    list-style: none;
}
.book_toc_indented li li {
    margin-top: 0px;
    list-style: none;
}

<?php
if (right_to_left()) { 
?>
.book_toc_bullets ul, .book_toc_indented ul ,.book_toc_numbered ul ,.book_toc_none ul {
padding-left:0px ;
padding-right:7px ;
text-align:right ;
}
.book_content {
text-align:right;
}
.book_chapter_title {
text-align:right;
}
<?php
}
?>