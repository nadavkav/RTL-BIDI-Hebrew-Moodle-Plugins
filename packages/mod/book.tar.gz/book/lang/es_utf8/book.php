<?PHP // $Id: book.php,v 1.1 2006/03/12 18:40:03 skodak Exp $
      // book.php - created with Moodle 1.3 (2004052500)
      // book.php - Translated to Spanish by Juan Luis Martinez from Dominican Republic (fernluichi@hotmail.com)

$string['addafter'] = 'Agregar un nuevo Cápitulo';
$string['chapterscount'] = 'Cápitulos';
$string['chaptertitle'] = 'Título del Cápitulo';
$string['confchapterdelete'] = 'En Realidad Desea Eliminar este Cápitulo?';
$string['content'] = 'Contenido';
$string['faq'] = 'Libro FAQ';
$string['hidepreview'] = 'Atrás para Modo Edición';
$string['modulename'] = 'Libro';
$string['modulenameplural'] = 'Libros';
$string['navexit'] = 'Salir del Libro';
$string['navnext'] = 'Siguiente';
$string['navprev'] = 'Anterior';
$string['numbering'] = 'Número del Cápitulo';
$string['numbering0'] = 'Nada';
$string['numbering1'] = 'Númerica';
$string['numbering2'] = 'Viñetas';
$string['numbering3'] = 'Indentidad';
$string['printbook'] = 'Imprimir el Libro Completo';
$string['printchapter'] = 'Imprimir este Cápitulo';
$string['printdate'] = 'Día';
$string['printedby'] = 'Imprimido por';
$string['showpreview'] = 'Mostrar TOC Preliminar';
$string['subchapter'] = 'Subcápitulo';
$string['toc'] = 'Tabla de Contenido';
$string['tocwidth'] = 'Seleciona el Ancho de la Tabla de Contenidos de Todos los Libros.';
$string['top'] = 'arriba';

?>
