<?PHP // $Id: version.php,v 1.5.2.5 2009/02/28 19:20:15 dlnsk Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of attforblock
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2009022800;  // The current module version (Date: YYYYMMDDXX)
$module->release = '2.1.1';
$module->cron     = 0;           // Period for cron to check this module (secs)
?>
