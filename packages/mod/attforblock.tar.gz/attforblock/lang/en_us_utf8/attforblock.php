<?PHP // $Id: attforblock.php,v 1.1.2.2 2009/02/23 19:22:46 dlnsk Exp $
// block_attendance.php - created with Moodle 1.5.3+ (2005060230)


$string['strftimedm'] = '%%m.%%d';
$string['strftimedmy'] = '%%m.%%d.%%Y';
$string['strftimedmyw'] = '%%m.%%d.%%y&nbsp;(%%a)';
$string['strftimeshortdate'] = '%%m.%%d.%%Y';

?>