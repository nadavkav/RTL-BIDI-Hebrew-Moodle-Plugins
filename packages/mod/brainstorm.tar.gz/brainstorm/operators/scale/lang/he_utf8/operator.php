<?php

$string['absolute'] = 'סדר מוחלט';
$string['absoluteconstraint'] = 'יש לסדר את המדד באופן כולל ומדוייק. אין אפשרות להשתמש בערך זה שוב.';
$string['allevaluated'] = 'כל הרעיונות הוערכו';
$string['barwidth'] = 'רוחב עמודה';
$string['clearall'] = 'מחיקת כל המידע';
$string['givingweightstoideas'] = 'הגדרת משקלים לרעיונות';
$string['moodlescale'] = 'מדרגות־הערכה מערכתיים';
$string['myscaling'] = 'מדרגות־הערכה שלי';
$string['nootherscalings'] = 'לא זמינות מדרגות־הערכה נוספות ממשתמשים אחרים';
$string['noscalings'] = 'נתוני מדרגות־הערכה לא זמינים';
$string['otherscales'] = 'מדרגות־הערכה של משתמשים אחרים';
$string['parallelquantify'] = 'הערכה מקבילה';
$string['quantifiertype'] = 'סוג מדד כמותי';
$string['randomquantify'] = 'מדד כמותי אקראי';
$string['savescaling'] = 'שמירת מדרגות־הערכה';
$string['scale'] = 'מדד';
$string['scalesettings'] = 'הגדרות מאפייני \"מדד\"';
$string['unscaled'] = 'רעיונות אשר טרם הוערכו';
?>