<?php

$string['absolute'] = 'סידור מוחלט';
$string['agreewithyou'] = '$a מסכים אתך';
$string['agreewithyousingle'] = '$a מסכים אתך';
$string['checkpreference'] = 'בדקו את העדפותיכם (ציון גבוה) ';
$string['comparisons'] = ' מתאים לאישור ';
$string['confirmpaircompare'] = 'אזהרה, סידור זה יסיר את הסדר הקיים. האם להמשיך ?';
$string['finished'] = 'שקלתם את כל הצמדים. הסידור הסופי שקבלתם הוא :';
$string['myordering'] = 'הסידור שלי';
$string['noorderset'] = 'לא נבחר סידור עדיין';
$string['noresponses'] = 'אין תגובות לסידור';
$string['order'] = 'סידור';
$string['ordersettings'] = 'הגדרות משתנים של \"סידור\"';
$string['original'] = 'מקורי (סידור על פי זמנים)';
$string['paircompare'] = 'תהליך סידור לפי סידור על פי זוגות';
$string['pickandswapordering'] = 'בחירה והחלפה';
$string['puttingideasinorder'] = 'מיקום רעיונות לפי סדר';
$string['rank'] = 'ציון';
$string['remains'] = 'נשאר ';
$string['reordering...'] = 'סידור מחדש לתצוגה סופית... הסתיים.';
$string['response'] = 'תגובה';
$string['resume'] = 'עצרו את התהליך עכשיו ';
$string['saveorder'] = 'שמרו את הסדר';
$string['startpaircompare'] = 'התחילו לסדר על ידי השוואת זוגות';

?>