<?php

$string['addcategory'] = 'Add a category';
$string['agreewithyou'] = '$a inputs agree with you';
$string['agreewithyousingle'] = '$a input agrees with you';
$string['allowmultiple'] = 'Allow multiple categry indexing ';
$string['blindness'] = 'User isolation when organizing ';
$string['categorize'] = 'Categorization';
$string['categories'] = 'Categories';
$string['categorizesettings'] = 'Operator settings for categorization';
$string['categoriseresponses'] = 'Categorize ideas';
$string['disagreewithyou'] = '$a inputs DO NOT agree with you';
$string['disagreewithyousingle'] = '$a input DOES NOT agree with you';
$string['maxitemspercategory'] = 'Max items per category ';
$string['mycategories'] = 'My categorization';
$string['nocategories'] = 'No categories';
$string['notcategorised'] = 'Not categorized';
$string['nothinghere'] = 'No inputs for this category';
$string['organizingcategorize'] = 'Categorizing ideas';
$string['othercategories'] = 'Categories from other participants';
$string['publishcategoriesoncollect'] = 'Publish categories on collect form';
$string['savecategories'] = 'Save categories';
$string['savecategorization'] = 'Save the categorization';
$string['uncategorized'] = 'Uncategorized';
?>