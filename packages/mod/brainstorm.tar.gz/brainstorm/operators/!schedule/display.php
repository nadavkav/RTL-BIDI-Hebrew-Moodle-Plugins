<?php 

/**
* Module Brainstorm V2
* Operator : schedule
* @author Valery Fremaux
* @package Brainstorm 
* @date 20/12/2007
*/

echo '<center>';
print_simple_box(get_string('notimplemented', 'brainstorm'));
echo '/<center>';
?>