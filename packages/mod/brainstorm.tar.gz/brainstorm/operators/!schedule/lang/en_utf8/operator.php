<?php

$string['schedule'] = 'Scheduling';
$string['schedulesettings'] = 'Parameter settings for scheduling';
$string['quantifyedges'] = 'Quantify edges';
?>