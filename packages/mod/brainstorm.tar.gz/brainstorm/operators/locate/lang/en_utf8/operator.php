<?php

$string['datarangeis'] = 'You must enter values in the range';
$string['displaysize'] = 'Display dimension';
$string['height'] = 'Height';
$string['locate'] = '2D Cartography';
$string['locatesettings'] = 'Parameter settings for 2D cartography';
$string['notconfigured'] = 'This module seems not having been configured.';
$string['organizinglocate'] = 'Location (2D) of the ideas';
$string['savelocations'] = 'Save coordinates';
$string['showlabels'] = 'Display labels';
$string['width'] = 'Width';
$string['xmaxrange'] = 'Max value (X)';
$string['xminrange'] = 'Min value (X)';
$string['xquantifier'] = 'X quantifier';
$string['ymaxrange'] = 'Max value (Y)';
$string['yminrange'] = 'Min value (Y)';
$string['yquantifier'] = 'Y quantifier';
?>