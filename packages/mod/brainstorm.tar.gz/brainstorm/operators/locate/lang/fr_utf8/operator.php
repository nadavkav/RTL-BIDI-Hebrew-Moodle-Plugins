<?php

$string['datarangeis'] = 'Entrez des données dans l\'intervalle';
$string['displaysize'] = 'Dimensions de visualisation ';
$string['height'] = 'Hauteur ';
$string['locate'] = 'Cartographie';
$string['locatesettings'] = 'Réglage des paramètres de cartographie';
$string['notconfigured'] = 'Ce module ne semble pas avoir été configuré ';
$string['organizinglocate'] = 'Localisation (2D) des entrées';
$string['savelocations'] = 'Enregistrer les coordonnées ';
$string['showlabels'] = 'Afficher les textes ';
$string['width'] = 'Largeur ';
$string['xmaxrange'] = 'Valeur maximale en X ';
$string['xminrange'] = 'Valeur minimale en X ';
$string['xquantifier'] = 'Quantificateur en abscisses (X) ';
$string['ymaxrange'] = 'Valeur maximale en Y ';
$string['yminrange'] = 'Valeur minimale en Y ';
$string['yquantifier'] = 'Quantificateur en ordonnées (Y) ';
?>