<?php

$string['absolute'] = 'סדר מוחלט';
$string['allowreducesource'] = 'אפשרו צמצום המקור';
$string['candeletemore'] = 'אפשר למחוק יותר מהשארית הרצויה';
$string['filter'] = 'סינון';
$string['filtereddata'] = 'קלט אשר סונן';
$string['filtersettings'] = 'הגדרות מאפייני \"סינון\"';
$string['maxideasleft'] = 'מספר רעיונות מירבי לאחר סינון';
$string['myfilter'] = 'הסינון שלי';
$string['nofilteringinprogress'] = 'לא קיים תהליך סינון,כעת.';
$string['nootherstatuses'] = 'לא קיים תהליך סינון כלשהו על ידי משתמשים אחרים, כעת.';
$string['organizingfilter'] = 'צמצום מספר הרעיונות על ידי ביטול';
$string['otherfilters'] = 'סינון של משתמשים אחרים';
$string['responsestoeliminate'] = 'רעיונות לביטול';
$string['saveordering'] = 'שמירת הסינון';
$string['saveorderingandreduce'] = 'שמירה וצימצום הרעיונות המקוריים (מחיקת המסוננים)';
$string['keepit'] = 'שמירת רעיונות';
$string['recording filter...'] = 'שמירת מידע מסונן...הסתיים.';
?>