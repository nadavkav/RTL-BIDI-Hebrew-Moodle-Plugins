<?php

/**
* Module Brainstorm V2
* Operator : hierarchize
* @author Valery Fremaux
* @package Brainstorm 
* @date 20/12/2007
*/

// Void controller for include
?>