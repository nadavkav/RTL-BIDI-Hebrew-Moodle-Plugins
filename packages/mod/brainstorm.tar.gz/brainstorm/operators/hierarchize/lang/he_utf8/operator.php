<?php

$string['clearalldata'] = 'מחיקת כל נתוני המִדְרָג';
$string['hierarchize'] = 'מִדְרָג';
$string['hierarchizesettings'] = 'הגדרות מאפייני ה\"מִדְרָג\"';
$string['maxarity'] = 'מספר מירבי של תתי־ענפים בעץ־המִדְרָג';
$string['maxlevels'] = 'גובה מירבי של עץ־המִדְרָג';
$string['mytree'] = 'מִדְרָג שלי';
$string['notreeset'] = 'טרם נקבע עץ־מִדְרָג';
$string['printindeepness'] = 'עומק תצוגת המִדְרָג';
$string['printbyline'] = 'תצוגה על פי קווים';
$string['tree'] = 'רעיונות מִדְרָג';
?>