<?php

$string['clearalldata'] = 'Effacer toutes les données';
$string['hierarchize'] = 'Hiérarchisation';
$string['hierarchizesettings'] = 'Réglage des paramètres pour la hiérarchisation';
$string['maxarity'] = 'Nombre fils maximum par branche (arité)';
$string['maxlevels'] = 'Hauteur maximale de l\'arbre de hiérarchie';
$string['mytree'] = 'Mon arbre';
$string['notreeset'] = 'L\'arbre n\'est pas encore constitué';
$string['printindeepness'] = 'Affichage en profondeur';
$string['printbyline'] = 'Affichage en hauteur';
$string['tree'] = 'Hierachisation des idées';
?>