<?php
$string['resourcetypeweblink'] = 'קישור לאתר אינטרנט';
?>