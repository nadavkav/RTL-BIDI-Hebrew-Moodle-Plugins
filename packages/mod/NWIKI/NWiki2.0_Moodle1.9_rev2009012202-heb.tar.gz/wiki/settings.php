<?php  //$Id: settings.php,v 1.1.2.5 2009/01/17 19:30:08 stronk7 Exp $

// if (!$options = get_records("block")) {
//     $options = array();
// }
$options = get_records("block");
$options2 = array();
foreach ($options as $option) {
    $options2[$option->id] = $option->name;
}
$settings->add(new admin_setting_configmultiselect('wiki_defaultblocks', get_string('wiki_defaultblocks', 'wiki'), 
  get_string('wiki_defaultblocksconfig', 'wiki'), array(), $options2));

$defaulteditor = array('htmleditor','nwiki','ewiki', 'dfwiki');
$settings->add(new admin_setting_configmultiselect('wiki_defaulteditor', get_string('wiki_defaulteditor', 'wiki'), 
  get_string('wiki_defaulteditorconfig', 'wiki'), array(), $defaulteditor));

//$settings->add(new admin_setting_configcheckbox('forum_googletranslator', get_string('googletranslator', 'forum'),
//                   get_string('configgoogletranslator', 'forum'), 0));
?>
