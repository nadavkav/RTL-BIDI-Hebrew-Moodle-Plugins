<?php // $Id: version.php,v 1.2 2008/11/06 17:39:11 tedbow Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////
/**
 * version.php
 * @package map
 * @author Ted Bowman <ted@tedbow.com>
 * @version 0.1
 *
 */
$module->version  = 2008110601;
$module->requires = 2006110201;  // Requires this Moodle version
$module->cron     = 0;


?>
