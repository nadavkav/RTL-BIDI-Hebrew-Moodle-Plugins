<?php // $Id: participants.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $

/**
 * Used to update the participants for a given meeting.
 *
 * @version $Id: participants.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Remote Learner - http://www.remote-learner.net/
 */


require_once('../../config.php');
require_once($CFG->dirroot . '/mod/elluminate/lib.php');


$id           = required_param('id', PARAM_INT);
$firstinitial = optional_param('firstinitial', '', PARAM_ALPHA);
$lastinitial  = optional_param('lastinitial', '', PARAM_ALPHA);
$sort         = optional_param('sort', '', PARAM_ALPHA);
$dir          = optional_param('dir', '', PARAM_ALPHA);

if (!$meeting = get_record('elluminate', 'id', $id)) {
	error('You must specify a valid meeting ID.');
}

if (!$course = get_record('course', 'id', $meeting->course)) {
	error('Invalid course.');
}

if (!$elluminatemod = get_record('modules', 'name', 'elluminate')) {
	error('Could not get record for the Elluminate Live! module!');
}

if (!$cm = get_record('course_modules', 'course', $course->id, 'instance', $meeting->id, 'module',
$elluminatemod->id)) {
	error('Invalid course module.');
}

if (!isteacheredit($course->id)) {
	error('You must be an editing teacher in this course to perform this opertaion.');
}

$usingroles = file_exists($CFG->libdir . '/accesslib.php');

$meeting->name = stripslashes($meeting->name);
$notice        = '';

/// Process data submission.
if (($data = data_submitted($CFG->wwwroot . '/mod/elluminate/participants.php')) && confirm_sesskey()) {
	/// Delete records for selected participants chosen to be removed.
	if (!empty($data->userscur)) {
		if (!elluminate_del_users($meeting->meetingid, $data->userscur)) {
			$notice = get_string('couldnotremoveusersfrommeeting', 'elluminate');
		}
	}

	/// Add records for selected moderators chosen to be added.
	if (!empty($data->usersavail)) {
		if (!elluminate_add_users($meeting->meetingid, $data->usersavail)) {
			$notice = get_string('couldnotadduserstomeeting', 'elluminate');
		}
	}
}

/// Get a list of existing moderators for this meeting (if any) and assosciated
/// information.
$curmods = elluminate_get_meeting_participants($meeting->meetingid, true);

/// Get a list of existing participants for this meeting (if any) and assosciated
/// information.
$curusers = elluminate_get_meeting_participants($meeting->meetingid);


$usersexist = array();
if (!empty($curusers))
{
	foreach ($curusers as $curuser)
	{
		$usersexist[] = $curuser->id;
	}
	reset($curusers);
}

if (!empty($curmods))
{
	foreach ($curmods as $curmod)
	{
		$usersexist[] = $curmod->id;
	}
}

$LIKE     = sql_ilike();

$select = ' AND mu.deleted = 0 AND mu.confirmed = 1';

if ($firstinitial) {
	$select .= ' AND mu.firstname ' . $LIKE . ' \'' . $firstinitial . '%\' ';
}

if ($lastinitial) {
	$select .= ' AND mu.lastname ' . $LIKE . ' \'' . $lastinitial . '%\' ';
}

if (!empty($sort) && !empty($dir)) {
	$sort .= ' ' . $dir;
} else {
	$sort = ' mu.lastname ASC, mu.firstname ASC';
}


/// Particpants can be teachers or students in this course who have an account on
/// the Elluminate server.
if ($usingroles) {
	$roleteacher     = get_field('role', 'id', 'shortname', 'teacher');
	$roleteacheredit = get_field('role', 'id', 'shortname', 'editingteacher');
	$rolestudent     = get_field('role', 'id', 'shortname', 'student');
	$context         = get_context_instance(CONTEXT_COURSE, $course->id);

	$sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}role_assignments ra on ra.userid = mu.id
                WHERE ra.contextid = '$context->id'
                AND ( ra.roleid = '$roleteacher' OR ra.roleid = '$roleteacheredit' )";
} else {
	$sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}user_teachers mt on mt.userid = mu.id
                WHERE mt.course = $meeting->course ";
}

/// Exlude any existing moderators or participants from the result.
if (!empty($usersexist)) {
	$sql .= "AND mu.id NOT IN (" . implode(',', $usersexist) . ") ";
}

$sql .= $select;
$sql .= ' ORDER BY ' . $sort;

$availteachers = get_records_sql($sql);

if ($usingroles) {
	$sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}role_assignments ra on ra.userid = mu.id
                WHERE ra.contextid = '$context->id'
                AND ra.roleid = '$rolestudent' ";
} else {
	$sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}user_students ms on ms.userid = mu.id
                WHERE ms.course = $meeting->course ";
}

/// Exlude any existing moderators or participants from the result.
if (!empty($usersexist)) {
	$sql .= "AND mu.id NOT IN (" . implode(',', $usersexist) . ") ";
}

$sql .= $select;
$sql .= ' ORDER BY ' . $sort;

$availstudents = get_records_sql($sql);

$availusers = array();

if (!empty($availteachers)) {
	foreach($availteachers as $availteacher) {
		//##

		if (!$elmuser = get_record('elluminate_users', 'userid', $availteacher->id)) {
			elluminate_new_user($availteacher->id, random_string(10));
		}
		$availusers[] = $availteacher;
	}
}
if (!empty($availstudents)) {
	foreach($availstudents as $availstudent) {
		//##

		if (!$elmuser = get_record('elluminate_users', 'userid', $availstudent->id)) {
			elluminate_new_user($availstudent->id, random_string(10));
		}

		if(!checkListForUserById($availstudent, $availusers))
		{
			$availusers[] = $availstudent;
		}
	}
}

$cavailusers = empty($availusers) ? 0 : count($availusers);
$ccurusers   = empty($curusers) ? 0 : count($curusers);

$sesskey         = !empty($USER->sesskey) ? $USER->sesskey : '';
$strmeeting      = get_string('modulename', 'elluminate');
$strmeetings     = get_string('modulenameplural', 'elluminate');
$strparticipants = get_string('editingparticipants', 'elluminate');
$struserscur     = ($ccurusers == 1) ? get_string('existingparticipant', 'elluminate') :
get_string('existingparticipants', 'elluminate', $ccurusers);
$strusersavail   = ($cavailusers == 1) ? get_string('availableparticipant', 'elluminate') :
get_string('availableparticipants', 'elluminate', $cavailusers);
$strfilterdesc   = get_string('participantfilterdesc', 'elluminate');
$strall          = get_string('all');
$alphabet        = explode(',', get_string('alphabet'));

print_header("$course->shortname: $strparticipants", "$course->fullname: $strparticipants",
                "<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a>
                -> <a href=\"$CFG->wwwroot/mod/elluminate/index.php?id=$course->id\">$strmeetings</a>
                -> <a href=\"$CFG->wwwroot/mod/elluminate/view.php?id=$cm->id\">" . stripslashes($meeting->name) .
                "</a> -> $strparticipants", "");

if (!empty($notice)) {
	notify($notice);
}

include($CFG->dirroot . '/mod/elluminate/participants-edit.html');

print_footer();

?>
