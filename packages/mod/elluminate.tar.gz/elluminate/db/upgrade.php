<?php // $Id: upgrade.php,v 1.1 2008/02/08 18:59:10 mchurch Exp $

/**
 * 
 *
 * @version $Id: upgrade.php,v 1.1 2008/02/08 18:59:10 mchurch Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Open Knowlege Technologies - http://www.oktech.ca/
 * @author Remote Learner - http://www.remote-learner.net/
 */

    function xmldb_mod_elluminate_upgrade($oldversion = 0) {
        global $CFG;

        $result = true;

        if ($oldversion < 2006062102) {            
            $result = install_from_xmldb_file($CFG->dirroot . '/mod/elluminate/db/install.xml');
        }

        return $result;
    }

?>
