<?php // $Id: index.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $


    require_once("../../config.php");
    require_once("lib.php");


    $id = required_param('id', PARAM_INT);   // course

    if (! $course = get_record("course", "id", $id)) {
        error("Course ID is incorrect");
    }

    require_login($course->id);

    add_to_log($course->id, "elluminate", "view all", "index.php?id=$course->id", "");


/// Get all required strings

    $strelluminates = get_string("modulenameplural", "elluminate");
    $strelluminate  = get_string("modulename", "elluminate");


/// Print the header

    if ($course->category) {
        $navigation = "<a href=\"../../course/view.php?id=$course->id\">$course->shortname</a> ->";
    }

    print_header("$course->shortname: $strelluminates", "$course->fullname", "$navigation $strelluminates", "", "", true, "", navmenu($course));

/// Get all the appropriate data

    if (! $elluminates = get_all_instances_in_course("elluminate", $course)) {
        notice("There are no Elluminate Live! meetings ", "../../course/view.php?id=$course->id");
        die;
    }

/// Print the list of instances (your module will probably extend this)

    $timenow = time();
    $strname  = get_string("name");
    $strweek  = get_string("week");
    $strtopic  = get_string("topic");

    if ($course->format == "weeks") {
        $table->head  = array ($strweek, $strname);
        $table->align = array ("center", "left");
    } else if ($course->format == "topics") {
        $table->head  = array ($strtopic, $strname);
        $table->align = array ("center", "left", "left", "left");
    } else {
        $table->head  = array ($strname);
        $table->align = array ("left", "left", "left");
    }

    foreach ($elluminates as $elluminate) {
        $elluminate->name = stripslashes($elluminate->name);

        if (!$elluminate->visible) {
            //Show dimmed if the mod is hidden
            $link = "<a class=\"dimmed\" href=\"view.php?id=$elluminate->coursemodule\">$elluminate->name</a>";
        } else {
            //Show normal if the mod is visible
            $link = "<a href=\"view.php?id=$elluminate->coursemodule\">$elluminate->name</a>";
        }

        if ($course->format == "weeks" or $course->format == "topics") {
            $table->data[] = array ($elluminate->section, $link);
        } else {
            $table->data[] = array ($link);
        }
    }

    echo "<br />";

    print_table($table);

/// Finish the page

    print_footer($course);

?>
