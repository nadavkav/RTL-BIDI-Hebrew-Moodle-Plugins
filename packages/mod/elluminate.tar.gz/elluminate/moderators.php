<?php // $Id: moderators.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $

/**
 * Used to update the moderators for a given meeting.
 * 
 * @version $Id: moderators.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Remote Learner - http://www.remote-learner.net/
 */


    require_once('../../config.php');
    require_once($CFG->dirroot . '/mod/elluminate/lib.php');


    $id           = required_param('id', PARAM_INT);
    $firstinitial = optional_param('firstinitial', '', PARAM_ALPHA);
    $lastinitial  = optional_param('lastinitial', '', PARAM_ALPHA);
    $sort         = optional_param('sort', '', PARAM_ALPHA);
    $dir          = optional_param('dir', '', PARAM_ALPHA);

    if (!$meeting = get_record('elluminate', 'id', $id)) {
        error('You must specify a valid meeting ID.');
    }

    if (!$course = get_record('course', 'id', $meeting->course)) {
        error('Invalid course.');
    }

    if (!$elluminatemod = get_record('modules', 'name', 'elluminate')) {
        error('Could not get record for the Elluminate Live! module!');
    }

    if (!$cm = get_record('course_modules', 'course', $course->id, 'instance', $meeting->id, 'module',
                          $elluminatemod->id)) {
        error('Invalid course module.');
    }

    if (!isteacheredit($course->id)) {
        error('You must be an editing teacher in this course to perform this opertaion.');
    }

    $usingroles = file_exists($CFG->libdir . '/accesslib.php');

    $meeting->name = stripslashes($meeting->name);

/// Process data submission.
    if (($data = data_submitted($CFG->wwwroot . '/mod/elluminate/moderators.php')) && confirm_sesskey()) {
    /// Delete records for selected moderators chosen to be removed.
       
        if (!empty($data->modscur)) {
            if (!elluminate_del_users($meeting->meetingid, $data->modscur, true)) {
                notify(get_string('couldnotremoveusersfrommeeting', 'elluminate'));
            }
        }

    /// Add records for selected moderators chosen to be added.
        if (!empty($data->modsavail)) {
            if (!elluminate_add_users($meeting->meetingid, $data->modsavail, true)) {
                notify(get_string('couldnotadduserstomeeting', 'elluminate'));
            }
        }
    }

/// Get a list of existing moderators for this meeting (if any) and assosciated
/// information.
    $curmods = elluminate_get_meeting_participants($meeting->meetingid, true);
    
    $modsexist = array();    
    if (!empty($curmods)) {
        foreach ($curmods as $curmod) {
            $modsexist[] = $curmod->id;
        }
        reset($curmods);
    }
    
/// Make sure that we don't include any potential moderators who have already
/// been added as participants.
    $curusers = elluminate_get_meeting_participants($meeting->meetingid);
    
    if (!empty($curusers)) {
        foreach ($curusers as $curuser) {
            $modsexist[] = $curuser->id;
        }
    }

    $LIKE     = sql_ilike();

/// Available moderators are teachers in this course who have an account on the
/// Elluminate server.
    if ($usingroles) {
        $roleteacher     = get_field('role', 'id', 'shortname', 'teacher');
        $roleteacheredit = get_field('role', 'id', 'shortname', 'editingteacher');
        $context         = get_context_instance(CONTEXT_COURSE, $course->id);

        $sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}role_assignments ra on ra.userid = mu.id
                WHERE ra.contextid = '$context->id'
                AND ( (ra.roleid = '$roleteacher') OR (ra.roleid = '$roleteacheredit') )
                AND mu.id != {$meeting->creator}";
    } else {
        $sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}user_teachers mt on mt.userid = mu.id
                WHERE mt.course = $meeting->course
                AND mu.id != {$meeting->creator}";
    }

    $select = ' AND mu.deleted = 0 AND mu.confirmed = 1';

    if ($firstinitial) {
        $select .= ' AND mu.firstname ' . $LIKE . ' \'' . $firstinitial . '%\' ';
    }

    if ($lastinitial) {
        $select .= ' AND mu.lastname ' . $LIKE . ' \'' . $lastinitial . '%\' ';
    }

    if (!empty($sort) && !empty($dir)) {
        $sort .= ' ' . $dir;
    } else {
        $sort = ' mu.lastname ASC, mu.firstname ASC';
    }

    if ($usingroles) {
        $roleteacher     = get_field('role', 'id', 'shortname', 'teacher');
        $roleteacheredit = get_field('role', 'id', 'shortname', 'editingteacher');
        $context         = get_context_instance(CONTEXT_COURSE, $course->id);

    /// Available moderators are teachers in this course who have an account on the
    /// Elluminate server.
        $sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}role_assignments ra on ra.userid = mu.id
                WHERE ra.contextid = '$context->id'
                AND ( (ra.roleid = '$roleteacher') OR (ra.roleid = '$roleteacheredit') )
                AND mu.id != {$meeting->creator}";
    } else {
    /// Available moderators are teachers in this course who have an account on the
    /// Elluminate server.
        $sql = "SELECT mu.id, mu.firstname, mu.lastname, mu.username
                FROM {$CFG->prefix}user mu
                LEFT JOIN {$CFG->prefix}user_teachers mt on mt.userid = mu.id
                WHERE mt.course = $meeting->course
                AND mu.id != {$meeting->creator}";
    }

/// Exlude any existing moderators from the result.
    if (!empty($modsexist)) {
        $sql .= " AND mu.id NOT IN (" . implode(',', $modsexist) . ")";
    }
		
    $sql .= $select;
    $sql .= ' ORDER BY ' . $sort;

    $availmods = get_records_sql($sql);
    
    $cavailmods = empty($availmods) ? 0 : count($availmods);
    $ccurmods   = empty($curmods) ? 0 : count($curmods);

    $sesskey         = !empty($USER->sesskey) ? $USER->sesskey : '';
    $strmeeting      = get_string('modulename', 'elluminate');
    $strmeetings     = get_string('modulenameplural', 'elluminate');
    $strmoderators   = get_string('editingmoderators', 'elluminate');
    $strmodscur      = ($ccurmods == 1) ? get_string('existingmoderator', 'elluminate') :
                                          get_string('existingmoderators', 'elluminate', $ccurmods);
    $strmodsavail    = ($cavailmods == 1) ? get_string('availablemoderator', 'elluminate') :
                                            get_string('availablemoderators', 'elluminate', $cavailmods);
    $strfilterdesc   = get_string('participantfilterdesc', 'elluminate');
    $strall          = get_string('all');
    $alphabet        = explode(',', get_string('alphabet'));

    print_header("$course->shortname: $strmoderators", "$course->fullname: $strmoderators",
                "<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a>
                -> <a href=\"$CFG->wwwroot/mod/elluminate/index.php?id=$course->id\">$strmeetings</a>
                -> <a href=\"$CFG->wwwroot/mod/elluminate/view.php?id=$cm->id\">$meeting->name</a>
                -> $strmoderators", "");

    include($CFG->dirroot . '/mod/elluminate/moderators-edit.html');

    print_footer();

?>
