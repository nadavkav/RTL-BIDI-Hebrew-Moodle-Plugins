<?php // $Id: version.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of elluminate
///  This fragment is called by moodle_needs_upgrading() and /admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2008011101;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 900;         // Period for cron to check this module (secs)

?>
