<?php // $Id: attendance.php,v 1.2 2008/09/17 19:30:12 jfilip Exp $

/**
 * Displays an attendance report for a meeting configured to track attendance.
 *
 * @version $Id: attendance.php,v 1.2 2008/09/17 19:30:12 jfilip Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Remote Learner - http://www.remote-learner.net/
 */


    require_once('../../config.php');
    require_once($CFG->dirroot . '/mod/elluminate/lib.php');
    require_once($CFG->libdir . '/tablelib.php');


    $id = required_param('id', PARAM_INT);

    if (!$meeting = get_record('elluminate', 'id', $id)) {
        error('Incorrect meeting ID (' . $meetingid . ')');
    }

    if (!$course = get_record('course', 'id', $meeting->course)) {
        error('Invalid course!');
    }

    require_login($course->id, false);

    if (!isteacheredit($course->id, $USER->id)) {
        error('You do not have access to this page.');
    }

    if (!$elmmeeting = elluminate_get_meeting($meeting->meetingid)) {
        error('Could not get this meeting from the Elluminate Live! server!');
    }

    $usingroles = file_exists($CFG->libdir . '/accesslib.php');


/// Process any attendance modifications.
    if (($data = data_submitted($CFG->wwwroot . '/mod/elluminate/attendance.php')) && confirm_sesskey()) {
        foreach ($data->userids as $idx => $userid) {
            if ($data->attendance[$idx] > 0) {
                if ($ea = get_record('elluminate_attendance', 'userid', $userid,
                                     'elluminateid', $meeting->id)) {
                    if (empty($ea->grade)) {
                        $ea->grade = $data->attendance[$idx];

                        update_record('elluminate_attendance', $ea);
                    }

                } else {
                    $ea = new Object();
                    $ea->userid           = $userid;
                    $ea->elluminateid = $meeting->id;
                    $ea->grade            = $data->attendance[$idx];

                    insert_record('elluminate_attendance', $ea);
                }
            } else {
                if ($ea = get_record('elluminate_attendance', 'userid', $userid,
                                     'elluminateid', $meeting->id)) {
                    if (!empty($ea->grade)) {
                        $ea->grade = 0;

                        update_record('elluminate_attendance', $ea);
                    }
                }
            }
        }
    }


    $strattendancefor   = get_string('attendancefor', 'elluminate', stripslashes($meeting->name));
    $strelluminates = get_string('modulenameplural', 'elluminate');
    $strelluminate  = get_string('modulename', 'elluminate');

    print_header("$course->shortname: $strattendancefor", "$course->fullname",
                 "<a href=\"$CFG->wwwroot/course/view.php?id=$course->id\">$course->shortname</a> -> " .
                 "<a href=\"$CFG->wwwroot/mod/elluminate/index.php?id=$course->id\">$strelluminates</a> -> " .
                 "<a href=\"$CFG->wwwroot/mod/elluminate/view.php?a=$meeting->id\">" .
                 stripslashes($meeting->name) . "</a> -> $strattendancefor");

/// Get a list of user IDs for students who are allowed to participate in this meeting.
    $userids = array();

    if ($elmmeeting->privatemeeting) {
        if ($participants = elluminate_get_participants($elmmeeting->meetingid, ELLUMINATELIVE_ROLE_PARTICIPANT)) {
            foreach ($participants as $participant) {
                if ($elmuser = get_record('elluminate_users', 'elm_id', $participant->userid)) {
                    $userids[] = $elmuser->userid;
                }
            }
        }
    }

    if ($usingroles) {
        $rolestudent = get_field('role', 'id', 'shortname', 'student');
        $context     = get_context_instance(CONTEXT_COURSE, $course->id);

        $sql = "SELECT u.id, u.firstname, u.lastname
                FROM {$CFG->prefix}user u
                LEFT JOIN {$CFG->prefix}role_assignments ra on ra.userid = u.id
                WHERE ra.contextid = '$context->id'
                AND ra.roleid = '$rolestudent'";
    } else {
        $sql = "SELECT u.id, u.firstname, u.lastname
                FROM {$CFG->prefix}user u
                LEFT JOIN {$CFG->prefix}user_students s ON u.id = s.userid
                WHERE s.course = $course->id";
    }

    if (!empty($userids)) {
        $sql .= " AND u.id IN ( " . implode(', ', $userids) . ")";
    }

    $sql .= " ORDER BY u.lastname ASC, u.firstname ASC";

    $usersavail = get_records_sql($sql);

    $table = new flexible_table('meeting-attendance-', $meeting->id);

    $tablecolumns = array('fullname', 'attended');
    $tableheaders = array(get_string('fullname'), get_string('attended', 'elluminate'));

    $table->define_columns($tablecolumns);
    $table->define_headers($tableheaders);
    $table->define_baseurl($CFG->wwwroot . '/mod/elluminate/attendance.php?id=' . $meeting->id);

    $table->set_attribute('cellspacing', '1');
    $table->set_attribute('cellpadding', '8');
    $table->set_attribute('align', 'center');
    $table->set_attribute('class', 'generaltable generalbox');

    $table->setup();

    if (!empty($usersavail)) {
        $yesno = array(0 => get_string('no'), 1 => get_string('yes'));

        foreach ($usersavail as $useravail) {
            $sql = "SELECT a.*
                    FROM {$CFG->prefix}elluminate_attendance a
                    WHERE a.userid = '$useravail->id'
                    AND a.elluminateid = '$meeting->id'
                    AND a.grade > 0";

        /// Display different form items depending on whether we're using a scale
        /// or numerical value for an attendance grade.
            if (($attended = get_record_sql($sql))) {
                if ($meeting->grade > 0) {
                    $select = choose_from_menu($yesno, 'attendance[]', 1, NULL, '', '', true);
                } else {
                    $select = choose_from_menu(make_grades_menu($meeting->grade), 'attendance[]', $attended->grade, get_string('no'), '', -1, true);
                }
            } else {
                if ($meeting->grade > 0) {
                    $select = choose_from_menu($yesno, 'attendance[]', 0, NULL, '', '', true);
                } else {
                    $select = choose_from_menu(make_grades_menu($meeting->grade), 'attendance[]', -1, get_string('no'), '', -1, true);
                }
            }

            $table->add_data(
                array(
                    '<input type="hidden" name="userids[]" value="' . $useravail->id . '" />' . fullname($useravail),
                    $select
                )
            );
        }
    }

    if ($meeting->grade < 0) {
        print_heading(get_string('attendancescalenotice', 'elluminate'), 'center', '3');
    }

    $sesskey = !empty($USER->sesskey) ? $USER->sesskey : '';

    echo '<form input action="' . $CFG->wwwroot . '/mod/elluminate/attendance.php" method="post">';
    echo '<input type="hidden" name="id" value="' . $meeting->id . '"/>';
    echo '<input type="hidden" name="sesskey" value="' . $sesskey . '" />';

    $table->print_html();

    echo '<center><input type="submit" value="' . get_string('updateattendance', 'elluminate') . '" />';
    echo '</form>';

    print_footer($course);

?>
