<?php // $Id: loadmeeting.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $

/**
 * Elluminate Live! meeting load script.
 * 
 * @version $Id: loadmeeting.php,v 1.1 2008/02/08 18:59:06 mchurch Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Remote Learner - http://www.remote-learner.net/
 */


    require_once('../../config.php');
    require_once($CFG->dirroot . '/mod/elluminate/lib.php');


    $id = required_param('id', PARAM_INT);


    if (!$elluminate = get_record('elluminate', 'id', $id)) {
        error('Could not get meeting (' . $id . ')');
    }

    if ($mod = get_record('modules', 'name', 'elluminate')) {
        $cm = get_record('course_modules', 'course', $elluminate->course,
                         'module', $mod->id, 'instance', $elluminate->id);
    } else {
        $cm = NULL;
    }

    require_login($elluminate->course, false);

    if (!$meeting = elluminate_get_meeting($elluminate->meetingid)) {
        error('Incorrect meeting ID value (' . $meetingid . ')');
    }

    if (!$elmuser = get_record('elluminate_users', 'userid', $USER->id)) {
    /// If this is a public meeting and the user is a member of this course,
    /// they can join the meeting.
        if (empty($elluminate->private) && (isadmin() || iscreator($USER->id) ||
                  isteacher($elluminate->course, $USER->id) || isstudent($elluminate->course))) {
            if (!elluminate_new_user($USER->id, random_string(10))) {
               error('Could not create new Elluminate Live! user account!');
            }
            
            $elmuser = get_record('elluminate_users', 'userid', $USER->id);
            
            if (!elluminate_add_participant($elluminate->meetingid, $elmuser->elm_id)) {
                error('Could not add you as a participant to this meeting.');
            }
        } else {
            error('You must have an Elluminate Live! user account to access this resource.');
        }
    }


    if (!elluminate_is_participant($elluminate->meetingid, $elmuser->elm_id, true) &&
        !elluminate_is_participant($elluminate->meetingid, $elmuser->elm_id)) {
        if ($elluminate->private) {
            error('You must be a participant of the given meeting to access this resource.');
        } else if (isteacher($elluminate->course, $USER->id) || isstudent($elluminate->course)) {
            if (!elluminate_add_participant($elluminate->meetingid, $elmuser->elm_id)) {
                error('Could not add you as a participant to this meeting.');
            }
        }
    }

/// Do we need to assign a grade for this meeting?
    if (($elluminate->grade !== 0) && isstudent($elluminate->course, $USER->id)) {
        if (!$grade = get_record('elluminate_attendance', 'elluminateid', $elluminate->id,
                                 'userid', $USER->id)) {
        /// Get the grade value for this meeting (either scale or numerical value).
            if ($elluminate->grade < 0) {
                $grades = make_grades_menu($elluminate->grade);
                $ugrade = key($grades);
            } else {
                $ugrade = $elluminate->grade;
            }

            $grade = new Object();
            $grade->elluminateid = $elluminate->id;
            $grade->userid           = $USER->id;
            $grade->grade            = $ugrade;
            $grade->timemodified     = time();

            insert_record('elluminate_attendance', $grade);
        } else {
            $grade->attended = 1;
            
            update_record('elluminate_attendance', $grade);
        }
    }

    if (!empty($cm)) {
        $cmid = $cm->id;
    } else {
        $cmid = 0;
    }

    add_to_log($elluminate->course, 'elluminate', 'view meeting', 'loadmeeting.php?id=' .
               $elluminate->id, $elluminate->id, $cmid, $USER->id);

/// Load the meeting.
    if (!elluminate_build_meeting_jnlp($elluminate->meetingid, $USER->id)) {
        error('Could not load Elluminate Live! meeting.');
    }

?>
