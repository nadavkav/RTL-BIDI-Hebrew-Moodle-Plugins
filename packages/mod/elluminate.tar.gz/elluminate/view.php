<?php // $Id: view.php,v 1.1 2008/02/08 18:59:07 mchurch Exp $

/// This page prints a particular instance of elluminate
/// (Replace elluminate with the name of your module)

    require_once('../../config.php');
    require_once('lib.php');
    require_once($CFG->libdir . '/weblib.php');

    $id           = optional_param('id', 0, PARAM_INT); // Course Module ID, or
    $a            = optional_param('a', 0, PARAM_INT);  // elluminate ID
    $delrecording = optional_param('delrecording', 0, PARAM_INT);

    if ($id) {
        if (! $cm = get_record("course_modules", "id", $id)) {
            error("Course Module ID was incorrect");
        }
    
        if (! $course = get_record("course", "id", $cm->course)) {
            error("Course is misconfigured");
        }
    
        if (! $elluminate = get_record("elluminate", "id", $cm->instance)) {
            error("Course module is incorrect");
        }

    } else {
        if (! $elluminate = get_record("elluminate", "id", $a)) {
            error("Course module is incorrect");
        }
        if (! $course = get_record("course", "id", $elluminate->course)) {
            error("Course is misconfigured");
        }
        if (! $cm = get_coursemodule_from_instance("elluminate", $elluminate->id, $course->id)) {
            error("Course Module ID was incorrect");
        }
    }

    require_login($course->id, false);

/// Get the meeting object from the Elluminate Live! server.
    $meeting = elluminate_get_meeting($elluminate->meetingid);

    // ##REMOVED
/// Get the server parameters for the meeting from the Elluminate Live! server.
//    $sparams = elluminate_get_server_parameters($meeting->meetingid);

    if ($CFG->elluminate_boundary_default != -1)
    	{
        $boundary = $CFG->elluminate_boundary_default;
    } else if (array_key_exists($meeting->boundaryTime, $elluminate_boundary_times))
    	{
        $boundary = $meeting->boundaryTime;
    } else
    {
    	$boundary = ELLUMINATELIVE_BOUNDARY_DEFAULT;
    }

/// Calculate the actual number of seconds for the boundary time.
    $boundaryminutes = $boundary * 60;


/// Print the page header
    $elluminate->name = stripslashes($elluminate->name);

    if ($course->category) {
        $navigation = "<a href=\"../../course/view.php?id=$course->id\">$course->shortname</a> ->";
    }

    $strelluminates = get_string("modulenameplural", "elluminate");
    $strelluminate  = get_string("modulename", "elluminate");

    print_header("$course->shortname: $elluminate->name", "$course->fullname",
                 "$navigation <a href=index.php?id=$course->id>$strelluminates</a> -> $elluminate->name", 
                  "", "", true, update_module_button($cm->id, $course->id, $strelluminate), 
                  navmenu($course, $cm));

    $sesskey = !empty($USER->sesskey) ? $USER->sesskey : '';

/// Print the main part of the page
    print_simple_box_start('center', '50%');
    

/// Check for data submission.
    if (($data = data_submitted($CFG->wwwroot . '/mod/elluminate/view.php')) && confirm_sesskey()) {
        if (isset($data->seats)) {
            $seats   = trim($data->seats);
        		
            $umeeting = elluminate_update_meeting($meeting->meetingid, $meeting->start,
                                                      $meeting->end, $meeting->name,
                                                      $meeting->facilitatorid, $meeting->password,
                                                      $meeting->privatemeeting, $seats, $meeting->boundaryTime, $meeting->recordingModeType);

            if (!$umeeting) {
            	
                redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $id,
                         get_string('couldnotchangeseatreservation', 'elluminate'), 3);
            } else if (is_string($umeeting)) {

                if (strstr($umeeting, 'Not enough seats available to create meeting!')) {
                    $seats = elluminate_get_max_available_seats($meeting->start, $meeting->end);
                }

                if (!$umeeting = elluminate_update_meeting($meeting->meetingid, $meeting->start,
                                                      $meeting->end, $meeting->name,
                                                      $meeting->facilitatorid, $meeting->password,
                                                      $meeting->privatemeeting, $seats, $meeting->boundaryTime, $meeting->recordingModeType)) {
                    redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $id,
                             get_string('couldnotchangeseatreservation', 'elluminate'), 3);
                } else {
                    $meeting = $umeeting;
                }

            } else {
                $meeting = $umeeting;
            }

            $elluminate->seats = $seats;
            $elluminate->name  = addslashes($elluminate->name);

            if (!update_record('elluminate', $elluminate)) {
                error('Could not update elluminate record.');
            }
        }
    }

/// Handle a request to delete a recording.
    if (!empty($delrecording)) {
    /// Don't go any further if the user sending this information has no access
    /// to delete recordings for this meeting.
        if (!isadmin() || ($elluminate->creator != $USER->id)) {
            redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id);
        }

        if (!$recording = get_record('elluminate_recordings', 'id', $delrecording)) {
            error('Could not find meeting recording record');
        }

        if (optional_param('confirm', '', PARAM_ALPHANUM) == $sesskey) {
            if (elluminate_delete_recording($recording->recordingid)) {
                delete_records('elluminate_recordings', 'id', $recording->id);
                redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id,
                         get_string('deleterecordingsuccess', 'elluminate'), 4);
            } else {
                redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id,
                         get_string('deleterecordingfailure', 'elluminate'), 4);
            }

        } else {
            notice_yesno(get_string('deleterecordingconfirm', 'elluminate', userdate($recording->created)),
                         $CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id .
                         '&amp;delrecording=' . $recording->id . '&amp;confirm=' . $sesskey,
                         $CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id);
        }

        print_simple_box_end();
        print_footer($course);
        exit;            
    }

    add_to_log($course->id, "elluminate", "view", "view.php?id=$cm->id", "$elluminate->id");

/// Determine if the current user can participate in this meeting.
    $participant = false;

    if ($elluminate->private) {
        if ($elm_id = get_field('elluminate_users', 'elm_id', 'userid', $USER->id)) {
            $participant = (elluminate_is_participant($elluminate->meetingid, $elm_id) ||
                            elluminate_is_participant($elluminate->meetingid, $elm_id, true));
        }
    } else {
        $participant = true;
    }
    
    
?>
<form name="editmeeting" action="<?php echo $CFG->wwwroot; ?>/mod/elluminate/view.php" method="post">
    <input type="hidden" name="id" value="<?php echo $id; ?>" />
    <input type="hidden" name="meetingid" value="<?php echo $meeting->meetingid; ?>" />
    <input type="hidden" name="starttime" value="<?php echo $meeting->start; ?>" />
    <input type="hidden" name="endtime" value="<?php echo $meeting->end; ?>" />
    <input type="hidden" name="sesskey" value="<?php echo $sesskey; ?>" />
    <table align="center" cellpadding="5">
        <tr valign="top">
            <td align="right"><b><?php print_string('name'); ?>:</b></td>
            <td align="left"><?php p($elluminate->name); ?></td>
        </tr>
		<tr valign="top">
            <td align="right"><b><?php print_string('description'); ?>:</b></td>
            <td align="left"><?php echo $elluminate->description; ?></td>
        </tr>
		<tr valign="top">
            <td align="right"><b><?php print_string('meetingbegins', 'elluminate'); ?>:</b></td>
            <td align="left"><?php echo userdate($meeting->start); ?></td>
        </tr>
		<tr valign="top">
            <td align="right"><b><?php print_string('meetingends', 'elluminate'); ?>:</b></td>
            <td align="left"><?php echo userdate($meeting->end); ?></td>
        </tr>
		<tr valign="top">
            <td align="right"><b><?php print_string('boundarytime', 'elluminate'); ?>:</b></td>
            <td align="left"><?php echo $boundary . ' ' . get_string('minutes'); ?></td>
        </tr>

<?php

		// ## REMOVED!
//    if (($parameters = elluminate_get_meeting_parameters($meeting->meetingid)) &&
//        !empty($parameters->recordingstatus) && ($meeting->end > time())) {
		if($meeting->end > time())
		{

		echo '<tr valign="top">';
        echo '<td align="center" colspan="2">';

        switch ($meeting->recordingModeType) {
            case ELLUMINATELIVE_RECORDING_TYPE_MANUAL:
                echo get_string('recordingmanual', 'elluminate');
                break;
            case ELLUMINATELIVE_RECORDING_TYPE_AUTO:
                echo get_string('recordingautomatic', 'elluminate');
                break;
            case ELLUMINATELIVE_RECORDING_TYPE_DISABLED:
                echo get_string('recordingnone', 'elluminate');
                break;
        }

        echo '</td></tr>';
    }

    if (isteacheredit($course->id) && (time() < $meeting->end)) {
        echo '<tr valign="top">';
        echo '<td align="center" colspan="2"><a href="' . $CFG->wwwroot . '/mod/elluminate/moderators.php?id=' . $elluminate->id . '">' . get_string('editmoderatorsforthismeeting', 'elluminate') . '</a></td>';
        echo '</tr>';
        if ($elluminate->private) {
            echo '<tr>';
            echo '<td align="center" colspan="2"><a href="' . $CFG->wwwroot . '/mod/elluminate/participants.php?id=' . $elluminate->id . '">' . get_string('editparticipantsforthismeeting', 'elluminate') . '</a></td>';
            echo '</tr>';
        }
    }

/// Only display a link to join the meeting if the current user is a participant
/// or moderator for this meeting and it is currently happening right now.
    if ($participant && (($meeting->start - $boundaryminutes) <= time()) && ($meeting->end > time())) {
        echo '<tr valign="top">';

        $url = $CFG->wwwroot . '/mod/elluminate/loadmeeting.php?meetingid=' . $elluminate->meetingid; 

        echo '<td align="center" colspan="2"><a href="' . $CFG->wwwroot .
             '/mod/elluminate/loadmeeting.php?id=' . $elluminate->id .
             '" target="meeting">' . get_string('joinmeeting', 'elluminate') . '</a></td></tr>';
        echo '<tr valign="top"><td align="center" colspan="2">' .
             get_string('supportlinktext', 'elluminate', elluminate_support_link()) . '</a></td></tr>';
    }

/// Display a link to play the recording if one exists.
    if ($participant &&
        ($recordings = get_records('elluminate_recordings', 'meetingid', $elluminate->meetingid,
                                   'created ASC'))) {

        echo '<tr><td colspan="2"><hr /></td></tr>';

        foreach ($recordings as $recording) {
            echo '<tr valign="top">';
            echo '<td align="center" colspan="2"><a href="' . $CFG->wwwroot .
                 '/mod/elluminate/loadrecording.php?id=' . $recording->id .
                 '" target="new">' . get_string('playrecording', 'elluminate') . '</a> - ' .
                 userdate($recording->created);

            if (isadmin() || ($elluminate->creator == $USER->id)) {
                echo ' <a href="' . $CFG->wwwroot . '/mod/elluminate/view.php?id=' . $cm->id .
                     '&amp;delrecording=' . $recording->id . '" title="' .
                     get_string('deletethisrecording', 'elluminate') . '"><img src="' .
                     $CFG->pixpath . '/t/delete.gif" width="11" height="11"/></a>';
            }

            echo '</td></tr>';
        }
    }

/// Display an attendance page if attendance was recorded for this meeting.
    if (isteacheredit($course->id, $USER->id) && $elluminate->grade && (time() > $meeting->end)) {
        echo '<tr valign="top">';
        echo '<td align="center" colspan="2"><a href="' . $CFG->wwwroot . 
             '/mod/elluminate/attendance.php?id=' . $elluminate->id .
             '">' . get_string('meetingattendance', 'elluminate') . '</a>';
        echo '</tr>';
    }

    echo '</table></form>';
    print_simple_box_end();

/// Finish the page
    print_footer($course);

?>