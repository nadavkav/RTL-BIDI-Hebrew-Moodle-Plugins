<?php // $Id: lib.php,v 1.3 2008/06/24 13:11:52 jfilip Exp $

/**
 * Elluminate Live! Module
 *
 * Allows Elluminate Live! meetings to be created and managed on an
 * Elluminate Live! server via a Moodle activity module.
 *
 * @version $Id: lib.php,v 1.3 2008/06/24 13:11:52 jfilip Exp $
 * @author Justin Filip <jfilip@oktech.ca>
 * @author Remote Learner - http://www.remote-learner.net/
 */

/**
 * Elluminate Live! role types.
 */
define('ELLUMINATELIVE_ROLE_SERVER_ADIMINISTRATOR', 0);
define('ELLUMINATELIVE_ROLE_APPADMIN',              1);
define('ELLUMINATELIVE_ROLE_MODERATOR',             2);
define('ELLUMINATELIVE_ROLE_PARTICIPANT',           3);


/**
 * Elluminate Live! boundary time values (in minutes).
 */
$elluminate_boundary_times = array(
-1  => get_string('choose'),
0  => '0',
15 => '15',
30 => '30',
45 => '45',
60 => '60'
);


/**
 * Elluminate Live! boundary time default value.
 */
define('ELLUMINATELIVE_BOUNDARY_DEFAULT', 15);


/**
 * Elluminate Live! seat reservation enabled string.
 */
define('ELLUMINATELIVE_SEAT_RESERVATION_ENABLED', 'preferred');


/**
 * Elluminate Live! recording values.
 */
//define('ELLUMINATELIVE_RECORDING_NONE',      0);
//define('ELLUMINATELIVE_RECORDING_MANUAL',    1);
//define('ELLUMINATELIVE_RECORDING_AUTOMATIC', 3);

define('ELLUMINATELIVE_RECORDING_NONE_NAME',      'off');
define('ELLUMINATELIVE_RECORDING_MANUAL_NAME',    'remote');
define('ELLUMINATELIVE_RECORDING_AUTOMATIC_NAME', 'on');


/**
 * Elluminate Live! recording Type
 */
define('ELLUMINATELIVE_RECORDING_TYPE_MANUAL', 1);
define('ELLUMINATELIVE_RECORDING_TYPE_AUTO', 2);
define('ELLUMINATELIVE_RECORDING_TYPE_DISABLED', 3);

/**
 * The Elluminate Live! XML namespace.
 */
define('ELLUMINATELIVE_XMLNS', 'http://www.soapware.org/');


/**
 * How many times should we attempt to create an Elluminate Live! user account by adding an
 * increasing integer on the end of a user name?
 */
define('ELLUMINATELIVE_CREATE_USER_TRIES', 20);


/**
 * Set to true so that any reminded added will have its time value set to trigger a message sent
 * at the next cron run.
 */
define('REMINDER_DEBUG', false);


/**
 * Reminder types
 */
define('REMINDER_TYPE_DELTA',    0);
define('REMINDER_TYPE_INTERVAL', 1);


/**
 * When adding a new event, we can't calculate the number of available days so
 * we just give a fairly large number of days to choose from.  The actual
 * value can be edited with the event later and then only an appropriate number
 * of days will be avaiable for chosing.
 */
define('REMINDER_DELTA_DEFAULT', 86400); // 1 day (24 * 60 * 60)


function elluminate_add_instance($elluminate) {
    global $CFG;
    global $USER;
    if (!$elmuser = get_record('elluminate_users', 'userid', $USER->id)) {
        return false;
    }

    $start = make_timestamp($elluminate->syear, $elluminate->smonth,
    $elluminate->sday, $elluminate->shour,
    $elluminate->sminute);

    $end = make_timestamp($elluminate->eyear, $elluminate->emonth,
    $elluminate->eday, $elluminate->ehour,
    $elluminate->eminute);

    /// The start and end times don't make sense.
    if ($start > $end) {
        $a = new stdClass;
        $a->timestart = userdate($start);
        $a->timeend   = userdate($end);

        redirect($CFG->wwwroot . '/course/mod.php?id=' . $elluminate->course . '&amp;section=' .
        $elluminate->section . '&amp;sesskey=' . $USER->sesskey . '&amp;add=elluminate',
        get_string('invalidmeetingtimes', 'elluminate', $a), 5);
    }

    $elluminate->creator = $USER->id;

    /// Attempt to add this meeting on the Elluminate Live! server.

    $search =  array("!", "@", "#", "$", "%", "^", "?", "&", "/", "\\", "'", ";", "\"", ",", ".", "<", ">");
    $replace = ' ';

    /// The Elluminate Live! server can't store certain characters in a meeting name.
    $name = str_replace($search, $replace, stripslashes($elluminate->name));
    $elluminate->name = stripslashes($elluminate->name);

//    if (!is_int($elluminate->seats)) {
//        $elluminate->seats = 0;
//    }

    //$elluminate->seats = intval(trim($elluminate->seats));


    /// Adjust boundary time for this meeting.
    if ($CFG->elluminate_boundary_default != -1)
    {
        $boundaryTime = $CFG->elluminate_boundary_default;
    } else
    {
        $boundaryTime = $elluminate->boundary_time;
    }

    $result = elluminate_create_meeting($start, $end, $name, $elmuser->elm_id, '', true,
    0, $boundaryTime, $elluminate->recorded);

    if (!$result || $result == false) {
        redirect($CFG->wwwroot . '/course/view.php?id=' . $elluminate->course,
                     'Could not add this meeting on the Elluminate Live! server.', 5);
    }

    /// Adjust recording setting for this meeting.
    switch($elluminate->recorded) {
        case ELLUMINATELIVE_RECORDING_TYPE_MANUAL:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_MANUAL;
            break;
        case ELLUMINATELIVE_RECORDING_TYPE_AUTO:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_AUTO;
            break;
        case ELLUMINATELIVE_RECORDING_TYPE_DISABLED:
        default:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_DISABLED;
            break;
    }

    //        if (!elluminate_set_meeting_parameters($result->meetingid, '', '', '', $recording)) {
    //            return false;
    //        }

    $elluminate->meetingid        = $result->meetingid;
    $elluminate->meetingtimebegin = $start;
    $elluminate->meetingtimeend   = $end;
    $elluminate->timemodified     = time();

    if (!$elluminate->id = insert_record('elluminate', $elluminate)) {
        return false;
    }

    /// If this is a private meeting, make sure to add an event for the creator.
    if ($elluminate->private) {
        elluminate_add_users($result->meetingid, array($USER->id), true);
    }

    if (!elluminate_cal_edit($elluminate->meetingid)) {
        return false;
    }

    return $elluminate->id;
}


function elluminate_update_instance($elluminate) {
    global $CFG;
    global $USER;

    $meeting = get_record('elluminate', 'id', $elluminate->instance);

    $elluminate->timemodified = time();
    $elluminate->id           = $elluminate->instance;

    $start = make_timestamp($elluminate->syear, $elluminate->smonth,
    $elluminate->sday, $elluminate->shour,
    $elluminate->sminute);
    $end   = make_timestamp($elluminate->eyear, $elluminate->emonth,
    $elluminate->eday, $elluminate->ehour,
    $elluminate->eminute);

    /// The start and end times don't make sense.
    if ($start > $end) {
        /// Get the course module ID for this instance.
        $sql = "SELECT cm.id
                    FROM {$CFG->prefix}modules m,
                    {$CFG->prefix}course_modules cm
                    WHERE m.name = 'elluminate'
                    AND cm.module = m.id
                    AND cm.instance = '{$elluminate->id}'";

                    if (!$cmid = get_field_sql($sql)) {
                        redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $elluminate->id,
                         'The meeting start time of ' . userdate($start) . ' is after the meeting end' .
                         'time of ' . userdate($end), 5);
                    }

                    redirect($CFG->wwwroot . '/course/mod.php?update=' . $cmid . '&amp;return=true&amp;' .
                     'sesskey=' . $USER->sesskey,
                     'The meeting start time of ' . userdate($start) . ' is after the meeting end' .
                     'time of ' . userdate($end), 5);
    }

    /// If the grade value for attendance has changed, modify any existing attendance records.
    if ($elluminate->grade != $meeting->grade) {
        if ($attendance = get_records('elluminate_attendance', 'elluminateid', $meeting->id)) {
            foreach ($attendance as $attendee) {
                if ($attendee->grade > 0) {
                    /// We're using a scale.
                    if ($elluminate->grade < 0) {
                        $grades = make_grades_menu($elluminate->grade);
                        $attendee->grade = key($grades);

                        /// We're using a numerical value.
                    } else {
                        $attendee->grade = $elluminate->grade;
                    }

                    update_record('elluminate_attendance', $attendee);
                }
            }
        }
    }

    /// Attempt to update this meeting on the Elluminate Live! server.
    $elmuser = get_record('elluminate_users', 'userid', $USER->id);

    $search =  array("!", "@", "#", "$", "%", "^", "?", "&", "/", "'", ";", "\"", ",", ".", "<", ">");
    $replace = ' ';

    $creatorid = get_field('elluminate_users', 'elm_id', 'userid', $meeting->creator);


    /// The Elluminate Live! server can't store certain characters in a meeting name.
    $name = str_replace($search, $replace, stripslashes($elluminate->name));
    $elluminate->name = stripslashes($elluminate->name);


//    if (!is_int($elluminate->seats)) {
//        $elluminate->seats = 0;
//    }

    //$elluminate->seats = intval(trim($elluminate->seats));

    /// Adjust boundary time for this meeting.
    if ($CFG->elluminate_boundary_default != -1)
    {
        $boundaryTime = $CFG->elluminate_boundary_default;
    } else
    {
        $boundaryTime = $elluminate->boundary_time;
    }

    $result = elluminate_update_meeting($meeting->meetingid, $start, $end, $name,
    $creatorid, '', true, 0, $boundaryTime, $elluminate->recorded);


    if (!empty($elluminate->seats))
    {
        if (!$result)
        {
            redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $elluminate->id,
                         'Could not change seat reservation for this meeting.', 5);
        }

        if (is_string($result) || !$result)
        {
            if (strstr($result, 'Not enough seats available to create meeting!'))
            {
                $seats = elluminate_get_max_available_seats($start, $end, "$meeting->id");

                if (!elluminate_update_meeting($meeting->meetingid, $start, $end, $name,
                    $meeting->creator, '', true, 0, $boundaryTime, $elluminate->recorded))
                {
                    return false;
                }
            }
        }
    } else if (!$result) {
        redirect($CFG->wwwroot . '/mod/elluminate/view.php?id=' . $elluminate->id,
                     'Could not update this meeting on the Elluminate Live! server.', 5);
    }

    /// Adjust recording setting for this meeting.
    switch($elluminate->recorded) {
        case ELLUMINATELIVE_RECORDING_TYPE_MANUAL:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_MANUAL;
            break;
        case ELLUMINATELIVE_RECORDING_TYPE_AUTO:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_AUTO;
            break;
        case ELLUMINATELIVE_RECORDING_TYPE_DISABLED:
        default:
            $recording = ELLUMINATELIVE_RECORDING_TYPE_DISABLED;
            break;
    }

//    if (!elluminate_set_meeting_parameters($meeting->meetingid, '', '', '', $recording)) {
//        return false;
//    }



    if (!$result) {
        return false;
    }

    update_record('elluminate', $elluminate);

    return elluminate_cal_edit($meeting->meetingid);
}


function elluminate_delete_instance($id) {
    /// Given an ID of an instance of this module,
    /// this function will permanently delete the instance
    /// and any data that depends on it.

    //print_r("delete instance");

    if (!$elluminate = get_record('elluminate', 'id', $id)) {
        return false;
    }

    if (!elluminate_delete_meeting($elluminate->meetingid)) {
        return false;
    }


    /// Delete all the event records assosciated with this meeting.
    elluminate_cal_edit($elluminate->meetingid, true);


    /// Clean up any recordings stored for this meeting.
    delete_records('elluminate_recordings', 'meetingid', $elluminate->meetingid);

    if (!delete_records('elluminate', 'id', $id)) {
        return false;
    }

    return true;
}


function display_grade($grade, $elluminate) {

    static $scalegrades = array();   // Cache scales for each assignment - they might have different scales!!

    if ($elluminate->grade >= 0) {    // Normal number
        if ($grade == -1) {
            return '-';
        } else {
            return $grade.' / '.$elluminate->grade;
        }

    } else {                                // Scale
        if (empty($scalegrades[$elluminate->id])) {
            if ($scale = get_record('scale', 'id', -($elluminate->grade))) {
                $scalegrades[$elluminate->id] = make_menu_from_list($scale->scale);
            } else {
                return '-';
            }
        }
        if (isset($scalegrades[$elluminate->id][$grade])) {
            return $scalegrades[$elluminate->id][$grade];
        }
        return '-';
    }
}


function elluminate_user_outline($course, $user, $mod, $elluminate) {
    /// Return a small object with summary information about what a
    /// user has done with a given particular instance of this module
    /// Used for user activity reports.
    /// $return->time = the time they did it
    /// $return->info = a short text description
    if ($attendance = get_record('elluminate_attendance', 'userid', $user->id,
                                     'elluminateid', $elluminate->id)) {
    $result = new Object();

    $result->info = get_string('grade').': '.display_grade($attendance->grade, $elluminate);
    $result->time = $attendance->timemodified;

    return $result;
                                     }
                                     return NULL;
}


function elluminate_user_complete($course, $user, $mod, $elluminate) {
    /// Print a detailed representation of what a  user has done with
    /// a given particular instance of this module, for user activity reports.
    if ($attendance = get_record('elluminate_attendance', 'userid', $user->id,
                                     'elluminateid', $elluminate->id)) {
    print_simple_box_start();
    echo get_string('attended', 'elluminate'). ': ';
    echo userdate($attendance->timemodified);

    print_simple_box_end();

                                     } else {
                                         print_string('notattendedyet', 'elluminate');
                                     }
}


function elluminate_print_recent_activity($course, $isteacher, $timestart) {
    /// Given a course and a time, this module should find recent activity
    /// that has occurred in elluminate activities and print it out.
    /// Return true if there was output, or false is there was none.

    global $CFG;

    $content  = false;
    $meetings = NULL;

    if (!$logs = get_records_select('log', 'time > \''.$timestart.'\' AND '.
                                               'course = \''.$course->id.'\' AND '.
                                               'module = \'elluminate\' AND '.
                                               'action = \'view meeting\' ', 'time ASC')) {
    return false;
                                               }

                                               foreach ($logs as $log) {
                                                   //Create a temp valid module structure (course,id)
                                                   $tempmod = new Object();
                                                   $tempmod->course = $log->course;
                                                   $tempmod->id     = $log->info;
                                                   //Obtain the visible property from the instance
                                                   $modvisible = instance_is_visible($log->module,$tempmod);

                                                   //Only if the mod is visible
                                                   if ($modvisible) {
                                                       $meetings[$log->info] = get_record_sql("SELECT e.name, u.firstname, u.lastname
                                                           FROM {$CFG->prefix}elluminate e,
                                                           {$CFG->prefix}user u
                                                           WHERE e.id = '$log->info'
                                                           AND u.id = '$log->userid'");
                                                           $meetings[$log->info]->time = $log->time;
                                                           $meetings[$log->info]->url  = str_replace('&', '&amp;', $log->url);
                                                   }
                                               }

                                               if ($meetings) {
                                                   print_headline(get_string('newsubmissions', 'assignment').':');
                                                   foreach ($meetings as $meeting) {
                                                       print_recent_activity_note($meeting->time, $meeting, $isteacher, stripslashes($meeting->name),
                                                       $CFG->wwwroot.'/mod/elluminate/'.$meeting->url);
                                                   }
                                                   $content = true;
                                               }

                                               return $content;
}


function elluminate_cron () {
    /// Function to be run periodically according to the moodle cron
    /// This function searches for things that need to be done, such
    /// as sending out mail, toggling flags etc ...

    global $CFG;

    /// If the plug-in is not configured to coonect to Elluminate, return.
    if (empty($CFG->elluminate_auth_username) ||
    empty($CFG->elluminate_auth_username)) {
        return true;
    }

    if ($recordings = elluminate_list_all_recordings()) {
        foreach ($recordings as $recording) {
            if (record_exists('elluminate', 'meetingid', $recording->meetingid)) {
                if (!record_exists('elluminate_recordings', 'recordingid', $recording->recordingid)) {
                    $er = new Object();
                    $er->meetingid   = $recording->meetingid;
                    $er->recordingid = $recording->recordingid;
                    $er->created     = $recording->created;

                    insert_record('elluminate_recordings', $er);
                }
            }
        }
    }

    /// Clean elluminate/moodle user metadata table
    if ($users = get_records_select('elluminate_users')) {
        foreach ($users as $user) {

            /// Ensure that the elmuserid is equal to the moodle userid
            /// since we no longer create elluminate users
            if ($user->userid != $user->elm_id)
            {
                $user->elm_id = $user->userid;
                update_record('elluminate_users', $user);
            }

            if (!$moodleuser = get_record('user', 'id', $user->userid)) {
                elluminate_delete_user($user->elm_id);
            }
            else {
                if ( $moodleuser->deleted == true ) {
                    elluminate_delete_user($user->elm_id);
                }
            }
        }
    }


    return true;
}


function elluminate_grades($elluminateid) {
    if (!$elluminate = get_record('elluminate', 'id', $elluminateid)) {
        return NULL;
    }

    if ($elluminate->grade == 0) { // No grading
        return NULL;
    }

    $return = new Object();

    $grades = get_records_menu('elluminate_attendance', 'elluminateid',
    $elluminateid, '', 'userid,grade');

    if ($elluminate->grade > 0) {
        if ($grades) {
            foreach ($grades as $userid => $grade) {
                if ($grade == -1) {
                    $grades[$userid] = '-';
                }
            }
        }
        $return->grades   = $grades;
        $return->maxgrade = $elluminate->grade;

    } else { // Scale
        if ($grades) {
            $scaleid = - ($elluminate->grade);
            $maxgrade = "";
            if ($scale = get_record('scale', 'id', $scaleid)) {
                $scalegrades = make_menu_from_list($scale->scale);
                foreach ($grades as $userid => $grade) {
                    if (empty($scalegrades[$grade])) {
                        $grades[$userid] = '-';
                    } else {
                        $grades[$userid] = $scalegrades[$grade];
                    }
                }
                $maxgrade = $scale->name;
            }
        }
        $return->grades   = $grades;
        $return->maxgrade = $maxgrade;
    }

    return $return;
}


function elluminate_get_participants($elluminateid) {
    //Must return an array of user records (all data) who are participants
    //for a given instance of elluminate. Must include every user involved
    //in the instance, independient of his role (student, teacher, admin...)
    //See other modules as example.

    if (!$meeting = get_record('elluminate', 'id', $elluminateid)) {
        return false;
    }

    $participants = array();

    if ($moderators = elluminate_get_meeting_participants($meeting->meetingid, true)) {
        array_merge($participants, $moderators);
    }

    if ($users = elluminate_get_meeting_participants($meeting->meetingid)) {
        array_merge($participants, $users);
    }

    if (!empty($participants)) {
        return $participants;
    }

    return false;
}


function elluminate_scale_used ($elluminateid,$scaleid) {
    //This function returns if a scale is being used by one elluminate
    //it it has support for grading and scales. Commented code should be
    //modified if necessary. See forum, glossary or journal modules
    //as reference.

    $return = false;

    $rec = get_record("elluminate","id","$elluminateid","grade","-$scaleid");

    if (!empty($rec)  && !empty($scaleid)) {
        $return = true;
    }

    return $return;
}


/**
 * Process the module config options from the main settings page to remove
 * any spaces from the beginning of end of the string input fields.
 *
 * @param &$config Reference to the form config data.
 * @return none
 */
function elluminate_process_options(&$config) {
    $config->server        = trim($config->server);
    $config->adapter       = trim($config->adapter);
    $config->auth_username = trim($config->auth_username);
    $config->auth_password = trim($config->auth_password);
}


/**
 * Returns an array of user objects reprsenting the participants for a given
 * meeting.
 *
 * @uses $CFG
 * @param int $meetingid The meeting ID to get the participants list for.
 * @param string $fields A comma-separated list of fields to return.
 * @return array An aray of user objects.
 */
function elluminate_get_meeting_participants($meetingid, $moderator = false) {
    global $CFG;

    $users = array();

    if ($moderator) {
        $participants = elluminate_list_participants($meetingid, ELLUMINATELIVE_ROLE_MODERATOR);
    } else {
        $participants = elluminate_list_participants($meetingid, ELLUMINATELIVE_ROLE_PARTICIPANT);
    }

    if (!empty($participants)) {
        foreach ($participants as $participant) {

            if ($participant['user'])
            {
                $sql = "SELECT mu.*, eu.elm_id
                  FROM {$CFG->prefix}user mu
                  LEFT JOIN {$CFG->prefix}elluminate_users eu ON eu.userid = mu.id
                  WHERE eu.elm_id = {$participant['user']}";

                if ($user = get_record_sql($sql)) {
                    $users[] = $user;
                }
      }
        }
    }

    return $users;
}


/**
 * Find and return all the events assosciated with a given meeting.
 *
 * An event for a specific meeting has the meeting ID in a SPAN tag
 * surrounding the title of the format:
 *
 * <span id="elm-ID"> ... </span>
 *
 * Where ID is the meeting ID in question.
 *
 * @uses $CFG
 * @param long $meetingid The Elluminate Live! meeting ID.
 * @return array An array of events.
 */
function elluminate_get_events($meetingid) {
    global $CFG;

    $sql = "SELECT e.*
                FROM {$CFG->prefix}event e
                WHERE e.modulename = 'elluminate'
                AND e.instance = $meetingid";

    $events = get_records_sql($sql);
    return $events;
}


function elluminate_has_course_event($meetingid) {
    global $CFG;

    if (!$meeting = get_record('elluminate', 'meetingid', $meetingid)) {
        return false;
    }

    $sql = "SELECT *
                FROM {$CFG->prefix}event
                WHERE modulename = 'elluminate'
                AND instance = {$meeting->id}
                AND courseid = {$meeting->course}";

    return record_exists_sql($sql);
}


/**
 * Find and return a list of users who currently have events assosciated
 * with a given meeting.  This is useful when either adding new users or
 * deleting users from a private event.
 *
 * @uses $CFG
 * @param long $meetingid The Elluminate Live! meeting record ID.
 * @return array An array of user IDs.
 */
function elluminate_get_event_users($meetingid) {
    global $CFG;

    if (!$meeting = get_record('elluminate', 'meetingid', $meetingid)) {
        return false;
    }

    $sql = "SELECT u.id
                FROM {$CFG->prefix}user u
                LEFT JOIN {$CFG->prefix}event ON e.userid = u.id
                WHERE e.modulename = 'elluminate'
                AND e.instance = {$meeting->id}
                AND e.courseid = {$meeting->course}";

    return get_records_sql($sql);
}


/**
 * Add a list of users to a given meeting.  Also handles adding the calendar
 * event and any assosciated reminders for the user.  The latter action can
 * only occur with a private meeting.
 *
 * If $moderators is not set to true, the users will be added as participants.
 *
 * @param long $meetingid The Elluminate Live! meeting ID.
 * @param array $userids A list of user IDs to add to the meeting.
 * @param boolean $moderators True if the users being added are moderators.
 * @return boolean True on success, False otherwise.
 */
function elluminate_add_users($meetingid, $userids, $moderators = false)
{
    if (!$meeting = get_record('elluminate', 'meetingid', $meetingid))
    {
        return false;
    }

    if (!$elmmeeting = elluminate_get_meeting($meetingid))
    {
        return false;
    }

    /// Basic event record for the database.
    $event = new Object();
    $event->name         = addslashes(get_string('calendarname', 'elluminate', stripslashes($meeting->name)));
    $event->description  = $meeting->description;
    $event->format       = 1;
    $event->courseid     = 0;
    $event->groupid      = 0;
    $event->modulename   = 'elluminate';
    $event->instance     = $meeting->id;
    $event->eventtype    = '';
    $event->visible      = 1;
    $event->timestart    = $elmmeeting->start;
    $duration            = $elmmeeting->end - $elmmeeting->start;
    if ($duration < 0)
    {
        $event->timeduration = 0;
    }
    else
    {
        $event->timeduration = $duration;
    }

    foreach ($userids as $userid)
    {
        $elmuser = get_record('elluminate_users', 'userid', $userid);
        if($elmuser == false)
        {
            elluminate_new_user($userid, random_string(10));
            $elmuser = get_record('elluminate_users', 'userid', $userid);
        }

        if ($moderators)
        {
            if (!elluminate_add_participant($meetingid, $elmuser->elm_id, true))
            {
                return false;
            }
        }
        else
        {
            if (!elluminate_add_participant($meetingid, $elmuser->elm_id, false))
            {
                return false;
            }
        }

        /// Add a new event for this user.
        $event->userid       = $userid;
        $event->timemodified = time();

        $event->id = insert_record('event', $event);
    }

    return true;
}


/**
 * Remove a list of users from a given meeting.  Also handles removing the
 * calendar event and any assosciated reminders for the user.  This action
 * can only occur with a private meeting.
 *
 * If $moderators is not set to true, the users will be removed from the
 *
 * @uses $CFG
 * @param long $meetingid The Elluminate Live! meeting ID.
 * @param array $userids A list of Elluminate Live! user IDs to remove from the meeting.
 * @param boolean $moderators True if the users being removed are moderators.
 * @param boolean $force Whether to force an override of the behviour for not
 *                       deleting the meeting creator.
 * @return boolean True on success, False otherwise.
 */
function elluminate_del_users($meetingid, $userids, $moderators = false, $force = false) {
    global $CFG;

    $muserids = array();

    $creator = get_field('elluminate', 'creator', 'meetingid', $meetingid);

    /// Remove each user from the meeting on the Elluminate Live! server.
    foreach ($userids as $userid) {
        if (!$force && ($userid != $creator)) {
            $elmuser = get_record('elluminate_users', 'userid', $userid);

            $muserids[] = $userid;
        }
    }

    if (empty($muserids)) {
        return true;
    }

    if (!elluminate_delete_participants($meetingid, $muserids)) {
        return false;
    }

    $id = get_field('elluminate', 'id', 'meetingid', $meetingid);

    /// Delete the associated user events.
    if (count($muserids) > 1) {
        $sql = "DELETE FROM {$CFG->prefix}event
                    WHERE modulename = 'elluminatelve'
                    AND instance = $id
                    AND userid IN ( " . implode(',', $muserids) . " )";
    } else {
        $sql = "DELETE FROM {$CFG->prefix}event
                    WHERE modulename = 'elluminate'
                    AND instance = $id
                    AND userid = {$muserids[0]}";
    }

    return execute_sql($sql, false);
}


/**
 * Adds or edits an existing calendar event for an assosciated meeting.
 *
 * There aqre two possible meeting configurations:
 * 1. A private meeting where only the people chosen to be particpants
 *    are allowed access.
 * 2. A public meeting where anyone in a given course is allowed to
 *    access to meeting.
 *
 * We must handle adding and removing users to a private meeting and also
 * deleteing unnecessary events when a meeting changes from private to
 * public and vice versa.
 *
 * @uses $CFG
 * @param int $meetingid The meeting ID to edit the calendar event for.
 * @param boolean $delete Whether the meeting is being deleted.
 * @return boolean True on success, False otherwise.
 */
function elluminate_cal_edit($meetingid, $delete = false) {
    global $CFG;

    if (!$meeting = get_record('elluminate', 'meetingid', $meetingid)) {
        return false;
    }

    /// Special action if we're deleting a meeting.
    if ($delete) {
        if ($events = elluminate_get_events($meeting->id)) {
            foreach ($events as $event) {
                delete_records('event', 'id', $event->id);
            }
        }

        return true;
    }

    if (!$elmmeeting = elluminate_get_meeting($meetingid)) {
        return false;
    }

    if ($meeting->private) {
        /// If this meeting has been newly marked private, delete the old, public,
        /// event record.
        $admin = get_admin();

        $sql = "DELETE FROM `{$CFG->prefix}event`
                    WHERE modulename = 'elluminate'
                    AND instance = $meeting->id
                    AND courseid = $meeting->course
                    AND userid = $admin->id";

        execute_sql($sql, false);

    } else if (!$meeting->private && !elluminate_has_course_event($meetingid)) {
        /// Create the new course event.
        $admin = get_admin();

        $event = new Object();
        $event->name         = get_string('calendarname', 'elluminate', $meeting->name);
        $event->description  = $meeting->description;
        $event->format       = 1;
        $event->courseid     = $meeting->course;
        $event->groupid      = 0;
        $event->userid       = $admin->id;
        $event->modulename   = 'elluminate';
        $event->instance     = $meeting->id;
        $event->eventtype    = '';
        $event->visible      = 1;
        $event->timestart    = $elmmeeting->start;
        $duration            = $elmmeeting->end - $elmmeeting->start;
        if ($duration < 0){
            $event->timeduration = 0;
        } else {
            $event->timeduration = $duration;
        }
        $event->timemodified = time();

        $event->id = insert_record('event', $event);

        return true;
    }

    /// Modifying any existing events.
    if ($events = elluminate_get_events($meeting->id)) {
        foreach($events as $event) {
            /// Delete any non-moderator events if this meeting is public...
            $deleted = false;

            if (empty($meeting->private) && empty($event->userid)) {
                if ($elm_id = get_field('elluminate_users', 'elm_id', 'userid', $event->userid)) {
                    if (!elluminate_is_participant($meetingid, $elm_id, true)) {
                        delete_records('event', 'id', $event->id);

                        $deleted = true;
                    }
                }
            }

            if (!$deleted) {
                $event->name         = addslashes(get_string('calendarname', 'elluminate', $meeting->name));
                $event->description  = addslashes($meeting->description);

                $event->timestart    = $elmmeeting->start;
                $duration            = $elmmeeting->end - $elmmeeting->start;

                if ($duration < 0){
                    $event->timeduration = 0;
                } else {
                    $event->timeduration = $duration;
                }

                $eventtimemodified = time();

                if (!update_record('event', $event)) {
                    return false;
                }
            }
        }
    }

    return true;
}



/**
 * ===========================================================================
 * The following are all functions dealing with handling reminders attached
 * to a calendar event.
 * ===========================================================================
 */



/**
 * Adds a reminder for a calendar event.
 *
 * Please note that the last three parameters are only necessary when using
 * the REMINDER_TYPE_INTERVAL (1).
 *
 * @param int $eventid ID of the event to add a reminder for.
 * @param int $rtype The type of reminder.
 * @param int $timedelta The time before the event to send the reminder.
 * @param int $timeinterval The time between reminders being sent.
 * @param int $timeend The point past which no reminders will be send (the
 *                     default ending time is the event itself).
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_add_reminder($eventid, $rtype = 0, $timedelta = 0,
$timeinterval = 0, $timeend = 0) {
    // Make sure the event exists
    if (!$event = get_record('event', 'id', intval($eventid))) {
        error('Invalid event ID: ' . $eventid);
    }

    // Just check to make sure we have a valid reminder type
    switch($rtype) {
        case REMINDER_TYPE_DELTA:
        case REMINDER_TYPE_INTERVAL:
            break;
        default:
            return false;
            break;
    }

    // Create the new reminder object for the database
    $reminder = new stdClass;
    $reminder->event        = intval($event->id);
    $reminder->type         = intval($rtype);
    $reminder->timedelta    = intval($timedelta);
    $reminder->timeinterval = intval($timeinterval);
    $reminder->timeend      = intval($timeend);
    $reminder->id = insert_record('event_reminder', $reminder);

    if (!$reminder->id) {
        return false;
    }

    // Send the reminder immediately (for testing purposes)
    if (REMINDER_DEBUG) {
        elluminate_reminder_send($reminder->id);
        elluminate_reminder_remove($reminder->id);
    }

    return true;
}


/**
 * Removes a calendar event reminder.
 *
 * @param int $reminderid ID of the reminder to delete.
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_remove($reminderid) {
    if (!delete_records('event_reminder', 'id', intval($reminderid))) {
        return false;
    }

    return true;
}


/**
 * Edits an existing calendar event reminder.
 *
 * @param int $reminderid ID of the reminder to edit.
 * @param int $rtype The type of reminder.
 * @param int $timedelta The time before the event to send the reminder.
 * @param int $timeinterval The time between reminders being sent.
 * @param int $timeend The point past which no reminders will be send (the
 *                     default ending time is the event itself).
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_edit($reminderid, $rtype, $timedelta = 0,
$timeinterval = 0, $timeend = 0) {

    $reminderid   = intval($reminderid);
    $rtype        = intval($rtype);
    $timedelta    = intval($timedelta);
    $timeinterval = intval($timeinterval);
    $timeend      = intval($timeend);

    // Make sure the reminder exists
    if (!$reminder = get_record('event_reminder', 'id', $reminderid)) {
        return false;
    }

    // Modify any parameters that have changed
    if ($rtype and $rtype != $reminder->type) {
        $reminder->type = $rtype;
    }
    if ($timedelta and $timedelta != $reminder->timedelta) {
        $reminder->timedelta = $timedelta;
    }
    if ($timeinterval and $timeinterval != $reminder->timeinterval) {
        $reminder->timeinterval = $timeinterval;
    }
    if ($timeend and $reminder->timeend != $timeend) {
        $reminder->timeend = $timeend;
    }

    // Attempt to update the database record
    if (!update_record('event_reminder', $reminder)) {
        return false;
    }

    return true;
}


/**
 * Checks if a calendar event has any reminders assosicated with it and
 * returns them as an array of objects.  If there are no reminders returns
 * NULL instead.
 *
 * @param int $meetingid ID of the event to check for reminders.
 * @return array An array of reminder objects or NULL.
 */
function elluminate_reminder_get_reminders($meetingid) {
    // Make sure the event exists
    if (!$meeting = get_record('event', 'id', intval($meetingid))) {
        error('Invalid meeting ID: ' . $meetingid);
    }


    // Get records
    if (!$reminders = get_records('event_reminder', 'event', $event->id, 'timedelta ASC')) {
        return NULL;
    }

    return $reminders;
}


/**
 * Displays the HTML to edit / delete existing reminders and / or to add a new
 * reminder to an Elluminate Live! meeting.
 *
 * @param int $meetingid ID of the meeting HTML form we are drawing into (leave
 *                       blank to just draw the form elements to add a new
 *                       reminder.
 * @return none
 */
function elluminate_reminder_draw_form($meetingid = 0) {
    if ($meetingid) {
        if (!$meeting = get_record('elluminate', 'id', intval($meetingid))) {
            return;
        }
    }

    // Setup available number of days and hours
    $days  = array();
    $hours = array();

    // How many days can we choose from before the event in question?
    if ($meetingid) {
        $delta = $elluminate->meetingtimebegin - time();
    } else {
        $delta = REMINDER_DELTA_DEFAULT;
    }

    // Setup values for the select lists on the form
    $dayscount = floor($delta / (24 * 60 * 60));

    for ($i = 0; $i <= $dayscount; $i++) {
        $days[] = $i;
    }
    for ($i = 0; $i < 24; $i++) {
        $hours[] = $i;
    }

    // Print out any existing event reminders
    if($meetingid) {
        if ($reminders = elluminate_reminder_get_reminders($meeting->id)) {
            ?>
<tr>
  <td></td>
  <td>
  <fieldset><legend><?php print_string('formreminders', 'event_reminder'); ?></legend> <?php
  foreach($reminders as $reminder) {
      $remindername = 'reminder' . $reminder->id;

      ?>
  <div><input type="checkbox" name="reminderdeleteids[]" value="<?php echo $reminder->id; ?>" /> <?php print_string('formtimebeforeevent', 'event_reminder'); ?>
  <?php

  $day  = floor($reminder->timedelta / (24 * 60 * 60));
  $hour = ($reminder->timedelta - ($day * 24 * 60 * 60)) / (60 * 60);

  choose_from_menu($days, $remindername . '_days', $day, '');
  print_string('formdays', 'event_reminder');
  choose_from_menu($hours, $remindername . '_hours', $hour, '');
  print_string('formhours', 'event_reminder');

  ?></div>
  <br />
  <?php

}

?> <input type="submit" name="reminder_delete"
    value="<?php print_string('formdeleteselectedreminders', 'event_reminder'); ?>" /> <?php

}
}

?></fieldset>
  </td>
</tr>
<tr>
  <td colspan="2">
  <hr />
  <p><?php print_string('formaddnewreminder', 'event_reminder'); ?></p>
  </td>
</tr>
<tr>
  <td></td>
  <td>
  <div><?php print_string('formtimebeforeevent', 'event_reminder'); ?> <?php

  choose_from_menu($days, 'remindernew_days', '', '');
  print_string('formdays', 'event_reminder');
  choose_from_menu($hours, 'remindernew_hours', '', '');
  print_string('formhours', 'event_reminder');

  ?></div>
  </td>
</tr>
  <?php

}


/**
 * Determines the type of event and returns that type as a string.
 *
 * @param int $eventid The ID of the event.
 * @return string The type of the event.
 */
function elluminate_reminder_event_type($eventid) {
    // Make sure the event exists
    if (!$event = get_record('event', 'id', intval($eventid))) {
        error('Invalid event ID: ' . $eventid);
    }

    $type = 'none';

    // Determine the type of event
    if (!$event->courseid and !$event->groupid and $event->userid) {
        $type = 'user';
    } elseif ($event->courseid and !$event->groupid and $event->userid) {
        if ($event->courseid != SITEID) {
            $type = 'course';
        }
    } elseif ($event->courseid and $event->groupid and $event->userid) {
        $type = 'group';
    } else {
        $type = 'none';
    }

    return $type;
}


/**
 * Update the interval start time for a record of the interval type.
 *
 * @param int $reminderid ID of the reminder to update the interval for.
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_interval_update($reminderid) {
    if (!$reminder = get_record('event_reminder', 'id', intval($reminderid))) {
        return false;
    }

    // If the reminder type isn't of the Interval variety, we can't udpate
    // the interval, can we?
    if ($reminder->type != REMINDER_TYPE_INTERVAL) {
        return false;
    }

    // Update the value for the next interval
    $reminder->timedelta += $reminder->timeinterval;

    if (!update_record('event_reminder', $reminder)) {
        return false;
    }

    return true;
}


/**
 * Checks a calendar event to see if any reminders assosciated with it should
 * have a message sent out.
 *
 * @param int $eventid ID of the event to check the reminder times for.
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_check($eventid) {
    // Make sure the event exists
    if (!$event = get_record('event', 'id', intval($eventid))) {
        error('Invalid event ID: ' . $eventid);
    }

    // Get records
    if (!$reminders = get_records('event_reminder', 'event', $event->id)) {
        return false;
    }

    // Check each record to see if the time has passed to issue a reminder
    foreach ($reminders as $reminder) {
        switch($reminder->type) {
            case REMINDER_TYPE_DELTA:
                // If the current time is past the delta before the event,
                // send the message.
                if (time() > $event->timestart - $reminder->timedelta) {
                    //notify(userdate(time()) . ' ' . userdate($reminder->timedelta));
                    //if (time() > $reminder->timedelta) {
                    //                        notify('sending reminder!');
                    elluminate_reminder_send($reminder->id);
                    elluminate_reminder_remove($reminder->id);
                }
                break;

            case REMINDER_TYPE_INTERVAL:
                if (time() > $event->timeend) {
                    // If we are passed the cutoff (end) time for this reminder,
                    // delete the reminder from the system.
                    reminder_remove_reminder($reminder->id);
                } elseif (time() > $event->timedelta) {
                    // If we are passed an interval, send a reminder and update
                    // the interval start time.
                    //                        notify('sending reminder!');
                    elluminate_reminder_send($reminder->id);
                    elluminate_reminder_interval_udpdate($reminder->id);
                }
                break;

            default:
                return false;
                break;
        }
    }

    return true;
}


/**
 * Sends the reminder message for the specified reminder.
 *
 * @param int $reminderid ID of the reminder to send a message for.
 * @return boolean True on success, False otherwise.
 */
function elluminate_reminder_send($reminderid) {
    // Make sure the reminder exists
    if (!$reminder = get_record('event_reminder', 'id', intval($reminderid))) {
        return false;
    }

    // Get the event record that this reminder belongs to
    if (!$event = get_record('event', 'id', $reminder->event)) {
        return false;
    }

    // Determine the type of event
    $type = elluminate_reminder_event_type($event->id);

    // General message information.
    $userfrom = get_admin();
    $site     = get_site();
    $subject  = get_string('remindersubject', 'event_reminder', $site->fullname);
    $message  = elluminate_reminder_message($event->id, $type);

    // Send the reminders to user(s) based on the type of event.
    switch ($type) {
        case 'user':
            // Send a reminder to the user
            if (!empty($CFG->messaging)) {
                // use message system
            } else {
                $user = get_record('user', 'id', $event->userid);
                email_to_user($user, $userfrom, $subject, $message);
                //email_to_user($user, $userfrom, 'Reminder Test', 'Testing!');
            }
            break;

        case 'course':
            // Get all the users in the course and send them the reminder
            $users = get_course_users($event->courseid);

            foreach ($users as $user) {
                if (!empty($CFG->messaging)) {
                    // use message system
                } else {
                    email_to_user($user, $userfrom, $subject, $message);
                }
            }
            break;

        case 'group':
            // Get all the users in the group and send them the reminder
            $users = get_group_users($event->groupid);

            foreach ($users as $user) {
                if (!empty($CFG->messaging)) {
                    // use message system
                } else {
                    email_to_user($user, $userfrom, $subject, $message);
                }
            }
            break;

        default:
            return false;
            break;
    }

    return true;
}


/**
 * Returns a formatted upcoming event reminder message.
 *
 * @param int $eventid The ID of the event to format a message for.
 * @param string $type The type of event to format the message for.
 */
function elluminate_reminder_message($eventid, $type) {
    // Make sure the event exists
    if (!$event = get_record('event', 'id', intval($eventid))) {
        error('Invalid event ID: ' . $eventid);
    }

    switch($type) {
        case 'user':
            $message = get_string('remindermessageuser', 'event_reminder');
            break;

        case 'course':
            // Get the course record to format message variables
            $course = get_record('course', 'id', $event->courseid);
            $message = get_string('remindermessagecourse', 'event_reminder', $course->fullname);
            break;

        case 'group':
            // Get the group record to format message variables
            $group = get_record('groups', 'id' , $event->groupid);
            $message = get_string('remindermessagegroup', 'event_reminder', $group->name);
            break;

        default:
            return NULL;
            break;
    }

    // Add the date for the event and the description for the event to the end of the message.
    $message .= userdate($event->timestart);
    $message .= get_string('remindereventdescription', 'event_reminder', html2text($event->description));

    return $message;
}



/**
 * ===========================================================================
 * The following are all functions that deal with sending web services calls
 * to an Elluminate Live! server.
 * ===========================================================================
 */



/**
 * Sends a command to an Elluminate Live! server via the web services interface.
 *
 * The structure of the command arguments array is a two-dimensional array in
 * the following format:
 *   $args[]['name']  = argument name;
 *   $args[]['value'] = argument value;
 *   $args[]['type']  = argument type (i.e. 'xsd:string');
 *
 * @uses $CFG
 * @param string $command The name of the command.
 * @param array $args Command arguments.
 * @return mixed|boolean The result object/array or False on failure.
 */
function elluminate_send_command($command, $args = NULL) {
    global $CFG;

    $cfgServerUrl = $CFG->elluminate_server;
    $cfgUsername = $CFG->elluminate_auth_username;
    $cfgPassword = $CFG->elluminate_auth_password;

    return elluminate_send_soap_command($cfgServerUrl, $cfgUsername, $cfgPassword, $command, $args);
}

/**
 * ## PUt something here
 *
 *
 *
 *
 */
function elluminate_send_soap_command($cfgServerUrl, $cfgUsername, $cfgPassword, $command, $args = NULL)
{
    global $CFG;

    if (file_exists($CFG->dirroot . '/mod/elluminate/elivenusoap.php'))
    {
        require_once($CFG->dirroot . '/mod/elluminate/elivenusoap.php');
    } else
    {
        error('No SOAP library files found!');
    }

    if (substr($cfgServerUrl, strlen($cfgServerUrl) - 1, 1) != '/')
    {
        $cfgServerUrl .= '/webservice.event';
    } else
    {
        $cfgServerUrl .= 'webservice.event';
    }

    /// Encode parameters and the command and adapter name.
    $params = array();

    if (!empty($args))
    {
        foreach ($args as $arg)
        {
            $params[$arg['name']] = $arg['value'];
        }
    }

    /// Connect to the server.
    $client = new soap_client($cfgServerUrl);
    //$client = new soap_client($wsdlfile, true);
    $client->xml_encoding = "UTF-8";
    //$client->setCredentials($username,$password,'basic');


    /// Add authentication headers.
    $client->setHeaders(
            '<sas:BasicAuth xmlns:h="http://soap-authentication.org/basic/2001/10" mustUnderstand="1">
                    <Name>' . $cfgUsername . '</Name>
                                <Password>' . $cfgPassword . '</Password>
            </sas:BasicAuth>'
//  <Name>jcheng</Name>
//              <Password>*sakai*</Password>
    );

    $mynamespace = 'http://sas.elluminate.com/';

    /// Send the call to the server.
    $result = $client->call($command, $params, $mynamespace);
    //        $result = $client->call('request', $params);

    $result = elluminate_fix_object($result);

    /// If there is an error, notify the user.
    //if(is_$result['success'] != null)
    if(is_object($result))
    {
        if(array_key_exists('success', $result) && $result->success == false)
        {
            /// Check for an HTML 404 error.
            if (!empty($client->response) &&
            ((strstr($client->response, 'HTTP') !== false) &&
            strstr($client->response, '404') !== false)) {
                error('Server not found.');
            }

            $str = '<b>Elluminate Live! error:<br /><br /></b> <i>' . $result->message . '</i>';

            error($str);

            return false;
        }
    }

    return $result;
}

/**
 * Fix objects being returned as associative arrays (to fit with PHP5 SOAP support)
 *
 * @link /lib/soaplib.php - SEE FOR MORE INFO
 */
function elluminate_fix_object($value) {
    if (is_array($value)) {
        $value = array_map('elluminate_fix_object', $value);
        $keys = array_keys($value);


        // ### Add code to deal with doc/literal and multiple element vs single element arrays
        foreach ($keys as $key) {
            if (is_string($key)) {
                $value = (object) $value;
                break;
            }
        }
    }
    return $value;
}


/**
 * This tests for a valid connection to the configured Elluminate Live! server's
 * web service interface.
 *
 * @uses $CFG
 * @param string $serverurl The URL pointing to the Elluminate Live! manager (optional).
 * @param string $adapter   The adapter name (optional).
 * @param string $username  The authentication username (optional).
 * @param string $password  The authentication password (optional).
 * @return boolean True on successful test, False otherwise.
 */
function elluminate_test_connection($serverurl = '', $adapter = '',
$username = '', $password = '') {
    global $CFG;


    if (empty($serverurl)) {
        $serverurl = $CFG->elluminate_server;
    }
    if (empty($adapter)) {
        $adapter = $CFG->elluminate_adapter;
    }
    if (empty($username)) {
        $username = $CFG->elluminate_auth_username;
    }
    if (empty($password)) {
        $password = $CFG->elluminate_auth_password;
    }

    $args = array();


    //## This is required as the test command fails unless there is at least one argument
    $args[0]['name']  = 'testParameter';
    $args[0]['value'] = NULL;
    $args[0]['type']  = 'xsd:string';


    $result = elluminate_send_soap_command($serverurl, $username, $password, 'test', $args);

    if ($result != 'true')
    {
        return false;
    }
    return true;
}


/**
 * ##CHANGE DESCRIPTION!!!!
 *
 * Given a returned user object from an Elluminate Live! server, process
 * the object into a new, Moodle-useable object.
 *
 * The return object (on success) is of the following format:
 *   $user->userid
 *   $user->loginname
 *   $user->email
 *   $user->firstname
 *   $user->lastname
 *   $user->role
 *   $user->deleted
 *
 * @param object $useradapter The returned 'User Adapter' from the server.
 * @return object An object representing the usser.
 */
function elluminate_process_user($id, $loginname, $email, $firstname, $lastname)
{
    $user = new Object();
    $user->userid    = $id;
    $user->loginname = $loginname;
    $user->email     = $email;
    $user->firstname = $firstname;
    $user->lastname  = $lastname;

    if (isadmin($id))
    {
        $role = ELLUMINATELIVE_ROLE_APPADMIN;
    }
    else if (isteacherinanycourse($id))
    {
        $role = ELLUMINATELIVE_ROLE_MODERATOR;
    }
    else
    {
        $role = ELLUMINATELIVE_ROLE_PARTICIPANT;
    }

    $user->role = $role;

    if (!get_record('user', 'id', $id, 'deleted', 'false'))
    {
        $meeting->deleted = false;
    }
    else
    {
        $meeting->deleted = true;
    }

    return $user;
}


/**
 * Given a returned meeting object from an Elluminate Live! server, process
 * the object into a new, Moodle-useable object.
 *
 * The return object (on sucess) is of the following format:
 *   $meeting->meetingid
 *   $meeting->facilitatorid
 *   $meeting->privatemeeting
 *   $meeting->name
 *   $meeting->password
 *   $meeting->start
 *   $meeting->end
 *   $meeting->deleted
 *
 * @param object $meetingadapter The returned 'Meeting Adapter' from the server.
 * @return object An object representing the meeting.
 */
function elluminate_process_meeting($meetingadapter) {
    global $USER;

    $meeting = new Object();

    $meeting->meetingid      = $meetingadapter->meetingId;
    $meeting->facilitatorid  = $USER->id;

    //        switch ($meetingadapter->PrivateMeeting) {
    //            case 'true':
    //                $meeting->privatemeeting = true;
        //                break;
        //            case 'false':
        //                $meeting->privatemeeting = false;
        //                break;
        //        }

        $meeting->privatemeeting = false;
        $meeting->name           = $meetingadapter->name;
        $meeting->password       = '';//$meetingadapter->Password;
        $meeting->start          = substr($meetingadapter->startTime, 0, 10);
        $meeting->end            = substr($meetingadapter->endTime, 0, 10);

        //        switch ($meetingadapter->Deleted) {
        //            case 'true':
        //                $meeting->deleted = true;
        //                break;
        //            case 'false':
        //                break;
        //        }
        $meeting->deleted = false;

        // If $meeetingadapter is a ListMeetingShort object
        if(!array_key_exists('reserveSeats', $meetingadapter))
        {
            $args = array();

            $args[0]['name']  = 'meetingId';
            $args[0]['value'] = $meeting->meetingid;
            $args[0]['type']  = 'xsd:integer';

            $result = elluminate_send_command('listMeetingLong', $args);

            if (is_string($result)) {
                return false;
            } else if (is_object($result)) {
                foreach ($result as $entry) {
                    if (!empty($entry)) {
                        $meeting->boundaryTime = $entry->boundaryTime;
                        $meeting->recordingModeType = $entry->recordingModeType;
                        $meeting->reserveSeats = $entry->reserveSeats;
                    }
                }
            }

        }
        else
        {
            $meeting->boundaryTime = $meetingadapter->boundaryTime;
            $meeting->recordingModeType = $meetingadapter->recordingModeType;
            $meeting->reserveSeats = $meetingadapter->reserveSeats;
        }

        return $meeting;
}


/**
 * Given a returned participant list object from an Elluminate Live! server,
 * process the object into a new, Moodle-useable array of objects.
 *
 * The return array (on sucess) is of the following format:
 *   $participants['user'] = user object
 *   $participants['role'] = user role value
 *
 * @param object $plist The returned 'Participant List Adapter' from the server.
 * @return array An array representing the list of participants and their meeting roles.
 */
function elluminate_process_participant_list($session) {

    $retusers = array();
    $i = 0;

    // Moderators
    $chairtoken = strtok($session->chairList,",");

    while($chairtoken)
    {
        $retusers[$i]['user'] = $chairtoken;
        $retusers[$i]['role'] = ELLUMINATELIVE_ROLE_MODERATOR;
        $chairtoken = strtok(",");
        $i++;
    }

    // Participant
    $nonchairtoken = strtok($session->nonChairList,",");

    while($nonchairtoken)
    {
        $retusers[$i]['user'] = $nonchairtoken;
        $retusers[$i]['role'] = ELLUMINATELIVE_ROLE_PARTICIPANT;
        $nonchairtoken = strtok(",");
        $i++;
    }

    return $retusers;

}


/**
 * Create a new Elluminate Live! account for the supplied Moodle user ID.
 *
 * @param int $userid The Moodle user ID.
 * @return object|boolean The Elluminate Live! user object on success, False otherwise.
 */
function elluminate_new_user($userid, $password) {
    if (!$user = get_record('user', 'id', $userid)) {
        return false;
    }

    /// Determine what role to create this user as.
    $role = ELLUMINATELIVE_ROLE_PARTICIPANT;

    /// Admin = Application Administrator
    if (isadmin($user->id)) {
        $role = ELLUMINATELIVE_ROLE_APPADMIN;

        /// Editing Teachers = Moderator
    } else if (isteacherinanycourse($user->id)) {
        $role = ELLUMINATELIVE_ROLE_MODERATOR;
    }

    /// Let's give it a whirl!
    $result = elluminate_create_user($user->username, $password,
    $user->email, $user->firstname,
    $user->lastname, $role);

    if (!empty($result)) {
        return $result;
    }

    return false;
}


/**
 * Map an Elluminate Live! role value to it's string name.
 *
 * @param int $role An Elluminate Live! role value.
 * @return string The string name of the role value.
 */
function elluminate_role_name($role) {
    switch($role) {
        case ELLUMINATELIVE_ROLE_APPADMIN:
            $string = 'Application Administrator';
            break;
        case ELLUMINATELIVE_ROLE_MODERATOR:
            $string = 'Moderator';
            break;
        case ELLUMINATELIVE_ROLE_PARTICIPANT:
            $string = 'Participant';
            break;
        default:
            $string = '';
            break;
    }

    return $string;
}

/**
 * Get a specific user record from the Elluminate Live! server.
 *
 * See the comments for the elluminate_process_user() function for the format of the
 * returned user records returned in the array.
 *
 * @param int $userid The Elluminate Live! user ID.
 * @return object|boolean The Elluminate Live! user record or False on failure.
 */
function elluminate_get_user($userid) {

    if ($user = get_record('user', 'id', $userid))
    {
        return elluminate_process_user($user->id, $user->username, $user->email, $user->firstname, $user->lastname);
    }

    return false;
}


/**
 * Create's a user on the configured Elluminate Live! server and, if successful,
 * stores the mapping between the Moodle user ID and the Elluminate information.
 *
 * See the comments for the elluminate_process_user() function for the format of the
 * returned user records returned in the array.
 *
 * @param string $loginname Login name for this user.
 * @param string $loginpassword Login password for this user.
 * @param string $email The email address for this user.
 * @param string $firstname The first name for this user.
 * @param string $lastname The last name for this user.
 * @param int $role The Elluminate Live! Manager role.
 * @param int $tries Used to append an integer to a username if the username
 *                   we tried to create already exists on the server.
 * @return object|boolean The user object or False on failure.
 */
function elluminate_create_user($loginname, $loginpassword, $email,
$firstname, $lastname, $role, $tries = 0) {

    if ($user = get_record('user', 'username', $loginname, 'email', $email))
    {
        $elluminate_user = new Object();
        $elluminate_user->userid       = $user->id;
        $elluminate_user->elm_id       = $user->id;
        $elluminate_user->elm_username = $loginname;
        $elluminate_user->elm_password = $loginpassword;
        $elluminate_user->elm_role     = $role;
        $elluminate_user->timecreated  = time();


        if (!$elluminate_user->id = insert_record('elluminate_users', $elluminate_user))
        {
            return false;
        }

        return elluminate_process_user($user->id, $loginname, $loginpassword, $email, $firstname, $lastname);

    }

    return false;
}


/**
 * Changes the password on the Elluminate Live! server for a given user.
 *
 * @param int $userid The Elluminate Live! user ID.
 * @param string $password The new password.
 * @return boolean True on success, False otherwise.
 */
function elluminate_change_password($userid, $password) {

    $elmuser = get_record('elluminate_users', 'elm_id', $userid);
    $elmuser->password = $password;

    return update_record('elluminate_users', $elmuser);
}


/**
 * Delete's a user account on the Elluminate Live! server for a given user.
 *
 * @param int $userid The Elluminate Live! user ID.
 * @return boolean True on success, False otherwise.
 */
function elluminate_delete_user($userid) {

    return delete_records('elluminate_users', 'elm_id', $userid);

}


/**
 * Get a list of participants fora given meeting.
 *
 * The returned array is of the following structure:
 * array[]['user'] = user object
 * array[]['role'] = user role as a string
 *
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @param int $role The role type to return. (Default 0: return all)
 * @return array|boolean An array of users and roles or False on failure.
 */
function elluminate_list_participants($meetingid, $role = 0)
{
    /// Make sure the supplied role value is valid.
    switch ($role) {
        case 0:
        case ELLUMINATELIVE_ROLE_MODERATOR:
        case ELLUMINATELIVE_ROLE_PARTICIPANT:
            break;
        default:
            return false;
    }

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:int';

    $result = elluminate_send_command('listMeetingShort', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        if (!empty($result))
        {
            $entry = getArrayEntry($result, 0);
            $participants = elluminate_process_participant_list($entry);

            /// Return all participants for this meeting.
            if ($role == 0)
            {
                return $participants;
                /// Return only the selected role type for this meeting.
            }
            else
            {
                $retusers = array();

                foreach($participants as $participant)
                {
                    if ($participant['role'] == $role)
                    {
                        $retusers[] = $participant;
                    }
                }

                return $retusers;
            }
        }
    }

    return false;
}


/**
 * Determine if the user is a participant of the given meeting.
 *
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @param int $userid The Elluminate Live! user ID.
 * @param boolean $moderator Is the user being added as a moderator? (default False)
 * @return boolean True if the user is a participant, False otherwise.
 */
function elluminate_is_participant($meetingid, $userid, $moderator = false)
{
    $meetingparticipants = array();

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:int';

    $result = elluminate_send_command('listMeetingShort', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        if (!empty($result))
        {
            $entry = getArrayEntry($result, 0);
            $meetingparticipants = elluminate_process_participant_list($entry);

            if (!empty($meetingparticipants))
            {
                if ($moderator)
                {
                    foreach ($meetingparticipants as $participant)
                    {
                        if ($userid == $participant['user'] && ELLUMINATELIVE_ROLE_MODERATOR == $participant['role'])
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    foreach ($meetingparticipants as $participant)
                    {
                        if ($userid == $participant['user'] && ELLUMINATELIVE_ROLE_PARTICIPANT == $participant['role'])
                        {
                            return true;
                        }
                    }
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    return false;
}


/**
 * Add a user as a participant to a given meeting.
 *
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @param int $userid The Elluminate Live! user ID.
 * @param boolean $moderator Is the user being added as a moderator? (default False)
 * @return boolean True on success, False otherwise.
 */
function elluminate_add_participant($meetingid, $userid, $moderator = false)
{
    /// Make sure this user is not already a participant or moderator for this meeting.
    if (elluminate_is_participant($meetingid, $userid) ||
    elluminate_is_participant($meetingid, $userid, true))
    {
        return true;
    }

    /// Make sure any existing participants are included in the list.
    $participants = elluminate_list_participants($meetingid);

    $moderatoruserlist  = '';
    $participantuserlist = '';

    $moderatorusercount = 0;
    $participantusercount = 0;

    if (!empty($participants)) {
        foreach ($participants as $participant) {
            if (ELLUMINATELIVE_ROLE_MODERATOR == $participant['role'])
            {
                if ($moderatorusercount > 0) {
                    $moderatoruserlist .= ',';
                }
                $moderatoruserlist .= $participant['user'];
                $moderatorusercount++;
            }
            else
            {
                if ($participantusercount) {
                    $participantuserlist .= ',';
                }
                $participantuserlist .= $participant['user'];
                $participantusercount++;
            }
        }
    }

    /// Append the new user we're adding.
    if ($moderator)
    {
        if ($moderatorusercount)
        {
            $moderatoruserlist .= ',';
        }
        $moderatoruserlist .= $userid;
    }
    else
    {
        if ($participantusercount)
        {
            $participantuserlist .= ',';
        }
        $participantuserlist .= $userid;
    }

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:int';

    $args[1]['name']  = 'chairList';
    $args[1]['value'] = $moderatoruserlist;
    $args[1]['type']  = 'xsd:string';

    $args[2]['name']  = 'nonChairList';
    $args[2]['value'] = $participantuserlist;
    $args[2]['type']  = 'xsd:string';

    $result = elluminate_send_command('setMeeting', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        if (!empty($result))
        {
            return true;
        }
    }

    return false;
}


/**
 * Delete a participant(s) from a given meeting.
 * ## Needs to be tested
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @param int $userid The Elluminate Live! user ID.
 * @return boolean True on success, False otherwise.
 */
function elluminate_delete_participants($meetingid, $muserids)
{
    $chairListArray = array();
    $nonCharListArray = array();

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:integer';

    $result = elluminate_send_command('listMeetingLong', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        if (!empty($result))
        {
            $session = getArrayEntry($result, 0);
            $chairListArray = string_token_to_array($session->chairList, ",");
            $nonCharList = string_token_to_array($session->nonChairList, ",");
        }
    }

    $newChairList = remove_items_from_array($chairListArray, $muserids);
    $newNonChairList = remove_items_from_array($nonCharList, $muserids);

    $chairList = implode(",", $newChairList);
    $nonChairList = implode(",", $newNonChairList);

    $args[1]['name']  = 'chairList';
    $args[1]['value'] = $chairList;
    $args[1]['type']  = 'xsd:string';

    $args[2]['name']  = 'nonChairList';
    $args[2]['value'] = $nonChairList;
    $args[2]['type']  = 'xsd:string';

    $result = elluminate_send_command('setMeeting', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        if (!empty($result))
        {
            return true;
        }
    }

    return false;
}


/**
 * Get a list of meetings from the Elluminate Live! server.
 *
 * See the comments for the elluminate_processmeeting() function for the format
 * of the returned meeting records returned in the array.
 *
 * @param int $role The Elluminate Live! role type to fetch.
 * @return mixed|boolean An array of user objects or False on failure.
 */
function elluminate_list_meetings() {
    $result = elluminate_send_command('listMeetings');

    if (is_string($result)) {
        return false;
    } else if (is_object($result)) {
        if (!empty($result->Collection->Entry)) {
            $retmeetings = array();
            if (is_array($result->Collection->Entry)) {
                foreach($result->Collection->Entry as $entry) {
                    $retmeetings[] = elluminate_process_meeting($entry->MeetingAdapter);
                }
            } else {
                $retmeetings[] = elluminate_process_meeting($result->Collection->Entry->MeetingAdapter);
            }

            return $retmeetings;
        }
    }

    return false;
}


/**
 * Create a new Elluminate Live! meeting on the server.
 *
 * @param int $start The start date and time of the meeting.
 * @param int $end The end date and time of the meeting.
 * @param string $name The name of the meeting.
 * @param string $facilitator The user ID of the creator of this meeting.
 * @param string $password The password for this meeting.
 * @param boolean $private Is this meeting a private or public meeting?
 * @param int $seats The number of seats to reserve for his meeting.
 * @return object|boolean The newly created meeting object or False on failure.
 */
function elluminate_create_meeting($start, $end, $name, $facilitator,
$password = '', $private = false, $seats = 0, $boundryTime, $recordingModeType)
{
    return elluminate_set_meeting('', $start, $end, $name, $facilitator, $password, $private, $seats, $boundryTime, $recordingModeType);
}


/**
 * Modify an existing Elluminate Live! meeting on the server.
 *
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @param int $start The start date and time of the meeting.
 * @param int $end The end date and time of the meeting.
 * @param string $name The name of the meeting.
 * @param string $facilitator The user ID of the creator of this meeting.
 * @param string $password The password for this meeting.
 * @param boolean $private Is this meeting a private or public meeting?
 * @param int $seats The number of seats to reserve for his meeting.
 * @return object|boolean The newly created meeting object or False on failure.
 */
function elluminate_update_meeting($meetingid, $start, $end, $name, $facilitator,
$password = '', $private = false, $seats = 0, $boundryTime, $recordingModeType) {

    $result = elluminate_set_meeting($meetingid, $start, $end, $name, $facilitator,
        $password, $private, $seats, $boundryTime, $recordingModeType);



    /// Check for an error.
    if (isset($result->Detail->Stack->Trace)) {
        $return = '';

        foreach ($result->Detail->Stack->Trace as $trace) {
            $return .= $trace . "\n";
        }

        return $return;
    }

    return $result;
}

function elluminate_set_meeting($meetingid, $start, $end, $name, $facilitator,
$password, $private, $seats, $boundryTime, $recordingModeType)
{
    global $USER;

    $args = array();
    $i    = 0;

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:integer';

    $args[1]['name']  = 'creatorId';
    $args[1]['value'] = $USER->id;
    $args[1]['type']  = 'xsd:string';

    $args[2]['name']  = 'startTime';
    $args[2]['value'] = $start . '000';
    $args[2]['type']  = 'xsd:long';

    $args[3]['name']  = 'endTime';
    $args[3]['value'] = $end . '000';
    $args[3]['type']  = 'xsd:long';

    $args[4]['name']  = 'name';
    $args[4]['value'] = $name;
    $args[4]['type']  = 'xsd:string';

    $args[5]['name']  = 'reserveSeats';
    $args[5]['value'] = $seats;
    $args[5]['type']  = 'xsd:integer';

    $currChairList = '';
    if($meetingid != '')
    {
        $moderators = elluminate_get_meeting_participants($meetingid, true);
        foreach($moderators as $moderator)
        {
            if($currChairList == '')
                $currChairList = $moderator->id;
            else
                $currChairList = $currChairList . ', ' . $moderator->id;
        }
    } else
    {
        $currChairList = $USER->id;
    }

    $args[6]['name']  = 'chairList';
    $args[6]['value'] = $currChairList;
    $args[6]['type']  = 'xsd:string';

    $args[7]['name']  = 'boundaryTime';
    $args[7]['value'] = $boundryTime;
    $args[7]['type']  = 'xsd:integer';

    $args[8]['name']  = 'recordingModeType';
    $args[8]['value'] = $recordingModeType;
    $args[8]['type']  = 'xsd:integer';
    /*
    $args[9]['name']  = 'reserveSeats';
    $args[9]['value'] = $seats;
    $args[9]['type']  = 'xsd:integer';*/


    $result = elluminate_send_command('setMeeting', $args);



    if (is_string($result)) {
        return false;
    } else if (is_object($result)) {
        $entry = getArrayEntry($result, 0);

        return elluminate_process_meeting($entry);
    }
    return false;

}


/**
 * Delete a meeting on the Elluminate Live! server.
 *
 * @param long $meetingid The Elluminate Live! meeting ID.
 * @return boolean True on success, False otherwise.
 */
function elluminate_delete_meeting($meetingid) {

//print_r("delete instance");

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:integer';

    $result = elluminate_send_command('removeMeeting', $args);

    if (is_string($result))
    {
        return true;
    }/* else if (is_object($result)) {
        if (!empty($result->MeetingAdapter)) {
            if (elluminate_process_meeting($result->MeetingAdapter)) {
                return true;
            }
        }
    }*/

    return false;
}


/**
 * Get a meeting object from the Elluminate Live! server.
 *
 * @param int $meetingid The Elluminate Live! meeting ID.
 * @return object|boolean The meeting object or False on failure.
 */
function elluminate_get_meeting($meetingid) {
    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:integer';

    $result = elluminate_send_command('listMeetingLong', $args);


    if (is_string($result)) {
        return false;
    } else if (is_object($result)) {
        foreach($result as $entry)
        {
            return elluminate_process_meeting($entry);
        }
    }

    return false;
}

/**
 * Delete the recording for the given recording ID.
 *
 * @param $string $recordingid Recording ID to identify the recording.
 * @return bool True on success, False otherwise.
 */
function elluminate_delete_recording($recordingid) {
    $args = array();

    $args[0]['name']  = 'recordingId';
    $args[0]['value'] = $recordingid;
    $args[0]['type']  = 'xsd:string';

    $result = elluminate_send_command('removeRecording', $args);

    if (is_string($result)) {
        return false;
    } else if (is_object($result)) {
        if ($result->id == $recordingid) {

            // If deleted correctly, remove on Moodle side as well.
            delete_records('elluminate_recordings', 'recordingid', $recordingid);

            return true;
        }
    }

    return false;
}


/**
 * Get a list of recordings from the Elluminate Live! server and return them in
 * a Moodle object format:
 *
 *  $recording->recordingid - Recording ID.
 *  $recording->meetingid   - Meeting ID.
 *  $recording->roomname    - Meeting name.
 *  $recording->facilitator - Facilitator user ID.
 *  $recording->created     - Date/time recording created.
 *
 * @param $string filter
 * @return array|boolean An array of recording object or False on failure.
 */
function elluminate_list_recordings($meetingId) {

    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingId;
    $args[0]['type']  = 'xsd:integer';

    $result = elluminate_send_command('listRecordingShort', $args);

    if (is_string($result)) {
        return false;
    }
    else
    {
        $recordings = array();
        if (is_array($result))
        {
            foreach ($result as $dummy_entry)
            {
            $entry = getArrayEntry($dummy_entry, 0);
                    $recordings[] = setRecordingObject($entry);
            }
        } else
        {
      $entry = getArrayEntry($result, 0);
            $recordings[] = setRecordingObject($entry);
        }
        return $recordings;
    }

}

function setRecordingObject($entry)
{
        $recording = new Object();
        $recording->recordingid = $entry->id;
        $recording->meetingid   = $entry->meetingId;
        $recording->roomname    = $entry->name;
        $recording->facilitator = 0; // There is no facilitator required for SAS
        $recording->created     = substr($entry->creationDate, 0, 10);
        return $recording;

}

/**
 * Get a list of recent recorded meetings based upon the user's system authority:
 *  - admins can see all recent meeting recordings
 *  - teachers see recent recordings in their courses
 *  - students see recent recordings they participated in
 *
 * The return array is of the format where each entry is an object that consists
 * of the following information:
 *
 *  $entry->name        = meeting name
 *  $entry->recordingid = recording ID
 *
 * @uses $USER
 * @param none
 * @return array An array of recorded meeting information.
 */
function elluminate_recent_recordings() {
    global $USER;
/*
    if (!$elmuser = get_record('elluminate_users', 'userid', $USER->id)) {
        return NULL;
    }
*/


    /// Get the five most recent recordings.
    if (!$recordings = get_records('elluminate_recordings', '', '', 'created DESC', '*', '', 5)) {
        return NULL;
    }



    $return = array();

    $type = 'student';

    if (isadmin($USER->id)) {
        $type = 'admin';
    } else if (isteacherinanycourse($USER->id, false)) {
        $type = 'teacher';
    }

    $rids = array();

    foreach ($recordings as $recording) {
        $meeting = get_record('elluminate', 'meetingid', $recording->meetingid);
        $meeting->name = stripslashes($meeting->name);

        if (in_array($meeting->id, $rids)) {
            continue;
        }

        if($meeting->private == false)
        {
            $return[] = createRecordingEntry($meeting, $recording);
        }
        else
        {
            // ## REFACTOR THIS MESS!!!!
            switch ($type) {
                case 'admin':
                    $return[] = createRecordingEntry($meeting, $recording);
                    break;

                case 'teacher':
                    if (isteacher($meeting->course, $USER->id, false)) {
                        $return[] = createRecordingEntry($meeting, $recording);
                    }

                    break;

                case 'student':
                    if (elluminate_is_participant($recording->meetingid, $USER->id)) {
                        $return[] = createRecordingEntry($meeting, $recording);
                    }
                    break;

                default:
                    break;
            }
        }
    }

    return $return;
}

function createRecordingEntry($meeting, $recording)
{
    $entry = new Object();
    $entry->meetingid   = $meeting->id;
    $entry->name        = $meeting->name;
    $entry->recordingid = $recording->id;
    $entry->created     = $recording->created;

    $rids[]   = $meeting->id;
    return $entry;
}


/**
 * Login a user and load a meeting object from the Elluminate Live! server.
 *
 * @param long $meetingid The Elluminate Live! meeting ID.
 * @param int $userid A Moodle user ID.
 * @return file|boolean A meeting.jnlp attachment to load a meeting or False on failure.
 */
function elluminate_build_meeting_jnlp($meetingid, $userid) {
    if (!$user = get_record('user', 'id', $userid)) {
        return false;
    }

    if (!$elmuser = get_record('elluminate_users', 'userid', $user->id)) {
        return false;
    }


    $args = array();

    $args[0]['name']  = 'meetingId';
    $args[0]['value'] = $meetingid;
    $args[0]['type']  = 'xsd:integer';

    $args[1]['name']  = 'displayName';
    $args[1]['value'] = $user->firstname . ' ' . $user->lastname;//$elmuser->elm_username;
    $args[1]['type']  = 'xsd:string';

    $args[2]['name']  = 'userId';
    $args[2]['value'] = $elmuser->elm_id;
    $args[2]['type']  = 'xsd:string';

    $result = elluminate_send_command('buildMeetingJNLPUrl', $args);

    if (!is_string($result))
    {
        return false;
    }
    else
    {
        header('Location:'.$result);
        return true;
    }
}


/**
 * Login a user and load a recording object from the Elluminate Live! server.
 *
 * @param long $recordingid The Elluminate Live! recording ID.
 * @param int $userid A Moodle user ID.
 * @return file|boolean A meeting.jnlp attachment to load a meeting or False on failure.
 */
function elluminate_build_recording_jnlp($recordingid, $userid) {
    if (!$user = get_record('user', 'id', $userid)) {
        return false;
    }

    if (!$elmuser = get_record('elluminate_users', 'userid', $user->id)) {
        return false;
    }

    $args = array();

    $args[0]['name']  = 'recordingId';
    $args[0]['value'] = $recordingid;
    $args[0]['type']  = 'xsd:integer';

    $result = elluminate_send_command('buildRecordingJNLPUrl', $args);

    if (!is_string($result))
    {
        return false;
    }
    else
    {
        header('Location:'.$result);
        return true;
    }
}


/**
 * Get the maximum number of seats available with the current server license.
 *
 * @param none
 * @return int|boolean The maximum number of seats available with the current
 *                     license or false on failure.
 */
function elluminate_get_max_seats() {

    $result = elluminate_get_server_configuration();

    return $result->sessionQuota;
}


/**
 * Get the maximum number of seats available across the specified time span.
 *
 * @param int $start The beginning time.
 * @param int $end The ending time.
 * @param string $exclude A comma-separated list of meeting ID's to exclude from this search.
 * @return int|boolean The maximum number of seats avaialble or false on failure.
 */
function elluminate_get_max_available_seats($start, $end, $exclude = '') {


    // ## The maxAvailableSeats command does not exist in the SAS Default Adapter
    $result = elluminate_get_server_configuration();

    return $result->sessionQuotaAvailable;
}


/**
 * Get the server configuration parameters in object form.
 *
 * @param none
 * @return object|boolean The configuration object or False on failure.
 */
function elluminate_get_server_configuration() {
    $config = new stdClass;

    $args = array();

    // ## Hack to make sas accept command with no arg.
    $args[0]['name']  = 'dummyArg';
    $args[0]['value'] = '';
    $args[0]['type']  = 'xsd:string';

    $result = elluminate_send_command('getServerConfiguration', $args);

    if (is_string($result))
    {
        return false;
    }
    else if (is_object($result))
    {
        $serverConfigEntry = getArrayEntry($result, 0);
        $config->boundaryTime = $serverConfigEntry->boundaryTime;
        $config->diskQuota  = $serverConfigEntry->diskQuota;
        $config->diskQuotaAvailable = $serverConfigEntry->diskQuotaAvailable;
        $config->maxAvailableTalkers = $serverConfigEntry->maxAvailableTalkers;
        $config->raiseHandOnEnter = $serverConfigEntry->raiseHandOnEnter;
        $config->sessionQuota = $serverConfigEntry->sessionQuota;
        $config->sessionQuotaAvailable = $serverConfigEntry->sessionQuotaAvailable;
        $config->timeZone = $serverConfigEntry->timeZone;

        return $config;
    }
}


/**
 * Check to see if seat reservation is enabled on the Elluminate Live! server.
 * ## Currently there is no way to determine seat reservation checking through
 * ## the SAS default adapter.  Currently we simply return the value 'false'
 *
 * @param none
 * @return bool True if seat reservation is enabled on the server, False otherwise.
 */
function elluminate_seat_reservation_check()
{
    return true;
}


/**
 * Return the URL linking to the support page on the configured Elluminagte Live! server.
 *
 * @param none
 * @return string The URL pointing to the support page.
 */
function elluminate_support_link() {
    return 'http://www.elluminate.com/support/';/*
    global $CFG;

    /// Create the correct URL of the endpoint based upon the configured server address.
    $serverurl = $CFG->elluminate_server;

    if (substr($serverurl, strlen($serverurl) - 1, 1) != '/') {
        $serverurl .= '/support.help';
    } else {
        $serverurl .= 'support.help';
    }

    return $serverurl;*/
}

/**
 * Convert a string tokens to an array providing a delimeter
 *
 * @param $str = The string to be converted to an array
 * @param $del = The delimeter
 */
function string_token_to_array( $str, $del )
{
    $array = array();
    $i = 0;

    $token = strtok($str,$del);

    while($token)
    {
        $array[$i] = $token;
        $token = strtok($del);
        $i++;
    }

    return $array;
}

function remove_items_from_array( $mainlist, $itemstoremove )
{
    $newarray = array();

    foreach ($mainlist as $mainlistitem)
    {
        if ( !in_array($mainlistitem, $itemstoremove) )
        {
            $newarray[] = $mainlistitem;
        }
    }

    return $newarray;
}

function getArrayEntry($result, $index)
{
    $i = 0;
    foreach ($result as $entry) {
        if ($i == $index) {
            return $entry;
        }
    }
}

function checkListForUserById($user, $userList)
{
    foreach($userList as $entry)
    {
        if($entry->id == $user->id)
            return true;
    }
    return false;
}

function elluminate_list_all_recordings()
{
    $args = array();

    $args[0]['name']  = 'startTime';
    $args[0]['value'] = getLastDayTimeInMilliseconds();
    $args[0]['type']  = 'xsd:long';

    $args[1]['name']  = 'endTime';
    $args[1]['value'] = getCurrentTimeInMilliseconds();
    $args[1]['type']  = 'xsd:long';

    /// 31535940000 -- # of miliseconds in a year

    $result = elluminate_send_command('listRecordingShort', $args);

    if (is_string($result)) {
        return false;
    }
    else
    {
        $recordings = array();
        if (is_array($result))
        {
            foreach ($result as $dummy_entry)
            {
                $entry = getArrayEntry($dummy_entry, 0);
                $recordings[] = setRecordingObject($entry);
            }
        }
        else
        {
            $entry = getArrayEntry($result, 0);
            $recordings[] = setRecordingObject($entry);
        }
        return $recordings;
    }
}

function getCurrentTimeInMilliseconds(){
    $currDate = date('U') * 1000;
    $currDate = number_format($currDate, 0, '.', '');
    return $currDate;
}

function getLastDayTimeInMilliseconds(){
    $lastDay = date('U') * 1000 - (24 * 60 * 60 * 1000);
    $lastDay = number_format($lastDay, 0, '.', '');
    return $lastDay;
}

?>
