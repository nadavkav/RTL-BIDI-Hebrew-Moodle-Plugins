<?PHP // $Id$
      // tab.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['changestyle'] = 'עריכת קובצי עיצוב';
$string['css'] = 'קובץ עיצוב';
$string['displaymenu'] = 'תצוגת תפריט החוצץ';
$string['displaymenuagree'] = 'אשרו אם אתם מעוניינים להציג תפריט';
$string['displayfp'] = 'האם להציג בדף הראשי של מרחב הלימוד?';
$string['special'] = 'הגדרות מיוחדות';
$string['menucss'] = 'עריכת עיצוב התפריט';
$string['menuname'] = 'שם תפריט';
$string['modulename'] = 'דף תוכן משולב חוצצים';
$string['modulenameplural'] = 'דפי תוכן משולבי חוצצים';
$string['moretabs'] = 'הוספת חוצצים נוספים';
$string['name'] = 'שם';
$string['tabcontent1'] = 'תוכן החוצץ מספר 1';
$string['tabcontent2'] = 'תוכן החוצץ מספר 2';
$string['tabcontent3'] = 'תוכן החוצץ מספר 3';
$string['tabcontent4'] = 'תוכן החוצץ מספר 4';
$string['tabcontent5'] = 'תוכן החוצץ מספר 5';
$string['tabcontent6'] = 'תוכן החוצץ מספר 6';
$string['tabcontent7'] = 'תוכן החוצץ מספר 7';
$string['tabcontent8'] = 'תוכן החוצץ מספר 8';
$string['tabname'] = 'שם החוצץ מספר';
$string['tabname1'] = 'שם החוצץ מספר 1';
$string['tabname2'] = 'שם החוצץ מספר 2';
$string['tabname3'] = 'שם החוצץ מספר 3';
$string['tabname4'] = 'שם החוצץ מספר 4';
$string['tabname5'] = 'שם החוצץ מספר 5';
$string['tabname6'] = 'שם החוצץ מספר 6';
$string['tabname7'] = 'שם החוצץ מספר 7';
$string['tabname8'] = 'שם החוצץ מספר 8';
$string['tabs'] = 'חוצצים';
$string['tab2'] = 'מאפייני חוצץ 2';
$string['tab3'] = 'מאפייני חוצץ 3';
$string['tab4'] = 'מאפייני חוצץ 4';
$string['tab5'] = 'מאפייני חוצץ 5';
$string['tab6'] = 'מאפייני חוצץ 6';
$string['tab7'] = 'מאפייני חוצץ 7';
$string['tab8'] = 'מאפייני חוצץ 8';
$string['btnShowNextHeader'] = 'הוספת חוצץ';
?>
