<?php


$string['thiscourse'] = 'מרחב הלימוד';
$string['whatsnew'] = 'מה חדש?';
$string['mycourses'] = 'מרחבי הלימוד שלי';
$string['messages'] = 'מסרים';
$string['mypublicportfolio'] = 'תיק־התוצרים שלי';
$string['myprivatefiles'] = 'מחסן הקבצים שלי';
$string['myinternalemails'] = 'הדואר שלי';
$string['wikipedia'] = 'הויקיפדיה';


?>