<?php


$string['thiscourse'] = 'Course\'s Frontpage';
$string['whatsnew'] = 'What\'s New?';
$string['mycourses'] = 'My Courses';
$string['messages'] = 'Messages';
$string['mypublicportfolio'] = 'My Portfolio';
$string['myprivatefiles'] = 'My Files';
$string['myinternalemails'] = 'My eMail';
$string['wikipedia'] = 'Wikipedia';


?>