<ul id="menu">
	<li><a href="<?php echo $CFG->wwwroot; ?>/course/view.php?id=<?php echo $COURSE->id; ?>" title="Course Frontpage"><?php echo get_string('thiscourse','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/my" title="What's New?"><?php echo get_string('whatsnew','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/course/index.php?mycourses=1" title="Courses"><?php echo get_string('mycourses','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/calendar/view.php?view=month" title="Calendar"><?php echo get_string('calendar','calendar'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/message/index.php" title="Internal Messenger"><?php echo get_string('messages','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/blocks/exabis_eportfolio/view.php?courseid=<?php echo $COURSE->id; ?>" title="Public Portfolio"><?php echo get_string('mypublicportfolio','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/blocks/file_manager/view.php?id=<?php echo $COURSE->id; ?>" title="Private files"><?php echo get_string('myprivatefiles','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a href="<?php echo $CFG->wwwroot; ?>/blocks/email_list/email/index.php?id=<?php echo $COURSE->id; ?>" title="Internal eMail"><?php echo get_string('myinternalemails','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>
	<li><a target="_new" href="http://he.wikipedia.com" title="Hebrew Wikipedia"><?php echo get_string('wikipedia','theme_ingenuous','',$CFG->dirroot.'/theme/ingenuous/lang/'); ?></a></li>

</ul>