<?php
// display teacher's creative commons and contact details

  if ($COURSE->id !=0 && isset($COURSE->id)) {
  //echo '<br>$COURSE->id='.$COURSE->id;

  }
    $teachers = get_course_teachers($COURSE->id);
  
    if (isset($teachers)) {
        foreach ($teachers as $teacher) {
          echo '<div id="credit"><center>';
          echo 'מרחב לימוד זה מנוהל על ידי';
          echo ' '.$teacher->firstname.' '.$teacher->lastname.' (<a href="mailto:'.$teacher->email.'">'.$teacher->email.'</a>) ';
          echo 'ולכן כפוף ל<a href="http://creativecommons.org/licenses/by-sa/3.0/deed.he">זכויות יוצרים<a/>';
          echo '</center></div>';
          exit;
        }
      }
      unset($teachers);

?>
