<?php

$plugin->version  = 2007082700;
$plugin->requires = 2006073000;

?>
