<?PHP // $Id: version.php,v 1.1 2008/07/24 01:48:12 arborrow Exp $

$plugin->version  = 2008061500;
$plugin->requires = 2007101000;

?>
