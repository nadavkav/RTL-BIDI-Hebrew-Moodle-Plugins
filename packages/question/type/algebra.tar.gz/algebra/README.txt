MOODLE ALGEBRA QUESTION TYPE

These files implement a algebra based question type for Moodle.
Installation instructions are found in the file INSTALL.

Note that this is ALPHA quality software. It has not been throughly
tested for robustness and the XML-RPC server/client aspects
have not been rigourously tested for security. In short you would
be insane to install this code on a production Moodle server in
its current state!

The code is all released under the GPL V3.

Please send any bugs, comments, suggestions for new features etc.
to me.

Enjoy,

Roger Moore <rwmoore (at) ualberta.ca>
