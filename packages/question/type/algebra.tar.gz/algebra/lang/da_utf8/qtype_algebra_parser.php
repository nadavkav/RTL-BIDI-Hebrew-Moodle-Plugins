<?php
// Translations provided by Morten Brydensholt
$string['badclosebracket'] = 'Ugyldig slutparantes blev fundet';
$string['badequivtype'] = 'Ugyldig type: Kan kun sammenligne parserudtryk med andre parserudtryk';
$string['badfuncargs'] = 'Ugyldigt argument for funktionen \'$a\'';
$string['decimal'] = ',';
$string['mismatchedbracket'] = 'Sammenblanding af parenteser: Start- og slutparanteser er ikke af samme type \'$a\'';
$string['mismatchedcloseb'] = 'Sammenblanding af parenteser: Slutparentes uden en startparentes blev fundet';
$string['mismatchedopenb'] = 'Sammenblanding af parenteser: Startparentes uden en slutparentes blev fundet';
$string['missingonearg'] = 'Syntaksfejl: Operator \'$a\' mangler sit argument';
$string['missingtwoarg'] = 'Syntaksfejl: Operator \'$a\' beh¯ver to argumenter';
$string['morethantwoargs'] = 'Fors¯ger at sammenligne et udtryk med mere end 2 argumenter - ingen kode til at behandle dette tilfÊlde!';
$string['multiply'] = '\\\\cdot';
$string['nargswrong'] = 'Forkert antal argumenter for udtrykket \'$a\'';
$string['noevaluate'] = 'Evalueringsmetoden for udtrykket \'$a\' er ikke blevet implementeret';
$string['notopterm'] = 'Syntaksfejl: Ude af stand til at kondensere udtrykket til en enkelt operator pÂ topniveau';
$string['undeclaredvar'] = 'Ikke-deklareret variabel \'$a\' blev fundet';
$string['undefinedfunction'] = 'Ikke-defineret funktion \'$a\'';
$string['undefinedvariable'] = 'Ikke-defineret variabel \'$a\' blev fundet under den numeriske evaluering af udtrykket';
$string['unknownterm'] = 'Syntaksfejl: Ukendt udtryk blev fundet ved \'$a\' i udtrykket';
?>