<?php
    
    $string['multinumerical'] = 'מספרי (רב-שדות)';
    $string['editingmultinumerical'] = 'עריכת שאלה מספרית (רב-שדות)';
    $string['parameters'] = 'מאפיינים';
    $string['conditions'] = 'תנאים';
    $string['feedbackperconditions'] = 'משוב לכל תנאי';
    $string['noncomputable'] = '(לא ניתן לחישוב)';
    $string['onlyforcalculations'] = 'לצורך חישובי בלבד';
    $string['usecolorforfeedback'] = 'השתמשו בצבעים לתנאים השונים';
    $string['binarygrade'] = 'חישוב ציונים';
    $string['gradebinary'] = 'הכל או כלום';
    $string['gradefractional'] = 'שבר';
    $string['conditionnotverified'] = 'תנאי לא בדוק';
    $string['conditionverified'] = 'תנאי בדוק';
    $string['displaycalc'] = 'הצגת תוצאות החישוב';
    $string['helponquestionoptions'] = 'For more information on this question type and the behaviour of the following options, please click the help button at the top of this form.';
    
?>