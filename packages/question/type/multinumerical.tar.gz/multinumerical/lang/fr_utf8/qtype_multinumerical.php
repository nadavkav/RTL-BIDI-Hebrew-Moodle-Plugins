<?php
    
    $string['multinumerical'] = 'Multinumérique';
    $string['editingmultinumerical'] = 'Edition d\'une quesiton multinumérique';
    $string['parameters'] = 'Paramètres';
    $string['conditions'] = 'Contraintes';
    $string['feedbackperconditions'] = 'Feedback par contraintes';
    $string['noncomputable'] = '(non calculable)';
    $string['onlyforcalculations'] = 'Seulement pour les calculs';
    $string['usecolorforfeedback'] = 'Utiliser de la couleur pour les feedbacks par contrainte';
    $string['binarygrade'] = 'Calcul des points';
    $string['gradebinary'] = 'Tout ou rien';
    $string['gradefractional'] = 'Fractions de points';
    $string['conditionnotverified'] = 'condition non vérifiée';
    $string['conditionverified'] = 'condition vérifiée';
    $string['displaycalc'] = 'Afficher le résultat du calcul';
    $string['helponquestionoptions'] = 'Pour des informations sur le fonctionnement de ce type de question et sur les paramètres suivants, utilisez le bouton d\'aide tout en haut du formulaire.';
    
?>