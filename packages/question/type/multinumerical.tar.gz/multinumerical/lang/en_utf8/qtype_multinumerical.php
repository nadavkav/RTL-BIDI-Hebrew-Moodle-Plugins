<?php
    
    $string['multinumerical'] = 'Multinumerical';
    $string['editingmultinumerical'] = 'Editing multinumerical question';
    $string['parameters'] = 'Parameters';
    $string['conditions'] = 'Constraints';
    $string['feedbackperconditions'] = 'Per constraint feedback';
    $string['noncomputable'] = '(not computable)';
    $string['onlyforcalculations'] = 'Only for calculations';
    $string['usecolorforfeedback'] = 'Use color for per constraint feedback';
    $string['binarygrade'] = 'Grade calculation';
    $string['gradebinary'] = 'All or nothing';
    $string['gradefractional'] = 'Fractional';
    $string['conditionnotverified'] = 'Unverified constraint';
    $string['conditionverified'] = 'Verified constraint';
    $string['displaycalc'] = 'Display calculation result';
    $string['helponquestionoptions'] = 'For more information on this question type and the behaviour of the following options, please click the help button at the top of this form.';
    
?>