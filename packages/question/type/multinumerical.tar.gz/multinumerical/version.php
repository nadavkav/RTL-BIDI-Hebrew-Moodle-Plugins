<?PHP // $Id: version.php,v 1.2.2.1 2007/11/02 16:20:41 tjhunt Exp $

$plugin->version  = 2009040100;
$plugin->requires = 2007101000;

?>
