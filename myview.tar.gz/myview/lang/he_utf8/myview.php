<?php

$string['filterbyactivity'] = 'תצוגת כל העדכונים בכל מרחבי הלימוד השייכים לפעילות: ';
$string['filterby'] = 'סינון תצוגת על־פי';
$string['filter'] = 'סינון';
$string['coursename'] = 'אנא הזינו שם מלא או חלקי של';
$string['or'] = 'או';
$string['toview'] = 'לתצוגה';
$string['allcourses'] = 'כל הקורסים';

$string['waitingyourattention'] = 'קיימים עדכונים חדשים במרחב לימוד זה, אנא הקליקו לצפייה בעדכונים...';

$string['calendar'] = 'לוח־שנה';
$string['internalemail'] = 'דואר פנימי';
$string['myprofile'] = 'פרופיל אישי';
$string['instantmessages'] = 'מסרים';
$string['myfiles'] = 'הקבצים שלי';
$string['eportfolio'] = 'פורטפוליו';
$string['blogpost'] = 'הבלוג שלי';
$string['davidsononline'] = 'דוידסון און ליין';
$string['games'] = 'משחקים';
$string['help'] = 'תמיכה';
$string['logoff'] = 'יציאה';

$string['settings'] = 'הגדרות MYVIEW';
$string['supportlink'] = 'קישור תמיכה';
$string['supportlinkinfo'] = 'כתובת דף תמיכה';
$string['latestnews'] = 'הודעות אחרונות';

?>