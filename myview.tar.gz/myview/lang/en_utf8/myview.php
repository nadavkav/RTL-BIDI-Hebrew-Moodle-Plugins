<?php

$string['filterbyactivity'] = 'Show updates from all my courses related to activity: ';
$string['filterby'] = 'Choose';
$string['filter'] = 'Filter';
$string['or'] = 'Or';
$string['toview'] = 'To view';
$string['allcourses'] = 'All Courses';
$string['coursename'] = 'Type in a full or partial course name';

$string['waitingyourattention'] = 'Please click here to see Updates...';

$string['calendar'] = 'Calendar';
$string['internalemail'] = 'Internal eMail';
$string['myprofile'] = 'My Profile';
$string['instantmessages'] = 'My Messages';
$string['myfiles'] = 'My Files';
$string['eportfolio'] = 'Portfolio';
$string['blogpost'] = 'Post 2 Blog';
$string['games'] = 'Games';
$string['davidsononline'] =  'Davidson Online';
$string['help'] = 'Help';
$string['logoff'] = 'Log off';

?>