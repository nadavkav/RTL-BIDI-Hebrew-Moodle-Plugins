<?PHP // $Id: block_loancalc.php,v 1.1 2007/05/14 11:56:47 emanuel1 Exp $ 
      // block_loancalc.php - created with Moodle 1.8 dev (2006120700)


$string['amountofloan'] = 'סכום ההלוואה';
$string['fortnightly'] = 'דו-שבועי';
$string['interestrate'] = 'שיעור הריבית';
$string['loancalc'] = 'מחשב הלוואות';
$string['loanterm'] = 'תנאי ההלוואה (שנים)';
$string['monthly'] = 'חודשי';
$string['repaymentamount'] = 'סכום הפירעון';
$string['repaymentfreq'] = 'תדירות הההחזרים';
$string['weekly'] = 'שבועי';

?>
