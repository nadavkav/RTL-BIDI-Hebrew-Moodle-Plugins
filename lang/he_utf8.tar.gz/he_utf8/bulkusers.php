<?PHP // $Id: bulkusers.php,v 1.2 2008/12/23 11:54:38 emanuel1 Exp $ 
      // bulkusers.php - created with Moodle 1.9.3+ (Build: 20081126) (2007101532)


$string['addall'] = 'הוסף הכל לבחירה';
$string['addsel'] = 'הוסף לבחירה';
$string['allfilteredusers'] = 'אלו שסוננו ($a->count/$a->total)';
$string['allselectedusers'] = 'אלו שנבחרו ($a->count/$a->total)';
$string['allusers'] = 'כל המשתמשים ($a)';
$string['available'] = 'זמין';
$string['confirmmessage'] = 'האם אכן ברצונך לשלוח את הודעה זו לכל משתמשים אלו? <br />$a';
$string['nofilteredusers'] = 'כלל לא נמצאו משתמשים (0/$a)';
$string['noselectedusers'] = 'לא נבחרו משתמשים';
$string['removeall'] = 'נקה בחירה';
$string['removesel'] = 'הסר מהבחירה';
$string['selected'] = 'נבחר';
$string['selectedlist'] = 'רשימת משתמשים נבחרת';
$string['usersfound'] = '$a משתמש(ים) נמצא)(ן)';
$string['usersinlist'] = 'משתמשים ברשימה';
$string['usersselected'] = '$a משתמשים נבחרו';

?>
