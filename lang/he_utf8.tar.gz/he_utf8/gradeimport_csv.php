<?PHP // $Id: gradeimport_csv.php,v 1.2 2009/01/25 10:18:15 emanuel1 Exp $ 
      // gradeimport_csv.php - created with Moodle 1.9.3+ (Build: 20081126) (2007101532)


$string['csv:view'] = 'ייבא ציונים מ CSV';
$string['modulename'] = 'ייבא קובץ CSV';

?>
