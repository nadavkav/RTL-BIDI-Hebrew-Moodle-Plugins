<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_nologindescription'] = 'התקן תקן מסייע שמונע ממשתמשים להתחבר לתוך המערכת ובנוסף מבטל כל דואר שנשלח למשתמש. ניתן לשמש כדי <em>להשהות</em> חשבונות משתמש.';
$string['auth_nologintitle'] = 'אין התחברות';