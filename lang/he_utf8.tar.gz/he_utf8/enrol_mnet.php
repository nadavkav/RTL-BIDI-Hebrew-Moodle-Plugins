<?PHP // $Id: enrol_mnet.php,v 1.2 2008/02/19 14:23:43 emanuel1 Exp $ 
      // enrol_mnet.php - created with Moodle 1.9 Beta 4 (2007101507)


$string['allcategories'] = '$a קטגוריות פוטנציאליות';
$string['allcourses'] = '$a קורסים פוטנציאליים';
$string['allow_allcourses'] = 'אפשר הירשמויות בכל הקורסים החיצוניים';
$string['allowedcategories'] = '$a קטגוריות מורשות';
$string['allowedcourses'] = '$a קורסים מורשים';
$string['allowedcourseslinktext'] = 'ערוך את הקורסים והקטגוריות המורשות כאן.';
$string['description'] = 'תיאור של הרשמה לאורך תקשורת Moodle.';
$string['enrolname'] = 'תקשורת Moodle';
$string['mnet_enrol_description'] = 'פרסם את השירות הזה על מנת לאפשר למנהלים ב- $a לרשום את הסטודנטים שלהם
לקורסים שיצרת על השרת שלך. <br/><ul><li><em>תלות</em>:בנוסף, חובה עליך 
 <strong>לפרסם </strong> את השירות SSO (מספק השירות) ל $a.

</li><li><em>תלות</em>:
 בנוסף, חובה עליך <strong>להירשם</strong> לשירות ה-SSO (מספק הזהות) על $a.</li></ul><br/>הירשם לשירות זה כדי שתוכל לרשום את הסטודנטים שלך לקורסים שנמצאים ב-$a
.<br/><ul><li><em>תלות</em>:
 בנוסף, חובה עליך <strong>להירשם</strong> לשירות SSO (מספק השירות) ב-$a.</li><li><em>תלות</em>:

 בנוסף, חובה עליך <strong>לפרסם</strong> את שירות ה-SSO (מספק הזהות) ל-$a.</li></ul><br/>';
$string['mnet_enrol_name'] = 'הרשמה מרושתת למוודל';
$string['mnetlocalforexternal'] = 'קורסים מקומיים עבור משתמשים חיצוניים';
$string['nocategoriesdefined'] = 'לא נמצאו קטגוריות קורסים. הגדר קטגוריות חדשות <a href=\"$a\">כאן</a>.';
$string['nocoursesdefined'] = 'לא נמצאו קורסים. הגדר קורסים חדשים <a href=\"$a\">כאן</a>.';

?>
