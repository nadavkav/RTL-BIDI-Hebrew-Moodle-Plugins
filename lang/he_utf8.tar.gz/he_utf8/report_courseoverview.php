<?PHP // $Id: report_courseoverview.php,v 1.1 2009/02/26 10:19:48 emanuel1 Exp $ 
      // report_courseoverview.php - created with Moodle 1.9.4+ (Build: 20090211) (2007101540)


$string['courseoverview:view'] = 'הצג דוח סקירה כללית של הקורס';

?>
