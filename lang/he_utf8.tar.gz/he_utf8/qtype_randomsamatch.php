<?PHP // $Id: qtype_randomsamatch.php,v 1.1 2007/07/24 13:38:13 emanuel1 Exp $ 
      // qtype_randomsamatch.php - created with Moodle 1.8 + (2007021503)


$string['nosaincategory'] = 'בקטגוריה \'$a->catname\' אותה בחרת אין שאלות \'תשובה קצרה\'. בחר בקטגוריה אחרת, 
עשה כמה שאלות בקטגוריה זו.';
$string['notenoughsaincategory'] = 'ישנהן רק $a->nosaquestions שאלות \'תשובה קצרה\' בקטגוריה \'$a->catname\' בה בחרת. בחר בקטגוריה אחרת, צור כמה סאלות נוספות בקטגוריה זו כדי להקטין את מספר השאלות בהן בחרת.';

?>
