<?PHP // $Id: gradeexport_txt.php,v 1.2 2009/01/25 10:18:14 emanuel1 Exp $ 
      // gradeexport_txt.php - created with Moodle 1.9.3+ (Build: 20081126) (2007101532)


$string['modulename'] = 'ייצא לקובץ \"טקסט פשוט\"';
$string['txt:publish'] = 'פרסם יצוא ציונים TXT';
$string['txt:view'] = 'השתמש ביצוא ציונים טקסטואלי';

?>
