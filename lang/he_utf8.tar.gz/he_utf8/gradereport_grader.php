<?PHP // $Id: gradereport_grader.php,v 1.2 2009/05/27 12:44:17 emanuel1 Exp $ 
      // gradereport_grader.php - created with Moodle 1.9.5 (Build: 20090513) (2007101550)


$string['grader:manage'] = 'נהל את דוח הבודק';
$string['grader:view'] = 'הצג את דוח הבודק';
$string['modulename'] = 'דוח הבודק';
$string['preferences'] = 'מאפייני שוח הבודק';

?>
