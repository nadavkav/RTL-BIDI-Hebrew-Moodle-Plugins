<?PHP // $Id: mimetypes.php,v 1.1 2007/05/14 11:56:49 emanuel1 Exp $ 
      // mimetypes.php - created with Moodle 1.8 dev (2006120700)


$string['application/msword'] = 'מסמך Word';
$string['application/pdf'] = 'מסמך PDF';
$string['application/vnd.ms-excel'] = 'גיליון Excel';
$string['application/vnd.ms-powerpoint'] = 'מצגת Powerpoint';
$string['application/zip'] = 'ארכיון zip';
$string['audio/mp3'] = 'קובץ אודיו (שמיעתי) MP3';
$string['audio/wav'] = 'קובץ קול (סאונד)';
$string['document/unknown'] = 'קובץ';
$string['image/bmp'] = 'תמונת BMP לא מכווצת';
$string['image/gif'] = 'תמונת GIF';
$string['image/jpeg'] = 'תמונת JPEG';
$string['text/plain'] = 'קובץ טקסט';
$string['text/rtf'] = 'מסמך RTF';

?>
