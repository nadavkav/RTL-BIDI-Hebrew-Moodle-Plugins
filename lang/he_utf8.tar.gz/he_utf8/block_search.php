<?PHP // $Id: block_search.php,v 1.3 2009/06/07 14:29:15 emanuel1 Exp $ 
      // block_search.php - created with Moodle 1.9.5 (Build: 20090513) (2007101550)


$string['asynchronous'] = 'אסינכרוני';
$string['blockname'] = 'חיפוש גלובלי';
$string['blockssearchmnetfeatures'] = 'חיפוש רשת Moodle';
$string['blockssearchswitches'] = 'אינדוקס אקטיבי עבור בלוקים';
$string['bytes'] = 'בתים (bytes) 0 משמעו ללא גבולות';
$string['configbuttonlabel'] = 'תווית לחיצה';
$string['configenablefileindexing'] = 'אפשר מפתוח (הכנסת אינדקים) לקובץ';
$string['configfiletypes'] = 'סוגי קבצים מטופלים';
$string['configlimitindexbody'] = 'גבול גודל גוף האינדקס';
$string['configpdftotextcmd'] = 'נתיב לפקודת pdftotext';
$string['configsearchtext'] = 'טקסט חיפוש';
$string['configtypetotxtcmd'] = 'שורת פקודה של הממיר';
$string['configtypetotxtenv'] = 'הגדרת סביבה עבור ממיר';
$string['configusingsoftlock'] = 'שילוב תוכנה (עבור קלסטרים משולבים של NFS)';
$string['configutf8transcoding'] = 'המרת כיוון קידוד UTF-8 עבור תוצאות';
$string['configwordtotextcmd'] = 'נתיב לפקודת doctotext';
$string['configwordtotextenv'] = 'הגדרות סביבה עבור ממיר MSWord';
$string['disabled'] = 'מנוטרל';
$string['disabledsearch'] = 'מנוע החיפוש הגלובלי מכובה. אנא ידע את מנהל המערכת.';
$string['enabled'] = 'מופעל';
$string['go'] = 'חפש!';
$string['handlingfor'] = 'טיפול נוסף עבור';
$string['modulessearchswitches'] = 'הפעלת עורך אינדקסים  עבור מודולים';
$string['nosearchableblocks'] = 'אין בלוקים הניתנים לחיפוש';
$string['nosearchablemodules'] = 'אין מודולים הניתנים לחיפוש';
$string['pdfhandling'] = 'טיפול ב-Acrobat PDF';
$string['search'] = 'חיפוש';
$string['searchdiscovery'] = 'גילוי פריטים הניתנים לחיפוש';
$string['searchmoodle'] = 'מודול חיפוש';
$string['synchronous'] = 'בו-זמני';
$string['usemoodleroot'] = 'השתמש במקור Moodle עבור ממירים חיצוניים';
$string['wordhandling'] = 'טיפול ב-Microsoft Word';

?>
