<?PHP // $Id: gradereport_outcomes.php,v 1.3 2008/04/07 09:50:43 emanuel1 Exp $ 
      // gradereport_outcomes.php - created with Moodle 1.9 + (Build: 20080326) (2007101509)


$string['addoutcome'] = 'הוסף תוצאה';
$string['courseoutcomes'] = 'תוצאות הקורס';
$string['coursespecoutcome'] = 'תוצאות הקורס';
$string['modulename'] = 'תוצאות';
$string['outcomes:view'] = 'הצג את תוצאות הדו\"ח';
$string['usedgradeitem'] = 'מספר נושאי ציון';

?>
