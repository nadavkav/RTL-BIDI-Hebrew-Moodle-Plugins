<?PHP // $Id: report_unittest.php,v 1.1 2009/02/26 10:19:48 emanuel1 Exp $ 
      // report_unittest.php - created with Moodle 1.9.4+ (Build: 20090211) (2007101540)


$string['unittest:view'] = 'בצע נסיונות יחידה';

?>
