<?PHP // $Id: qtype_numerical.php,v 1.1 2007/07/24 13:38:11 emanuel1 Exp $ 
      // qtype_numerical.php - created with Moodle 1.8 + (2007021503)


$string['addmoreanswerblanks'] = 'מרווחים עבור {no} תשובות נוספות';
$string['addmoreunitblanks'] = 'מרווחים עבור {no} יחידות נוספות';
$string['answermustbenumberorstar'] = 'חובה שהתשובה תהיה מספר, או  \'*\'';
$string['answerno'] = 'תשובה $a';
$string['errornomultiplier'] = 'עלייך לפרט מכפיל עבור יחידה זו';
$string['errorrepeatedunit'] = 'אינך יכול שיהיו לך שתי יחידות בעלות אותו השם';
$string['notenoughanswers'] = 'חובה עלייך להקליד לפחות תשובה אחת';
$string['unithdr'] = 'יחידה $a';

?>
