<?PHP // $Id: coursereport_log.php,v 1.1 2009/02/26 10:19:47 emanuel1 Exp $ 
      // coursereport_log.php - created with Moodle 1.9.4+ (Build: 20090211) (2007101540)


$string['log:view'] = 'הצג יומני מעקב הקורס';
$string['log:viewlive'] = 'הצג יומני מעקב חיים';
$string['log:viewtoday'] = 'הצג יומני מעקב מהיום';
$string['loglive'] = 'יומני מעקב חיים';

?>
