<?PHP // $Id: access.php,v 1.2 2008/02/19 14:23:43 emanuel1 Exp $ 
      // access.php - created with Moodle 1.9 Beta 4 (2007101507)


$string['access'] = 'נגישות';
$string['accesshelp'] = 'נגישות - עזרה';
$string['accesskey'] = 'מקש גישה, $a';
$string['accessstatement'] = 'הצהרת נגישות';
$string['activitynext'] = 'הפעילות הבאה';
$string['activityprev'] = 'הפעילות הקודמת';
$string['breadcrumb'] = 'נתיב מסלול ההצבעה';
$string['currenttopic'] = 'נושא זה';
$string['currentweek'] = 'שבוע זה';
$string['hideblocka'] = 'הסתר את בלוק $a';
$string['monthnext'] = 'החודש הבא';
$string['monthprev'] = 'החודש הקודם';
$string['showblocka'] = 'הראה את בלוק $a';
$string['sitemap'] = 'מפת האתר';
$string['skipa'] = 'דלג על $a';
$string['skipblock'] = 'דלג על הבלוק';
$string['skipnavigation'] = 'דלג על הניווט';
$string['tabledata'] = 'טבלת נתונים, $a';
$string['tablelayout'] = 'טבלת מערך, $a';
$string['tocontent'] = 'לך לתוכן העיקרי';
$string['tonavigation'] = 'לך לניווט';
$string['youarehere'] = 'אתה נמצא כאן';
$string['showhideblock'] = 'הצג או הסתר את הבלוק'; // ORPHANED

?>
