<?PHP // $Id: userkey.php,v 1.1 2009/02/26 10:19:48 emanuel1 Exp $ 
      // userkey.php - created with Moodle 1.9.4+ (Build: 20090211) (2007101540)


$string['createnewkey'] = 'צור מפתח משתמש חדש';
$string['createuserkey'] = 'צור מפתח משתמש';
$string['deletekeyconfirm'] = 'האם ברצונך למחוק את מפתח משתמש זה?';
$string['edituserkey'] = 'ערוך את מפתח המשתמש';
$string['keyiprestriction'] = 'מפתח הגבלת IP';
$string['keymanager'] = 'ניהול מפתח';
$string['keyvaliduntil'] = 'מפתח יחידה תקפה';
$string['keyvalue'] = 'ערך מפתח';
$string['newuserkey'] = 'מפתח משתמש חדש';
$string['userkey'] = 'מפתח משתמש';
$string['userkeys'] = 'מפתחות משתמש';

?>
