<?PHP // $Id: qtype_random.php,v 1.1 2009/02/26 10:19:48 emanuel1 Exp $ 
      // qtype_random.php - created with Moodle 1.9.4+ (Build: 20090211) (2007101540)


$string['selectmanualquestions'] = 'שאלות אקראיות יכולות להשתמש בשאלות שהציון ניתן להן ידנית';

?>
