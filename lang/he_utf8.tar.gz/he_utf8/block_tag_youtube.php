<?PHP // $Id: block_tag_youtube.php,v 1.1 2007/08/22 13:17:25 emanuel1 Exp $ 
      // block_tag_youtube.php - created with Moodle 1.9 Beta + (2007081600)


$string['anycategory'] = 'כל קטדוריה';
$string['autosvehicles'] = 'מכוניות   וכלי רכב';
$string['blockname'] = 'Youtube';
$string['category'] = 'קטגוריה';
$string['comedy'] = 'קומדיה';
$string['configtitle'] = 'כותרת';
$string['entertainment'] = 'בידור';
$string['filmsanimation'] = 'סרטים והנפשה';
$string['gadgetsgames'] = 'אביזרים ומשחקים';
$string['howtodiy'] = 'כיצד? ו\"עשה זאת באצמך\"';
$string['includeonlyvideosfromplaylist'] = 'כולל סרטי ווידאו רק מרשימת הנגינה עם הזיהוי';
$string['music'] = 'מוזיקה';
$string['newspolitics'] = 'חדשות ופוליטיקה';
$string['numberofvideos'] = 'מספר ברטי הווידאו';
$string['peopleblogs'] = 'אנשים ובלוגים';
$string['petsanimals'] = 'חיות וחיות מחמד';
$string['sports'] = 'ספורט';
$string['travel'] = 'נסיסעות ומקומות';

?>
