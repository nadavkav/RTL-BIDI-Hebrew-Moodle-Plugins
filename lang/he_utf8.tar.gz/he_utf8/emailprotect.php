<?PHP // $Id$ 
      // emailprotect.php - created with Moodle 1.5 ALPHA (2005042300)


$string['filtername'] = 'הגנת דוא\"ל';

?>
