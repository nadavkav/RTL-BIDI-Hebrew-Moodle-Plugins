<?PHP // $Id: qtype_calculated.php,v 1.2 2009/02/12 10:25:44 emanuel1 Exp $ 
      // qtype_calculated.php - created with Moodle 1.9.3+ (Build: 20081126) (2007101532)


$string['addmoreanswerblanks'] = 'הוסף מרוח נוסף לתשובה.';
$string['addmoreunitblanks'] = 'מרווחים עבור $a יחידות נוספות';
$string['answerhdr'] = 'תשובה';
$string['atleastoneanswer'] = 'עליך לספק לפחות תשובה אחת';
$string['correctanswershows'] = 'התשובה הנכונה מראה';
$string['correctanswershowsformat'] = 'פורמט';
$string['existingcategory1'] = 'ישתמש במערך נתונים משותף שכבר קיים';
$string['keptcategory1'] = 'ישתמש באותו מערך נתונים משותף כמקודם';
$string['keptlocal1'] = 'ישתמש באותו מערך נתונים פרטי כמקודם';
$string['makecopynextpage'] = 'עמוד הבא (שאלה חדשה)';
$string['mandatoryhdr'] = 'תווים כלליים שהינם חובה נוכחים בתשובות';
$string['mustbenumeric'] = 'חובה עלייך להכניס כאן מספר כלשהו';
$string['mustnotbenumeric'] = 'זה אינו יכול להיות מספר';
$string['newcategory1'] = 'ישתמש במערך נתונים משותף חדש';
$string['newlocal1'] = 'ישתמש במערך נתונים פרטי חדש';
$string['nextitemtoadd'] = '\'הפריט להוספה\' הבא';
$string['nextpage'] = 'העמוד הבא';
$string['nodataset'] = 'כלום - זהו איננו תו כללי';
$string['nosharedwildcard'] = 'בקטגוריה זו אין תווים כלליים משותפים';
$string['possiblehdr'] = 'תווים כללים אפשריים נמצאים רק בטקסט של השאלה';
$string['tolerance'] = 'מרווח סובלנות &plusmn;';
$string['trueanswerinsidelimits'] = 'תשובה נכונה: $a->correct בטווח ערכי אמת $a->true';
$string['updatecategory'] = 'עדכן את הקטגוריה';
$string['usedinquestion'] = 'משמש בשאלה';
$string['youmustenteramultiplierhere'] = 'כאן חובה עלייך להכניס מכפיל';

?>
