<?PHP // $Id: gradeexport_csv.php,v 1.1 2007/08/15 11:43:41 emanuel1 Exp $ 
      // gradeexport_csv.php - created with Moodle 1.8 + (2007021503)


$string['modulename'] = 'ייצא לקובץ CVS';

?>
