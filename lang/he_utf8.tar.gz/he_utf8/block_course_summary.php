<?PHP // $Id$ 
      // block_course_summary.php - created with Moodle 1.8 dev (2006120700)


$string['coursesummary'] = 'סיכום הקורס';
$string['pagedescription'] = 'תיאור האתר או הקורס';

?>
