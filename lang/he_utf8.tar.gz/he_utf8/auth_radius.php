<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_radiuschangepasswordurl_key'] = 'ובת URL לשינוי סיסמה';
$string['auth_radiusdescription'] = 'שיטה זו עושה שימוש בשרת <a href=\"http://en.wikipedia.org/wiki/RADIUS\" target=\"_blank\">RADIUS</a> כדי לבדוק האם שם המשתמש והסיסמה הם תקפים.';
$string['auth_radiushost'] = 'כתובת שרת ה-RADIUS';
$string['auth_radiushost_key'] = 'מחשב מארח';
$string['auth_radiusnasport'] = 'פתחה בה יש להשתמש כדי להתחבר';
$string['auth_radiusnasport_key'] = 'יציאה';
$string['auth_radiussecret'] = 'סוד משותף';
$string['auth_radiussecret_key'] = 'סוד';
$string['auth_radiustitle'] = 'השתמש בשרת RADIUS';