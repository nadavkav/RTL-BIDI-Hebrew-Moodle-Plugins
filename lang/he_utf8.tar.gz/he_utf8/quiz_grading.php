<?PHP // $Id: quiz_grading.php,v 1.5 2009/02/12 10:25:45 emanuel1 Exp $ 
      // quiz_grading.php - created with Moodle 1.9.3+ (Build: 20081126) (2007101532)


$string['essayonly'] = 'לשאלות הבאות צריך לתת ציון באופן ידני.';
$string['gradeall'] = 'תן ציונים לכל $a נסיונות המענה';
$string['graded'] = 'ניתן ציון';
$string['gradenextungraded'] = 'תן ציון ל-$a נסיונות המענה הבאים';
$string['gradeungraded'] = 'תן ציון ל-$a נסיונות המענה שלא נבדקו';
$string['grading'] = 'מתן ציון באופן ידני';
$string['gradingall'] = 'כל $a נסיונות המענה בשאלה זו.';
$string['gradingattempt'] = 'נסיון מענה מס\' $a->attempt עבור $a->fullname.';
$string['gradingnextungraded'] = 'נסיון מענה מס\' $a הבא שלא נבדק';
$string['gradingnotallowed'] = 'אין לך היתר לתת ציון לתגובות או תשובות באופן ידני';
$string['gradingungraded'] = 'נסיון מענה $a שלא נבדק';
$string['gradinguser'] = 'נסיונות מענה עבור $a';

?>
