<?PHP // $Id$ 
      // autoview.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['autoviewtext'] = 'מצגת וידאו מתואמת';
$string['chooseconfig'] = 'בחרו קובץ הגדרות';
$string['configfile'] = 'קובץ הגדרות';
$string['configflashserver'] = 'כתובת שרת RED5 / FLASH MEDIA SERVER';
$string['confignote2'] = 'שרותי תוספים';
$string['conversiondone'] = 'המסמך הומר בהצלחה';
$string['conversionfailed'] = 'המרת המסמך נכשלה';
$string['convertsavefailed'] = 'לא ניתן לשמור את קובץ המסמך המומר החדש';
$string['editbutton'] = 'מעבר למצב עריכה';
$string['editoff'] = 'מעבר למצב תצוגה';
$string['hidenav'] = 'הסתרת סרגל הניווט של המערכת';
$string['modulename'] = 'מצגת וידאו מתואמת';
$string['modulenameplural'] = 'מצגות וידאו מתואמות';

?>
