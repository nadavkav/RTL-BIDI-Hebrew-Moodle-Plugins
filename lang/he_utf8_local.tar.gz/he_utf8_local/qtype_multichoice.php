<?PHP // $Id$ 
      // qtype_multichoice.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addingmultichoice'] = 'הוספת שאלה מסוג רב־בחירה';
$string['answernumberingABCD'] = 'A, B, C, ...';
$string['clozeaid'] = 'הזינו את המילה החסרה';
$string['editingmultichoice'] = 'עריכת שאלת רב־בחירה (אמריקאית)';
$string['errfractionsnomax'] = 'על אחת מהתשובות להיות  100%%, כך <br />שיהיה אפשרי לקבל את מלוא הציון עבור השאלה הזו';
$string['fillouttwochoices'] = 'עליכם למלא לפחות שתי בחירות. בחירות שתשאירו ריקות לא יחשבו.';
$string['shuffleanswers'] = 'לערבב את התשובות?';
$string['singleanswer'] = 'בחרו בתשובה אחת.';

?>
