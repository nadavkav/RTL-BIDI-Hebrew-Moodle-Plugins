<?php

$string['webclass'] = 'webclass';

$string['modulename'] = 'Web Class';
$string['modulenameplural'] = 'Web Classes';

$string['webclassfieldset'] = 'Custom example fieldset';
$string['webclassintro'] = 'Introduction to web class ';
$string['webclassname'] = 'webclass Name';
$string['startdate'] = 'Starting date and time';
$string['uploadtext'] = 'Upload a zip file which have power point presentaion saved as jpeg';
$string['enroltext'] = 'Class entrance key';
$string['gotoclass'] = 'Click here to enter class room';
$string['Youareloginas'] = 'You are login as ';
$string['Pleaselogin'] = 'Please login as a teacher or student.';

$string['commentsforteacher'] = 'To start the brodcasting lecture, click broadcast button. you can use First, Next, Previous buttons to change the slides. Some time student ask question from the text chat. you can answer for that using text chat or audio chat. your answer is brodcasted for every one who have logged as student.';

$string['commentsforstudents'] = 'you can listen the lecture clicking on the listen button.If you have any question about the lecture you can ask using text chat from the lecturer. your question can see every one who have logged as teacher or student. you can use First, Next, Previous buttons to change the slides.';

$string['slidenumber'] = 'Teachers slide number should be here';
$string['slideshow'] = 'There should be slide show.';
$string['studentlist'] = 'Here will be students who have asked questions form you.';
$string['lectureroom'] = 'LECTURE ROOM';
$string['askquestion'] = 'Ask Question ';
$string['privetanswer'] = 'Private Answers';
$string['publicquestion'] = 'Public Question ';

//printanswer..
$string['question'] = 'QUESTION : -';
$string['answer'] = 'ANSWER : -';
$string['nopriqus'] = 'No questions and answers.';




//showpublicqus..
$string['noans'] = 'No answers.Please wait......';
$string['noqus'] = 'There is no public questions and answers.';

//question..
$string['msgtyp'] = 'Message type';
$string['private'] = 'Private';
$string['public'] = 'Public';

?>
