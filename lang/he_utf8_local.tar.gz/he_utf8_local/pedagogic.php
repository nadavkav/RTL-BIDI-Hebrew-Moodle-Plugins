<?PHP // $Id$ 
      // pedagogic.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['pedagogic_chat'] = '<div style=\"direction:rtl; text-align:right;float:right;\">
1. דו שיח עם המורה לפני מבחן
<br/>
2. רעיון עם דמות מפורסמת
<br/>
3. תלמיד מתחזה לדמות והכיתה משוחחת איתו
<br/>
<br/></div>';

?>
