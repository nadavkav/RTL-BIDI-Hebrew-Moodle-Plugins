<?PHP // $Id$ 
      // block_section_links.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['oldernewstopics'] = 'ידיעות חדשותיות ישנות';
$string['addanewstopic'] = 'הוספת ידיעה חדשה';
$string['block_newsitems_numchars'] = '250';
$string['confignewsitemblock'] = 'מספר תווים להצגה מתוך הידיעה החדשותית';

?>
