<?PHP // $Id$ 
      // learningdiary.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['guideddiary'] = 'יומן אישי (מודרך)';
$string['modulename'] = 'יומן אישי (מודרך)';
$string['modulenameplural'] = 'יומני תלמיד אישיים';
$string['userdiary'] = 'יומן אישי (מודרך)';
$string['chooseastudent'] = 'בחרו תלמיד'; // ORPHANED

?>
