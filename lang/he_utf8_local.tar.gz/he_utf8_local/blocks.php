<?php

//$string['notext'] = 'ללא תוכן';
$string['notext'] = 'משבצת זו טרם הוגדרה'.'<br/><br/>';
//$string['nofooter'] = 'ללא תחתית';
$string['nofooter'] = '.';

?>