<?PHP // $Id$ 
      // gradereport_grader.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['grader:manage'] = 'נהל טבלת ציוני תלמידים כוללת';
$string['grader:view'] = 'הצגת טבלת ציוני תלמידים כוללת';
$string['modulename'] = 'טבלת ציוניי תלמידים כוללת של מרחב-לימוד זה';

?>
