<?PHP // $Id$ 
      // block_section_links.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['blockname'] = 'קישורים ליחידות הוראה';
$string['jumptocurrenttopic'] = 'ניווט לנושא הנוכחי';
$string['jumptocurrentweek'] = 'ניווט לשבוע הנוכחי';

?>
