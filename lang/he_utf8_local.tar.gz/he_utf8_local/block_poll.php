<?PHP // $Id$ 
      // block_poll.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['pollconfirmdelete'] = 'האם אתם בטוחים שאתם מעוניינים למחוק את הסקר (a$) וכל המידע הקשור בו ?';
$string['pollwarning'] = 'רק מורים מורשים לביצוע פעולה זו';

?>
