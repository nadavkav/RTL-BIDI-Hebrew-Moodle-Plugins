<?PHP // $Id$ 
      // form.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addfields'] = 'הוספת $a שדות לטופס';
$string['display'] = 'הצגה';
$string['err_alphanumeric'] = 'כאן, יש להקליד רק אותיות או מספרים.';
$string['err_email'] = 'כאן, יש להקליד כתובת דואר אלקטרוני תקינה ותקפה.';
$string['err_lettersonly'] = 'כאן, יש להקליד אותיות בלבד.';
$string['err_maxlength'] = 'כאן, לא ניתן להקליד יותר מ-$a->format תווים.';
$string['err_minlength'] = 'כאן יש להקליד לפחות $a->format תווים.';
$string['err_nonzero'] = 'כאן, יש להקליד מספר שאינו מתחיל ב-0.';
$string['err_nopunctuation'] = 'כאן, לא ניתן להקליד סימני פיסוק.';
$string['err_numeric'] = 'כאן, עליכם להקליד מספר.';
$string['err_required'] = 'שדה זה חשוב! יש להזין בו ערך משמעותי.';
$string['hideadvanced'] = 'הסתרת מאפיינים נוספים';
$string['modstandardels'] = 'הגדרות כלליות';
$string['requiredelement'] = 'יש להזין תוכן בשדה זה';
$string['revealpassword'] = 'חשיפה';
$string['selectallornone'] = 'בחרו הכל או כלום';
$string['showadvanced'] = 'הצגת מאפיינים נוספים';
$string['unmaskpassword'] = 'הצגת תוכן השדה';

?>
