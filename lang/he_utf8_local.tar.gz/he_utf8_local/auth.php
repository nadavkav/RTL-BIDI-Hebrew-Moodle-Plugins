<?PHP // $Id$ 
      // auth.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['actauthhdr'] = 'רכיבי התחברות פעילים';
$string['auth_cas_auth_user_create'] = 'יצירת משתמשים באופן חיצוני';
$string['auth_cas_create_user_key'] = 'יצירת משתמש';
$string['auth_common_settings'] = 'הגדרות כלליות';
$string['auth_data_mapping'] = 'מיפוי שדות מידע בין מערכות';
$string['auth_dbpasstype_key'] = 'תצורת הסיסמה';
$string['auth_emailchangecancel'] = 'ביטול שינוי כתובת דואר';
$string['auth_emailchangepending'] = 'ביצוע השינוי ממתין לאישור אשר נשלך אל תיבת הדואר שלכם';
$string['auth_emailrecaptcha_key'] = 'הפעלת שיטת זיהוי מסוג reCAPTCHA';
$string['auth_emailsettings'] = 'מאפיינים';
$string['auth_emailupdate'] = 'עדכון כתובת דואר אלקטרוני';
$string['auth_fieldlock'] = 'נעילת ערך';
$string['auth_fieldlocks'] = 'נעילת שדות משתמשים';
$string['auth_imaptitle'] = 'השתמשו בשרת IMAP';
$string['auth_ldap_attrcreators_key'] = 'יוצרי המאפיינים';
$string['auth_ldap_auth_user_create_key'] = 'יצירת משתמשים במקור חיצוני';
$string['auth_ldap_groupecreators_key'] = 'יוצרי קבוצות';
$string['auth_ldap_passtype'] = 'פרט את תצורת המבנה של סיסמאות חדשות או כאלה ששונו בשרת ה-LDAP.';
$string['auth_ldap_passtype_key'] = 'תצורת מבנה הסיסמה';
$string['auth_ldap_preventpassindb_key'] = 'הסתרת סיסמאות';
$string['auth_ldap_search_sub_key'] = 'חיפוש בתת-הקשרים';
$string['auth_ntlmsso'] = 'NTLM SSO';
$string['auth_pop3port'] = 'ממשק חיבור (port) שרת (110 הינו הכי נפוץ)';
$string['auth_radiusnasport'] = 'מספר ממשק חיבור (port) בו יש להשתמש כדי להתחבר';
$string['auth_radiustype_key'] = 'זיהוי';
$string['auth_radiustypechapmd5'] = 'CHAP MD5';
$string['auth_radiustypemschapv1'] = 'Microsoft CHAP version 1';
$string['auth_radiustypemschapv2'] = 'Microsoft CHAP version 2';
$string['auth_radiustypepap'] = 'PAP';
$string['auth_remove_keep'] = 'שמירה פנימית';
$string['auth_remove_suspend'] = 'השהייה פנימית';
$string['auth_remove_user'] = 'פרטו מה יש לעשות עם חשבונות משתמש פנימיים בזמן תאום המוני כאשר המשתמש הוצא ממקור חיצוני. רק משתמשים מושהים מוחזרים לשימוש באופן אוטומטי במידה והם מופיעים מחדש במקור החיצוני.';
$string['auth_shib_only'] = 'אימות שיבולת בלבד';
$string['auth_shibboleth_login_long'] = 'התחברות למוודל דרך שיבולת';
$string['auth_shibboleth_select_member'] = 'אני חבר ב...';
$string['auth_sync_script'] = 'אוסף פקודות סנכרון ה-corn';
$string['auth_updatelocal'] = 'עדכון מקומי';
$string['auth_updatelocal_expl'] = '<p><b>עדכון מקומי:</b>אם אפשרות זו מופעלת, השדה יתעדכן (מתוך מקור ווידוי חיצוני) בכל פעם שהמשתמש מתחבר למערכת או כשמתרחש סינכרון משתמשים. 
את השדות שמוגדרים לעדכון מקומי צריך לנעול. 
 
</p>';
$string['auth_updateremote'] = 'עדכון חיצוני';
$string['auth_updateremote_expl'] = '<p><b>עדכון חיצוני:</b>אם אפשרות זו מופעלת, מקור הווידוי החיצוני יתעדכן בכל פעם שמתבצע עדכון רשומת המשתמש. אין לנעול את השדות כדי לאפשר את עריכתם. </p>';
$string['auth_usernameexists'] = 'שם משתמש נבחר כבר קיים. אנא בחרו שם חדש.';
$string['chooseauthmethod'] = 'בחרו צורת אימות:';
$string['createpasswordifneeded'] = 'יצירת סיסמה, אם היא נדרשת';
$string['enterthenumbersyouhear'] = 'הקלידו את המספרים אותם אתם שומעים';
$string['enterthewordsabove'] = 'הקלידו את המילים הרשומות מעלה';
$string['errorminpassworddigits'] = 'סיסמאות מחייבות לפחות $a ספרות.';
$string['errorminpasswordnonalphanum'] = 'סיסמאות מחייבות לפחות $a תווים שהם לא אלפאנומרים (אותיות).';
$string['forcechangepassword'] = 'אלצו שינוי סיסמה';
$string['forcechangepassword_help'] = 'אלצו משתמשים לשנות את הסיסמה שלהם בנסיון ההתחברות הבא ל-Moodle.';
$string['forcechangepasswordfirst_help'] = 'אלצו משתמשים לשנות את הסיסמה שלהם בנסיון ההתחברות הראשון ל-Moodle.';
$string['forgottenpasswordurl'] = 'כתובת URL למצב של אובדן סיסמה על ידי המשתמש';
$string['getanaudiocaptcha'] = 'הצגת CAPTCHA קולי';
$string['getanimagecaptcha'] = 'הצגת CAPTCHA חזותי';
$string['getanothercaptcha'] = 'הצגת CAPTCHA מסוג אחר';
$string['incorrectpleasetryagain'] = 'שגיאה. אנא נסו שוב';
$string['plaintext'] = 'מלל פשוט';
$string['pluginnotenabled'] = 'התוסף המשמש לאימות \'$a\' איננו מופעל';
$string['pluginnotinstalled'] = 'התוסף המשמש לאימות \'$a\' איננו מותקן';
$string['recaptcha'] = 'reCAPTCHA';
$string['showguestlogin'] = 'אתם יכולים להחביא או להראות את כפתור ההתחברות לאורחים בעמוד ההתחברות.';
$string['stdchangepassword'] = 'השתמשו בדף שינוי סיסמה תקני';
$string['auth_openidtitle'] = 'OpenID'; // ORPHANED
$string['auth_openiddescription'] = 'OpenID is an open, decentralized, free framework for user-centric digital identity. To find out more, visit <a href=\"http://openid.net/\">OpenID.net</a>.'; // ORPHANED
$string['auth_openid_ssotitle'] = 'OpenID SSO'; // ORPHANED
$string['auth_openid_ssodescription'] = 'OpenID is an open, decentralized, free framework for user-centric digital identity. To find out more, visit <a href=\"http://openid.net/\">OpenID.net</a>.'; // ORPHANED

?>
