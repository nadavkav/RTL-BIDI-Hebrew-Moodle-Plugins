<?PHP // $Id$ 
      // block_ajax_marking.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['ago'] = 'בעבר';
$string['ajaxmarking'] = 'מחכים לציון';
$string['assignment'] = 'משימה';
$string['collapse'] = 'רענון רשימה';
$string['configure'] = 'מאפיינים';
$string['day'] = 'יום';
$string['days'] = 'ימים';
$string['discussion'] = 'דיון';
$string['earliest'] = 'תגובה ללא ציון';
$string['forum'] = 'קבוצת דיון';
$string['hour'] = 'שעה';
$string['hours'] = 'שעות';
$string['marking'] = 'מחכים לציון';
$string['nothing'] = 'אין מטלות חדשות :-)';
$string['submitted'] = 'הוגשו';
$string['total'] = 'סהכ מחכים לציון';
$string['waiting'] = 'מחכים';
$string['week'] = 'שבוע';
$string['weeks'] = 'שבועות';
$string['workshop'] = 'סדנה';

?>
