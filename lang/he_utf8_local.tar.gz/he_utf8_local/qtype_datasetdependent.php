<?PHP // $Id: qtype_datasetdependent.php,v 1.4 2007/08/15 11:43:28 emanuel1 Exp $
      // qtype_datasetdependent.php - created with Moodle 1.8 + (2007021503)


$string['additem'] = 'הוספת משתנה';
$string['atleastonerealdataset'] = 'חובה שבתוכן השאלה יהיה לפחות מערך נתונים אמיתי אחד';
$string['atleastonewildcard'] = 'בנוסחאת השאלה או בתוכן השאלה צריך להיות לפחות תו־כללי (משתנה) אחד';
$string['calcdistribution'] = 'חלוקת ערכים';
$string['calclength'] = 'מקומות עשרוניים';
$string['calcmax'] = 'מירבי';
$string['calcmin'] = 'נמוך';
$string['dataitemdefined'] = 'זמינה עם $a ערכים מספריים שמוגדרים כבר';
$string['datasetrole'] = 'התווים־הכללים (המשתנים)  <strong>{x..}</strong> יוחלפו על ידי ערך מספרי שיילקח ממערך הנתונים';
$string['deletelastitem'] = 'מחקו את התשובה האחרונה';
$string['existingcategory1'] = 'ערך מקבוצת ערכים אשר קיימים ושמישים בשאלות אחרות בסיווג זה.';
$string['existingcategory2'] = 'קובץ מתוך קבוצה קיימת של קבצים אשר קיימים ושמישים בשאלות אחרות בסיווג זה.';
$string['existingcategory3'] = 'קישור מתוך קבוצה קיימת של קישורים אשר קיימים ושמישים בשאלות אחרות מסיווג זה.';
$string['forceregeneration'] = 'ערכים חדשים, עבור כל תשובה - אוסף משתנים';
$string['getnextnow'] = 'יצירת \'משתנה נוסף\' חדש';
$string['item(s)'] = 'ערכים חדשים למשתנים הקיימים';
$string['itemno'] = 'תשובה $a';
$string['itemscount'] = 'ספירת<br/>תשובות';
$string['itemtoadd'] = 'הגדות משתנים, המשמשות ליצירת תשובות חדשות';
$string['keptcategory1'] = 'ערך מאותו סיווג של קבוצת ערכים הניתן לשימוש חוזר כמקודם';
$string['keptcategory2'] = 'קובץ מתוך מאותו הסיווג, אוסף קבצים הניתן לשימוש חוזר כמקודם';
$string['keptcategory3'] = 'קישור מתוך מאותו הסיווג, אוסף קישורים הניתן לשימוש חוזר כמקודם';
$string['keptlocal1'] = 'ערך מאותה קבוצת ערכים של שאלות פרטיות הניתן לשימוש חוזר כמקודם';
$string['keptlocal2'] = 'קובץ מאותה השאלה, אוסף פרטי של קבצים הניתן לשימוש חוזר כמקודם';
$string['keptlocal3'] = 'קישור מאותה השאלה, אוסף פרטי של קישורים הניתן לשימוש חוזר כמקודם';
$string['lastitem(s)'] = 'תשובות אחרונות)';
$string['loguniform'] = 'סבירות גובהה לערכים הקרובים לתחילת הטווח';
$string['minmax'] = 'טווח ערכים';
$string['newcategory1'] = 'ערך מתוך אוסף קיים של ערכים אשר יכולים להשתמש על ידי שאלות אחרות בסיווג זה.';
$string['newcategory2'] = 'קובץ מתוך אוסף חדש של קבצים, בהם יכולות להשתמש גם שאלות אחרות בסיווג זה';
$string['newcategory3'] = 'קישור מתוך אוסף חדש של קישורים, בהם יכולות להשתמש גם שאלות אחרות בסיווג זה';
$string['newlocal1'] = 'ערך מקבוצה חדשה של ערכים שישתמשו בו אך ורק בשאלה זאת';
$string['newlocal2'] = 'קובץ מתוך אוסף חדש של קבצים שישמשו רק את השאלה הזו';
$string['newlocal3'] = 'קישור מתוך אוסף חדש של קישורים שישמשו רק את השאלה הזו';
$string['nodataset'] = 'כלום - זהו איננו תו־כללי';
$string['param'] = 'Param {<strong>$a</strong>}';
$string['replacewithrandom'] = 'החליפו בערך אקראי';
$string['reuseifpossible'] = 'עשו שימוש חוזר בערך הקודם, אם הדבר אפשרי';
$string['sharedwildcard'] = 'תו־כללי (משתנה) משותף';
$string['sharedwildcards'] = 'תוים־כלליים (משתנים) משותפים';
$string['uniform'] = 'חלוקה אחידה של הערכים';
$string['updatedatasetparam'] = 'רענון הגדרות - \"מחולל התשובות\"';
$string['youmustaddatleastoneitem'] = 'עלייכם להוסיף לפחות תשובה אחת למערך התשובות לפני שתוכל לשמור את השאלה הזו.';

?>
