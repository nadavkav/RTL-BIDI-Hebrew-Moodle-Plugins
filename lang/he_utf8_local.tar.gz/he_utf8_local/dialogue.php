<?PHP // $Id$ 
      // dialogue.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['allowmultiple'] = 'הרשה יותר מדו-שיח אחד עם אותו אדם';
$string['allowstudentdialogues'] = 'הרשה דו-שיח בין סטודנט לסטודנט';
$string['closeddialogues'] = 'דו-שיח סגורים';
$string['deleteafter'] = 'מחק דו-שיח סגורים לאחר (ימים)';
$string['dialogueclosed'] = 'דו-שיח סגור';
$string['dialogueintro'] = 'דו-שיח היכרות';
$string['dialoguemail'] = '$a->userfrom פרסם הודעה חדשה בהודעת השו-שיח שלך
ל\'$a->dialogue\'

אתה יכול לראות אותו כנספח להודעת השו-שיח שלך:

    $a->url';
$string['dialoguename'] = 'שם דו-שיח';
$string['dialogueopened'] = 'נפתח דו-שיח עם $a';
$string['dialoguewith'] = 'דו-שיח עם $a';
$string['mailnotification'] = 'הודעה בדואר אלקטרוני';
$string['modulename'] = 'דו-שיח';
$string['modulenameplural'] = 'רב-שיח';
$string['namehascloseddialogue'] = '$a סגר דו-שיח';
$string['newdialogueentries'] = 'הודעות חדשות בדו-שיח';
$string['noavailablepeople'] = 'אף אחד אינו זמין לקיום דו-שיח';
$string['notavailable'] = 'לתלמידים אורחים לא מתאפשר לקיים דו-שיח';
$string['notextentered'] = 'לא הוכנס מלל';
$string['notstarted'] = 'עדיין לא התחלת דו-שיח זה';
$string['openadialoguewith'] = 'פתח בדו-שיח עם';
$string['opendialogue'] = 'פתח דו-שיח';
$string['opendialogueentries'] = 'פתח הודעות דו-שיח';
$string['opendialogues'] = 'פתח רב-שיח';
$string['pane0'] = 'פתח דו-שיח';
$string['pane1'] = '$a דו-שיח המחכים לתגובה ממך';
$string['pane1one'] = 'דו-שיח 1 המחכה לתגובה ממך';
$string['pane2'] = '$a דו-שיח המחכים לתגובה מהאדם האחר';
$string['pane2one'] = 'דו-שיח 1 המחכה לתגובה מהאדם השני';
$string['pane3'] = '$a דו-שיח סגורים';
$string['pane3one'] = 'דו-שיח סגור 1';
$string['studenttostudent'] = 'תלמיד לתלמיד';
$string['teachertostudent'] = 'מורה לתלמיד';
$string['typeofdialogue'] = 'סוג דו-שיח';
$string['viewallentries'] = 'ראה $a הודעות דו-שיח';

?>
