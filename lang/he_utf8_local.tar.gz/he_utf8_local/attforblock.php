<?PHP // $Id: attforblock.php,v 1.1.2.1 2008/06/20 17:37:42 dlnsk Exp $ 
      // attendanceblk.php - created with Moodle 1.5.3+ (2005060230)


$string['attforblock:changepreferences'] = 'שינוי מאפיינים';
$string['attforblock:export'] = 'ייצוא דוחות';
$string['attforblock:manageattendances'] = 'ניהול נוכחות';
$string['attforblock:takeattendances'] = 'רישום נוכחות';
$string['attforblock:view'] = 'תצוגת נוכחות';
$string['attforblock:viewreports'] = 'תצוגת דוחות';
$string['description'] = 'ניתן להוסיף פעילות רישום-נוכחות אחת לכל מרחב לימוד.';
$string['modulename'] = 'רישום נוכחות';
$string['modulenameplural'] = 'רישום נוכחות';
$string['notfound'] = 'יש להוסיף פעילות רישום-נוכחות למרחב הלימוד!';

?>
