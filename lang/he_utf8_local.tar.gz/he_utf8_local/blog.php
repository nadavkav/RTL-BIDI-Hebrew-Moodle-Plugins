<?PHP // $Id$
      // blog.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addnewentry'] = 'הוספת ידיעה חדש';
$string['backupblogshelp'] = 'אפשרות זו תצרף את הבלוגים לגיבויים האוטומטים של האתר';
$string['blockmenutitle'] = 'תפריט בלוג מערכתי';
$string['blocktagstitle'] = 'תוויות בלוגים מערכתיים';
$string['blocktitle'] = 'כותרת תוויות הבלוג';
$string['blog'] = 'הבלוג שלי';
$string['blogtags'] = 'תוויות בלוגים';
$string['courseblog'] = 'בלוג מרחב הלימוד: $a';
$string['courseblogs'] = 'משתמשים יכולים לראות את הבלוגים של חבריהם במרחב-הלימוד בלבד';
$string['deleteotagswarn'] = 'האם אתם בטוחים שברצונכם להסיר תווית זו? (התוויות הללו) <br /> מכל ההודעות שפורסמו בקבוצת הדיון ולהוציא אותה מתוך המערכת?';
$string['disableblogs'] = 'הסירו את מערכת הבלוגים לחלוטין';
$string['emptybody'] = 'יש למלא תוכן בגוף ידיעה בבלוג';
$string['emptytitle'] = 'יש להזין כותרת לידיעה בבלוג';
$string['entrybody'] = 'גוף הידיעה בבלוג';
$string['entrybodyonlydesc'] = 'תיאור מאמר';
$string['entryerrornotyours'] = 'ידיעת בלוג זו אינה שלכם';
$string['entrysaved'] = 'הידיעה שלכם נשמר';
$string['entrytitle'] = 'כותרת הידיעה';
$string['entryupdated'] = 'ידיעת הבלוג עודכנה';
$string['norighttodeletetag'] = 'אין לכם הרשאה למחוק את התווית הזו - $a';
$string['notallowedtoedit'] = 'אתם לא מורשים לערוך רשומה זו';
$string['numberofentries'] = 'ידיעות: $a';
$string['numberoftags'] = 'מספר התוויות להצגה';
$string['pagesize'] = 'מספר ידיעות הבלוגים שיופיעו בכל עמוד';
$string['permalink'] = 'קישור קבוע';
$string['publishto'] = 'פרסמו ל';
$string['publishtonoone'] = 'עצמך (רק אתם רואים)';
$string['siteblog'] = 'בלוג מערכתי: $a';
$string['tags'] = 'תוויות';
$string['tagsort'] = 'מיון תצוגת התווים על פי';
$string['tagtext'] = 'תוכן התווית';
$string['timewithin'] = 'הצגת התווים שנעשה בהם שימוש בטווח זה של ימים';
$string['updateentrywithid'] = 'מעדכן את הידיעה';
$string['viewcourseentries'] = 'הצגת ידיעות הבלוגים של משתמשי מרחב־לימוד זה';
$string['viewmyentries'] = 'הצגת הידיעות שלי';
$string['viewsiteentries'] = 'הצגת ידיעות מהמערכת כולה';
$string['worldblogs'] = 'העולם כולו יכול לקרוא את הידיעות שהוגדרו כ\'נגישות לעולם\'.';
$string['myblog'] = 'צפייה בבלוג';
$string['addcomment'] = 'הוסיפו תגובה';
$string['listcomments'] = 'רשימת תגובות';
$string['by'] = 'נכתב על ידי';
$string['relatedtocourse'] = 'ידיעה זו מתייחסת למרחב הלימוד';

?>
