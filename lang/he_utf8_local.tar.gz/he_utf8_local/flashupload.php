<?PHP // $Id: flashupload.php,v 0.1 2007/08/30 hgeppl
      // flashupload.php - created with Moodle 1.7

$string['flashupload'] = 'העלאת מספר קבצים';
$string['cancel_upload'] = 'ביטול העלאה';
$string['upload_files'] = 'העלאת מספר קבצים';
$string['file_too_big'] = 'קובץ גדול מידי';
$string['zero_byte'] = 'אין אפשרות להעלות קובץ ריק';
$string['pending'] = 'ממתין...';
$string['false_flashver'] = '<strong>הערה:</strong> כדי להעלות מספר קבצים ביחד, יש לעדכן את גירסת התוסף פלאש!'

?>
