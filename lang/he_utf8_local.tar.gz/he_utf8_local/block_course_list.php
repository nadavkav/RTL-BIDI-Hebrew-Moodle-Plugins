<?PHP // $Id$ 
      // block_course_list.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['allcourses'] = 'משתמש בתפקיד מנהל רואה את כל מרחבי הלימוד';
$string['blockname'] = 'רשימת מרחבי לימוד';
$string['configadminview'] = 'מה המנהל צריך לראות במשבצת-ניהול רשימת מרחבי הלימוד?';
$string['confighideallcourseslink'] = 'הסתר את קישור \"כל מרחבי הלימוד\" בסוף משבצת-התוכן. הסתרת קישור לא משפיעה על תצוגת המנהל';
$string['hideallcourseslink'] = 'הסתרת כל הקישורים למרחבי הלימוד';
$string['owncourses'] = 'משתמש בתפקיד מנהל רואה רק את מרחבי הלימוד שלו';

?>
