<?PHP // $Id: qtype_calculated.php,v 1.1 2007/07/24 13:38:10 emanuel1 Exp $
      // qtype_calculated.php - created with Moodle 1.8 + (2007021503)


$string['addmoreanswerblanks'] = 'הוספת נוסחאת תשובה נוספת';
$string['addmoreunitblanks'] = 'הוספת $a יחידות משתנים נוספות';
$string['answerhdr'] = 'תשובה';
$string['atleastoneanswer'] = 'עליכם לספק לפחות תשובה אחת';
$string['correctanswershows'] = 'התשובה הנכונה מראה';
$string['correctanswershowsformat'] = 'תצורה';
$string['existingcategory1'] = 'ישתמש במערך נתונים משותף שכבר קיים';
$string['keptcategory1'] = 'ישתמש באותו מערך נתונים משותף כמקודם';
$string['keptlocal1'] = 'ישתמש במערך נתונים פרטי';
$string['makecopynextpage'] = 'עמוד הבא (שאלה חדשה)';
$string['mandatoryhdr'] = 'תווים־כלליים (משתנים) הכרחיים, הנוכחים בתשובות';
$string['mustbenumeric'] = 'חובה עלייך להכניס כאן מספר כלשהו';
$string['mustnotbenumeric'] = 'זה אינו יכול להיות מספר';
$string['newcategory1'] = 'ישתמש במערך נתונים משותף חדש';
$string['newlocal1'] = 'ישתמש במערך נתונים פרטי חדש';
$string['nextitemtoadd'] = 'מאפייני התשובות המחוללות הבאות';
$string['nextpage'] = 'העמוד הבא';
$string['nodataset'] = 'כלום - זהו איננו תו כללי';
$string['nosharedwildcard'] = 'בסיווג זה אין תווים־כלליים (משתנים) משותפים';
$string['possiblehdr'] = 'תווים־כללים (משתנים) אפשריים נמצאים רק בתוכן של השאלה';
$string['tolerance'] = 'מרווח סובלנות &plusmn;';
$string['updatecategory'] = 'עדכון סיווג';
$string['usedinquestion'] = 'משמש בשאלה';
$string['youmustenteramultiplierhere'] = 'חובה עלייכם להכניס מכפיל';

?>
