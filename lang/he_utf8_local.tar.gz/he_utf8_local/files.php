<?php

$string['selectallfiles'] = 'בחרו את כל הקבצים';
$string['deselectallfiles'] = 'בטלו את בחירת כל הקבצים';
$string['actionforselectedfiles'] = 'בחרו פעולה עבור הקבצים המסומנים: ';
$string['zipselectedfiles'] = 'יצירת קובץ זיפ';
$string['choosenewfoldername'] = 'בחרו שם לספרייה החדשה: ';
$string['movefilestofolder'] = 'העברת הקבצים המסומנים לספרייה: ';
$string['movefilestofolderchoose'] = 'בחרו ספרייה...';
$string['rootfolder'] = 'ספרייה ראשית';
$string['movedeletezipinstructions'] = 'לשם העברה, מחיקה או אירכוב של מספר קבצים, יש לסמן אותם תחילה ולאחר מכן, לבחור בפעולה המתאימה על ידי לחיצה על הכפתור הרצוי';

?>