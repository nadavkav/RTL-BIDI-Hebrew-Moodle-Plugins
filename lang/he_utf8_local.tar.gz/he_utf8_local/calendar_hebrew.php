<?php

$string['Tishri'] = 'תשרי';
$string['Heshvan'] = 'חשוון';
$string['Kislev'] = 'כסלו';
$string['Tevet'] = 'טבת';
$string['Shevat'] = 'שבט';
$string['AdarI'] = 'אדר';
$string['AdarII'] = 'אדר־ב';
$string['Nisan'] = 'ניסון';
$string['Iyyar'] = 'אייר';
$string['Sivan'] = 'סיוון';
$string['Tammuz'] = 'תמוז';
$string['Av'] = 'אב';
$string['Elul'] = 'אלול';

?>