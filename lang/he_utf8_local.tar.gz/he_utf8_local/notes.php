<?PHP // $Id$ 
      // notes.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addnewnote'] = 'הוספת הערה חדשה';
$string['addnewnoteselect'] = 'בחרו משתמשים עליהם תרצו לכתוב הערות';
$string['content'] = 'תוכן ההערה';
$string['course'] = 'מרחב לימוד';
$string['coursenotes'] = 'הערות משותפות בין מורים במרחב לימוד זה';
$string['deleteconfirm'] = 'למחוק הערה זו?';
$string['deletenotes'] = 'מחיקת כל ההערות';
$string['editnote'] = 'עדכון הערה';
$string['groupaddnewnote'] = 'הוספת  הערה חדשה לכולם';
$string['nocontent'] = 'תוכן ההערה איננו יכול להיות ריק';
$string['nonotes'] = 'אין הערות';
$string['note'] = 'הערה';
$string['notes'] = 'הערות מורה';
$string['notesnotvisible'] = 'אינכם מורשים לצפות בהערה זו';
$string['nouser'] = 'חובה עליכם לבחור משתמש';
$string['personalnotes'] = 'הערות אישיות שלי (המורה) על התלמיד';
$string['publishstate'] = 'רמת שיתוף';
$string['sitenotes'] = 'הערות משותפות ברמת המערכת';

?>
