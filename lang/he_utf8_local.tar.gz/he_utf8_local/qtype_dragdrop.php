<?PHP // $Id$ 
      // qtype_dragdrop.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addmoreanswerblanks'] = 'תוכן-ריק כדי לא להוסיף גרירה ומיקום';
$string['correctanswers'] = 'גרירה ושחרור';
$string['dragdrop'] = 'גרירת תמונה ומיקום (על תמונת רקע)';
$string['dragdropanswer'] = 'תשובה';
$string['dragdroparrange'] = 'גרירה ומיקום: יש לסדר את תמונות-המקור במשבצות-היעד המתאימות.';
$string['dragdropimage'] = 'תמונה';
$string['dragdropno'] = 'גרירה ושחרור $a';
$string['editingdragdrop'] = 'עריכת שאלת גרירה ושחרור';
$string['feedbackmin'] = 'הצגת משוב חיובי עבור ציון גבוה מ-';
$string['feedbackmissed'] = 'משוב כללי (תשובה שגוייה)';
$string['feedbackok'] = 'משוב כללי (תשובה נכונה)';
$string['filloutoneanswer'] = 'יש לבחור תמונת-מקור אחת לפחות אותה ניתן לגרור למשבצת-יעד.';
$string['finished'] = 'הסתיים בהצלחה. המשיכו';
$string['hidehotspots'] = 'הסתרת משבצות-יעד';
$string['hideimages'] = 'הסתרת תמונות';
$string['hotspot'] = 'משבצת-יעד: X,Y,רוחב,גובה';
$string['hotspotheight'] = 'משבצת-יעד: גובה';
$string['hotspotspecify'] = 'מיקום משבצות-יעד';
$string['hotspotwidth'] = 'משבצת-יעד: רוחב';
$string['hotspotx'] = 'משבצת-יעד: X';
$string['hotspoty'] = 'משבצת-יעד: Y';
$string['imageposition'] = 'תמונת-מקור: X,Y,רוחב,גובה';
$string['imagepositionheight'] = 'תמונת-מקור: גובה';
$string['imagepositionwidth'] = 'תמונת-מקור: רוחב';
$string['imagepositionx'] = 'תמונת-מקור: X';
$string['imagepositiony'] = 'תמונת-מקור: Y';
$string['needbackground'] = 'שאלת גרירה ומיקום דורשת רקע מסוג תמונה.';
$string['showhotspots'] = 'הצגת משבצות-יעד';
$string['showimages'] = 'הצגת תמונות-מקור';
$string['snaphotspots'] = 'קישור אזורים-חמים לכל התמונות';
$string['snapimages'] = 'קישור תמונות לאזורים-חמים';

?>
