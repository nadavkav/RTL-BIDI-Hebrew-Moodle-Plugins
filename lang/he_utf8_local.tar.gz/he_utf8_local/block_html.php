<?PHP // $Id$ 
      // block_html.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['configtitle'] = 'כותרת משבצת-הוראה';
$string['html'] = 'תוכן מעוצב';
$string['leaveblanktohide'] = 'השאירו ריק להסתרת הכותרת';
$string['newhtmlblock'] = '(משבצת-הוראה חדשה)';

?>
