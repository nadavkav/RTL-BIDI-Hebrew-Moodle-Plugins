<?PHP // $Id$ 
      // block_search_forums.php - created with Moodle 1.8 dev (2006120700)


$string['advancedsearch'] = 'חיפוש מתקדם';
$string['blocktitle'] = 'חיפוש בקבוצות הדיון';

?>
