<?PHP // $Id$ 
      // magtest.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['<<'] = 'הקודם';
$string['>>'] = 'הבא';
$string['addcategories'] = 'הוספת סיווגים';
$string['addcategory'] = 'הוספת סיווג';
$string['addone'] = 'הוספת סיווג אחד';
$string['addquestion'] = 'הוספת שאלה';
$string['addthree'] = 'הוספת 3 שאלות';
$string['allowreplay'] = 'אפשרות הצגה מקדימה של מבחן';
$string['answercount'] = 'מספר תשובות';
$string['answerquestions'] = 'מבחן:';
$string['answers'] = 'תשובות';
$string['answertext'] = 'תשובה עבור סיווג: a$';
$string['categories'] = 'סיווגים';
$string['category'] = 'סיווג';
$string['categoryresult'] = 'מבחן מסכם עבור הסיווג';
$string['categoryshortname'] = 'שם קצר לסיווג';
$string['choosecategoryforanswer'] = 'בחרו סיווג עבור שאלה זו';
$string['closed'] = 'המבחן הסתיים. אין אפשרות לענות על שאלות נוספות.';
$string['closedtestadvice'] = 'המבחן הסתיים. אין אפשרות להציג אותו שוב.';
$string['commands'] = 'פעולות';
$string['descresult'] = 'תוצאות';
$string['description'] = 'תאור';
$string['doit'] = 'ביצוע המבחן';
$string['editquestions'] = 'עריכת שאלות';
$string['endtime'] = 'זמן סיום';
$string['helpnavigationquestion'] = 'עזרה';
$string['modulename'] = 'מבחן רב-מסלולים';
$string['modulenameplural'] = 'מבחנים רבי-מסלולים';
$string['nocategories'] = 'לא הגדרתם עדיין סיווגים במבחן';
$string['notopened'] = 'המבחן אינו זמין, עדיין.';
$string['nouseranswer'] = 'אף תלמיד לא ענה על המבחן, עדיין.';

?>
