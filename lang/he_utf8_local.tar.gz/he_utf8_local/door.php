<?PHP
$string['chooseafile'] = 'עצם למידה מקומי';
$string['resourcetypedoor'] = 'מאפייני עצם הלמידה';
$string['repositorybutton'] = 'עצם למידה ממאגר חיצוני';
$string['completeallfields'] = 'אנא הזינו את כל הנתונים';
$string['from']="בחרו מתוך";
$string['modulename'] = 'DOOR';
$string['modulenameplural'] = 'DOOR';
$string['title'] = 'כותרת';
$string['description'] = 'תאור';
//LEARNING OBJECT ERRORS
$string['isnotalo'] = 'The file is not a valid Learning Object';
$string['isnotalomanifest'] = 'The file is not a valid Learning Object, the file imsmanifest.xml cannot be found';
$string['isnotalometadatalink'] = 'The file is not a valid Learning Object, the metadata filename is not specified in the imsmanifest.xml file';
$string['isnotalometadata'] = 'The file is not a valid Learning Object, the metadata file doesn\'t exist';
$string['isnotaloemptytitledescription'] = 'The file is not a valid Learning Object, title and / or description are not specified in the metadata file';
$string['isnotaloemptyfilename'] = 'The file is not a valid Learning Object, attachment filename is not specified in the metadata file';
$string['lozipfileinexistent'] = "לא בחרתם עצם למידה,עדיין";
//OTHER ERRORS
$string['missingparameter'] = 'Error! A required parameter is missing.';
$string['authorizationfailed'] = 'You are not authorized to access this page.';
$string['makeresourcedatadirerror'] = 'Error during the creation of the resource data folder';
$string['makedatadirerror'] = 'Error during the creation of the Learning Object data folder';
$string['movedatadirerror'] = 'Error while moving the Learning Object data folder';
$string['deletedatadirerror'] = 'Error while deleting the Learning Object data folder';
$string['repositoryaddresserror'] = "Error while reading the repository address from the DB";
$string['repositorytypeerror'] = "Error while reading the repository type from the DB";
$string['sesskeyerror'] = "Login key not present";
$string['removetempzipfileerror'] = "Error while deleting the Learning Object temporary zip file";
//CONFIGURATION
$string['configtitle'] = "LEARNING OBJECTS REPOSITORIES MANAGEMENT";
$string['configcompleteallfields'] = "Every repository must have a name and an address!";
$string['configservername'] = "שם למאגר";
$string['configserveraddress'] = "כתובת שרת מאגר עצמי הלימוד";
$string['configauthentication'] = "מנגנון הזדהות";
$string['configsavechanges'] = "שמירת שינויים";
$string['configeditrepositories'] = "MODIFY EXISTING REPOSITORIES";
$string['configaddnewrepository'] = "הוספת מאגר עצמי למידה חדש";
$string['configupdaterepositoryerror'] = "Error while updating a repository";
$string['configaddrepositoryerror'] = "Error while adding a repository";
$string['configdeleterepositoryerror'] = "Error while deleting a repository";
$string['configdeleterepositorybutton'] = "מחיקה";
$string['configdeleterepositoryconfirm'] = "Are you sure you want to delete this repository? This action cannot be undone.";
//HELP
$string['helprepositoriestitle'] = "מאגרי עצמי לימוד";
?>
