<?PHP // $Id$ 
      // quiz_overview.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['allattempts'] = 'הצגת כל ניסיונות המענה';
$string['allattemptscontributetograde'] = 'כל הנסיונות תורמים לציון הסופי של התלמיד בבוחן זה.';
$string['allstudents'] = 'הצגת כל ה-$a';
$string['attemptsprepage'] = 'מספר ניסיונות מענה בדף';
$string['deleteselected'] = 'מחיקת נסיונות מענה מסומנים';
$string['highlightinggraded'] = 'הציון המודגש, יחשב בשיקלול הציון הסופי של התלמיד';
$string['onlyoneattemptallowed'] = 'בבוחן זה מותר נסיון מענה אחד בלבד.';
$string['optallattempts'] = 'כל הניסיונות';
$string['optallstudents'] = 'כל $a';
$string['optattemptsonly'] = '$a עם נסיונות בלבד';
$string['optnoattemptsonly'] = '$a ללא נסיונות';
$string['optonlygradedattempts'] = 'רק הניסיון בעל הציון של כל תלמיד ($a)';
$string['overviewreportgraph'] = 'גרף עמודות המציג תחום ציונים אותו השיגו התלמידים';
$string['pagesize'] = 'גודל דף';
$string['preferencespage'] = 'מאפיינים לדף זה בלבד';
$string['preferencessave'] = 'שמירת מאפיינים';
$string['preferencesuser'] = 'מאפייני דוח זה';
$string['show'] = 'תצוגה / הורדות';
$string['showdetailedmarks'] = 'תצוגה / הורדת ציונים לכל שאלה';
$string['showinggraded'] = 'הצגת הנסיונות של כל תלמיד אשר קיבל ציון';
$string['showinggradedandungraded'] = 'טבלה זו מציגה נסיונות מענה עם ציון וללא ציון עבור כל תלמיד. <BR> הציון המשמעותי עבור כל תלמיד מוגדש. <BR> שיטת מתן הציונים של בוחן זה היא $a.';
$string['overviewmsg'] = 'מי לא ענה?';

?>
