<?PHP // $Id$ 

$string['changenumsections'] = 'הוספה או החסרה של יחידת הוראה';


?>
