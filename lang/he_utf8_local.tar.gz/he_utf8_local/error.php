<?PHP // $Id$ 
      // error.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['adminprimarynoedit'] = 'משתמשים רגילים אינם יכולים לערוך את המנהל הראשי';
$string['cannotassignrole'] = 'לא ניתן למנות תפקיד במרחב זה';
$string['cannotcustomizelocallang'] = 'אין לכם רשות לבצע התאמה אישית לתרגום המחרוזות. הראשה זאת מבוקרת על ידי היכולת \"moodle/site:langeditlocal\". בקשו ממנהל המערכת להפעיל יכולת זאת בכדי לאפשר לכם לערוך את חבילות השפה המקומיות במידה ואתם רוצים לשנות תרגומים עבור מערכת מוודל האישית שלכם.';
$string['cannoteditmasterlang'] = 'אין לכם רשות לערוך את חבילת השפה הראשית. אישור זה מבוקר על ידי ההרשאה moodle/site:langeditmaster. בקשו ממנהל המערכת להפעיל יכולת זאת בכדי לאפשר לכם לערוך את חבילות השפה המקומיות במידה ואתם רוצים לתחזק את חבילת תרגום שפה זו.';
$string['cannotviewprofile'] = 'אינכם רשאים לראות את הנתונים האישיים של משתמש זה.';
$string['cantunenrollfrommetacourse'] = 'אינכם יכולים לבטל את הרשמתכם ממרחב-על זה.';
$string['cantunenrollinthisrole'] = 'אינכם יכולים לבטל את הרשמתכם ממרחב-לימוד זה כל עוד אתם נמצאים בתפקיד הנוכחי שלכם.';
$string['cmunknown'] = 'לא ניתן למצוא את רכיב או פעילות ההוראה של מרחב-לימוד זה.';
$string['componentisuptodate'] = 'רכיב הוראה זה מעודכן.';
$string['couldnotassignrole'] = 'חלה שגיאה רצינית אך לא מוגדרת במהלך הניסיון למנות אותכם לתפקיד.';
$string['coursegroupunknown'] = 'לא צויין מרחב-לימוד התואם את קבוצה $a.';
$string['csvfewcolumns'] = 'אין מספיק עמודות, אנא וודאו את הגדרת התו התוחם.';
$string['csvweirdcolumns'] = 'קובץ CVS פגום - מספר העמודות לא קבוע';
$string['errorsavingrequest'] = 'שגיאה התגלתה בזמן שמירת בקשתכם';
$string['forumblockingtoomanyposts'] = 'עברתם את סף פרסום ההודעות אשר נקבעו לקבוצת דיון זו.';
$string['groupalready'] = 'המשתמש כבר מצוי בקבוצה $a';
$string['groupexistforcourse'] = 'קבוצה \"$a\" כבר קיימת במרחב-לימוד זה';
$string['groupunknown'] = 'קבוצה $a אינה שייכת למרחב-הלימוד המצויין';
$string['guestnoeditprofile'] = 'משתמש אורח אינו יכול לערוך את נתוני המשתמש האישיים שלו';
$string['guestnoeditprofileother'] = 'לא ניתן לערוך את נתוני המשתמש של משתמש האורח';
$string['guestsarenotallowed'] = 'משתמש אורח אינו מורשה לבצע פעולה זו';
$string['invalidcourse'] = 'מרחב-לימוד לא חוקי';
$string['invalidcourseid'] = 'אתה מנסה להשתמש במספר ID של מרחב-לימוד לא חוקי';
$string['invalidcoursemodule'] = 'מודול ID של מרחב-לימוד לא חוקי';
$string['invalidipformat'] = 'מבנה כתובת IP שגוי.';
$string['invalidsesskey'] = 'קוד זיהוי משתמש אינו תקין! הטופס לא נשלח.';
$string['listupdatefail'] = 'פעולת מסד הנתונים נכשלה בעת עריכת ההיררכיה.';
$string['mustbeteacher'] = 'חובה עליכם להיות מורה כדי לראות את עמוד זה';
$string['nocategorydelete'] = 'סיווג \'$a\' לא ניתנת למחיקה!';
$string['nocontext'] = 'סליחה, אבל מרחב-הלימוד ההוא איננו הקשר-תוכן תקף';
$string['noinstances'] = 'אין מופעים של $a במרחב-לימוד זה!';
$string['nologinas'] = 'אינכם מורשים להתחבר כמשתמש ההוא.';
$string['noparticipatorycms'] = 'סליחה, אבל אין לכם רכיבי מרחב-לימוד הדורשים השתתפות, לדווח עליהם.';
$string['nopermissions'] = 'סליחה, אבל כרגע אין לכם את ההרשאות לעשות זאת ($a)';
$string['onlyadmins'] = 'רק מנהלים יכולים לבצע פעולה זו';
$string['onlyeditingteachers'] = 'רק מורים-עורכים יכולים לבצע פעולה זו';
$string['onlyeditown'] = 'אתם יכולים לערוך את הנתונים האישיים שלכם בלבד';
$string['pagenotexist'] = 'חלה שגיאה לא רגילה (בניסיון להציג עמוד אשר אינו קיים)';
$string['pleasereport'] = 'אם יש לכם זמן, אנא הודיעו לנו מה ניסיתם לעשות כאשר הופיעה השגיאה:';
$string['pluginrequirementsnotmet'] = 'לא ניתן היה להתקין את התוסף \"$a->pluginname\" ($a->pluginversion). התקנתו דורשת גירסה עדכנית יותר של מוודל (כרגע אתם משתמשים ב- $a->currentmoodle, אתם צרכים את $a->requiremoodle).';
$string['processingstops'] = 'העיבוד נעצר כאן, תוך התעלמות מהרשומות הנותרות.';
$string['remotedownloaderror'] = 'הורדת הרכיב לשרת שלכם כשלה! אנא וודאו את הגדרות ה-proxy שלך. תוספת PHP cURL מומלצת מאוד להתקנה.
<br /><br />
הינכם צרכים להוריד את קובץ ההדרכה <a href=\"$a->url\">$a->url</a> ולהעתיק אותו ל \"$a->dest\"
בשרת שלכם ולכווץ אותו שם.';
$string['remotedownloadnotallowed'] = 'לא מורשת הורדה של רכיבים לשרת שלכם (פונקצייתallow_url_fopen מנוטרלת).<br /><br />עליכם להוריד את קובץ ה<a href=\"$a->url\">$a->url</a> באופן ידני, להעתיק אותו לתוך \"$a->dest\" בשרת שלכם, ולפתוח אותו שם.';
$string['restricteduser'] = 'מצטערים אבל חשבון המשתמש הנוכחי \"$a\" מוגבל מלעשות זאת.';
$string['scheduledbackupsdisabled'] = 'גיבויים מתוכננים נוטרלו על ידי מנהל המערכת';
$string['sendmessage'] = 'שליחת הודעה';
$string['sessionerroruser'] = 'נתוני הזיהוי שלכם מול המערכת נמחקו לאחר תקופת זמן של אי שימוש במחשב. אנא התחבר שוב.';
$string['sessionerroruser2'] = 'נתגלתה שגיאה של השרת שמשפיעה של נתוני זיהוי ההתחברות שלכם. אנא התחבר שוב, או התחלו מחדש את השרת שלכם.';
$string['sessionipnomatch'] = 'סליחה, אבל נראה כי מספר ה-IP שלכם השתנה מאז הפעם הראשונה שהתחברתם למערכת. תכונת אבטחה זו מונעת גורמים חיצוניים לגנוב את הזהות שלכם בזמן שאתם מחוברים לאתר (מערכת). משתמשים רגילים לא אמורים לראות את ההודעה הזו - אנא בקש עזרה ממנהל האתר שלכם.';
$string['tagnotfound'] = 'התווית המתוארת לא נמצאה במסד הנתונים';
$string['unicodeupgradeerror'] = 'אנו מצטערים אך בסיס הנתונים שלכם עדיין לא כתוב ב- Unicode, וגירסה זו של מוודל לא מסוגלת להמיר את בסיס הנתונים שלך ל-Unicode. אנא שדרג למוודל 1.7.x תחילה ובצא את ההמרה ל-Unicode מעמוד ההנהלה. לאחר שזה נעשה, לא אמורה להיות לך כל בעיה בהמרה למוודל Moodle $a.';
$string['unknowncourse'] = 'מרחב-לימוד לא ידוע בשם \"$a\"';
$string['unknowncourseidnumber'] = 'מספר זהות מרחב-הלימוד \"$a\" לא ידוע';
$string['unknowncourserequest'] = 'בקשת מרחב-לימוד לא ידוע';
$string['userautherror'] = 'תוסף זיהוי אוטומטי לא ידוע';
$string['userauthunsupported'] = 'תוסף זיהוי אוטומטי לא נתמך';
$string['usernotaddederror'] = 'משתמש \"$a\" לא התווסף - טעות לא ידועה';
$string['usernotaddedregistered'] = 'משתמש \"$a\" לא התווסף - כבר רשום';
$string['usernotavailable'] = 'פרטיו האישיים של משתמש זה אינם זמינים.';

?>
