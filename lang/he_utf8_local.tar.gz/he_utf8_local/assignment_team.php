<?php

$string['typeteam'] = 'משימה קבוצתית';
$string['existingteams'] = 'קבוצות קיימות';
$string['jointeam'] = 'הצטרפו לקבוצה';
$string['createteam'] = 'יצירת קבוצה';
$string['teammember'] = 'חברי הקבוצה';
$string['viewmember'] = 'תצוגת חברי הקבוצה';
$string['createteamlabel'] = 'הוסיפו אותי לקבוצה חדשה';
$string['teamname'] = 'שם הקבוצה';
$string['editteam'] = 'עריכת מאפייני הקבוצה';
$string['deleteteam'] = 'מחיקת קבוצה';
$string['openclosemembership'] ='פתיחה/סגירה';
$string['removeteammember'] = 'הסרת חבר מהקבוצה';
$string['teamsubmission'] = 'הגשות הקבוצה';
$string['teamnameerror'] = 'יש להזין שם לקבוצה';
$string['teamnameexist'] = 'קבוצה בשם זה,קיימת.';
$string['createteamerror'] = 'שגיאה בעת יצירת הקבוצה';
$string['jointeamerror'] = 'שגיאה בעת הוספה של חבר חדש לקבוצה';
$string['lastmembererror'] = 'לא ניתן להסיר את החבר קבוצה האחרון';
$string['teamclosedwarning'] = 'יכולת הרשמה והצטרפות לקבוצה הסתיימה';
$string['teamopen'] = 'ניתן להצטרף לקבוצה';
$string['teamclosed'] = 'הרשמה והצטרפות לקבוצה, הסתיימה.';

?>