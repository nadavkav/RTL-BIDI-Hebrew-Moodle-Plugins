<?PHP // $Id$ 
      // block_course_summary.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['coursesummary'] = 'סיכום מרחב-הלימוד';
$string['pagedescription'] = 'תיאור האתר או מרחב-הלימוד';

?>
