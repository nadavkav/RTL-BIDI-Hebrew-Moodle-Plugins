<?PHP // $Id$ 
      // whiteboard.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['modulename'] = 'לוח ציור משותף';
$string['modulenameplural'] = 'לוחות ציור משותפים';
$string['whiteboard'] = 'לוח ציור משותף';
$string['whiteboardfieldset'] = 'דוגמה לשדות מיוחדים';
$string['whiteboardintro'] = 'הקדמה לתצוגת לוח ציור משותף';
$string['whiteboardname'] = 'שם לוח הציור המשותף';

?>
