<?PHP // $Id$ 
      // calendar.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['clickhide'] = 'הסתרה';
$string['clickshow'] = 'הצגה';
$string['course'] = 'מרחב לימוד';
$string['courseevent'] = 'ארוע מרחב לימוד';
$string['courseevents'] = 'ארועי מרחב לימוד';
$string['courses'] = 'מרחבי לימוד';
$string['dayview'] = 'תצוגת יום';
$string['deleteevent'] = 'מחיקת ארוע';
$string['deleteevents'] = 'מחיקת אירועים';
$string['detailedmonthview'] = 'תצוגת חודש מפורטת';
$string['errorbeforecoursestart'] = 'אין אפשרות לקבוע ארוע לפני תאריך תחילת קורס';
$string['errorinvalidminutes'] = 'פרטו משך זמן בדקות על ידי נתינת מספר בין 1 ו 999';
$string['errorinvalidrepeats'] = 'פרטו את מספר הארועים על ידי נתינת מספר בין 1 ו 999';
$string['export'] = 'יצוא';
$string['exportbutton'] = 'יצוא';
$string['exportcalendar'] = 'יצוא לוח שנה';
$string['global'] = 'כללי';
$string['globalevent'] = 'ארוע כללי';
$string['globalevents'] = 'ארועים כללים';
$string['gotocalendar'] = 'הצגת ללוח שנה';
$string['iwanttoexport'] = 'יצוא';
$string['monthlyview'] = 'תצוגה חודשית';
$string['monthnext'] = 'החודש הבא';
$string['monththis'] = 'החודש נוכחי';
$string['pref_timeformat'] = 'תצורת תצוגת זמן';
$string['spanningevents'] = 'ארועים עתידיים';
$string['tt_deleteevent'] = 'מחיקת ארוע';
$string['tt_editevent'] = 'עריכת ארוע';
$string['typecourse'] = 'ארוע מרחב-לימוד';

?>
