<?PHP // $Id$ 
      // block_attendance.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['alltaken'] = 'הכל בשימוש';
$string['downloadexcel'] = 'הורדה בתצורת EXEL למחשב האישי';
$string['downloadooo'] = 'הורדה בתצורת OpenOffice למחשב האישי';
$string['downloadtext'] = 'הורדה בתצורת Text למחשב האישי';
$string['editsession'] = 'ערכית מפגש';
$string['errorinaddingsession'] = 'תקלה בעת הוספת מפגש';
$string['erroringeneratingsessions'] = 'תקלה בעת יצירת מפגשים';
$string['indetail'] = 'בפרוט...';
$string['months'] = 'חודשים';
$string['newdate'] = 'תאריך חדש';
$string['noattforuser'] = 'לא קיים רישום נוכחות עבור משתמש זה';
$string['noguest'] = 'אורח אינו יכול לראות רישום נוכחות';
$string['noofdaysabsent'] = 'מספר ימים - חיסור';
$string['noofdaysexcused'] = 'מספר ימים - חיסור מאושר';
$string['noofdayslate'] = 'מספר ימים - איחור';
$string['noofdayspresent'] = 'מספר ימים - נוכח';
$string['nosessiondayselected'] = 'לא נבחר יום מפגש';
$string['nosessionexists'] = 'לא קיימים מפגשים עבור מרחב לימוד זה';
$string['olddate'] = 'תאריך ישן';
$string['sessionalreadyexists'] = 'קיים מפגש בתאריך זה';
$string['sessionscompleted'] = 'מפגשים הסתיימו';
$string['showdefaults'] = 'תצוגת בררת מחדל';

?>
