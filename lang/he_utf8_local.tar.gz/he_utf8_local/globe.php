<?php // $Id: fedsearch.php,v 1.2 2006/04/18 18:09:11 wildgirl Exp $ 
      // fedsearch.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005032600)

$string['ariadnelor'] = 'Ariadne';
$string['globerepository'] = 'מאגר רשת Globe';
$string['enterkeywords'] = 'הזינו מילות חיפוש';
$string['searchin'] = 'חיפוש במאגר:';
$string['noresult'] = 'לא נמצאו עצמי למידה התואמים את החיפוש שלכם, עדיין...';
$string['previewdocument'] = 'תצוגה מקדימה של המסמך';
$string['importdocument'] = 'יבוא המסמך למרחב לימוד זה';
$string['noresult'] = 'לא נמצאו תשובות לחיפוש, עדיין...';
$string['untitled'] = 'ללא שם';
$string['labelresultretrieved'] = 'התשובות שנמצאו לעת עתה: ';
$string['resultxmlerror'] = 'An XML error occured while parsing the results...';
$string['welcome'] = 'כלי חיפוש GLOBE מאפשר אחזור <b>עצמי למידה</b> המאוחסנים ב <b>מאגרי אינטרנט</b> שונים ויבוא עצמים אילו למרחב הלימוד הנוכחי <br> <a href=\"mailto:broisin@irit.fr\">אנא שלחו אלינו את הערותיכם!</a>';

$string['sqisessionconstructionerror'] = 'An error occured while initializing the session client.<br/>Please check the location of the SQI server within the configuration file...';
$string['sqianonymoussessionerror'] = 'An error occured while initializing the session identifier.<br/>Please try again later...';
$string['sqidestroysessionerror'] = 'An error occured while initializing the target client.<br/>Please check the location of the SQI server within the configuration file...';
$string['sqitargetconstructionerror'] = 'An error occured while initializing the target client.<br/>Please try again later...';
$string['sqiquerylanguageerror'] = 'An error occured while setting the query language of the query.<br/>Please try again later...';
$string['sqiresultsformaterror'] = 'An error occured while setting the results format of the query.<br/>Please try again later...';
$string['sqisetsizeerror'] = 'An error occured while setting the results size of the query.<br/>Please try again later...';
$string['sqisynchronousqueryerror'] = 'An error occured while sending the query.<br/>Please try again later...';
$string['sqinumberofresultserror'] = 'An error occured while getting the number of results.<br/>Please try again later...';
$string['sqimaxqueryresultserror'] = 'An error occured while setting the maximum number of results.<br/>Please try again later...';

$string['generalmetadatalabel'] = 'כללי';
$string['generallanguagelabel'] = 'שפה: ';
$string['generaldescriptionlabel'] = 'תאור: ';
$string['generalauthorlabel'] = 'מחבר(ים): ';
$string['generalcostslabel'] = 'עלויות: ';
$string['generalcopyrightslabel'] = 'זכויות יוצרים: ';

$string['semanticmetadatalabel'] = 'סמנטיקה';
$string['semanticsciencetypelabel'] = 'סוג מדע: ';
$string['semanticmaindisclabel'] = 'מגמת הוראה ראשית: ';
$string['semanticsubdisclabel'] = 'תת מגמת הוראה: ';
$string['semanticmainconceptlabel'] = 'רעיונות מרכזיים: ';

$string['pedagogicalmetadatalabel'] = 'פדגוגי';
$string['pedagogicaluserrolelabel'] = 'תפקיד המשתמש: ';
$string['pedagogicalinteractivitylabel'] = 'סוג הפעילות: ';

$string['technicalmetadatalabel'] = 'טכני';
$string['technicaldocformatlabel'] = 'סוג/תצורת המסמך: ';
$string['technicaldocsizelabel'] = 'גידול/נפח המסמך: ';
$string['technicaldocoslabel'] = 'מערכת הפעלה: ';

?>
