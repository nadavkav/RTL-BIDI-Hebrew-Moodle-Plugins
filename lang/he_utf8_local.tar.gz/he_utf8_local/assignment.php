<?PHP // $Id$
      // assignment.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['allowdeleting'] = 'אפשרות מחיקה';
$string['allowmaxfiles'] = 'מספר הקבצים המירבי שניתן להעלות';
$string['allownotes'] = 'אפשרות להערות תלמידים';
$string['allowresubmit'] = 'אפשרות הגשה חוזרת';
$string['alreadygraded'] = 'למשימה שלכם ניתן ציון. לכן, הגשה חוזרת איננה אפשרית.';
$string['assignment:grade'] = 'בדקו ותנו ציון למשימה';
$string['assignment:submit'] = 'הגשת משימה';
$string['assignment:view'] = 'הצגת משימה';
$string['assignmentdetails'] = 'נתוני המשימה';
$string['assignmentmail'] = '$a->teacher פרסם משוב על התרגיל שהגשתם עבור \'$a->assignment\'אתם יכולים לראות את המשוב כנספח לתרגיל שהגשתם:$a->url';
$string['assignmentmailhtml'] = '$a->teacher שלח משוב על התרגיל שהגשתם עבור \'<i>$a->assignment</i>\'<br /><br />אתם יכולים לראות את המשוב כנספח ל<a href=\"$a->url\">משימה שהגשתם</a>.';
$string['assignmentname'] = 'שם המשימה';
$string['assignmenttype'] = 'סוג המשימה';
$string['configitemstocount'] = 'מאפייני הפריטים אשר נספרים כהגשות תלמידים במטלות מקוונות';
$string['confirmdeletefile'] = 'האם אתם בטוחים לחלוטין שאתם רוצים למחוק קובץ זה?<br /><strong>$a</strong>';
$string['deleteallsubmissions'] = 'מחיקת כל ההגשות';
$string['description'] = 'הנחיה לתלמידים';
$string['editmysubmission'] = 'כתיבת תשובה למשימה';
$string['emptysubmission'] = 'טרם הגשתם תרגיל זה';
$string['enableemailnotification'] = 'שליחת הודעות בדואר';
$string['failedupdatefeedback'] = 'תקלה נגרמה בעת עדכון משוב ההגשה למשתמש $a';
$string['guestnosubmit'] = 'אנו מצטערים, אבל אורחים לא מורשים להגיש משימה. עליכם להירשם או להתחבר למערכת כדי להגיש את התשובה שלכם.';
$string['helpoffline'] = '<p>הגדרה זו שימושית כאשר המשימה מבוצעת מחוץ למוודל. היא יכולה להיות במקום אחר ברשת או בהגשה פנים-אל-פנים.</p><p>תלמידים יכולים לראות את הגדרת התרגיל, אבל לא יכולים להעלות קבצים או לערוך את התרגיל באופן מקוון. מתן ציונים עובד כרגיל, ותלמידים יקבלו הודעה כאשר הציון שלהם נקבע.</p>';
$string['helponline'] = '<p>סוג תרגיל זה מבקש מהמשתמשים לערוך מלל, בעזרת כלי העריכה הרגילים. המורים יכולים להעניק ציון באופן מקוון, ואפילו לבצע תיקונים או לרשום הערות בגוף המלל.</p>
<p>(אם השתמשת בגרסאות קודמות של מוודל, סוג מטלה זה דומה להתנהגות של מודול ה-Journal הישן.)</p>';
$string['helpupload'] = '<p>סוג משימה זה מאפשר לכל משתתף להעלות קובץ אחד, או יותר, מכל סוג שהוא. קבצים אלה יכולים להיות מסמכי Word, תמונות, אתרים המכווצים באמצעות תוכנת ZIP או כל דבר אחר שתבקשו מהמשתתפים להעלות.</p>
<p>בנוסף, סוג זה של משימה מאפשר לכם להעלות קבצי תגובה רבים. את קיבצי התגובה ניתן להעלות גם לפני ההגשה, וכך ניתן להשתמש בהם כדי לתת לכל משתתף קובץ אחר לעבוד איתו.
</p>
<p>בנוסף המשתתפים יכולים להוסיף הערות שמתארות את הקבצים שהם הגישו, מצב התקדמות העבודה או כל מידע כתוב אחר. </p>
<p>את ההגשות לסוג זה של משימה חייבים התלמידים לסיים בעצמם, באופן ידני. אתם יכולים לראות את המצב הנוכחי שלהם בכל עת, מטלות לא גמורות מסומנות כ\'טיוטא\'. בידיכם האפשרות להחזיר כל מטלה שעדיין לא ניתן לה ציון למצב של טיוטא.
</p>';
$string['hideintro'] = 'הסתרת התיאור לפני התאריך הזמין';
$string['modulename'] = 'משימה';
$string['modulenameplural'] = 'משימות';
$string['newsubmissions'] = 'המשימות שהוגשו';
$string['noassignments'] = 'עדיין אין משימות';
$string['noattempts'] = 'עדיין לא נעשו נסיונות לפתור את המשימה זו';
$string['notavailableyet'] = 'מצטערים, מטלה זו עדיין אינה זמינה<br />הוראות למילוי משימה, יוצגו כאן בתאריך המופיע למטה.';
$string['notgradedyet'] = 'טרם בוצעה הערכה למשימה זו';
$string['onceassignmentsent'] = 'מהרגע שמשימה נשלחת לבדיקה, לא תוכלו למחוק או להוסיף קבצים. האם אתם מעוניינים להמשיך?';
$string['overwritewarning'] = 'אזהרה: העלאה מחדש תחליף את ההגשה הנוכחית שלכם';
$string['pagesize'] = 'מספר ההגשות המוצגות בכל עמוד';
$string['preventlate'] = 'מניעת שליחת תרגילים באיחור';
$string['quickgrade'] = 'אפשרות נתינת ציון באופן מהיר';
$string['responsefiles'] = 'קובצי תגובות';
$string['responsefiles_list'] = 'רשימת קבצים מצורפים (אשר ישלחו לתלמיד)';
$string['responsefiles_empty'] = 'טרם נבחרו קבצים אשר ישלחו לתלמיד ביחד עם התגובה';
$string['saveallfeedback'] = 'שמירת כל המשובים שלי';
$string['sendformarking'] = 'שליחה לבדיקה וקבלת ציון';
$string['showrecentsubmissions'] = 'הצגת הגשות אחרונות';
$string['submissionsaved'] = 'השינויים שלכם נשמרו';
$string['submitassignment'] = 'הגישו את תשובתכם';
$string['submitedformarking'] = 'המשימה הוגשה להערכה ולא ניתן לעדכן אותה';
$string['submitformarking'] = 'הגשה סופית לבדיקת המשימה';
$string['trackdrafts'] = 'אפשרות שליחה לצורך ציון';
$string['typeonline'] = 'משימה מקוונת';
$string['typekaltura'] = 'יצירת סרט';
$string['typeteam'] = 'הגשת קבצים בקבוצה';
$string['unfinalize'] = 'חזרה למצב טיוטא';
$string['uploadnofilefound'] = 'לא נמצא קובץ - האם אתם בטוחים שבחרתם קובץ להעלאה?';
$string['viewfeedback'] = 'הצגת ציוני ומשובי תרגילים';
$string['viewsubmissions'] = 'הצגת $a תרגילים שהוגשו';
$string['yoursubmission'] = 'ההגשה שלכם';
$string['teachersubmitremark'] = 'שליחת תגובה לתלמיד'; // ORPHANED
$string['uploadafile'] = 'העלו קובץ מהמחשב האישי שלכם כתשובה למטלה זו'; // ORPHANED
$string['uploadthisfile'] = 'העלו קובץ זה כתשובה'; // ORPHANED
$string['attachthisresponsefile'] = 'צרפו קובץ זה לרשימת הקבצים של התגובה';
$string['responsefiles_empty'] = 'לא צרפתם קובצי תגובה לתלמיד, עדיין';
$string['youdonothavetofillthis'] = '<br/>שימו-לב! השדה <b>תקציר</b> משמש את המערכת לאפיון וחיפוש מידע,<br> התלמידים לא יראו אותו<br/>';
$string['answertemplate'] = 'תבנית בסיסית לתשובה אותה התלמידים מתבקשים להשלים בעצמם';

?>
