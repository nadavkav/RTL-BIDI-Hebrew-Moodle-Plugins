<?PHP // $Id$ 
      // access.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['breadcrumb'] = 'נתיב מסלול הניווט';
$string['hideblocka'] = 'הסתרת משבצת-הניהול $a';
$string['showblocka'] = 'הצגת משבצת-ניהול $a';
$string['skipblock'] = 'דלגו על משבצת-ניהול';
$string['skipnavigation'] = 'דלגו על הניווט';
$string['tablelayout'] = 'טבלת תצורה, $a';
$string['tocontent'] = 'מעבר לתוכן העיקרי';
$string['tonavigation'] = 'מעבר לניווט';
$string['youarehere'] = 'אתם נמצאים כאן';

?>
