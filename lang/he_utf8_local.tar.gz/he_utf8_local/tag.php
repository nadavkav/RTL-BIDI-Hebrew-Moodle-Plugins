<?PHP // $Id$ 
      // tag.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addedotag'] = '\"$a\" נוסף כתחום עניין מערכתי';
$string['addotags'] = 'הוספת תחום עניין מערכתי';
$string['addtagtomyinterests'] = 'הוספת הנושא \"$a\" לתחומי העניין שלי';
$string['blocktagstitle'] = 'תחומי עניין';
$string['changename'] = 'שינוי שם תחום העניין';
$string['changetype'] = 'שינוי סוג תחום עניין';
$string['count'] = 'מספר מופעים';
$string['delete'] = 'מחיקה';
$string['deleted'] = 'נמחק';
$string['description'] = 'תאור';
$string['edittag'] = 'עריכת תחום עניין זה';
$string['flag'] = 'סימון';
$string['flagasinappropriate'] = 'סמנו כבעייתי';
$string['helprelatedtags'] = 'תחומי עניין קשורים מופרדים בפסיקים';
$string['id'] = 'מספר זיהוי';
$string['managetags'] = 'ניהול תחומי עניין';
$string['name'] = 'שם תחום העניין';
$string['namesalreadybeeingused'] = 'תחום עניין זה מצוי כבר בשימוש';
$string['newname'] = 'תחום עניין חדש';
$string['noresultsfor'] = 'לא נמצאו תחומיי עניין לחיפוש \"$a\"';
$string['officialtag'] = 'תחום עניין מערכתי';
$string['otags'] = 'תחומיי עניין מערכתיים';
$string['owner'] = 'בעלים';
$string['ptags'] = 'תחומיי עניין של משתמשים ברשימה מופרדת בפסיקים';
$string['relatedblogs'] = 'ידיעות בלוג חדשות בתחום עניין זה';
$string['relatedtags'] = 'תחומי עניין קשורים';
$string['removetagfrommyinterests'] = 'הסרת תחום העניין \"$a\" מרשימת תחומי העניין שלי';
$string['reset'] = 'איפוס';
$string['resetflag'] = 'איפוס סימון כ\"בעייתי\"';
$string['responsiblewillbenotified'] = 'הודעה תשלח לצוות ניהול האתר';
$string['search'] = 'חיפוש תחומי עניין';
$string['searchresultsfor'] = 'תוצאות חיפוש תחום עניין \"$a\"';
$string['searchtags'] = 'חיפוש תחומיי עניין';
$string['seeallblogs'] = 'הצגת כל הבלוגים הקשורים בתחום עניין זה';
$string['select'] = 'בחירה';
$string['tag'] = 'תחום עניין';
$string['tagdescription'] = 'תאור תחום העניין';
$string['tags'] = 'תחומיי עניין';
$string['tagsaredisabled'] = 'תצוגת תחומיי עניין לא זמינה';
$string['tagtype'] = 'סוג תחום עניין';
$string['tagtype_default'] = 'משתמש';
$string['tagtype_official'] = 'מערכתי';
$string['thingstaggedwith'] = '$a->count פריטים מסומנים בתווית \"$a->name\"';
$string['thistaghasnodesc'] = 'לתחום עניין זה אין תאור';
$string['timemodified'] = 'תאריך עדכון';
$string['typechanged'] = 'סוג תחום העניין עודכן';
$string['updated'] = 'עודכן';
$string['updatetag'] = 'עדכון';
$string['userstaggedwith'] = 'משתמשים בעליי תחום עניין \"$a\"';
$string['withselectedtags'] = 'עם תחומי העניין המסומנים...';
$string['relatedcourses'] = 'מרחבי־לימוד בעלי תוכן התואם לתווית \"$a\" זו'; // ORPHANED

?>
