<?PHP // $Id$ 
      // block_search.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['asynchronous'] = 'נפרד';
$string['blockname'] = 'חיפוש באתר כולו';
$string['blockssearchmnetfeatures'] = 'חיפוש ברשת מוודל';
$string['blockssearchswitches'] = 'הפעלת חיפוש במשבצות-ההוראה';
$string['bytes'] = 'תווים (0 = ללא הגבלה)';
$string['configbuttonlabel'] = 'תווית הכפתור';
$string['configenablefileindexing'] = 'האם לחפש בקבצים?';
$string['configfiletypes'] = 'סוגי קבצים לחיפוש';
$string['configlimitindexbody'] = 'גודל קבצים מירבי לעיבוד';
$string['configpdftotextcmd'] = 'התיקייה בה מצוי היישום pdftotext';
$string['configsearchtext'] = 'חיפוש מלל';
$string['configwordtotextcmd'] = 'התיקייה בה מצוי היישום doctotext';
$string['configwordtotextenv'] = 'מאפייני סביבה עבור ממיר MSWORD';
$string['disabled'] = 'לא פעיל';
$string['disabledsearch'] = 'רכיב החיפוש של המערכת כבוי. אנא הודיעו על כך להנהלת האתר';
$string['enabled'] = 'פעיל';
$string['go'] = 'חיפוש!';
$string['modulessearchswitches'] = 'חיפוש בפעילויות ורכיבי הוראה';
$string['nosearchableblocks'] = 'לא ניתן לבצע חיפוש במשבצות הוראה אילו';
$string['nosearchablemodules'] = 'לא ניתן לבצע חיפוש ברכיבי הוראה אילו';
$string['pdfhandling'] = 'קורא קבצי PDF';
$string['search'] = 'חיפוש';
$string['searchmoodle'] = 'חיפוש במערכת מוודל';
$string['synchronous'] = 'בו זמני';
$string['usemoodleroot'] = 'השתמשו בנתיב הראשי של מוודל לחיפוש';
$string['wordhandling'] = 'קורא קבצי מיקרוסופט אופיס';

?>
