<?PHP // $Id: bulkusers.php,v 1.1 2007/08/22 13:17:26 emanuel1 Exp $
      // bulkusers.php - created with Moodle 1.9 Beta + (2007081600)


$string['addall'] = 'הוספת כל המשתמשים לרשימה';
$string['addsel'] = 'הוספת משתמשים מסומנים לרשימה';
$string['available'] = 'זמין';
$string['removeall'] = 'איפוס בחירה';
$string['removesel'] = 'הסרת משתמשים מהרשימה';
$string['selected'] = 'נבחר';
$string['selectedlist'] = 'בחרו פעולה:';
$string['usersselected'] = '$a משתמשים נבחרו.';
$string['usersfound'] = '$a משתמש(ים) נמצא)(ן)';
$string['usersinlist'] = 'משתמשים ברשימה';
$string['noselectedusers'] = 'לא נבחרו משתמשים';
$string['nofilteredusers'] = 'לא נמצאו משתמשים (0/$a)';
?>
