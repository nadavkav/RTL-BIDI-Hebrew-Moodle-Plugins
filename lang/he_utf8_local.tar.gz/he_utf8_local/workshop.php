<?PHP // $Id$ 
      // workshop.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['modulename'] = 'הערכת עמיתים';
$string['modulenameplural'] = 'הערכות עמיתים';
$string['regradestudentassessments'] = 'בדקו שנית את הערכות התלמיד, ותנו ציון בהתאם.';
$string['releaseteachergrades'] = 'הצגת ציוני המורים';
$string['removeallattachments'] = 'הסרת כל הקבצים המצורפים';
$string['reply'] = 'חזרה על הניתוח';
$string['returntosubmissionpage'] = 'חזרה לעמוד ההגשה';
$string['rubric'] = 'מאפיין';
$string['saveleaguetableoptions'] = 'שמירת האפשרויות של טבלת הליגה (הישגים)';
$string['savemyassessment'] = 'שמירת ההערכה שלי';
$string['savemycomment'] = 'שמירת ההערה שלי';
$string['savemygrading'] = 'שמירת הציון שלי';
$string['savemysubmission'] = 'שמירת ההגשה שלי';
$string['saveoverallocation'] = 'שמירת רמת ההקצא';
$string['select'] = 'בחרו';
$string['showdescription'] = 'הצגת תיאור פעילות הערכת עמיתים';
$string['showgrades'] = 'הצגת הציונים';
$string['showsubmission'] = 'הצג ת ההגשות: $a';
$string['submitassignment'] = 'הגישו את המטלה';
$string['submitassignmentusingform'] = 'הגישו את המטלה שלך באמצעות טופס זה';
$string['submitexample'] = 'הגישו דוגמא';
$string['submitexampleassignment'] = 'הגישו מטלה לדוגמא';
$string['submitrevisedassignment'] = 'הגישו מטלה המתוקנת באמצעות טופס זה';
$string['uploadsuccess'] = 'הועלה בהצלחה';
$string['usepassword'] = 'השתמשו בסיסמה';
$string['view'] = 'הצגה';
$string['workshop:manage'] = 'ניהול הגדרות';
$string['workshop:participate'] = 'השתתף בפעילות הערכת עמיתים';
$string['workshopassessments'] = 'הערכות משתתפים בפעילות זו';
$string['workshopcomments'] = 'הערות המשתתפים בהערכת עמיתים';
$string['workshopfeedback'] = 'משוב המשתתפים בהערכת עמיתים';
$string['workshopsubmissions'] = 'הגשות המשתתפים בהערכת עמיתים';
$string['wrongpassword'] = 'סיסמה לא נכונה עבור פעילות זו';

?>
