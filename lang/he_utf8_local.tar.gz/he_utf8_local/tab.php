<?PHP // $Id$ 
      // tab.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['changestyle'] = 'עריכת קובצי עיצוב';
$string['css'] = 'קובץ עיצוב';
$string['displaymenu'] = 'תצוגת תפריט החוצץ';
$string['displaymenuagree'] = 'אשרו אם אתם מעוניינים להציג תפריט';
$string['menucss'] = 'עריכת עיצוב התפריט';
$string['menuname'] = 'שם תפריט';
$string['modulename'] = 'דף תוכן משולב חוצצים';
$string['modulenameplural'] = 'דפי תוכן משולבי חוצצים';
$string['moretabs'] = 'הוספת חוצצים נוספים';
$string['name'] = 'שם';
$string['tabcontent'] = 'תוכן החוצץ';
$string['tabname'] = 'שם החוצץ';
$string['tabs'] = 'חוצצים';

?>
