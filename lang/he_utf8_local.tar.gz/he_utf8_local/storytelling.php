<?PHP // $Id: storytelling.php, 2007/3/30 11:35:05 moodler Exp $ 
      // storytelling.php - created with Moodle 1.8 beta + (2006042900)



$string['modulename'] = 'Storytelling';
$string['modulenameplural'] = 'Storytellings';
$string['chooseaneditor'] = 'Create one new profile or modify one already existing :';
$string['newprofile'] = 'New profile';
$string['next'] = 'Next';
$string['profile'] = 'Profile: ';
$string['profilename'] = 'Profile name :';
$string['profileweight'] = 'Weight :';
$string['choosearol'] = 'Choose a rol';
$string['send'] = 'Send';
$string['datastored'] = 'Data stored';
$string['dataupdated'] = 'Data updated';
$string['title'] = 'Title: ';
$string['privacity'] = 'Privacity: ';
$string['public'] = 'public';
$string['private'] = 'private';
$string['class'] = 'class';
$string['editingnewprofile'] = 'Editing a new profile';
$string['modifyingprofile'] = 'Modifying profile : ';
$string['noname'] = 'Error: profile without name';
$string['profilerepeated'] = 'Error: profile name already existing';
$string['norole'] = 'Error: role not picked';
$string['notitle'] = 'Error: You must enter a title to your story';
$string['letswriting'] = 'Let\'s writing';
$string['newstory'] = 'New story';
$string['nostories'] = 'There is no available stories';
$string['younostories'] = 'You have not writen stories yet';
$string['allstories'] = 'See all my stories';
$string['mystory'] = 'My story';
$string['privacitylevel'] = 'Who do you want to read your story ?';
$string['justme'] = 'Just me';
$string['myfriends'] = 'My friends';
$string['everybody'] = 'Everybody';
$string['laststories'] = 'My last stories';
$string['search'] = 'Search';
$string['patternsearch'] = 'Search pattern: ';
$string['user'] = 'User: ';
$string['content'] = 'Content: ';
$string['mystories'] = 'My stories';
$string['print'] = 'print';
$string['edit'] = 'edit';
$string['delete'] = 'delete';
$string['share'] = 'share';
$string['wanttodelete'] = 'Attention !! Are you sure you want to delete the story ';
$string['privacityon'] = 'Right now, your story can be read by:';
$string['configwarning1'] = 'Select those rols that will see the webeditor with this profile.';
$string['configwarning2'] = '<strong>Warning:</strong> Former role selections will be overwriten.';
$string['configwarning3'] = 'Select what buttons will be avaliable on this profile (and the prefered toolbar to be shown)';
$string['searchauthand'] = 'Search results by author (AND):';
$string['searchtitleand'] = 'Search results by title (AND):';
$string['searchcontentand'] = 'Search results by content (AND):';
$string['searchauthor'] = 'Search results by author (OR):';
$string['searchtitleor'] = 'Search results by title (OR):';
$string['searchcontentor'] = 'Search results by content (OR):';

?>
