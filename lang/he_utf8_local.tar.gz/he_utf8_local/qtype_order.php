<?PHP // $Id$ 
      // qtype_order.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addingorder'] = 'הוספת שאלת מיון פריטים';
$string['addmoreqblanks'] = 'הוספת פריטים חדשים';
$string['defaultresponse'] = 'ללא תשובה';
$string['editingorder'] = 'עריכת שאלת מיון פריטים';
$string['filloutthreeitems'] = '<BR>עליכם להזין לפחות שלוש פריטים בסדר תקין.
פריטים ריקים לא מוצגים.';
$string['horizontal'] = 'הצגה אופקית של פריטים';
$string['itemno'] = 'פריט $a';
$string['order'] = 'מיון פריטים (בגרירה)';

?>
