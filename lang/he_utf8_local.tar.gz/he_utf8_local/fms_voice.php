<?PHP // $Id: mediaplugin.php,v 1.3 2008/10/28 12:47:13 moodler Exp $ 
      // mediaplugin.php - created with Moodle 1.9 


$string['filtername'] = 'הקלטת תגובה קולית';

?>