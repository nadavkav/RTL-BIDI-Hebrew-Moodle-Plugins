<?PHP // $Id$ 
      // bookmarks.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['additem'] = 'הוספת אתר חדש';
$string['canceled'] = 'הפעולה בוטלה';
$string['nogroupsset'] = 'לא קיימות קבוצות במרחב לימוד זה';
$string['noresults'] = 'לא נמצאו קישורים לאתרים העונים על מאפייני החיפוש שלכם';
$string['repeatedlink'] = 'הקישור קיים כבר במערכת';

?>
