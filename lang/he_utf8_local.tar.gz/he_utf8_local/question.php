<?PHP // $Id$ 
      // question.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['categorycurrent'] = 'סיווג נוכחי';
$string['categorycurrentuse'] = 'השתמש בסיווג זה';
$string['categorydoesnotexist'] = 'סיווג זה אינו קיים';
$string['categorymoveto'] = 'שמירה בסיווג';
$string['changepublishstatuscat'] = '<a href=\"caturl\">לסיווג \"a->name\"</a>במרחב לימוד \"$a->coursename\" יהיה מצב שיתופי שישונה מ<strong>$a->changefrom ל$a->changeto </strong>';
$string['cwrqpfs'] = 'בחירה של שאלות אקראיות מתת-סיווג.';
$string['cwrqpfsnoprob'] = 'שום סיווג שאלות באתר שלכם אינו מושפע על ידי השאלות ה\'אקראיות\' הבוחדרות שאלות מתת-סיווגים.';
$string['defaultinfofor'] = 'ברירת המחדל לסיווג השאלות המשותפות בהקשר $a';
$string['editingcategory'] = 'עריכת סיווג';
$string['exportcategory'] = 'ייצא סיווג';
$string['filesareacourse'] = 'אזור הקבצים של מרחב הלימוד';
$string['filesareasite'] = 'אזור הקבצים של האתר';
$string['getcategoryfromfile'] = 'קבעו סיווג מהקובץ';
$string['getcontextfromfile'] = 'קבעו הקשר מהקובץ';
$string['ignorebroken'] = 'התעלמו מקישורים שבורים';
$string['makechildof'] = 'בנו צאצא של  $a';
$string['maketoplevelitem'] = 'הזזו לרמה עליונה';
$string['move'] = 'הזזו מ-$a ושנה את הקישורים';
$string['movecategory'] = 'הזזת סיווג';
$string['moveqtoanothercontext'] = 'הזזת השאלה להקשר';
$string['movingcategory'] = 'הזזת סיווג';
$string['needtochoosecat'] = 'עליכם לבחור סיווג אליו יש להעביר שאלה זאת או לחצו על \'בטל\'';
$string['nopermissionadd'] = 'אין לכם רשות להוסיף שאלות במקום זה';
$string['notenoughdatatoeditaquestion'] = 'לא צויינו: מספר זיהוי השאלה או מספר זיהוי הסיווג או סוג השאלה.';
$string['notenoughdatatomovequestions'] = 'עליכם לספק את מספרי הזיהוי של השאלות שאתה רוצה להעביר';
$string['permissionedit'] = 'עריכת שאלה זו';
$string['permissionmove'] = 'העברת שאלה זו';
$string['permissionsaveasnew'] = 'שמירת הגדרות שאלה זו... כשאלה חדשה';
$string['permissionto'] = 'יש לכם רשות:';
$string['questioncategory'] = 'הסיווג בו מצוייה השאלה';
$string['questioncatsfor'] = 'סיווג שאלה עבור \'$a\'';
$string['questionuse'] = 'השתמשו בשאלה בפעילות זאת';
$string['shareincontext'] = 'שתפו בהקשר עבור $a';
$string['tofilecategory'] = 'כתבו את סיווג לקובץ';
$string['tofilecontext'] = 'כתבו את ההקשר לקובץ';

?>
