<?PHP // $Id$ 
      // filters.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['actfilterhdr'] = 'מסננים פעילים (מצורפים ביחד)';
$string['addfilter'] = 'הוספת מסנן';
$string['anycategory'] = 'כל סיווג';
$string['anycourse'] = 'כל מרחב-לימוד';
$string['categoryrole'] = 'סיווג התפקיד';
$string['removeall'] = 'הסרת כל המסננים';
$string['removeselected'] = 'הסרת מסננים מסומנים';

?>
