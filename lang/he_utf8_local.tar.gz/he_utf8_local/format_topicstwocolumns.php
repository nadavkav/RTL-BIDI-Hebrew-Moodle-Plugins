<?php 

$string['topicstwocolumns'] = 'topicstwocolumns';

?>