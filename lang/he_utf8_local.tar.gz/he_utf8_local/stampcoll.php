<?PHP // $Id$ 
      // stampcoll.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addstampbutton'] = 'הוסיפו';
$string['deletestamp'] = 'מחיקת חותמת';
$string['editstamps'] = 'עריכת חותמות';
$string['givenby'] = 'מ: a$';
$string['givento'] = 'ל: a$';
$string['modulename'] = 'אוסף חותמות';
$string['modulenameplural'] = 'אוספי חותמות';
$string['nostampscollected'] = 'לא נאספו חותמות, עדיין.';
$string['nostampsincollection'] = 'אין חותמות באוסף זה';
$string['nousers'] = 'אין משתמשים';
$string['numberofstamps'] = 'חותמות';
$string['ownstamps'] = 'החותמות שלי';
$string['stampcoll:collectstamps'] = 'איסוף חותמות';
$string['stampcoll:givestamps'] = 'תנו חותמות';
$string['stampcoll:managestamps'] = 'ניהול חותמות';
$string['stampcoll:viewotherstamps'] = 'הצגת חותמות של משתמשים אחרים';
$string['stampcoll:viewownstamps'] = 'הצגת החותמות שלי';
$string['stampimage'] = 'תמונת החותמת';
$string['stampimageinfo'] = 'גודל מומלץ 35X35 נקודות.';
$string['studentsperpage'] = 'מספר תלמידים בדף';
$string['timemodified'] = 'עדכון אחרון';
$string['updatestampbutton'] = 'עדכון';
$string['viewstamps'] = 'תצוגת חותמות';

?>
