<?PHP // $Id$ 
      // chat.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['autoscroll'] = 'גלילה אוטומטית';
$string['chat:chat'] = 'השתתפו בשיחה';
$string['chat:deletelog'] = 'מחקת יומני המעקב של השיחה';
$string['chat:readlog'] = 'הצגת יומני המעקב של השיחה';
$string['chatintro'] = 'הנחיות מורה בתחילת השיחה';
$string['chatname'] = 'שמו של חדר שיחה זה';
$string['chatreport'] = 'דוח ארכיון שיחה';
$string['chattime'] = 'זמן השיחה הבא';
$string['configservermax'] = 'המספר המירבי המותר של משתמשים מחוברים (\"לקוחות\")';
$string['configserverport'] = '\"port\" בו ניתן להשתמש בשביל תוכנת \"daemon\".';
$string['currentchats'] = 'רשימת חדרי שיחה פעילים';
$string['currentusers'] = 'משתמשים נוכחים';
$string['deletesession'] = 'מחיקת שיחה זו';
$string['deletesessionsure'] = 'האם אתם בטוחים שאתם רוצים למחוק שיחה זו?';
$string['donotusechattime'] = 'הסתרם זמני קיום מפגשי שיחה';
$string['enterchat'] = 'לחצו כאן, להיצטרף לחדר שיחה זה עכשיו';
$string['errornousers'] = 'לא נמצאו משתמשים!';
$string['helpchatting'] = 'עזרה עם שיחה';
$string['messageenter'] = '$a הצטרף/פה לשיחה זו.';
$string['messageexit'] = '$a עזב/ה שיחה זו.';
$string['method'] = 'שיטת ניהול חדרי שיחה';
$string['methoddaemon'] = 'תוכנת \"daemon\" השוהה בשרת \"IRC\"';
$string['methodnormal'] = 'מערכת מוודל מנהלת את חדרי השיחה';
$string['modulename'] = 'רב־שיח (צ\'אט)';
$string['modulenameplural'] = 'רב־שיח (צ\'אטים)';
$string['neverdeletemessages'] = 'אין למחוק הודעות משיחות בארכיון';
$string['nextsession'] = 'זמן רב־השיח המתוכן הבאה';
$string['noguests'] = 'רב-שיח זה לא פתוח לאורחים';
$string['noscheduledsession'] = 'לא קיימים מפגשי רב-שיח מתוכננות';
$string['oldping'] = 'משך זמן ללא פעילות המאפשר ניתוק משתמש לא פעיל';
$string['pastchats'] = 'ארכיון שיחות';
$string['refreshroom'] = 'רענון תצוגת תוכן השיחה';
$string['refreshuserlist'] = 'רענון רשימת משתתפים';
$string['removemessages'] = 'הסרת כל ההודעות';
$string['repeattimes'] = 'תצוגה חוזרת של מפגשי שיחה קודמים';
$string['savemessages'] = 'שמירת שיחות ישנות';
$string['seesession'] = 'הצגת שיחה זו';
$string['servermax'] = 'מספר משתתפים מירבי';
$string['sessions'] = 'מפגשיי שיחה';
$string['updatemethod'] = 'עדכון שיטה ניהול שרת חדרי שיחות';
$string['viewreport'] = 'הצגת מפגשיי שיחה ישנים';

?>
