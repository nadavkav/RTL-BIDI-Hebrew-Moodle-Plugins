<?php

$string['Remembering_en'] = 'Remembering';
$string['remember'] = 'הזכירו';
$string['remember_en'] = 'Remember';
$string['list_en'] = 'list';
$string['define_en'] = 'define';
$string['state_en'] = 'state';
$string['repeat_en'] = 'repeat';
$string['duplicate_en'] = 'duplicate';

$string['classify_en'] = 'classify';
$string['describe_en'] = 'describe';
$string['discuss_en'] = 'discuss';
$string['explain_en'] = 'explain';
$string['identify_en'] = 'identify';
$string['locate_en'] = 'locate';
$string['recognize_en'] = 'recognize';
$string['report_en'] = 'report';
$string['select_en'] = 'select';
$string['translate_en'] = 'translate';
$string['paraphrase_en'] = 'paraphrase';

$string['choose_en'] = 'choose';
$string['demonstrate_en'] = 'demonstrate';
$string['employ_en'] = 'employ';
$string['illustrate_en'] = 'illustrate';
$string['interpert_en'] = 'interpert';
$string['operate_en'] = 'operate';
$string['sketch_en'] = 'sketch';
$string['solve_en'] = 'solve';
$string['use_en'] = 'use';
$string['scheduale_en'] = 'scheduale';

$string['apprise_en'] = 'apprise';
$string['compare_en'] = 'compare';
$string['contrast_en'] = 'contrast';
$string['criticise_en'] = 'criticise';
$string['differentiate_en'] = 'differentiate';
$string['disciminate_en'] = 'disciminate';
$string['distinguish_en'] = 'distinguish';
$string['examine_en'] = 'examine';
$string['experiment_en'] = 'experiment';
$string['question_en'] = 'question';
$string['test_en'] = 'test';

?>