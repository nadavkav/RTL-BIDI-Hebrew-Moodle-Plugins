<?PHP // $Id$ 
      // block_mnet_hosts.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['mnet_hosts'] = 'רשת חברתית חיצונית';

?>
