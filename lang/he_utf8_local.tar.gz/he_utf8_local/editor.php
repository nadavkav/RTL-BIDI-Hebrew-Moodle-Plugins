<?PHP // $Id$
      // editor.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['alertnoselectedtext'] = 'תחילה, יש לסמן מלל כל שהו!';
$string['alternatetext'] = 'מלל חלופי';
$string['choosechar'] = 'בחרו תו';
$string['chooseicon'] = 'בחרו סמל אותו יש להכניס';
$string['createanchor'] = 'צרו עוגן';
$string['createfolder'] = 'צרו תיקייה';
$string['createlink'] = 'הכנסת קישור אינטרנט';
$string['cut'] = 'גזירת קטע נבחר';
$string['delete'] = 'מחיקה';
$string['enterurlfirst'] = 'תחילה, עליכם להכניס כתובת URL';
$string['htmlmode'] = 'הצג קוד מקור HTML';
$string['insertchar'] = 'הכנסת תו מיוחד';
$string['insertimage'] = 'הכנסת תמונה';
$string['insertlink'] = 'הכנסת קישור';
$string['insertsmile'] = 'הכנסת סמיילי';
$string['inserttable'] = 'הכנסת טבלה';
$string['openclipartgallery'] = 'מאגר תמונות חופשי';
$string['googleimggallery'] = 'חיפוש בגוגל תמונות';
$string['ccbycolorgallery'] = 'חיפוש לפי צבע';
$string['insertembed'] = 'הדביקו את קוד ה־EMBED במשבצת זו:';
$string['chooseavideowebsite'] = 'בחרו אתר לחיפוש סרט וידאו חדש:';
$string['insertmultimediatitle'] = 'שיבוץ מולטימדיה';
$string['insertmultimedia'] = 'אנא בחרו הקלטה של קול או סרטון...';
$string['purifyhtml'] = 'ניקוי תוכן מיותר...';
$string['purifyhtmlinfo'] = 'ניתן ללחוץ מספר פעמים על הכפתור ניקוי עד אשר מתקבלת התוצאה הרצויה';
$string['purify'] = 'ניקוי';

$string['leavevoicecomment'] = 'הקליקו על קישור זה להקלטת הודעה קולית';
$string['listentocomment'] = 'הקשיבו להודעה קולית שהקלטתם';
$string['voicecommentsaved'] = 'ההקלטה שלכם נשמרה בהצלחה, אנא הקליקו על הכפתור <b>אישור</b> לסיום';
$string['getwebtoo'] = 'בחרו שרות WEB2 מהרשימה לשם שיבוץ במרחב הלימוד שלכם';



?>