<?PHP // $Id$ 
      // lightboxgallery.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addcomment'] = 'הוספת תגובה';
$string['allowcomments'] = 'האם ניתן לכתוב תגובות';
$string['backtogallery'] = 'חזרה לאלבום';
$string['commentadded'] = 'תגובותכם צורפו לאלבום';
$string['commentdelete'] = 'אישור מחיקת הערה?';
$string['currentsize'] = 'גודל נוכחי';
$string['dimensions'] = 'מימדים';
$string['dirdown'] = 'מטה';
$string['dirleft'] = 'שמאלה';
$string['dirright'] = 'ימינה';
$string['dirup'] = 'מעלה';
$string['displayinggallery'] = 'תצוגת אלבום: $a';
$string['edit_caption'] = 'כותרת';
$string['edit_crop'] = 'חיתוך';
$string['edit_delete'] = 'מחיקה';
$string['edit_flip'] = 'היפוך';
$string['edit_resize'] = 'שינוי גודל';
$string['edit_resizescale'] = 'מתיחה';
$string['edit_rotate'] = 'סיבוב';
$string['edit_thumbnail'] = 'תמונה יצוגית';
$string['editimage'] = 'עריכת תמונה';
$string['errornofile'] = 'הקובץ המבוקש לא נמצא';
$string['errornogalleries'] = 'לא נמצאו אלבומי תמונות במרחב לימוד זה';
$string['errornoimages'] = 'לא נמצאו תמונות באלבום זה';
$string['extendedinfo'] = 'תצוגת מאפייני תמונה נוספים';
$string['imageadd'] = 'הוספת תמונות';
$string['imagedirectory'] = 'הצגת הספרייה';
$string['imagelocation'] = 'מיקום תמונה';
$string['imagesperpage'] = 'תמונות בדף';
$string['lightboxgallery:addcomment'] = 'הוספת הערות לאלבום';
$string['lightboxgallery:edit'] = 'עריכת אלבום';
$string['lightboxgallery:viewcomments'] = 'הצגת תגובות לאלבום';
$string['modulename'] = 'אלבום תמונות';
$string['modulenameadd'] = 'תצוגת ספריה כאלבום תמונות';
$string['modulenameplural'] = 'אלבומי תמונות';
$string['modulenameshort'] = 'אלבום';
$string['resizeto'] = 'שינוי גודל';
$string['selectflipmode'] = 'בחירת מצב היפוך';
$string['selectrotation'] = 'בחירת זווית סיבוב';
$string['selectthumbpos'] = 'קביעת מיקום תמונה מקדימה';
$string['showall'] = 'כל התמונות';
$string['thumbnailoffset'] = 'מיקום חדש';
$string['editlightboxgallery'] = 'צפייה באלבום'; // ORPHANED

?>
