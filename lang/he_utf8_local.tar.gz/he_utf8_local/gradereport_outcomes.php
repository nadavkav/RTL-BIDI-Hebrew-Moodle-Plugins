<?PHP // $Id$ 
      // gradereport_outcomes.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addoutcome'] = 'הוספת השג';
$string['courseoutcomes'] = 'השגי מרחב הלימוד';
$string['coursespecoutcome'] = 'השגי מרחביי הלימוד';
$string['modulename'] = 'דוח השגים';
$string['outcomes:view'] = 'הצגת דוח השגים';
$string['usedgradeitem'] = 'מספר פריטי ציון';

?>
