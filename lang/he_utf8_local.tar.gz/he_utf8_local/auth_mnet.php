<?PHP // $Id$ 
      // auth_mnet.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle



?>
