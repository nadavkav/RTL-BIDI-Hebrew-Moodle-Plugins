<?PHP // $Id$ 
      // my.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['mymoodle'] = 'סקירת מרחבי-הלימוד שלי';
$string['nocourses'] = 'אין מידע שניתן להציג על מרחב-הלימוד';
$string['noguest'] = 'עמוד \'סקירת מרחבי-לימוד\' לא זמין לאורחים.';
$string['pinblocks'] = 'הגדרת משבצות-הוראה מקובעות למוודל שלי';
$string['pinblocksexplan'] = 'כל הגדרת משבצת-הוראה שתגדירו את התצורה שלה כאן, תוצג לכל משתמש של מוודל בעמוד סקירת \'מוודל שלי\' שלהם (אבל הם לא יוכלו לערוך אותה.)';

?>
