<?PHP // $Id$ 
      // oublog.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['1comment'] = 'הערה אחת';
$string['accessdenied'] = 'אינכם מורשים לצפות בדף זה.';
$string['atomfeed'] = 'שידור RSS מסוג Atom';
$string['blogfeed'] = 'ידיעות בלוג חדשות';
$string['commentsfeed'] = 'הערות חדשות בלבד';
$string['completioncomments'] = 'משתמש חייב להעיר הערות על ידיעות בבלוג:';
$string['completioncommentsgroup'] = 'חובה להוסיף הערות';
$string['completioncommentshelp'] = 'דרושות הערות לסיום המשימה';
$string['completionposts'] = 'משתמש חייב להוסיף ידיעות:';
$string['completionpostsgroup'] = 'חובה להוסיף ידיעות';
$string['completionpostshelp'] = 'חובה להוסיף ידיעות על מנת לסיום המשימה';
$string['configshowuserpics'] = 'אפשרות זו מציגה תמונות משתמש לצד כל ידיעה';
$string['confirmdeletecomment'] = 'האם אתם בטוחים שאתם מעוניים למחוק ידיעה זו?';
$string['confirmdeletelink'] = 'האם אתם בטוחים שאתם מעוניינים למחוק קישור זה?';
$string['confirmdeletepost'] = 'האם אתם בטוחים שאתם מעוניינים למחוק ידעיה זו?';
$string['extranavtag'] = 'תווית: $a';
$string['feeds'] = 'שידור עדכוני RSS של בלוג זה';
$string['modulename'] = 'בלוג (יומן רב-משתתפים)';
$string['modulenameplural'] = 'בלוגים (יומנים רבי-משתתפים)';
$string['newcomment'] = 'הערה חדשה לבלוג';
$string['newerposts'] = 'ידעות חדשות &gt;';
$string['olderposts'] = '&lt; ידעות ישנות';
$string['oublog:audit'] = 'תצוגת ידעות אשר נמחקו וגירסאות ישנות';
$string['oublog:contributepersonal'] = 'כתיבת ידיעות והערות בבלוגים האישיים';
$string['oublog:viewpersonal'] = 'הצגת ידיעות מבלוגים אישיים';
$string['overviewnumentrylog'] = 'ידיעות מאז ביקורכם האחרון';
$string['overviewnumentrylog1'] = 'ידיעה מאז ביקורכם האחרון';
$string['overviewnumentryvw'] = 'ידיעות מאז צפייתכם האחרונה';
$string['overviewnumentryvw1'] = 'ידיעה מאז צפייתכם האחרונה';
$string['searchblogs'] = 'חיפוש בבלוגים';
$string['searchthisblog'] = 'חיפוש בבלוג זה';
$string['siteentries'] = 'ידיעות מהאתר כולו';
$string['tags'] = 'תוויות (מופרדות בפסיקים)';

?>
