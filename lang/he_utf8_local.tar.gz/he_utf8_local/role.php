<?PHP // $Id$
      // role.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['allsiteusers'] = 'כל המשתמשים במערכת';
$string['assignglobalroles'] = 'ניהול תפקידים מערכתיים';
$string['assignroles'] = 'ניהול תפקידים';
$string['assignrolesin'] = 'הקצאת תפקידים ב $a';
$string['defineroles'] = 'הגדרת תפקידים';
$string['block:view'] = 'הצגת משבצת-ניהול';
$string['blog:create'] = 'יצירת רשומות חדשות בבלוג';
$string['blog:manageofficialtags'] = 'ניהול תוויות מערכתיות';
$string['blog:managepersonaltags'] = 'ניהול תוויות אישיות';
$string['notes:manage'] = 'ניהול מסרים';
$string['notes:view'] = 'צפייה במסרים';
$string['overridepermissions'] = 'עקיפת הרשאות';
$string['overridepermissionsin'] = 'עקיפת הרשאות ב$a';
$string['overrideroles'] = 'עקיפת תפקידים';
$string['overriderolesin'] = 'עקיפת תפקידים ב$a';
$string['potentialusers'] = '$a משתמשים אפשריים';
$string['site:webdav'] = 'ניהול קבצים בעזרת WebDAV';
$string['userswithrole'] = 'כל המשתמשים בעלי התפקיד';
$string['continuetofrontpage'] = 'המשיכו לדף הראשי של מרחב הלימוד'; // ORPHANED
$string['searchusershowto'] = '';

?>
