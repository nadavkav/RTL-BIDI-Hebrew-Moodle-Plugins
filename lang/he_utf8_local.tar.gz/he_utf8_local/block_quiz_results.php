<?PHP // $Id$ 
      // block_quiz_results.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['config_grade_format'] = 'הצגת ציונים כ:';
$string['config_names_full'] = 'הצגת שמות מלאים';
$string['config_names_id'] = 'הצגת מספרי זיהוי בלבד';
$string['config_no_quizzes_in_course'] = 'מרחב-לימוד זה לא מכיל אף פעילות בוחן. עליכם להוסיף לפחות פעילות בוחן אחת לפני שתוכלו להשתמש במשבצת-הוראה זו בצורה נכונה.';
$string['config_select_quiz'] = 'תוצאות של איזה בוחן על משבצת-הוראה זו להציג?';
$string['config_show_best'] = 'כמה מהציונים הגבוהים ביותר להציג (כדי לבטל: 0)?';
$string['config_show_worst'] = 'כמה מהציונים הנמוכים ביותר להציג (כדי לבטל: 0)?';
$string['configuredtoshownothing'] = 'הגדרת התצורה של משבצת-הוראה זו, לא מאפשרת לו כרגע להציג תוצאות כלשהם. יכול להיות שתירצו או להגדיר לו מחדש את התצורה או להסתיר אותו.';
$string['error_emptyquizid'] = 'כרגע יש שגיאה במשבצת-הוראה זו: עליכם לבחור את תוצאותיו של איזה בוחן עליו להציג.';
$string['error_emptyquizrecord'] = 'כרגע יש שגיאה משבצת-הוראה זו: נראה כאילו הבוחן הנבחר לא קיים במאגר הנתונים.';
$string['error_nogroupsexist'] = 'כרגע יש שגיאה משבצת-הוראה זו: היא מוגדרת להציג את הציונים במצב קבוצה, אבל במרחב-לימוד זה אין קבוצות מוגדרות.';

?>
