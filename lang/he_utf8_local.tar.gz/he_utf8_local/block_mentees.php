<?PHP // $Id$ 
      // block_mentees.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['blockname'] = 'בקרת הורים';
$string['configtitle'] = 'בקרת הילדים שלי';
$string['leaveblanktohide'] = 'כדי להסתיר את הכותרת השאירו אתה ריקה';
$string['newmenteesblock'] = 'בקרת הורים';
$string['nomentees'] = '<b>למשתמש זה לא משויכים ילדים.</b> אנא פנו לצוות ניהול האתר לשם שיוך ילד/ים למשתמש שלכם';

?>
