<?PHP // $Id$ 
      // block_rss_client.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['addfeed'] = 'הוספת כתובת URL להזנת RSS:';
$string['addheadlineblock'] = 'הוספת משבצת RSS';
$string['addnew'] = 'הוסיפו הזנה חדשה';
$string['choosefeedlabel'] = 'בחרו את ההזנות אשר ברצונכם להפוך לזמינות במשבצת RSS זו:';
$string['clientshowimagelabel'] = 'הצגת תמונת ההזנה, אם היא זמינה:';
$string['configblock'] = 'הגדרו משבצת RSS זו';
$string['deletefeedconfirm'] = 'האם אתם מעוניינים למחוק הזנה זו?';
$string['editfeeds'] = 'ערכו, הירשמו כמנויים או בטלו רישום להזנות RSS/Atom';
$string['editnewsfeeds'] = 'עריכת הזנת RSS';
$string['editrssblock'] = 'עריכת משבצת RSS';
$string['feedadded'] = 'נוספה הזנת RSS חדשה';
$string['feeddeleted'] = 'נמחקה הזנת RSS קיימת';
$string['feeds'] = 'רשימת הזנות RSS קיימות';
$string['feedsaddedit'] = 'הוסיפו או ערכו הזנות';
$string['feedsconfigurenewinstance'] = 'לחצו כאן להגדרת משבצת הזנות RSS זו';
$string['feedupdated'] = 'הזנת RSS עודכנה';
$string['findmorefeeds'] = 'מצאו עוד הזנות RSS';
$string['managefeeds'] = 'ניהול ההזנות שלי';
$string['nofeeds'] = 'אין הזנות RSS אשר מוגדרות עבור אתר זה.';
$string['pickfeed'] = 'בחרו הזנת RSS';
$string['remotenewsfeed'] = 'הזנת RSS חיצונית';
$string['rss_client:createprivatefeeds'] = 'יצירת הזנות RSS פרטיות';
$string['rss_client:createsharedfeeds'] = 'יצירת הזנות RSS משותפות';
$string['rss_client:manageanyfeeds'] = 'ניהול כל הזנת RSS שהיא';
$string['rss_client:manageownfeeds'] = 'ניהול הזנת ה-RSS שלי';
$string['seeallfeeds'] = 'צפייה בכל ההזנות';
$string['shownumentrieslabel'] = 'מספר הרשומות המירבי שיוצג בכל משבצת RSS.';
$string['timeout'] = 'תפוגת זמן משבצת RSS';
$string['updatefeed'] = 'עדכון כתובת ה-URL של הזנת RSS:';
$string['validatefeed'] = 'בדקו את תקינות הקישור להזנת RSS זו';

?>
