<?PHP // $Id$
      // message.php - created with Moodle 1.9.3+ (Build: 20090107) (2007101533.01)
      // local modifications from http://localhost/moodle-193


$string['addcontact'] = 'הוספת איש קשר';
$string['allstudents'] = 'כל ההודעות בין התלמידים במרחב-הלימוד.';
$string['blockcontact'] = 'חסימת איש הקשר.';
$string['contactlistempty'] = 'נכון לרגע זה רשימת אנשי הקשר שלכם ריקה.';
$string['discussion'] = 'דיון';
$string['emailtagline'] = 'הודעת דוא\"ל זו היא העתק של הודעה שנשלחה אליכם ב-\"$a\".';
$string['emptysearchstring'] = 'עליכם לערוך חיפוש אחר משהו.';
$string['includeblockedusers'] = 'כולל משתמשים חסומים';
$string['mailsent'] = 'הודעתך נשלחה באמצעות דואר אלקטרוני';
$string['maxmessages'] = 'מספר ההודעות המירבי שיש להראות בהיסטוריה של דיון.';
$string['messagingdisabled'] = 'שליחת הודעות לא אפשרית כעת! לחלופין, ישלח דואר אלקטרוני למשתמש.';
$string['newonlymsg'] = 'הצגת הודעות חדשות בלבד';
$string['nosearchresults'] = 'לחיפוש שלכם לא היו תוצאות';
$string['onlymycourses'] = 'רק במרחבי-הלימוד שלי';
$string['readmessages'] = '$a הודעות נקראו.';
$string['removecontact'] = 'הסרת איש הקשר';
$string['savemysettings'] = 'שמירת ההגדרות שלי';
$string['search'] = 'עריכת חיפוש';
$string['searchforperson'] = 'עריכת חיפוש אחר מישהו';
$string['searchmessages'] = 'עריכת חיפוש בהודעות';
$string['sendmessage'] = 'שליחת הודעה';
$string['sendmessageto'] = 'שליחת הודעה ל-$a';
$string['sendmessagetopopup'] = 'שליחת הודעה לחלונו החדש של $a';
$string['settingssaved'] = 'ההגדרות שלכם נשמרו';
$string['showmessagewindow'] = 'הצגה אוטומטית של חלון ההודעה בכל פעם שאני מקבל הודעה חדשה (עליכם להגדיר את הדפדפן שלך כך שהוא לא יחסום \'חלונות קופצים\' באתר זה.)';
$string['timesent'] = 'זמן השליחה';
$string['unblockcontact'] = 'ביטול חסימת איש הקשר';
$string['unreadmessages'] = '$a הודעות ממתינות לקריאה';
$string['userisblockingyou'] = 'משתמש זה חסם אותכם, ולכן אינכם יכולים לשלוח אליו הודעות.';
$string['userisblockingyounoncontact'] = 'משתמש זה מקבל את ההודעות של האנשים שרשומים אצלו כאנשי קשר בלבד, ונכון לרגע זה אתם לא נמצאים ברשימה.';

$string['inbox'] = 'התקבלו';
$string['outbox'] = 'נשלחו';
$string['to'] = 'נמענים';
$string['write'] = 'כתיבה';
$string['newmsg'] = 'כתיבת מסר חדש:';
$string['selectuser'] = 'הוספת משתמש זה לרשימת הנמענים';
$string['selectcourse'] = 'בחירת מרחב־לימוד';
$string['tocourse']='לכל המשתתפים במרחב';
$string['delrecipients']='הסרת משתמש';
$string['addrecipients']='הוספת נמענים';
$string['msgsend']='המסר נשלח';
$string['dellist']='הסרה מרשימת הנמענים';
$string['blockedcontacts']='משתמשים חסומים';


?>