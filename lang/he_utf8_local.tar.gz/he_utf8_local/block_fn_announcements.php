<?PHP // $Id$ 
      // block_fn_announcements.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['blocktitle'] = 'חדשות מרחב נגללות';
$string['displaytitle'] = 'חדשות מרחב נגללות';

?>
