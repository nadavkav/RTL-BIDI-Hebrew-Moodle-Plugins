<?PHP // $Id$ 
      // forumng.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['modulename'] = 'קבוצות־דיון (ניסיוני)';
$string['modulenameplural'] = 'קבוצות־דיון (ניסיוני)';

?>
