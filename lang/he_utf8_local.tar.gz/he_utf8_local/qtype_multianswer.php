<?php
$string['decodeverifyquestiontext'] = 'בדקו את תחביר השאלה אשר הזנתם';
$string['questiondefinition'] = 'מבנה השאלה המקורי';
$string['layout'] = 'תצורה';
$string['layoutselectinline'] = 'מילה חסרה';
$string['layouthorizontal'] = 'מילה חסרה אופקי';

$string['regex_sa'] = 'תק|תשובהקצרה';
$string['regex_mch'] = 'רבאופקי';
$string['regex_mcv'] = 'רבאנכי';
$string['regex_mc'] = 'רב';
$string['regex_mwc'] = 'תקמ';
$string['regex_nm'] = 'מספר';
?>
