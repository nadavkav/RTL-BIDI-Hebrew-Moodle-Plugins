<?php
$string['docviewplugin'] = 'תוסף לתצוגה של מסמכי אופיס';
$string['docviewservicedoc'] = 'שרות תצוגת מסמכי עיבוד תמלילים';
$string['docviewservicepresent'] = 'שרות תצוגת מצגות';
$string['docviewpluginheight'] = 'גובה חלון התצוגה';
$string['docviewpluginwidth'] = 'רוחב חלון התצוגה';
$string['docviewchooseservice'] = 'אנא בחרו שרות תצוגה למסמכי אופיס מהרשימה';

?>