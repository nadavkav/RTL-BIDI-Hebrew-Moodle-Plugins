<?PHP // $Id$ 
      // block_completion_report.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['assignments'] = 'משימות';
$string['averagegradesfromallassignments'] = 'ציון ממוצע של כלל המשימות';
$string['averagegradesfromallquizzes'] = 'ציון ממוצע של כלל המבחנים';
$string['averageofallassignments'] = 'ממוצע של כלל המשימות';
$string['averageofallquizzes'] = 'ממוצע של כלל המבחנים';
$string['blockname'] = 'דוח מסכם';
$string['changecurrentgrade'] = 'שינוי ציון נוכחי';

?>
