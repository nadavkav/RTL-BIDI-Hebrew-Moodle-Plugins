<?PHP // $Id$
      // resource.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addresource'] = 'הוספת משאב';
$string['browserepository'] = 'הצגת מאגר קבצים';
$string['clicktoopen'] = 'כדי להציג את המסמך הזה, לחצו על הקישור הבא:';
$string['choose'] = 'בחרו';
$string['chooseafile'] = 'בחרו או העלו קובץ';
$string['chooseparameter'] = 'בחרו משאב';
$string['emptyfolder'] = 'ריקון התיקייה';
$string['fulltext'] = 'מלל מלא';
$string['newstatus'] = 'הצגת סרגל המצב';
$string['newtoolbar'] = 'הצגת סרגל הכלים';
$string['pan'] = 'הזזה';
$string['redeploy'] = 'מיקום חוזר';
$string['repository'] = 'מאגר IMS';
$string['resource:view'] = 'הצגת משאב';
$string['resourcetype4'] = 'מלל פשוט';
$string['resourcetype6'] = 'מלל מסוג HTML';
$string['resourcetypedirectory'] = 'הצגת ספרייה (ממאגר הקבצים)';
$string['resourcetypehtml'] = 'דף תוכן מעוצב';
$string['resourcetypeims'] = 'הוספת חבילת תוכן IMS';
$string['resourcetypelabel'] = 'הכנסת פסקה מעוצבת';
$string['resourcetyperepository'] = 'יצירת קישור למסמך במאגר';
$string['resourcetypetext'] = 'דף מלל פשוט (מבוטל!)';

$string['resourcetypeweblink'] = 'קישור לאתר אינטרנט';
$string['resourcetypefileupload'] = 'העלאת קובץ יחיד';
$string['urllocation'] = 'כתובת אתר האינטרנט';
$string['filename_current'] = 'קובץ נוכחי';
$string['browserlocalcomputer'] = 'בחרו קובץ מהמחשב האישי';
$string['filename_new'] = 'הקובץ החדש שנבחר';

$string['showcourseblocks'] = 'הצג את משבצות התוכן הצדדיות של מרחב הלימוד';
$string['tableofcontentsabbrev'] = 'תוכן העניינים';
$string['viewims'] = 'הצגת חבילת תוכן IMS';
$string['websearchdefault'] = 'בררת מחדל לחיפוש ברשת';
$string['resourcetypeglobe'] = 'שיבוץ עצם לימוד ממאגר GLOBE';
$string['globefilechoose'] = 'בחרו משאב עצם למידה ממאגר GLOBE';
$string['resourcetypedoor'] = 'קישור לעצם למידה DOOR';
$string['disabletexttype'] = 'ביטול האפשרות לשימוש במשאב - מלל פשוט';
$string['configdisabletexttype'] = 'בחירה באפשרות זו תסיר את המשאב - מלל פשוט מרשימת המשאבים במצב עריכה';
$string['twiddlabutton'] = 'יצירת משטח ציור משותף';

$string['resourcetypekalturaswfdoc'] = 'סרט + מצגת (מתואמים)';
$string['resourcetypekalturavideo'] = 'סרט';
$string['resourcetypeaccordion'] = 'הוספת פסקה נחבאת';
?>