<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 3/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'עריכה מתקדמת בעורך TINYMCE';
$string['title'] = 'עריכה מתקדמת בעורך TINYMCE';
$string['ok'] = 'סיימתי, אפשר להמשיך';
$string['cancel'] = 'ביטול';

?>