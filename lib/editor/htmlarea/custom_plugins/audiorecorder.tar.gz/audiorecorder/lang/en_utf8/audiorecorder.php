<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 6:41 PM
 *
 * Description:
 *
 */


$string['saveedsuccessfully'] = '<h2>Recording was successfully saved.</h2> <br/><br/>Please click the \"Close Window\" button to finish';
$string['closewindow'] = 'Close Window';
$string['clicktoplay'] = 'Click to play';
$string['recordinginstructions'] = 'First, Click the NEXT button, if one exists. <br/><br/> Then, Click on the \"Red Circle\" button to start recording. <br/> To stop recording, Click the \"Blue Square\" button. <br/> To hear the recodring, Click the \"Blue Triangle\" button. <br/> If you like what you hear, click the SEND button to save the recording.';

?>