<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 6:41 PM
 *
 * Description:
 *
 */


$string['saveedsuccessfully'] = '<h2>Recording was successfully saved.</h2> <br/><br/>Please click the \"Close Window\" button to finish';
$string['closewindow'] = 'Close Window';
$string['clicktoplay'] = 'Click to play';
?>