README for ListenUp Applet

This software may only be used in accordance
with the Software License Agreement at:

  http://www.javasonics.com/downloads/

More information and documentation on ListenUp may be found at:

    http://www.javasonics.com/
    http://www.javasonics.com/listenup/docs/
    
The documentation describes how to install the Applet
on your own web site. It also describes how to customize the
Applet for your own needs.

Please browse the "index.html" file for more information.
    
Phil Burk
phil@softsynth.com
