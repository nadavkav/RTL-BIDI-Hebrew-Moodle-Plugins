<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/16/11 Time: 1:35 AM
 *
 * Description:
 *
 */

$string['chooseicongallery'] = 'Choose an Icon you wish to insert into your text';
$string['choosenewgallery'] = 'Or, choose a new icon folder:';
$string['choosegallery'] ='Choose a folder...';
$string['cancel'] = 'Close and finish';

?>