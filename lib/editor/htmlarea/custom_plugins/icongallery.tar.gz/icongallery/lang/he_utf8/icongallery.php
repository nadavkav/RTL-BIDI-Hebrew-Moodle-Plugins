<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/16/11 Time: 1:23 AM
 *
 * Description:
 *
 */


$string['chooseicongallery'] = 'בחרו סמל אותו אתם מעוניינים לשבץ בתמליל שלכם';
$string['choosenewgallery'] = 'או, בחרו ספריית תמונות חדשה לתצוגה:';
$string['choosegallery'] ='בחרו ספרייה...';
$string['cancel'] = 'סיום וסגירת חלון';

?>