<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/13/11 Time: 6:14 PM
 *
 * Description:
 *
 */

$string['pluginname']='Line Height';
$string['title']='Line Height';
$string['mustenterlineheight']='You must choose line height, to continue.';
$string['lineheight']='Line Height';
$string['chooselineheight']='Choose line height ';
$string['set']='Update';
$string['cancel']='Cancel';

?>