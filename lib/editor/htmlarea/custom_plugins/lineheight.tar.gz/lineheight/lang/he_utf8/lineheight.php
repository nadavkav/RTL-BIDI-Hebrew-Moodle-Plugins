<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/13/11 Time: 6:14 PM
 *
 * Description:
 *
 */

$string['title']='קביעת מרווח בין שורות';
$string['mustenterlineheight']='יש לבחור מרווח בין שורות';
$string['lineheight']=' מרווח בין השורות';
$string['chooselineheight']='בחרו מרווח בין השורות ';
$string['set']='עדכון';
$string['cancel']='ביטול';

?>