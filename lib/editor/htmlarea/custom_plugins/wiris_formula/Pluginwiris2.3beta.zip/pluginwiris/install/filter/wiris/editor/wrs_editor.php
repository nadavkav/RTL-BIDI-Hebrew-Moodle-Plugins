<?php
// Load configuration constants
if(!isset($CFG)) {
    require_once('../../../config.php');
}
require_once($CFG->dirroot . '/filter/wiris/wrs_config.php');
require_once($CFG->dirroot . '/filter/wiris/lib/wrs_lang_inc.php');

// absolute url to the jar directory
$jardirurl = 'http://' . $CFG->wirisservicehost . ':' . $CFG->wirisserviceport . $CFG->wirisservicepath . '/codebase';

// get the character encoding
$charset = get_string("thischarset");
$lang = current_language();
$lang = substr($lang,0, 2);  //ignoring specific country code

require_js($CFG->wwwroot . '/filter/wiris/editor/wrs_editor.js.php');

$CFG->stylesheets[] = $CFG->wwwroot . '/filter/wiris/editor/wrs_dialog.css';

// Start the output.
print_header($title=wrs_get_string($lang, 'wirisformulaeditor'), $heading=$css, $navigation='', $focus='', $meta='', $cache=true, $button='&nbsp;', $menu='', $usexml=false, $bodytags='onload="wrs_initDocument()"', $return=false);
echo '<table class="wirisdialog_outer" width="100%" height="100%" cellpadding="0" cellspacing="0">
    <tbody>
        <!-- Formula Editor Applet -->
        <tr>
            <td class="wirisdialog_applet" colspan="2" style="height: 369px;">';
            $applet = '<applet alt="Wiris Editor" ';
            $applet .= 'name="' . 'FormulaEditor' . '" ';
            $applet .= 'codebase="' . $jardirurl . '" ';
            $applet .= 'archive="' . $CFG->wiriseditorarchive . '" ';
            $applet .= 'code="' . $CFG->wiriseditorclass . '" ';
            $applet .= 'width="' . '100%' . '" ';
            $applet .= 'height="' . '100%' . '"';
            $applet .= '>';
            $applet .= '<param name="lang" value="' . $lang . '" />';
            $applet .= '<param name="menuBar" value="true"/>';
            $params = array(
                'identMathvariant' => 'wirisimageidentmathvariant',
                'numberMathvariant' => 'wirisimagenumbermathvariant',
                'fontIdent' => 'wirisimagefontident',
                'fontNumber' => 'wirisimagefontnumber',
                'version' => 'wirisserviceversion'
            );

            foreach ($params as $key => $value) {
                if (isset($CFG->{$value})) {
                    $applet .= '<param name="' . $key . '" value="' . $CFG->{$value} . '" />';
                }
            }

            if (isset($CFG->wirisimagefontranges)) {
                $wirisimagefontrangesCount = count($CFG->wirisimagefontranges);
                for ($i = 0; $i < $wirisimagefontrangesCount; ++$i) {
                    $applet .= '<param name="font' . $i . '" value="' . $CFG->wirisimagefontranges[$i] . '" />';
                }
            }

            $applet .= '<p>You need JAVA&reg; to use WIRIS tools.<br />FREE download from <a target="_blank" href="http://www.java.com">www.java.com</a></p>';
            $applet .= '</applet>';
            echo $applet;
            echo '</td>
        </tr>
        <!-- Controls -->
        <tr>
            <td id="wirisdialog_controls">
                <table cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td class="wirisdialog_controls1">
                                <!-- <button id="button_Remove">';
                                echo wrs_get_string($lang, 'remove');
                                echo '</button> -->
                            </td>
                            <td class="wirisdialog_controls2">
                                <a id="manualLink" href="http://www.wiris.com/portal/docs/editor-manual" target="_blank">Manual &gt;&gt;</a>
                                <button id="button_Ok">';
                                    echo wrs_get_string($lang, 'ok');
                                echo'</button>
                                <button id="button_Cancel">';
                                    echo wrs_get_string($lang, 'cancel');
                                echo'</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>';