<?php
$CFG->wirisversion = '2.3b';   // SHOULD NOT BE MODIFIED