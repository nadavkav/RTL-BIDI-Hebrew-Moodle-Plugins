<?php
if (!defined('SECURITY_CONSTANT')) exit;

define('ERROR_DISPLAY_LEVEL', 0);
define('ALL_WELL', 0);
define('UNKNOWN_VERSION', 1);
define('NO_WRITE_PERMISION', 2);
define('NO_READ_PERMISION', 3);
define('ALREADY_PARSED', 4);
define('CAN_NOT_CONNECT', 5);