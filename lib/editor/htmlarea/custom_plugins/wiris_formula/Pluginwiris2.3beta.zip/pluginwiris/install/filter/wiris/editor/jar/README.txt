Here you must copy the JAR archive of the WIRIS Formula Editor
"wiriseditor.jar"