﻿<?php
$serverName = "ESPAÑA - Universidad - UOC";
$codebase = "http://cv.uoc.edu/webapps/calculadora/wiris-codebase/";
$archive = "wrs_uoc_ca.jar";
$class = "WirisApplet_uoc_ca";
$lang = "ca,es";