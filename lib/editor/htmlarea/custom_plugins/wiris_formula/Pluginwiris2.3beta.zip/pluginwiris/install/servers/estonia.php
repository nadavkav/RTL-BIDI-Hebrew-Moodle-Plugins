﻿<?php
$serverName = "ESTONIA";
$codebase = "http://www.wiris.ee/wiris/wiris-codebase/";
$archive = "wrs_estonia_et.jar";
$class = "WirisApplet_estonia_et";
$lang = "et";