﻿<?php
$serverName = "ESPAÑA - Catalunya";
$codebase = "http://calculadora.edu365.cat/wiris/wiris-codebase/";
$archive = "wrs_edu365_ca.jar";
$class = "WirisApplet_edu365_ca";
$lang = "ca";