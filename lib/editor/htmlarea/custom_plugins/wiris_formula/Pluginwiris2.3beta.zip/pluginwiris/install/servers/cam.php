﻿<?php
$serverName = "ESPAÑA - Madrid";
$codebase = "http://herramientas.educa.madrid.org/wiris/wiris-codebase/";
$archive = "wrs_cam_es.jar";
$class = "WirisApplet_cam_es";
$lang = "es";