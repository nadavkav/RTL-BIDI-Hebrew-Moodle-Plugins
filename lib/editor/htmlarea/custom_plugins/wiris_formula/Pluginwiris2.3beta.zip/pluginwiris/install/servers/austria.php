﻿<?php
$serverName = "AUSTRIA";
$codebase = "http://wiris.eduhi.at/wiris-codebase/";
$archive = "wrs_austria_de_en.jar";
$class = "WirisApplet_austria_de_en";
$lang = "de_en";