<?php
$string['apply'] = 'Apply';
$string['cancel'] = 'Cancel';
$string['executeonload'] = 'Calculate on load';
$string['elementarymode'] = "Elementary mode";
$string['focusonload'] = 'Focus on load';
$string['height'] = 'Height';
$string['language'] = 'Language';
$string['ok'] = 'Ok';
$string['remove'] = 'Remove';
$string['showtoolbar'] = 'Show toolbar';
$string['width'] = 'Width';
$string['wirisformulaeditor'] = 'WIRIS Formula Editor';
$string['wiristitletext'] = "Double click to edit";