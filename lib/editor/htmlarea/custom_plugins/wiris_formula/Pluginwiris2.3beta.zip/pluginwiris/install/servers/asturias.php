﻿<?php
$serverName = "ESPAÑA - Asturias";
$codebase = "http://nea.educastur.princast.es/wiris/wiris-codebase/";
$archive = "wrs_asturias_es.jar";
$class = "WirisApplet_asturias_es";
$lang = "es";