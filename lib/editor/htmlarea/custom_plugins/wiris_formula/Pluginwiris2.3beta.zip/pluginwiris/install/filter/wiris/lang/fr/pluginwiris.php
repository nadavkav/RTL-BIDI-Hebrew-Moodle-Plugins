<?php 
$string['apply'] = 'Appliquer';
$string['cancel'] = 'Annuler';
$string['executeonload'] = 'Calculer lors du chargement';
$string['elementarymode'] = 'Mode �l�mentaire';
$string['focusonload'] = 'Activer lors du chargement';
$string['height'] = 'Hauteur';
$string['language'] = 'Langue';
$string['ok'] = 'Accepter';
$string['remove'] = 'Retirer';
$string['showtoolbar'] = "Barre d'outils";
$string['width'] = 'Largeur';
$string['wirisformulaeditor'] = "�diteur d'�quations WIRIS";
$string['wiristitletext'] = "Double clic pour �diter";