<?php
require_once($CFG->dirroot . '/filter/wiris/wrs_config.php');

$items = array();
$formula = $CFG->wirisformulaeditorenabled;
$cas = $CFG->wiriscasenabled;

if (!$formula && !$cas) $output = 'WIRIS editor and WIRIS cas are not installed';
else if (!$formula) $output = 'WIRIS editor is not installed';
else if (!$cas) $output = 'WIRIS cas is not installed';
else $output = '';

$items[] = new admin_setting_heading('filter_wirisheading', 'WIRIS Filter Settings', $output);

if ($formula) $items[] = new admin_setting_configcheckbox('filter_wiris_editor_enable', 'WIRIS editor', '', '1');

if ($cas) $items[] = new admin_setting_configcheckbox('filter_wiris_cas_enable', 'WIRIS cas', '', '1');

foreach ($items as $item) {
    $settings->add($item);
}