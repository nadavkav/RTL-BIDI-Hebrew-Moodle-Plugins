<?php 
$string['apply'] = 'Aplicar';
$string['cancel'] = 'Cancel�lar';
$string['executeonload'] = 'Calcular al carregar';
$string['elementarymode'] = 'Mode prim�ria';
$string['focusonload'] = 'Activar al carregar';
$string['height'] = 'Altura';
$string['language'] = 'Idioma';
$string['ok'] = 'Acceptar';
$string['remove'] = 'Eliminar';
$string['showtoolbar'] = "Barra d'eines";
$string['width'] = 'Amplada';
$string['wirisformulaeditor'] = 'Editor de f�rmules WIRIS';
$string['wiristitletext'] = "Doble clic per editar";