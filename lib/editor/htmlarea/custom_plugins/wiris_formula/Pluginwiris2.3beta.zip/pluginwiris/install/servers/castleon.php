﻿<?php
$serverName = "ESPAÑA - Castilla y León";
$codebase = "http://www.educa.jcyl.es/wiris/wiris-codebase/";
$archive = "wrs_castleon_es.jar";
$class = "WirisApplet_castleon_es";
$lang = "es";