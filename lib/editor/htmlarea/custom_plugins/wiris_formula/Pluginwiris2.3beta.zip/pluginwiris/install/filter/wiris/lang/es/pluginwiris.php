<?php 
$string['apply'] = 'Aplicar';
$string['cancel'] = 'Cancelar';
$string['executeonload'] = 'Calcular al cargar';
$string['elementarymode'] = 'Modo elementario';
$string['focusonload'] = 'Activar al cargar';
$string['height'] = 'Altura';
$string['language'] = 'Idioma';
$string['ok'] = 'Aceptar';
$string['remove'] = 'Quitar';
$string['showtoolbar'] = 'Barra de herramientas';
$string['width'] = 'Anchura';
$string['wirisformulaeditor'] = 'Editor de f�rmulas WIRIS';
$string['wiristitletext'] = "Doble clic para editar";