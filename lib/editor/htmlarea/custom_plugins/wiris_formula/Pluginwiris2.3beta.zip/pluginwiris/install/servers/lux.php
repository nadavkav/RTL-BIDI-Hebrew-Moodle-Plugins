﻿<?php
$serverName = "LUXEMBURG";
$codebase = "http://wiristest.gates.myschool.lu/wiris/wiris-codebase/";
$archive = "wrs_lux_fr.jar";
$class = "WirisApplet_lux_fr";
$lang = "fr";