﻿<?php
$serverName = " DEMO";
$codebase = "http://www.wiris.net/demo/wiris/wiris-codebase";
$archive = "wrs_net_en.jar";
$class = "WirisApplet_net_en";
$lang = "en,es,fr,it,nl,et,ca,eu";