﻿<?php
$serverName="ITALIA - Ansas";
$codebase = "http://www.indire.it/wiris/wiris-codebase/";
$archive = "wrs_italy_it.jar";
$class = "WirisApplet_italy_it";
$lang = "it";