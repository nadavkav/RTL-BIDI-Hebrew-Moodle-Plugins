﻿<?php
$serverName = "ESPAÑA - Universidad - UPC";
$codebase = "http://wiris.upc.es/Wiris";
$archive = "wrs_ca_upc.jar";
$class = "WirisApplet";
$lang = "ca";