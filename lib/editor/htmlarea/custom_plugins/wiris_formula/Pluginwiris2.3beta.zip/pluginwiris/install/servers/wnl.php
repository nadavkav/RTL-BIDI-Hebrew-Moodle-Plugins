﻿<?php
$serverName = "BELGIUM - wirisonline.net";
$codebase = "http://users.wirisonline.net/applet/";
$archive = "wrs_wnl_nl.jar";
$class = "WirisApplet_wnl_nl";
$lang = "nl";