﻿<?php
$serverName="ESPAÑA - Andalucía";
$codebase = "http://www.juntadeandalucia.es/averroes/wiris/wiris-codebase/";
$archive = "wrs_andalucia_es.jar";
$class = "WirisApplet_andalucia_es";
$lang = "es";