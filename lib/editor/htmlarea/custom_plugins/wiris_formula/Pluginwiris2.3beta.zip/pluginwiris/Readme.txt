You can find the installation documentation at /pluginwiris/doc/index.html

Copy this files and directory into the moodle root directory