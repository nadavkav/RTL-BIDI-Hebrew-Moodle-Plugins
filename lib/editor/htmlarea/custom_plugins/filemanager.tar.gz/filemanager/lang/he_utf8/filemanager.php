<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 12:04 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'מנהל הקבצים האישי(משבצת)';

?>