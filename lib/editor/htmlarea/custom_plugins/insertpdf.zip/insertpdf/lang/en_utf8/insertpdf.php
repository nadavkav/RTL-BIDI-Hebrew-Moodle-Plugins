<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Embed PDF Document';
$string['title'] = 'Embed PDF Document';
$string['notpdf'] = 'The selected file is not a PDF Document. please choose another file';
?>