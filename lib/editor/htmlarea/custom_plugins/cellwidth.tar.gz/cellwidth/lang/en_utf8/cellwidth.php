<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/29/11 Time: 12:57 PM
 *
 * Description:
 *
 */
 
$string['mustentercellwidth'] = 'You must enter Column width, to continue';
$string['cellwidth'] = 'Please enter Column width';
$string['title'] = 'Table column width update';
$string['set'] ='Update';
$string['choosewidth'] ='Enter new Column width (can be in percent)';
$string['cancel'] ='Cancel';

?>