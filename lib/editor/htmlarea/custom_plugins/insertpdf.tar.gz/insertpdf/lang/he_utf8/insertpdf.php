<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'שיבוץ מסמך PDF';
$string['title'] = 'שיבוץ מסמך PDF';
$string['notpdf'] = 'הקובץ אשר נבחר אינו קובץ PDF. אנא בחרו קובץ אחר';
?>