<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/29/11 Time: 12:57 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'קביעת רוחב תמונה כ 100 אחוז';
$string['mustentercellwidth'] = 'יש להזין רוחב עמודה';
$string['cellwidth'] = 'יש להזין רוחב עמודה';
$string['title'] = 'עדכון רוחב עמודה בטבלה';
$string['set'] ='עדכון רוחב עמודה';
$string['choosewidth'] ='הזינו רוחב עמודה חדש (אפשר באחוזים)';
$string['cancel'] ='ביטול';

?>