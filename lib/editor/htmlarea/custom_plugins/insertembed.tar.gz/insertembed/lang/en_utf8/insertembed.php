<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['title'] = 'Insert EMBED into content';
$string['ok'] = 'I am finished';
$string['cancel'] = 'Cancel';
$string['chooseembedsite'] = 'Choose a website or an internet Service that support EMBED sharing<br/>Find the media you were lokking for<br/>Click the EMBED code and drag it or copy it to the box on the left.';

?>