<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['title'] = 'הכנסת EMBED לתוכן קיים';
$string['ok'] = 'סיימתי, אפשר להמשיך';
$string['cancel'] = 'ביטול';
$string['chooseembedsite'] = 'בחרו אתר או שרות אינטרנט אשר מאפשר להעתיק קוד EMBED <br/> בחרו בו, חפשו את התוכן בו אתם מעוניינים ומצאו את סמל ה EMBED הרצוי.<br/> כעת, גררו או העתיקו אותו למשבצת הריקה בצד שמאל';

?>