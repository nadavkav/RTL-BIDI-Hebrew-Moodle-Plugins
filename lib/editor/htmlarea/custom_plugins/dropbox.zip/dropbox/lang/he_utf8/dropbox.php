<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 9:50 AM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'קישור לקבצים הציבוריים שלי מ Dropbox';
$string['whatisuseremail'] = 'שם משתמש (דואר אלקטרוני)';
$string['whatisuserpassword'] = 'סיסמה';
$string['login'] = 'התחברו';
$string['logoff'] = 'Dropbox :התנתקו מ';
$string['add'] = 'הוספת הקישורים המסומנים לעורך';

?>