<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 9:48 AM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'My Public Dropbox files';
$string['whatisuseremail'] = 'Username (email)';
$string['whatisuserpassword'] = 'Password';
$string['login'] = 'Login';
$string['logoff'] = 'Logoff Dropbox';
$string['add'] = 'Add links to the Editor';

?>