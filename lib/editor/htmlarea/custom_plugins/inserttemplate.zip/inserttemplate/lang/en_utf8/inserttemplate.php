<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/29/11 Time: 12:57 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Template Bank';
$string['title'] = 'Template Bank';
$string['set'] ='Update';
$string['choosetemplate'] ='Choose Template...';
$string['cancel'] ='Cancel';

?>