<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/29/11 Time: 12:57 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'תבניות עיצוב';
$string['title'] = 'מאגר תבניות עיצוב';
$string['set'] ='שיבוץ תבנית זו';
$string['choosetemplate'] ='בחרו תבנית...';
$string['cancel'] ='ביטול';

?>