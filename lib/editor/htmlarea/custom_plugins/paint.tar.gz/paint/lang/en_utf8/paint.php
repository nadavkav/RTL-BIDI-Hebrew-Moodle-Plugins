<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 12:58 PM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'Paint';

?>