<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 11:19 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'DragMath';

?>