<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Draw vector images (SVG)';
$string['title'] = 'Draw (vectors) Diagrams, Objects and Sketches';
$string['ok'] = 'I am finished';
$string['cancel'] = 'Cancel';

?>