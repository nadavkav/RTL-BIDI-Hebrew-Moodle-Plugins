<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 10/6/11
 *
 * Description:
 *  Internal Link to Course activities and resources
 */

$string['pluginname'] = 'Internal link to a Course Activity';
$string['title'] = 'Internal link to a Course Activity';
$string['settitle'] = 'You can update the selected text<br/>Or, enter some new text, instead.';
$string['chooseactivity'] = 'Choose an Activity or a Resource';
$string['choosetarget'] = 'Choose Display Target';
$string['cancel'] ='Cancel';
$string['set'] ='I am done';

?>