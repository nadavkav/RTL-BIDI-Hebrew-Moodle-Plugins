<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 10/6/11
 *
 * Description:
 *  Internal Link to Course activities and resources
 */

$string['pluginname'] = 'קישור לפעילות או משאב בקורס זה';
$string['title'] = 'קישור לפעילות או משאב בקורס זה';
$string['settitle'] = 'עדכנו את התאור הקיים<br/>או, הזינו תאור קצר';
$string['chooseactivity'] = 'בחרו בפעילות או משאב';
$string['choosetarget'] = 'בחרו יעד תצוגה';
$string['cancel'] ='ביטול';
$string['set'] ='סיום';

?>