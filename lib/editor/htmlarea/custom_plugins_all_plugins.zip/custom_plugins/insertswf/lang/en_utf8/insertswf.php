<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Insert Flash';
$string['title'] = 'Insert Flash';
$string['notswf'] = 'The selected file is not a Shockwave Flash file. please choose another file';
?>