<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 3/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Advanced editing, using TinyMCE editor';
$string['title'] = 'Advanced editing, using TinyMCE editor';
$string['ok'] = 'I am done, let\'s finish';
$string['cancel'] = 'Cancel';

?>