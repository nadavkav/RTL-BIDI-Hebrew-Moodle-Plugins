<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 9:41 AM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'Expand the Editor\'s text area ';

?>