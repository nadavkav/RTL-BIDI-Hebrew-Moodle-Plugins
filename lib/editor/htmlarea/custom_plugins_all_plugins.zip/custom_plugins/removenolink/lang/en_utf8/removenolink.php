<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 12:59 PM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'Remove NOLINK tag';

?>