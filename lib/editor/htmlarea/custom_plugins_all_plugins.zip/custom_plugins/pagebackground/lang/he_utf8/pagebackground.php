<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'תמונת רקע';
$string['title'] = 'תמונת רקע';
$string['notimage'] = 'הקובץ אשר נבחר אינו קובץ תמונה. אנא בחרו קובץ אחר';
?>