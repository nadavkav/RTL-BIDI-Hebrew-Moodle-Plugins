<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'שיבוץ תמונות בגרירה מהמחשב האישי';
$string['notimgae'] = 'הקובץ אשר נבחר אינו קובץ תמונה. אנא בחרו קובץ אחר';
$string['useimages'] = 'הוסיפו את התמונות לעורך';
$string['draganddrop'] = 'גררו תמונות מהמחשב האישי שלכם לכאן';

?>