<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 10:15 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'Drag and Drop Images from your computer';
$string['notimage'] = 'The selected file is not an Image file. please choose another file';
$string['useimages'] = 'Add Images';
$string['draganddrop'] = 'Drag and drop files to upload!';


?>