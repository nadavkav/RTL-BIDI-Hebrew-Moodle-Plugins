<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/13/11 Time: 11:09 PM
 *
 * Description:
 *
 */

$string['htmlareasettings'] = 'הגדרות תוספים לעורך המובנה';
$string['editor_customplugins'] = 'תוספים זמינים';
$string['editor_customplugins_info'] = 'בחרו את התוספים אשר יופיע בעורך המובנה של המערכת';
$string['editor_showtableoperations'] = 'תצוגת סרגל עריכת טבלאות';
$string['editor_showtableoperations_info'] = 'בחרו באפשרות זו כדי להציג את סרגל הכלים לעיבוד טבלאות בעורך המבנה';
$string['editor_templateglossary'] = 'מאגר תבניות';
$string['editor_templateglossary_info'] = 'בחרו מאגר תבניות בו תרצו להשתמש כבסיס לתצוגה ושיבוץ של תבניות עיצוב';

?>