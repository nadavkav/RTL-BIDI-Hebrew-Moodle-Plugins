<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/13/11 Time: 11:44 PM
 *
 * Description:
 *
 */
 

$string['htmlareasettings'] = 'HTMLAREA Custom Plugins';
$string['editor_customplugins'] = 'Available Plugins';
$string['editor_customplugins_info'] = 'Please select the plugins that will be available to users on the HTMLAREA editor toolbar';
$string['editor_showtableoperations'] = 'Enable Table Toolbar';
$string['editor_showtableoperations_info'] = 'Enable this option to display a Table Operations toolbar';
$string['editor_templateglossary'] = 'Template Bank';
$string['editor_templateglossary_info'] = 'Choose a Template Bank from a Glossary on the Site\'s frontpage';

?>