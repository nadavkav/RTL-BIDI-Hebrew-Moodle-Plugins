<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 11:43 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'צייר וקטורי - דיאגרמות, צורות ותרשימים';
$string['title'] = 'צייר וקטורי - דיאגרמות, צורות ותרשימים';
$string['ok'] = 'סיימתי, אפשר להמשיך';
$string['cancel'] = 'ביטול';

?>