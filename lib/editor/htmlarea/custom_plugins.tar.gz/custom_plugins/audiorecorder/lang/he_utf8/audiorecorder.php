<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 1/15/11 Time: 6:38 PM
 *
 * Description:
 *
 */

$string['pluginname'] = 'הקלטה קולית';
$string['saveedsuccessfully'] = '<h2>ההקלטה נשמרה בהצלחה.</h2> <br/><br/> אנא הקליקו על הכפתור \"סגירת חלון\" לסיום הפעולה';
$string['closewindow'] = 'סגירת חלון';
$string['clicktoplay'] = 'הקליקו להשמעה';

?>