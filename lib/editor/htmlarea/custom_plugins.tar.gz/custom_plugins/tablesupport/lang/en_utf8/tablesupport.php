<?php
/**
 * Created by Nadav Kavalerchik.
 * Contact info: nadavkav@gmail.com
 * Date: 2/19/11 Time: 1:00 PM
 *
 * Description:
 *
 */
 
$string['pluginname'] = 'Table Support';

?>