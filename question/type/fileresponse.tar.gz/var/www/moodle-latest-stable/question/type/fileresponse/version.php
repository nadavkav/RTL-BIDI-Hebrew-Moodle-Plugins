<?php

$plugin->version  = 2007071600;
$plugin->requires = 2007061600;

?>
