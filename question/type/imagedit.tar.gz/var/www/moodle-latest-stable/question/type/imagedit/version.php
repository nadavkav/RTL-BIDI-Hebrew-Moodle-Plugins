<?php

$plugin->version  = 2010070703;
$plugin->requires = 2007101520;

?>
