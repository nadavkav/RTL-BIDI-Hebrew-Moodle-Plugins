<?php

$plugin->version  = 2010101904;
$plugin->requires = 2007101520;

?>
