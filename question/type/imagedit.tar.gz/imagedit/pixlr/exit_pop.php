<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>Exit Pixlr</title>
	<script type="text/javascript">
		window.close();
	</script>
</head>
<body bgcolor="#000000">
</body>
</html>