<?php

$plugin->version  = 2007081400;
$plugin->requires = 2007080200;

?>
