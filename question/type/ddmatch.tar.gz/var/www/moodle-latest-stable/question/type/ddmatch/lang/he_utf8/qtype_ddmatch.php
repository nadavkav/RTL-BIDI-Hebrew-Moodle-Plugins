<?PHP // $Id$ 
      // qtype_ddmatch.php - created with Moodle 1.9.2 (Build: 20080716) (2007101520)
      // local modifications from http://www.tikshuv.org.il/moodle


$string['addingddmatch'] = 'הוספת שאלת התאמה (בגרירה)';
$string['ddmatch'] = 'התאמה (בגרירה)';
$string['draganswerhere'] = 'תשובה';
$string['editingddmatch'] = 'עריכת שאלת התאמה (בגרירה)';

?>
