<?PHP // $Id: qtype_ddmatch.php,v 1.1 2008/04/14 15:32:50 arborrow Exp $ 
      // qtype_ddmatch.php - created with Moodle 1.9 + (Build: 20080402) (2007101509)


$string['addingddmatch'] = 'Eine Drag-and-Drop Zuordnungsfrage hinzufügen';
$string['ddmatch'] = 'Drag-and-Drop-Zuordnung';
$string['draganswerhere'] = 'Ziehen Sie mit der Maus die Antwort an die richtige Stelle in diesem Bereich';
$string['editingddmatch'] = 'Drag-and-Drop Zuordnungsfrage bearbeiten';

?>
