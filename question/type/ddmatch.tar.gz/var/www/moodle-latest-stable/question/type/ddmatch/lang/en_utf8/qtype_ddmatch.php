<?php
/**
 * The language strings for the match question type.
 *    
 * @copyright &copy; 2007 Adriane Boyd
 * @author adrianeboyd@gmail.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package aab_order
 */

$string['addingddmatch'] = 'Adding Drag-and-Drop Matching Question';
$string['editingddmatch'] = 'Editing Drag-and-Drop Matching Question';
$string['ddmatch'] = 'Drag-and-Drop Matching';
$string['draganswerhere'] = 'Drag answer here';

?>
