<?PHP // $Id: qtype_order.php,v 1.1 2008/04/14 15:32:49 arborrow Exp $ 
      // qtype_order.php - created with Moodle 1.9 + (Build: 20080402) (2007101509)

$string['addingorder'] = 'Anordnungsfrage hinzufügen';
$string['addmoreqblanks'] = 'Weitere Werte hinzufügen';
$string['defaultresponse'] = 'Ich weiß nicht';
$string['editingorder'] = 'Anordnungsfrage bearbeiten';
$string['filloutthreeitems'] = 'Sie müssen mindestens drei Werte in der richtigen Reihenfolge eingeben. Leere Felder werden ignoriert.';
$string['horizontal'] = 'Werte nebeneinander anzeigen';
$string['itemno'] = 'Wert $a';
$string['order'] = 'Anordnungsfrage';

?>
