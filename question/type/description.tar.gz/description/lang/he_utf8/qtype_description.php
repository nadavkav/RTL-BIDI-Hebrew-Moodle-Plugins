<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 1/29/12
 * Description:
 *    Change me...
 */

$string['followme'] = 'עקוב אחריי';
$string['pin'] = 'מקובע לדף';
$string['stop'] = 'חזרה לשאלון';