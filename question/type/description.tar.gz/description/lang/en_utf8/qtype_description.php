<?php
/**
 * Created by Nadav Kavalerchik.
 * eMail: nadavkav@gmail.com
 * Date: 1/29/12
 * Description:
 *    Change me...
 */

$string['followme'] = 'Follow Me';
$string['pin'] = 'Pin';
$string['stop'] = 'Stop';