<?PHP // $Id: version.php,v 1.1 2006/08/25 21:35:43 tjhunt Exp $

$plugin->version  = 2008060502; // TODO.
$plugin->requires = 2006032200;
?>